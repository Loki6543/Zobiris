# Zobiris v0.6.2 Implementation Handoff

**Date:** 2026-09-05  
**Target:** v0.6.2 Historical Personality + Kraken USD Execution-Liquidity Certification  
**Status:** Specifications complete; implementation and verification remain.

## Start here

This folder is the complete written handoff needed to implement the remaining v0.6.2 work. The implementation agent should read the documents in this order:

1. `ZOBIRIS_2_1_FINAL_SPEC.md` — authoritative Strategy 2.1 doctrine and hard execution rules.
2. `KRAKEN_USD_EXECUTION_LIQUIDITY_SPEC_v0.6.2.md` — exact 500x/200x, spread, depth, impact, and sizing definitions.
3. `../superpowers/specs/2026-09-05-historical-personality-calibration-design.md` — approved historical-personality architecture.
4. `../superpowers/plans/2026-09-05-historical-personality-calibration.md` — TDD implementation plan.
5. `V0_6_2_API_UI_CONTRACT.md` — concrete API/data/UI contract.
6. `V0_6_2_ACCEPTANCE_TEST_MATRIX.md` — required verification matrix.
7. `DYDX_LIQUIDITY_CERTIFICATION_2026-09-05.md` — worked reference case for the turnover gate.
8. `V0_6_2_RESEARCH_FIXTURES_2026-09-05.md` — dated non-production research fixtures for regression/adversarial testing.

## Precedence

If documents conflict, use this precedence:

1. `ZOBIRIS_2_1_FINAL_SPEC.md`
2. `KRAKEN_USD_EXECUTION_LIQUIDITY_SPEC_v0.6.2.md`
3. approved historical-personality design spec
4. implementation plan
5. dated research fixtures

Dated research rankings are **never production constants**.

## What remains to implement

### A. Kraken historical personality subsystem

Implement the eight tasks in the existing historical-personality plan: immutable Kraken 1h history, pair lifecycle, synchronized BTC-relative features, stress episodes, historical Elastic Strength, personality integration, embargoed analogs, append-only outcomes, API/UI exposure, and adversarial verification.

### B. Execution-liquidity certification subsystem

The existing Strategy 2.1 final spec already requires size-adaptive Kraken execution evidence. v0.6.2 must make that requirement deterministic and inspectable:

- direct active Kraken USD pair only;
- 14 completed UTC-day turnover history;
- 14d median daily USD notional >= `500 * q`;
- nearest-rank 10th-percentile daily notional >= `200 * q`;
- active-minute coverage >= 90%;
- p95 core spread <= 25 bps;
- p95 entry impact <= 35 bps;
- p95 exit impact <= 50 bps;
- p10 bid and ask depth within 50 bps >= `10 * q`;
- p10 bid and ask depth within 100 bps >= `25 * q`;
- full intended position remains liquidatable through the stressed bid book at <=250 bps total impact.

This is an **execution/eligibility** subsystem, not a personality feature and not a new evidence root.

### C. Explicit sizing output

Expose separate capacities instead of one opaque liquidity score:

```text
Q_turnover
Q_depth50
Q_depth100
Q_entryImpact
Q_exitImpact
Q_stressedExit
Q_liquidity = minimum of all applicable capacities
```

Do not infer capacity from global CoinMarketCap volume or aggregate Kraken activity across other quote currencies.

## Important DYDX status

The dated DYDX reference case confirms the **turnover portion** of a $30 scout-size test:

- 14d median direct Kraken DYDX/USD notional: `$33,927.85`
- median multiple at $30: `1,130.9x`
- nearest-rank p10 (second-lowest day): `$10,020.58`
- weak-day multiple at $30: `334.0x`
- turnover-only maximum order: `$50.10`

However, the current dataset does **not** contain 14 days of historical minute-book snapshots. Therefore p95 spread, p10 depth, p95 impact, active-minute coverage, and stressed-exit tests are not retrospectively certified. The app must not convert the turnover pass into full `ACTIVE_ELIGIBLE` status.

## Hard boundaries

- Spot only.
- Leverage = 0%.
- No trading endpoint is added by this release.
- Personality remains `DESCRIPTIVE_ONLY`.
- Liquidity certification may fail eligibility, but personality may not override liquidity or authorize a line.
- CMC/external data may provide context; it may not impersonate Kraken execution-grade history.
- No probability-like historical-match percentage until walk-forward calibration proves it.

## Definition of done

v0.6.2 is complete only when the test matrix is satisfied, Strategy 2.1 regressions pass, the no-trading guard passes, and release verification records precisely which checks were run and their actual results.
