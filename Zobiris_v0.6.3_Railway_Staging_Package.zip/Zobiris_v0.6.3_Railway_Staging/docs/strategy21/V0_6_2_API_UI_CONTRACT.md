# v0.6.2 Data, API, and UI Contract

## Purpose

This contract turns the approved historical-personality design and the Strategy 2.1 execution-liquidity rules into explicit app-facing types. Names may be adapted to existing code conventions, but semantics and authority boundaries must remain intact.

## 1. Historical data domain

```ts
type DataAuthority =
  | "KRAKEN_EXECUTION_GRADE"
  | "EXTERNAL_CONTEXT_ONLY"
  | "UNAVAILABLE";

interface HistoricalBar {
  assetId: string;
  symbol: string;
  venue: "KRAKEN" | "CMC_CONTEXT";
  pair: string;
  intervalMinutes: 60;
  openTime: string;
  closeTime: string;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
  vwap?: number;
  tradeCount?: number;
  sourcePublishedAt?: string;
  retrievedAt: string;
  isClosed: boolean;
  isFinal: boolean;
  sourceConfidence: number;
  ingestionVersion: string;
  payloadHash: string;
  validationReasons: string[];
}

interface PairLifecycle {
  assetId: string;
  venue: "KRAKEN";
  pair: string;
  validFrom: string;
  validTo?: string;
}

interface HistoricalCoverage {
  assetId: string;
  venue: string;
  firstBarAt?: string;
  lastBarAt?: string;
  expectedBars: number;
  observedBars: number;
  coverage: number;
  largestGapHours: number;
  recentGapHours: number;
  contiguousTailHours: number;
  zeroVolumeBars: number;
  invalidBars: number;
  duplicateBars: number;
  status: "READY" | "PARTIAL" | "INSUFFICIENT";
}
```

## 2. Execution liquidity

Implement the complete interfaces from `KRAKEN_USD_EXECUTION_LIQUIDITY_SPEC_v0.6.2.md` and attach the certification to existing `EligibilityResult`.

Recommended extension:

```ts
interface EligibilityResult {
  assetId: string;
  asOf: string;
  status: "QUARANTINED" | "INELIGIBLE" | "WATCH_ONLY" | "ACTIVE_ELIGIBLE";
  plannedOrderUsd: number;
  intendedFinalPositionUsd: number;
  maximumOrderUsd: number;
  maximumPositionUsd: number;
  spreadP95Bps?: number;
  entryImpactP95Bps?: number;
  exitImpactP95Bps?: number;
  stressedExitImpactBps?: number;
  executionLiquidity?: ExecutionLiquidityCertification;
  failureReasons: string[];
}
```

`maximumOrderUsd` must incorporate `Q_liquidity`; a missing required liquidity capacity cannot be treated as infinity.

## 3. Historical personality

```ts
interface FeatureProvenance {
  feature: string;
  dataAuthority: DataAuthority;
  sourceSnapshotIds: string[];
  lookbackStart?: string;
  lookbackEnd?: string;
  coverage: number;
  configVersion: string;
  exclusions: string[];
}

interface HistoricalElasticStrength {
  score?: number;
  band: "HIGH" | "MODERATE" | "LOW" | "INSUFFICIENT";
  independentStressEpisodes: number;
  coverage: number;
  confidence: number;
  components: Record<string, number | null>;
  reasons: string[];
  contradictions: string[];
  exclusions: string[];
  productionAuthority: "DESCRIPTIVE_ONLY";
}

interface HistoricalAnalogSummary {
  band: "HIGH" | "MEDIUM" | "LOW" | "INSUFFICIENT";
  rawSimilarWindowCount: number;
  independentEpisodeCount: number;
  eligibleHistoricalWindows: number;
  eligibleIndependentEpisodes: number;
  coverage: number;
  medianDistance?: number;
  distanceIqr?: number;
  featureVersion: string;
  analogVersion: string;
  explanations: string[];
}
```

The analog band is retrieval quality, not probability.

## 4. Observation/outcome ledger

```ts
interface PersonalityObservation {
  observationId: string;
  assetId: string;
  asOf: string;
  dataCutoffAt: string;
  featureVersion: string;
  personalityModelVersion: string;
  sourceSnapshotIds: string[];
  primary: BehavioralPersonality;
  secondary: BehavioralPersonality[];
  elasticStrength: HistoricalElasticStrength;
  historicalMatch: HistoricalAnalogSummary;
  featureVector: Record<string, number | null>;
  marketState: string;
  productionAuthority: "DESCRIPTIVE_ONLY";
}

type OutcomeStatus = "PENDING" | "RESOLVED" | "UNRESOLVABLE";

interface PersonalityOutcome {
  observationId: string;
  horizon: "1D" | "7D" | "30D" | "90D";
  status: OutcomeStatus;
  returnPct?: number;
  btcRelativeReturnPct?: number;
  maxAdverseExcursionPct?: number;
  maxFavorableExcursionPct?: number;
  personalityPersisted?: boolean;
  resolvedAt?: string;
  reason?: string;
  sourceSnapshotIds: string[];
}
```

## 5. Asset Case API payload

Recommended structure:

```ts
interface AssetCasePayload {
  assetId: string;
  asOf: string;
  authority: {
    eligibility: EligibilityResult;
    personalityAuthority: "DESCRIPTIVE_ONLY";
  };
  dataQuality: {
    marketHistory: HistoricalCoverage;
    btcSynchronizedCoverage?: number;
    executionLiquidity?: ExecutionLiquidityCertification;
    warnings: string[];
  };
  personality?: {
    primary: BehavioralPersonality;
    secondary: BehavioralPersonality[];
    elastic: HistoricalElasticStrength;
    analogs: HistoricalAnalogSummary;
    calibratedProbability: null;
  };
  contradictions: string[];
  exclusions: string[];
}
```

## 6. UI ordering

Asset Case File must render in this order:

```text
1. Authority
2. Data Quality
3. Execution Liquidity
4. Personality
5. Elastic Strength
6. Historical Analogs
7. Contradictions / Exclusions
8. Research-only outcome diagnostics
```

A user must never have to open the personality section to discover that the Kraken execution gate failed.

## 7. Execution Liquidity UI

Show separately:

- exact Kraken pair;
- as-of timestamp;
- planned order `q` and intended final position `Q`;
- 14d median direct USD notional and multiple;
- weak-day p10 direct USD notional and multiple;
- active-minute coverage;
- current spread and historical p95 spread;
- p10 50-bps bid/ask depth;
- p10 100-bps bid/ask depth;
- p95 entry/exit impact;
- stressed-exit impact;
- each capacity and final `Q_liquidity`;
- PASS / FAIL / INSUFFICIENT reasons.

Do not collapse missing metrics into a positive green summary.

## 8. Personality UI

Show:

- source authority and history span;
- synchronized coverage;
- primary and up to two secondary personalities;
- Elastic Strength band/score when sufficient;
- independent BTC stress episode count;
- historical-match band;
- raw windows and independent analog episode counts;
- contradictions and missing features;
- explicit `DESCRIPTIVE ONLY — NOT A TRADE TRIGGER` label.

Never display a percent historical match unless a later calibrated model legitimately outputs a tested probability.

## 9. Failure semantics

- Missing Kraken pair -> liquidity `INSUFFICIENT`, eligibility fails closed according to final spec.
- Incomplete 14-day turnover history -> `INSUFFICIENT`.
- Missing historical book snapshots -> book metrics `INSUFFICIENT`; no full liquidity pass.
- CMC history available but Kraken absent -> context may render, execution authority remains unavailable.
- Personality history insufficient -> personality absent/`INSUFFICIENT`; no effect on execution.
- Collector outage -> preserve prior validated history and mark freshness/staleness explicitly.

## 10. No-trading boundary

No API route or client action in v0.6.2 submits an order. The app may display a hypothetical/order-plan eligibility result but cannot execute it.
