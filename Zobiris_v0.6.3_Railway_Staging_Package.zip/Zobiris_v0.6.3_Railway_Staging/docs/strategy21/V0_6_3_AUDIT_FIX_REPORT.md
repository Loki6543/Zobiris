# ZOBIRIS v0.6.3 Audit Fix Report

**Date:** 2026-09-06  
**Input:** multi-agent v0.6.2 audit synthesis and external DYDX recomputation fixture  
**Release intent:** fix verified defects, harden fail-closed boundaries, and label unresolved subsystems truthfully.

## Executive status

| Audit item | v0.6.2 finding | v0.6.3 result |
|---|---|---|
| p10 turnover quantile | FAILED | **FIXED + VERIFIED** |
| Five-factor/scoring governance | FAILED / ambiguous | **FIXED governance boundary + VERIFIED Strategy21 tests** |
| Legacy score influences execution/sizing | authority leak | **REMOVED** |
| SuperTrend/Bollinger/ATR | UNVERIFIED | **Explicitly NOT_IMPLEMENTED / no authority** |
| DYDX L2 certification | INSUFFICIENT | **Still PENDING; turnover-only label enforced in docs** |
| Decision-gate precedence | disputed | **SOURCE-VERIFIED + regression tests** |
| Anonymous/public mutations | FAILED / security risk | **SOURCE HARDENED; deployed instance still requires redeploy + curl verification** |
| Current maneuver capital | stale $1,200 | **UPDATED to $1,500** |
| External bundle reproducibility | incomplete | **v0.6.3 verification bundle includes package/tsconfig/source/tests/fixtures** |

## 1. Liquidity quantile fix

### Root cause

`src/strategy21/engine/liquidity.ts` used a linear-interpolation quantile. The authoritative execution-liquidity convention is nearest-rank.

For 14 values:

```text
p10 rank = ceil(0.10 * 14) = 2
```

Therefore p10 is the second-lowest observation.

### Fix

- `quantile(values,p)` now uses nearest-rank.
- `median(values)` is separate and retains the arithmetic median convention.
- The shared p10/p95 call sites now use the same declared percentile convention.

### Golden DYDX result

```text
median14 = 33,927.8458786268 USD
p10 = 10,020.581623472979 USD
Q = 30 USD
median multiple = 1,130.9281959542268x
weak-day multiple = 334.0193874490993x
turnover max order = 50.1029081173649 USD
```

The old interpolation produced about `$56.9954` of turnover capacity; v0.6.3 reproduces the spec value of about `$50.10`.

## 2. Scoring governance fix

### Root cause

The repository contained multiple quantities that could be mistaken for one authoritative score. More seriously, the legacy 30/30/20/20 `researchScore` leaked into two executable paths:

- fallback expected gross return;
- requested position target sizing.

### Fix

Production ranking authority is now explicitly:

```text
OPPORTUNITY_HEURISTIC_V1
H = 100 * (0.25F + 0.20X + 0.25G + 0.15D + 0.15R)
```

API metadata:

```text
researchAuthority = DESCRIPTIVE_ONLY
rankingAuthority = OPPORTUNITY_HEURISTIC_V1
positionSizingAuthority = RISK_CAPS_ONLY
```

Removed:

- `researchScore * 20` expected-return fallback;
- legacy research-score-based requested-target sizing.

If expected gross return evidence is absent after execution history is otherwise complete, liquidity evaluation now fails closed to `WATCH_ONLY` with `expected gross return evidence incomplete`.

The manual five-factor 0–20 research tournament remains an analyst workflow only and is not represented as the runtime score.

## 3. Mutation-route hardening

### Root cause

`isAuthenticated()` previously honored `allowAnonymousRefresh`, so the refresh-specific development exception could unintentionally satisfy authentication checks on unrelated mutating routes. The anonymous option also lacked a production-environment prohibition.

### Fix

- `isAuthenticated()` now requires a bearer token and never considers anonymous refresh.
- `isRefreshAuthorized()` contains the only anonymous-refresh exception.
- `ZOBIRIS_ALLOW_ANONYMOUS_REFRESH=1` is ignored in `NODE_ENV=production`.
- `server.ts` has a centralized guard over API `POST`, `PUT`, `PATCH`, and `DELETE` requests.
- Only `POST /api/refresh` can use `isRefreshAuthorized()`; all other mutations require general bearer auth.

### Verification limitation

The actual security primitives were transpiled from `src/server/security.ts` and passed 3/3 dependency-free `node:test` checks. The full Vitest/HTTP integration suite could not be restored because npm registry requests failed with `EAI_AGAIN` in this environment.

This source package does **not** prove the already-public deployment has been patched. Rebuild/redeploy it, then verify anonymous mutation requests return 401/403.

## 4. Indicator truthfulness

No Average True Range, SuperTrend, or Bollinger Band implementation exists in this source tree. v0.6.3 does not invent one merely to turn an audit status green.

Status remains:

```text
SuperTrend: NOT_IMPLEMENTED / UNVERIFIED
Bollinger Bands: NOT_IMPLEMENTED / UNVERIFIED
ATR: NOT_IMPLEMENTED / UNVERIFIED
Production authority: NONE
```

A source scan is recorded in `docs/strategy21/verification/indicator_source_search.txt`.

## 5. DYDX L2 status

DYDX remains **turnover-certified only**. The following are still pending sufficient historical Kraken minute/L2 evidence:

- active-minute coverage;
- spread p95;
- entry/exit impact p95;
- p10 bid/ask depth at 50 and 100 bps;
- stressed full-position exit.

No full execution-certification claim is made.

## 6. Decision-gate precedence

The source already failed closed on execution eligibility and opportunity before line-specific conditions. v0.6.3 adds explicit regression tests for both cases:

- eligibility inactive + opportunity positive -> unauthorized;
- eligibility active + opportunity non-positive -> unauthorized.

This resolves the audit disagreement with executable evidence instead of assertion.

## 7. Capital base update

Default maneuver capital is now `$1,500`.

Current ceiling calculations:

```text
UNCERTAIN                  15% = $225
DELEVERAGED_ACCUMULATION   55% = $825
BROAD_EXPANSION            85% = $1,275
LEVERAGED_EXPANSION        45% = $675
EUPHORIA                   10% = $150
DETERIORATION              10% = $150
CAPITULATION               35% = $525
SYSTEMIC_BREAK              0% = $0
```

Other caps on the `$1,500` maneuver base:

```text
PROBE max           2.5% = $37.50
non-meme max         12% = $180
one meme              3% = $45
all memes              5% = $75
cluster               25% = $375
```

The `$37.50` probe value is a ceiling, not a requirement; a `$30` probe remains valid.

The existing `$1,800` future strategic-reserve target and `$3,000` eventual portfolio target are preserved as separate policy values. The final spec now states that the eventual target is an independent ceiling rather than an instruction to add `$1,500 + $1,800` and deploy `$3,300`.

## 8. Verification actually executed

Strategy 2.1 compile/test command:

```bash
tsc -p tsconfig.strategy21.json
node --test .strategy21-dist/tests/*.test.js
```

Result:

```text
71 tests
71 pass
0 fail
```

Includes:

- LIQ-05 nearest-rank p10;
- nearest-rank p95;
- arithmetic median;
- exact DYDX turnover fixture;
- missing expected-return fail-closed behavior;
- scoring authority metadata;
- $1,500 capital model;
- $825 DELEVERAGED_ACCUMULATION ceiling;
- $37.50 probe ceiling;
- eligibility/opportunity execution-gate regression tests.

Security primitive result:

```text
3 tests
3 pass
0 fail
```

Full npm/Vitest/UI integration status is documented in `verification/npm_environment_note.txt` rather than falsely reported as passing.

## Remaining work before calling all audited subsystems VERIFIED

1. Redeploy the hardened server and anonymously curl every mutation endpoint.
2. Restore dependencies in a network-enabled environment and run full `npm test`, typecheck, UI build and HTTP integration tests.
3. Begin/complete historical Kraken L2 collection and certify the pending DYDX gates.
4. Implement SuperTrend/Bollinger/ATR only if they are intentionally adopted into the canonical spec; otherwise keep them out of production claims.
