# v0.6.3 local baseline verification — 2026-09-06

## Status

Local automated gates pass. The release-grade baseline remains incomplete because hosted staging, deployed security probes, and rendered browser QA are outstanding. No historical L2 feature was added. This report supersedes the dependency-installation limitation in V0_6_3_MERGED_CHECKPOINT.md; that older report is retained as checkpoint history.

## Verified results

| Gate | Result | Evidence |
|---|---|---|
| Original-lockfile npm installation | 342 packages installed; exit 0 | Command witnessed: npm ci --ignore-scripts --no-audit --no-fund --fetch-retries=0 --fetch-timeout=15000 |
| Native SQLite | Real select 1 query and integration tests passed | Vitest log |
| Full application TypeScript | Pass | verification/baseline/typecheck.log |
| Full Vitest suite | 460 tests / 66 files pass | verification/baseline/vitest.log |
| Strategy 2.1 | 73 tests pass | verification/baseline/strategy21.log |
| Security primitives | 3 tests pass | verification/baseline/security-primitives.log |
| Static Strategy integration | 31 checks pass | verification/baseline/integration-static.log |
| No-trading static scan | Pass | verification/baseline/no-trading.log |
| Production UI build | Pass | verification/baseline/ui-build.log |
| Local production HTTP smoke | Health 200 JSON; six unauthorized mutations 401 | verification/baseline/production-local-smoke.log |
| Rendered browser QA | Blocked; not passed | verification/baseline/browser-qa.log |
| Container build / hosted staging / deployed probes | Not performed | STAGING.md contains the prepared recipe and remaining gates |

Runtime: Node v24.19.0, npm 11.9.0. The UI test uses jsdom and exercises Command Center → Asset Case File → Evidence Graph → controlled Challenger. It does not establish desktop/mobile visual correctness.

## Baseline repairs

- Excluded the isolated Strategy Node shim from full-app compilation; the Strategy-specific configuration retains it.
- Removed an unused personality helper and corrected a UI fixture to include the required nullable strategy21 field.
- Updated stale security tests: refresh-specific anonymous authorization does not grant general authentication. The unconfigured Challenger test now authenticates before expecting its 503 configuration response.
- Added real production HTTP regression tests for anonymous and incorrect-token rejection on all three mutation endpoints, including when anonymous refresh is explicitly enabled. A valid test token reaches the protected Challenger handler.
- Retained the merged fail-closed liquidity and return-evidence checks. No scoring, eligibility, sizing, or indicator feature changes were introduced in this baseline step.

Initial full Vitest results were 453 passing and two failing stale assertions; their output is retained in vitest-before.log. Final results include the additional authorization regression tests. The final full TypeScript check and UI build were repeated after code/test edits.

## Staging limitation

The available Sites hosting runtime uses Cloudflare Workers. This checkpoint uses Node HTTP and native better-sqlite3 with persistent disk. Uploading its static bundle would not test the merged server. No Node-compatible staging destination is connected for this task. Porting to Workers/D1 would be separate architecture work and is not presented as a baseline deployment.

The local security probe ran on a temporary production-mode server with an ephemeral test token and SQLite database. It never used trading credentials. The Dockerfile is a prepared recipe, not a tested container image.

## Required implementation order

1. Finish hosted staging and browser/security/persistence verification of this checkpoint.
2. Historical Kraken USD L2 certification with TDD: timestamped evidence, active-minute coverage, p95 spread, p10 bid/ask depth at 50 and 100 bps, $30 entry/exit impact, stressed full-exit impact, and 14-day turnover median/p10/capacity. Missing, incomplete, or snapshot-only evidence must remain WATCH_ONLY.
3. Deterministic decision trace and source/age/conflict provenance.
4. Persistent daily P/L ledger separating realized/unrealized, fees, Earn, capital flows, fills, cash, crypto value, basis, and pending commitments.
5. Consolidate authority: Tournament OPPORTUNITY_HEURISTIC; execution certification hard gate; Strategy 2.1 risk/sizing authority; Personality DESCRIPTIVE_ONLY. Prove tournament score changes cannot change eligibility or sizing.
6. Only then address ATR/Bollinger/SuperTrend with finalized bars, warm-up/reference tests, no forward fill, and no order authority before walk-forward validation.

These future tasks remain unimplemented in this baseline checkpoint. A green local suite is not historical execution certification.
