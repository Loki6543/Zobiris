# DYDX Kraken USD Liquidity Certification — 2026-09-05

**Asset:** dYdX / DYDX  
**Venue/pair:** Kraken `DYDX/USD` spot  
**Purpose:** Worked reference case for the v0.6.2 500x/200x turnover gate.  
**Important:** This document certifies **turnover only**, not the complete execution-liquidity gate.

## Source convention

Kraken public daily OHLC:

`https://api.kraken.com/0/public/OHLC?pair=DYDXUSD&interval=1440`

For each completed UTC day:

```text
dailyUsdNotional = Kraken daily VWAP * Kraken base volume
```

Current Sep. 5 UTC candle is excluded because it is incomplete.

## Latest 14 completed UTC days

| Date | Kraken VWAP | Kraken volume | Direct USD notional |
|---|---:|---:|---:|
| 2026-08-22 | $0.12398 | 799,175.30 DYDX | **$99,081.75** |
| 2026-08-23 | $0.12067 | 586,581.54 DYDX | **$70,782.79** |
| 2026-08-24 | $0.11852 | 248,844.75 DYDX | **$29,493.08** |
| 2026-08-25 | $0.11660 | 459,790.24 DYDX | **$53,611.54** |
| 2026-08-26 | $0.11933 | 186,621.16 DYDX | **$22,269.50** |
| 2026-08-27 | $0.11766 | 124,218.76 DYDX | **$14,615.58** |
| 2026-08-28 | $0.11281 | 329,332.81 DYDX | **$37,152.03** |
| 2026-08-29 | $0.10964 | 161,024.78 DYDX | **$17,654.76** |
| 2026-08-30 | $0.11182 | 321,338.97 DYDX | **$35,932.12** |
| 2026-08-31 | $0.10801 | 92,774.57 DYDX | **$10,020.58** |
| 2026-09-01 | $0.11026 | 358,063.58 DYDX | **$39,480.09** |
| 2026-09-02 | $0.11049 | 366,088.02 DYDX | **$40,449.07** |
| 2026-09-03 | $0.11413 | 64,848.81 DYDX | **$7,401.19** |
| 2026-09-04 | $0.11259 | 283,538.22 DYDX | **$31,923.57** |

## Deterministic calculations

Sorted daily notionals, ascending:

```text
$7,401.19, $10,020.58, $14,615.58, $17,654.76, $22,269.50, $29,493.08, $31,923.57, $35,932.12, $37,152.03, $39,480.09, $40,449.07, $53,611.54, $70,782.79, $99,081.75
```

14-day median:

```text
median14 = $33,927.85
```

Nearest-rank p10 with `n=14` is rank `ceil(0.10*14)=2`, therefore the second-lowest day:

```text
p10_14 = $10,020.58
```

For planned order `q = $30`:

```text
medianMultiple = 33,927.85 / 30 = 1,130.93x
weakDayMultiple = 10,020.58 / 30 = 334.02x
```

Requirements:

```text
medianMultiple >= 500x  -> PASS
weakDayMultiple >= 200x -> PASS
```

### Turnover result

**PASS** for a $30 planned order.

Turnover-derived maximum order:

```text
median capacity = 33,927.85 / 500 = $67.86
weak-day capacity = 10,020.58 / 200 = $50.10
Q_turnover = min(...) = $50.10
```

So the 14-day turnover history supports up to approximately **$50.10** under the 500x/200x rule.

## What is *not* certified yet

The complete Strategy 2.1 execution-liquidity gate also requires:

- >=90% active-minute coverage;
- p95 spread <=25 bps;
- p95 entry impact <=35 bps;
- p95 exit impact <=50 bps;
- p10 bid and ask depth within 50 bps >=10q;
- p10 bid and ask depth within 100 bps >=25q;
- stressed full-position exit <=250 bps.

The current research pull contains a current ticker snapshot but not a 14-day archive of minute-by-minute L2 order books. Therefore these historical book-derived conditions are **INSUFFICIENT**, not assumed to pass.

Current Kraken ticker snapshot observed around the research run:

```text
best ask = $0.11510
best bid = $0.11502
current spread ≈ 6.95 bps
```

That is a **current-spread pass only**; it is not the historical p95-spread certification.

## Zobiris rendering

Correct UI state:

```text
DYDX / Kraken USD
Turnover: PASS
  14d median: $33,928 (1,131x planned $30 order)
  weak-day p10: $10,021 (334x)
  turnover capacity: $50.10
Current spread: PASS (~6.95 bps)
Historical book certification: INSUFFICIENT
Overall execution liquidity: INSUFFICIENT
Reason: historical spread/depth/impact snapshots not yet collected
```

Do **not** render `ACTIVE_ELIGIBLE` until all hard liquidity fields required by the final spec are certified.

## Research-only entry context

The research discussion identified approximately `$0.110-$0.114` as a preferred DYDX ambush/retest corridor. This is a **dated research observation**, not an implementation constant and not a trade trigger.
