# Zobiris Behavioral Personality Engine — v1.0

## Purpose

The Behavioral Personality Engine turns recurring coin-specific behavior into a measured, falsifiable layer inside Zobiris.

It is **not** a permanent nickname and it is **not** a narrative score. A personality is a rolling behavioral regime inferred from repeated market behavior. It may change as ownership, liquidity, exchange access, token supply, narrative participation, and market structure change.

The layer sits after market/eligibility analysis and before human-facing doctrine/explainability:

```text
Izaya actor board
  -> market regime
  -> hard execution eligibility
  -> five production factors
  -> behavioral personality / Elastic Strength
  -> military doctrine + explainability
  -> capital authority / staged execution
```

Production rule: personality is currently **DESCRIPTIVE_ONLY**. It cannot increase confidence, bypass a hard gate, authorize an execution line, or increase position size until point-in-time historical calibration demonstrates incremental predictive value.

## Personality classes

- `BTC_SHADOW` — closely tracks BTC with exaggerated beta and weak independent resilience.
- `BREAKOUT_SPRINTER` — compression followed by unusually persistent range-break expansion.
- `MEAN_REVERTER` — breakouts frequently fade back toward the prior range.
- `DIP_EATER` — meaningful dips are repeatedly recovered quickly.
- `MOMENTUM_CASCADE` — follow-through, trend persistence and compression interact reflexively.
- `NARRATIVE_ROCKET` — price behavior is unusually dependent on sector/social attention.
- `LIQUIDITY_TRAP` — apparent strength is accompanied by false breakouts or deteriorating exit liquidity.
- `INDEPENDENT_LEADER` — maintains relative strength when BTC weakens and preserves support/spot participation.
- `SLOW_ACCUMULATOR` — persistent support, higher-lows behavior and measured recovery without vertical chase.
- `CAPITULATION_REBOUNDER` — strongest historical behavior occurs after severe reset/capitulation conditions.

A result contains one primary personality plus up to two secondary personalities.

## Elastic Strength

Elastic Strength formalizes the observed behavior: **the broader market pushes down, but the asset refuses to break.**

Inputs are normalized to `0..1`:

```text
ES =
  0.30 * relative_strength_during_BTC_down_windows
+ 0.25 * support_hold_rate_during_BTC_down_windows
+ 0.20 * spot_persistence_during_BTC_down_windows
+ 0.125 * (1 - funding_crowding)
+ 0.125 * (1 - open_interest_crowding)
```

The score is rendered `0..100`.

Bands:

- `HIGH` >= 75 with >=60% component coverage
- `MODERATE` >= 55
- `LOW` < 55
- `INSUFFICIENT` when coverage is too thin

Elastic Strength is intentionally not allowed to double-count the same underlying phenomenon as an independent confirmation. Its evidence roots are declared as:

- `PRICE_STRUCTURE`
- `SPOT_FLOW`
- `LEVERAGE`
- `NARRATIVE`
- `EXECUTION`

It may explain behavior and prioritize monitoring. It does not add a new independent root family.

## Historical personality match

Zobiris must not manufacture probability-like precision.

Current production output is categorical:

- `HIGH`
- `MEDIUM`
- `LOW`
- `INSUFFICIENT`

A historical-match label requires:

- at least 12 comparable historical setups; and
- at least 60% behavioral input coverage.

`calibratedProbability` remains `null` until walk-forward validation proves calibration. A future percentage such as `84%` must represent a tested probability, not a renamed heuristic score.

## Safety override: Liquidity Trap

If post-pump exit liquidity decay and false-breakout tendency jointly exceed the safety threshold, `LIQUIDITY_TRAP` may override an otherwise attractive momentum label.

This prevents Zobiris from describing a vertical move as desirable while ignoring the inability to exit safely.

## Current behavioral inputs

```ts
interface BehavioralProfileInput {
  btcCorrelation?: number;
  btcBeta?: number;
  relativeStrengthOnBtcDown?: number;
  supportHoldRateOnBtcDown?: number;
  spotPersistenceOnBtcDown?: number;
  fundingCrowding?: number;
  oiCrowding?: number;
  breakoutFollowThroughRate?: number;
  falseBreakoutRate?: number;
  dipRecoveryRate?: number;
  medianRecoveryHours?: number;
  compressionBreakoutRate?: number;
  trendPersistence?: number;
  narrativeSensitivity?: number;
  postPumpLiquidityDecay?: number;
  capitulationBounceRate?: number;
  similarSetupCount?: number;
}
```

## Integration contract

`evaluateZobirisDecision()` accepts an optional precomputed personality result and returns it as first-class explainability.

`integrateStrategy21()` accepts optional `personalityBySymbol` inputs and surfaces the result on each asset's Strategy 2.1 view.

The Asset Case File displays:

- primary/secondary personality;
- Elastic Strength score and band;
- historical-match band;
- behavioral coverage and confidence;
- number of comparable setups;
- warnings;
- explicit `descriptive only — no sizing authority` status.

## Required future data work before production authority

1. Store time-aligned asset/BTC return windows.
2. Add closed-candle Kraken or equivalent OHLC history for each eligible asset.
3. Store range-break and support-retention events point-in-time.
4. Store spot-volume persistence and leverage crowding without future leakage.
5. Build regime-conditioned analog sets.
6. Run purged walk-forward validation with embargo periods.
7. Measure whether personality adds predictive value beyond the existing five factors.
8. Promote personality to sizing authority only if calibration and incremental value are demonstrated.

Until those gates pass, personality is a **diagnostic and monitoring layer**, not an extra reason to buy.
