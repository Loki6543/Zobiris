# v0.6.2 Research Fixtures — 2026-09-05

**Purpose:** Dated regression/adversarial fixtures for development.  
**Not production rankings. Not trade signals. Do not hard-code prices or rankings into scoring logic.**

## Why these assets are useful test cases

| Asset | Development purpose |
|---|---|
| DYDX | Turnover varies materially by day; strong value-capture thesis; good test for 500x/200x vs current snapshot |
| BICO | High Kraken USD turnover but unusual price/turnover behavior; useful Liquidity Trap / distribution adversarial case |
| CHZ | Small USD market with real burn mechanism; useful borderline-liquidity and narrative/value-capture separation case |
| ORCA | Real DEX utility but smaller direct Kraken USD market; useful venue-local vs global-liquidity case |
| AIOZ | Small AI/DePIN asset with near-threshold Kraken turnover; useful partial-liquidity case |
| AEVO | Attractive buyback/burn economics with thin direct Kraken USD execution; proves fundamentals cannot override liquidity |
| ARKM | Good product with supply/unlock uncertainty; useful token-identity/tokenomics contradiction case |
| ACH | Real payments/regulatory trajectory but historically problematic spread snapshots; useful spread-fail case |
| RLC | Mature supply with borderline Kraken liquidity; useful size-adaptive PROBE case |
| SUSHI | Better direct Kraken USD activity and concrete buyback catalyst; useful liquid-small-cap comparison |
| ONDO | Existing high-quality incumbent; comparison baseline for RWA/fundamental trajectory |
| RENDER | Existing incumbent with real compute demand; comparison baseline for AI/DePIN candidates |
| KAS | Existing incumbent with strong direct Kraken liquidity; comparison baseline for smaller L1/infrastructure assets |
| TAO | AI incumbent with stronger venue liquidity but higher beta/dilution considerations |
| SUI | L1 incumbent with excellent liquidity and meaningful supply-overhang risk |

## Dated research observation

On the 2026-09-05 research pass, the new-coin screen did **not** justify replacing the established ONDO/RENDER/KAS/TAO/SUI group solely because a newcomer was smaller or newer. DYDX and SUSHI emerged as the strongest newcomers, but DYDX still lacked full historical-book certification and SUSHI's price had already moved sharply that day.

This observation exists only to create realistic fixtures and expected explainability. A future run may rank the assets differently.

## Required fixture principle

Every fixture must be generated from an `asOf` timestamp and source snapshot IDs. The test suite must be able to inject later data and verify that an earlier result does not change.
