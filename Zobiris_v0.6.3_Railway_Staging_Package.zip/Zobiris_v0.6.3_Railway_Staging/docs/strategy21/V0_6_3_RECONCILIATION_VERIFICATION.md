# Zobiris v0.6.3 Reconciliation Verification

**Date:** 2026-09-06

This verification applies to the reconstructed full source package described in `RECONCILIATION_NOTE.md`.

## Fresh checks

| Check | Result |
|---|---|
| Strategy 2.1 focused compile + node tests | **71/71 pass** |
| Security primitive tests | **3/3 pass** |
| Strategy integration/source assertions | **31/31 pass** |
| No executable trading-path static check | **PASS** |
| Node TS syntax check: `src/server/server.ts` | **PASS** |
| Node TS syntax check: `src/server/security.ts` | **PASS** |

Captured output is in `docs/strategy21/verification/`.

## Verified changes

- nearest-rank p10/p95 percentile convention;
- arithmetic median remains separate;
- DYDX weak-day p10/capacity regression;
- expected-return evidence fails closed rather than being synthesized from legacy research score;
- research score removed from requested-target sizing;
- explicit descriptive/ranking/sizing authority metadata;
- $1,500 current maneuver base and revised state/position caps;
- execution eligibility and opportunity remain hard AND gates;
- general auth no longer accepts anonymous-refresh policy;
- production ignores anonymous-refresh env opt-in;
- dedicated refresh authorization exists;
- centralized mutation guard exists in server source;
- no executable trading paths introduced.

## Still pending

- deployed-server anonymous mutation curl verification after redeploy;
- full dependency-restored npm/Vitest/UI/HTTP suite;
- historical Kraken L2 collection sufficient for active-minute, p95 spread, p10 depth, impact, and stressed-exit certification;
- ATR/SuperTrend/Bollinger implementation and verification.
