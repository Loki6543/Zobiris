# v0.6.2 Acceptance Test Matrix

This matrix supplements the historical-personality implementation plan. A release is not complete because the UI renders; each hard invariant below must have a deterministic test or documented manual verification.

| ID | Area | Required test | Expected result |
|---|---|---|---|
| HIST-01 | Bar finality | Still-forming Kraken candle supplied to collector | Excluded from eligible history |
| HIST-02 | Point in time | Bar after `asOf` injected | Earlier profile unchanged |
| HIST-03 | Pair lifecycle | Same symbol assigned to two lifecycle owners | Histories remain separate |
| HIST-04 | Gap handling | Missing hourly asset bar with complete BTC bar | Timestamp omitted; no forward fill |
| HIST-05 | Recent gap | Large trailing gap despite older coverage | Coverage downgraded / insufficient |
| HIST-06 | Source authority | CMC fallback has usable values | Marked `EXTERNAL_CONTEXT_ONLY`; no Kraken authority |
| FEAT-01 | Low beta | Flat/low-beta asset during BTC decline | Not falsely labeled independent leader |
| FEAT-02 | Denominator | Tiny BTC negative return | Downside capture insufficient/capped; no explosion |
| FEAT-03 | Stress clustering | Ten bars from one selloff | One independent stress episode |
| FEAT-04 | Recovery censoring | Drawdown never recovers inside window | Stored as censored/unrecovered |
| ANALOG-01 | Future leakage | Future setup inserted | Earlier analog set unchanged |
| ANALOG-02 | Overlap | 24 adjacent matching windows from one episode | Independent episode count remains 1 |
| ANALOG-03 | Missingness | Some vector dimensions missing | Retained weights renormalize; not zero-distance shortcut |
| OUT-01 | Maturity | 7D outcome checked at day 6 | `PENDING` |
| OUT-02 | Source consistency | Outcome Kraken price unavailable but other venue exists | No silent substitution; `UNRESOLVABLE`/pending grace |
| OUT-03 | Walk forward | Evaluation folds overlap embargo horizon | Test rejects configuration |
| AUTH-01 | Personality authority | Personality input changed from weak to strong | Executable rank/size/eligibility/Cowpens unchanged |
| LIQ-01 | Completed days | Current UTC daily candle present | Excluded from 14-day turnover window |
| LIQ-02 | Exact pair | Global/other-quote volume large, USD pair absent | Execution liquidity insufficient/fail closed |
| LIQ-03 | Median multiple | 14d median = `499*q` | Turnover FAIL |
| LIQ-04 | Median boundary | 14d median = `500*q` | Median leg PASS |
| LIQ-05 | Quantile convention | 14 values with known order | p10 equals second-lowest value |
| LIQ-06 | Weak-day multiple | p10 = `199*q` | Turnover FAIL |
| LIQ-07 | Weak-day boundary | p10 = `200*q` | Weak-day leg PASS |
| LIQ-08 | Missing day | Only 13 valid completed days | `INSUFFICIENT`, not FAIL/PASS |
| LIQ-09 | Current vs historical spread | Current spread 5 bps, p95 30 bps | Spread gate FAIL |
| LIQ-10 | Crossed book | best bid >= best ask | Snapshot invalid/excluded with reason |
| LIQ-11 | 50-bps depth | one side p10 depth = `9.9*q` | Depth gate FAIL |
| LIQ-12 | 100-bps depth | one side p10 depth = `24.9*q` | Depth gate FAIL |
| LIQ-13 | Entry impact | p95 buy impact = 35.1 bps | FAIL |
| LIQ-14 | Exit impact | p95 sell impact = 50.1 bps | FAIL |
| LIQ-15 | Stressed exit | stressed book cannot fully fill Q | FAIL closed |
| LIQ-16 | Capacity | turnover cap 50, depth cap 40, exit cap 35 | `Q_liquidity = 35` |
| LIQ-17 | DYDX fixture | dated 14 completed-day dataset, q=$30 | median~$33,927.85; p10~$10,020.58; turnover PASS |
| UI-01 | Data quality first | Personality HIGH but liquidity insufficient | UI leads with insufficient liquidity; no BUY implication |
| UI-02 | Analog language | HIGH analog match | No percent probability language |
| UI-03 | Missing book data | turnover passes but L2 history absent | Overall liquidity `INSUFFICIENT` |
| VERIFY-01 | Strategy suite | `npm run test:strategy21` | PASS |
| VERIFY-02 | Full tests | `npm test` | PASS or precise dependency limitation documented |
| VERIFY-03 | Typecheck | `npm run typecheck` | PASS or precise environment limitation documented |
| VERIFY-04 | Build | `npm run build` | PASS or precise environment limitation documented |
| VERIFY-05 | Integration | `node scripts/verify_strategy21_integration.mjs` | PASS |
| VERIFY-06 | No trading | `bash scripts/check_no_trading.sh` | PASS |

## DYDX deterministic fixture

Use the values in `DYDX_LIQUIDITY_CERTIFICATION_2026-09-05.md` as a regression fixture. The test should store the raw daily VWAP and volume, recompute notional inside the code under test, and verify:

```text
median14 ~= 33927.8458786268
nearestRankP10 ~= 10020.581623472981
medianMultiple(q=30) ~= 1130.9281959542268
weakDayMultiple(q=30) ~= 334.0193874490994
Q_turnover ~= 50.102908117364905
```

Use tolerances appropriate to decimal parsing; do not hard-code rounded display strings as calculation inputs.

## Required adversarial cases

Before release, explicitly exercise:

- Kraken OHLC revision after initial ingestion;
- pair migration or token-wrapper change;
- duplicate candle payload;
- invalid/non-finite price;
- isolated zero-volume day;
- recent history gap;
- one giant volume spike surrounded by weak days;
- deep book only on ask side but hollow bids;
- spoof-like top-level size that disappears in weak snapshots;
- current spread excellent while historical p95 fails;
- personality attractive while liquidity fails;
- liquidation capacity smaller than portfolio cap;
- future-bar injection into historical personality;
- outcome pricing missing at horizon maturity.

## Release claim rule

Verification documentation may say only what was actually run. Never transform an unrun or dependency-blocked check into a PASS.
