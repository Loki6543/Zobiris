# v0.6.3 merged checkpoint — 2026-09-06

Input archive SHA256: e142eda2b53f5da49f3323aa80f4d90a73506e8910ceddcc98597c5b0255d2bd.

This checkpoint adopts the supplied reconstructed v0.6.3 source. It preserves its nearest-rank quantiles, arithmetic median, $1,500 maneuver-capital policy, descriptive research authority, removal of legacy research-score sizing/return fallbacks, and mutation authentication changes.

## Additional fixes

The v0.6.2 recovery safeguard was absent. Required profile metrics now reject nonfinite and negative values with WATCH_ONLY and zero capacities. Fee and expected gross return evidence also reject NaN, infinity and negative values. The two new regression tests failed against the supplied source before implementation, then passed after the changes.

## Independent verification

- Strategy-only TypeScript compilation passed using the existing local TypeScript compiler.
- Before merge: 71 Strategy tests passed.
- After merge: 73 Strategy tests passed, zero failures.
- Security primitives: 3 passed, zero failures (native Node TypeScript support).
- Static Strategy integration checks: 31/31 passed.
- No-trading source scan passed.

Full dependency installation remains unavailable from earlier cancelled approval attempts. Full application typecheck, Vitest, HTTP integration, SQLite integration, UI build and browser QA have not been completed here. Strategy compilation excludes storage.ts and collector.ts. Static integration assertions are not HTTP integration tests.

No deployment was performed. ATR, SuperTrend, Bollinger indicators and full historical L2 certification remain unimplemented/unverified as described in the audit. The historical personality plan remains outstanding. This is a reconciled source checkpoint, not a fully verified release.
