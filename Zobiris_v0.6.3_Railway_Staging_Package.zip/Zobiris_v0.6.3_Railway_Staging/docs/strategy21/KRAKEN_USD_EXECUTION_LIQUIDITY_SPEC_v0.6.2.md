# Kraken USD Execution-Liquidity Specification — v0.6.2

**Status:** Authoritative implementation clarification of Section 7 in `ZOBIRIS_2_1_FINAL_SPEC.md`.  
**Scope:** Kraken spot execution eligibility only. This is separate from Behavioral Personality.

## 1. Purpose

Zobiris must answer a size-specific question:

> Is a proposed USD order `q`, and the intended final position `Q`, small enough relative to the actual **direct Kraken asset/USD spot market** that normal entry and stressed exit remain credible?

Global exchange volume is not sufficient. Aggregate Kraken volume across EUR/USDT/BTC pairs is not sufficient. A direct USD pair is required for execution-grade status.

## 2. Canonical pair and time rules

- Exact canonical asset identity must resolve to one active Kraken USD spot pair.
- Pair lifecycle must be versioned; migrations or symbol reuse may not merge histories.
- Turnover history uses UTC daily boundaries.
- Use the latest 14 **completed** UTC days at `asOf`.
- Never include the still-forming current day in quantiles.
- Historical book metrics use point-in-time snapshots available at the observation time; no future data.

## 3. Daily traded notional

For completed day `d`:

```text
N_d = sum(trade_price * trade_quantity)
```

If daily Kraken OHLC is used:

```text
N_d = daily_VWAP_d * daily_base_volume_d
```

Both definitions represent direct Kraken USD traded notional for the pair.

Reject or mark the day invalid if:

- the pair identity is unresolved;
- data are non-finite;
- the day is incomplete;
- source validation fails;
- the candle belongs to a different pair lifecycle interval.

Do not silently replace a missing Kraken day with CMC/global volume.

## 4. 500x / 200x turnover gate

For planned order `q`:

```text
median14 = median(N_d for latest 14 completed valid UTC days)
p10_14  = nearestRankQuantile(N_d, 0.10)
```

Nearest-rank definition:

```text
nearestRankQuantile(values, p):
  sorted = ascending(values)
  rank = ceil(p * len(sorted))
  return sorted[max(1, rank) - 1]
```

For 14 days, `p10_14` is the **second-lowest** day.

Hard requirements:

```text
median14 >= 500 * q
p10_14  >= 200 * q
```

Turnover capacity:

```text
Q_turnover = min(median14 / 500, p10_14 / 200)
```

### Status semantics

- `PASS`: both inequalities pass with 14 valid completed days.
- `FAIL`: either inequality fails with adequate data.
- `INSUFFICIENT`: fewer than 14 valid completed days or identity/source ambiguity.

There is no “average volume passes” shortcut.

## 5. Active-minute coverage

For the same lookback, define an active minute as a minute with qualifying market activity according to the existing collector's market-activity convention. Store the convention/version.

```text
activeMinuteCoverage = activeEligibleMinutes / expectedEligibleMinutes
```

Requirement:

```text
activeMinuteCoverage >= 0.90
```

Do not infer this from daily trade count alone.

## 6. Spread metric

At each eligible book snapshot:

```text
mid = (bestAsk + bestBid) / 2
spreadBps = (bestAsk - bestBid) / mid * 10_000
```

Use valid, non-crossed, non-empty snapshots only.

Requirement:

```text
p95(spreadBps) <= 25
```

The app must distinguish:

- `currentSpreadBps` — current snapshot only;
- `spreadP95Bps` — historical eligibility metric.

A good current spread does not prove the historical p95 gate.

## 7. Historical depth metrics

For each eligible book snapshot with mid `m`:

```text
bidDepth50Usd  = sum(price * qty for bids where price >= m * (1 - 0.0050))
askDepth50Usd  = sum(price * qty for asks where price <= m * (1 + 0.0050))
bidDepth100Usd = sum(price * qty for bids where price >= m * (1 - 0.0100))
askDepth100Usd = sum(price * qty for asks where price <= m * (1 + 0.0100))
```

For each side/radius, compute the nearest-rank 10th percentile over eligible snapshots.

Requirements for order `q`:

```text
p10(bidDepth50Usd)  >= 10 * q
p10(askDepth50Usd)  >= 10 * q
p10(bidDepth100Usd) >= 25 * q
p10(askDepth100Usd) >= 25 * q
```

Depth is explicitly **not** the 500x/200x metric.

Depth capacities:

```text
Q_depth50  = min(p10BidDepth50, p10AskDepth50) / 10
Q_depth100 = min(p10BidDepth100, p10AskDepth100) / 25
```

## 8. Entry and exit impact

Simulate a marketable order against each historical eligible book snapshot without allowing price improvement beyond displayed levels.

For a buy of `q`:

```text
entryImpactBps = (buyVWAP - mid) / mid * 10_000
```

For a sell of `q`:

```text
exitImpactBps = (mid - sellVWAP) / mid * 10_000
```

Requirements:

```text
p95(entryImpactBps) <= 35
p95(exitImpactBps)  <= 50
```

When solving maximum capacity, use monotonic search/bisection over `q` and store the largest size that still passes each threshold.

## 9. Stressed exit book

For intended final position `Q`, construct the stressed bid book per the final spec:

1. use a historical 10th-percentile/weak book representation;
2. remove bids inside the nearest 25 bps;
3. haircut remaining displayed bid sizes by 50%;
4. include taker fee and configured latency buffer;
5. simulate liquidation of the full intended position.

Requirement:

```text
stressedExitImpactBps <= 250
```

If the stressed book cannot fill the full position, fail closed.

## 10. Final liquidity capacity

Expose each capacity independently:

```ts
interface ExecutionLiquidityCapacity {
  qTurnoverUsd?: number;
  qDepth50Usd?: number;
  qDepth100Usd?: number;
  qEntryImpactUsd?: number;
  qExitImpactUsd?: number;
  qStressedExitUsd?: number;
  qLiquidityUsd?: number;
}
```

Then:

```text
Q_liquidity = min(all available required certified capacities)
```

If a required capacity is unavailable, status is `INSUFFICIENT`, not pass.

## 11. Required provenance

Every certification stores:

```ts
interface ExecutionLiquidityProvenance {
  assetId: string;
  venue: "KRAKEN";
  pair: string;
  quote: "USD";
  asOf: string;
  lookbackStart: string;
  lookbackEnd: string;
  validCompletedDays: number;
  validBookSnapshots: number;
  turnoverSource: "KRAKEN_OHLC" | "KRAKEN_TRADES";
  bookSource: "KRAKEN_L2";
  quantileMethod: "NEAREST_RANK";
  configVersion: string;
  sourceSnapshotIds: string[];
}
```

## 12. Eligibility output

```ts
type LiquidityGateStatus = "PASS" | "FAIL" | "INSUFFICIENT";

interface ExecutionLiquidityCertification {
  status: LiquidityGateStatus;
  plannedOrderUsd: number;
  intendedFinalPositionUsd: number;

  medianDailyNotional14d?: number;
  p10DailyNotional14d?: number;
  turnoverMedianMultiple?: number;
  turnoverWeakDayMultiple?: number;

  activeMinuteCoverage?: number;
  currentSpreadBps?: number;
  spreadP95Bps?: number;
  entryImpactP95Bps?: number;
  exitImpactP95Bps?: number;
  p10BidDepth50Usd?: number;
  p10AskDepth50Usd?: number;
  p10BidDepth100Usd?: number;
  p10AskDepth100Usd?: number;
  stressedExitImpactBps?: number;

  capacities: ExecutionLiquidityCapacity;
  failureReasons: string[];
  missingReasons: string[];
  provenance: ExecutionLiquidityProvenance;
}
```

## 13. UI language

Correct:

```text
TURNOVER PASS — median 1,131x / weak day 334x for $30
FULL LIQUIDITY CERTIFICATION — INSUFFICIENT: historical book snapshots unavailable
```

Incorrect:

```text
Liquidity passed because Kraken volume is $18k/day.
Liquidity is safe because today's spread is tight.
Global volume is $3m, therefore Kraken execution is liquid.
```

## 14. Authority boundary

This subsystem may reduce `maximumOrderUsd`, reduce `maximumPositionUsd`, or fail execution eligibility under the existing Strategy 2.1 rules.

It may **not**:

- create a buy signal;
- override market/asset state;
- increase five-factor scores;
- grant personality production authority;
- introduce leverage;
- submit an order.
