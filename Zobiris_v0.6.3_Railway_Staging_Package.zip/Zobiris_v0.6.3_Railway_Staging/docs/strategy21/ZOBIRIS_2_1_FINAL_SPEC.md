# ZOBIRIS 2.1 — Final Adaptive Market Strategy Engine

## Status

This specification consolidates:
- Zobiris 2.0,
- the first GPT-5.6 Sol red-team audit,
- the Sol continuation audit,
- final adjudication of what should ship now vs remain in shadow mode.

The Sol continuation again ended mid-implementation-contract, so the missing contract and implementation priorities below are completed here rather than falsely attributed to Sol.

---

# 1. Core philosophy

> Know the terrain. Model the players. Separate observation from story. Preserve optionality. Probe before committing. Measure executable liquidity. Attack asymmetry, not excitement. Change posture when evidence changes. Never confuse conviction with stubbornness.

A model that cannot say **what would make it change its mind** is not a strategy engine.

---

# 2. Capital model

Three capital pools must never be conflated:

```text
eventual_portfolio_target_usd = 3000
maneuver_capital_usd          = 1500   # currently available
future_strategic_reserve_usd  = 1800   # not currently available
```

Rules:
- Tactical orders may use only maneuver capital.
- Strategic reserve cannot fund current orders until actually funded and explicitly released.
- Cash is a valid output. Zobiris is never required to spend its entire authorization.
- Every order must pass market-state, asset-state, liquidity, concentration, and confidence limits.
- The $3,000 eventual target is an independent ceiling; do not add $1,500 + $1,800 and treat $3,300 as deployable.

---

# 3. Evidence architecture

Every evidence item is exactly one of:

```text
OBSERVATION
DERIVED_METRIC
CAUSAL_HYPOTHESIS
FORECAST
NARRATIVE_SIGNAL
```

Required metadata:

```ts
type EvidenceType =
  | "OBSERVATION"
  | "DERIVED_METRIC"
  | "CAUSAL_HYPOTHESIS"
  | "FORECAST"
  | "NARRATIVE_SIGNAL";

interface EvidenceItem {
  id: string;
  type: EvidenceType;
  claim: string;
  value?: number | string | Record<string, unknown>;
  confidence: number;           // 0..1
  observedAt: string;
  expiresAt: string;
  horizon: "MINUTES" | "HOURS" | "DAYS" | "WEEKS" | "MONTHS";
  sourceClass: string;
  dependencies: string[];
  contradictions: string[];
}
```

Rules:
1. Derived metrics inherit their source dependencies.
2. Correlated descendants do not count as independent confirmations.
3. Political incentives without observed action are capped at low confidence.
4. Causal hypotheses cannot directly authorize an order by themselves.
5. Forecasts require probability + horizon.
6. “Bullish” is a state label, not a forecast.

---

# 4. Dependency control

Every raw input belongs to one primary root family:

```text
EXECUTION
SPOT_FLOW
LEVERAGE
PRICE_STRUCTURE
FUNDAMENTALS
TOKEN_SUPPLY
NARRATIVE
MACRO
```

Examples:
- spread/depth/slippage -> EXECUTION
- spot CVD/volume residual -> SPOT_FLOW
- OI/funding/basis/liquidations -> LEVERAGE
- trend/relative strength/support -> PRICE_STRUCTURE
- users/fees/revenue/developers -> FUNDAMENTALS
- unlocks/dilution/emissions -> TOKEN_SUPPLY
- contributor breadth/social velocity -> NARRATIVE
- oil/Fed/yields/elections -> MACRO

A raw phenomenon may contribute to only one primary score. Reuse elsewhere is contextual only and cannot add confidence.

---

# 5. Internal market-state machine

Human-facing doctrine names remain in the UI, but the internal states are observable.

## States

```text
UNCERTAIN
DELEVERAGED_ACCUMULATION
BROAD_EXPANSION
LEVERAGED_EXPANSION
EUPHORIA
DETERIORATION
CAPITULATION
SYSTEMIC_BREAK
```

## UI aliases

| Internal state | Zobiris doctrine label |
|---|---|
| UNCERTAIN | Reconnaissance |
| DELEVERAGED_ACCUMULATION | Ambush / Elastic Defense |
| BROAD_EXPANSION | Offensive Rotation |
| LEVERAGED_EXPANSION | Elastic Offense |
| EUPHORIA | Strategic Retreat |
| DETERIORATION | Controlled Retreat |
| CAPITULATION | Valley Forge |
| SYSTEMIC_BREAK | Regime Break |

## Observable axes

Each axis normalized to `[-1, 1]`:

```text
S = BTC structural state
B = eligible-alt breadth / beta-neutral RS
P = spot participation
L = leverage/crowding
X = cross-market liquidity stress
E = sentiment/extension
M = macro financial-condition impulse
```

## Precedence

```text
SYSTEMIC_BREAK
> CAPITULATION
> DETERIORATION
> EUPHORIA
> LEVERAGED_EXPANSION
> BROAD_EXPANSION
> DELEVERAGED_ACCUMULATION
> UNCERTAIN
```

## Deployment caps on currently available $1,500

| State | Max deployable maneuver capital |
|---|---:|
| UNCERTAIN | 15% = $225 |
| DELEVERAGED_ACCUMULATION | 55% = $825 |
| BROAD_EXPANSION | 85% = $1,275 |
| LEVERAGED_EXPANSION | 45% = $675 |
| EUPHORIA | 10% = $150 |
| DETERIORATION | 10% = $150 |
| CAPITULATION | 35% = $525 |
| SYSTEMIC_BREAK | $0 new risk |

These are ceilings, not targets.

---

# 6. Asset-state machine

Market state and asset state are separate.

```text
INELIGIBLE
RESEARCH
PRE_IGNITION
PROBE
ACCUMULATE
CONFIRMED_TREND
EXTENDED
HARVEST
DETERIORATING
QUARANTINED
```

## PRE_IGNITION requirements

All must hold:

```text
fundamentalTrajectory >= 0
developerHealth >= minimum
executionEligibility == ACTIVE_ELIGIBLE
attentionPercentile < crowding threshold
observableCatalyst OR contributorBreadthImproving OR spotAccumulation
notStructurallyDeclining
notExtended
```

Low price and low attention alone never qualify.

---

# 7. Hard eligibility + execution liquidity

## Static fail-closed gates

- Exact token identity verified.
- Exact chain verified.
- Exact active Kraken USD pair verified.
- No unresolved migration/symbol collision.
- Critical Kraken order-book data fresh.
- No unresolved exploit/custody halt/manipulation fault.
- Tokenomics sufficiently complete.
- Book non-empty and non-crossed.
- Planned order has required execution-liquidity evidence.

## Size-adaptive execution rules

For planned dollar order `q`:

```text
14d median credible Kraken USD notional >= 500q
14d 10th-percentile credible daily notional >= 200q
active-minute coverage >= 90%
95th-percentile core spread <= 25 bps
entry impact 95th percentile <= 35 bps
exit impact 95th percentile <= 50 bps
10th-percentile bid AND ask depth within 50 bps >= 10q
10th-percentile bid AND ask depth within 100 bps >= 25q
```

Full intended position `Q` must remain liquidatable through a stressed bid book with total impact <= 250 bps.


## Metric convention amendment — 2026-09-05

The size-adaptive turnover rules above use the **exact direct Kraken asset/USD spot pair** and the latest **14 completed UTC daily intervals**. The still-forming current UTC day is excluded.

For each completed day `d`:

```text
N_d = sum(trade_price * trade_quantity)
```

When Kraken daily OHLC is the source, use the mathematically equivalent daily aggregate:

```text
N_d = Kraken_daily_VWAP_d * Kraken_daily_volume_d
```

The 14-day 10th percentile uses the deterministic **nearest-rank empirical quantile**:

```text
p10 = sorted_daily_notional[ceil(0.10 * n) - 1]
```

For `n = 14`, this is the **second-lowest** completed-day notional. Do not use an interpolated percentile because different libraries produce different results on small samples.

Turnover-derived order capacity is:

```text
Q_turnover = min(
  median_14d_daily_notional / 500,
  p10_14d_daily_notional / 200
)
```

`Q_turnover` is only one component of `Q_liquidity`. Final execution eligibility must still satisfy active-minute coverage, p95 spread, p95 entry/exit impact, historical p10 depth at 50/100 bps, and stressed-exit impact. A turnover pass alone must never be rendered as `ACTIVE_ELIGIBLE`.

## Stressed exit book

Construct by:
1. using historical 10th-percentile book;
2. removing bids inside nearest 25 bps;
3. haircutting remaining sizes by 50%;
4. including taker fee + latency buffer.

## Round-trip execution-cost rule

```text
roundTripCost <= min(
  150 bps,
  25% of estimated gross expected return
)
```

## Eligibility outcomes

```text
QUARANTINED
INELIGIBLE
WATCH_ONLY
ACTIVE_ELIGIBLE(q, Q)
```

Eligibility is size-specific.

---

# 8. Token-supply / unlock handling

Do not use FDV/market cap as a universal binary gate.

Define:

```text
unlockPressure30d =
  unlockUSD30d / max(medianCredibleDailySpotUSD, epsilon)
```

Unknown material unlock -> WATCH_ONLY.

Known unlock pressure:
- reduces Loss Resilience;
- reduces maximum permitted position.

Suggested position cap:

```text
Q_unlock_max = Q_max * exp(-min(3, unlockPressure30d))
```

---

# 9. Five orthogonal production factors

The old geometric Asymmetry Score is retired as production sizing authority.

## 9.1 Fundamental Trajectory — F
Measures protocol reality:
- user trajectory,
- fee/revenue trajectory,
- retention,
- developer breadth,
- token value capture.

## 9.2 Execution Quality — X
Measures ability to enter and exit:
- spread distribution,
- simulated impact,
- depth,
- venue dependence,
- continuity.

## 9.3 Flow / Setup — G
Compress all price/flow/trend evidence into one family:

```text
G =
  0.30 spotCVD
+ 0.20 spotVolumeResidual
+ 0.20 betaNeutralRS
+ 0.15 priceStructure
+ 0.15 leverageResilience
```

## 9.4 Discovery / Catalyst — D

```text
D =
  0.30 contributorBreadth
+ 0.20 attentionAcceleration
+ 0.25 catalystObservability
+ 0.15 sourceDiversity
+ 0.10 attentionHeadroom
- crowdingPenalty
```

## 9.5 Loss Resilience — R

```text
R = 1 - (
  0.25 dilutionRisk
+ 0.20 unlockRisk
+ 0.20 securityRisk
+ 0.15 holderConcentration
+ 0.10 regulatoryTail
+ 0.10 venueDependency
)
```

---

# 10. Meme model

Meme assets use the same lifecycle states but a separate evidence model.

Replace protocol Fundamental Trajectory with `DistributionIntegrity`.

Inputs:
- contract/ownership controls,
- holder concentration,
- market-maker dependence,
- venue health,
- chain health,
- holder-base persistence,
- social breadth,
- spot-flow quality,
- crowding,
- reflexive exit risk.

Rules:
- Meme assets can never receive CORE authority.
- One meme asset max: 3% of applicable capital base.
- All meme assets combined: 5% of applicable capital base.
- At $3,000 eventual portfolio: meme sleeve max = $150.
- At $1,500 maneuver base: meme sleeve max = $75 until the strategic sleeve is funded.

This means BONK/SHIB can remain research targets, but Zobiris must not silently treat their eventual-$3k sleeve as fully fundable from today's $1,500 tactical capital.

---

# 11. Probabilistic opportunity model — SHADOW MODE first

Long-term target:

Scenarios:

```text
CRASH
BEAR
BASE
BULL
SQUEEZE
```

For scenario returns `r_s`:

```text
mu_i = sum(p_s * r_s) - execution_cost
SE_i = posterior standard error
CVaR_i = expected loss in worst 5% tail
LCB_i = mu_i - 1.28*SE_i - 0.35*CVaR_i
NDV_i = LCB_i - correlation_penalty
```

Do not use production probabilistic authority until:
- point-in-time history exists,
- walk-forward calibration is demonstrated,
- reliability is acceptable.

Production now uses the five-factor heuristic plus confidence/coverage.

---

# 12. Position and concentration limits

Applicable capital base = capital actually funded and authorized.

| Constraint | Limit |
|---|---:|
| One PROBE position | 2.5% |
| One non-meme asset | 12% |
| One meme asset | 3% |
| All memes | 5% |
| One dependency cluster | 25% |
| Leverage | 0% |

Hard position cap:

```text
Q_hard = min(
  Q_portfolio,
  Q_liquidity,
  Q_unlock,
  Q_confidence,
  Q_mandate
)
```

Confidence:
- `<0.65` -> no order
- `0.65–0.75` -> PROBE only
- `>=0.75` -> later lines may be authorized

Clusters must include economic beta, not merely project labels:
- AI/compute,
- broad alt/L1,
- meme,
- Solana beta,
- RWA,
- liquidity-source dependence.

---

# 13. Three-line execution

For approved final target `Q*`:

```text
Line 1 = 20%  PROBE
Line 2 = 30%  ACCUMULATE
Line 3 = 50%  CONFIRMED_TREND
```

## Line 1 fires only if
- ACTIVE_ELIGIBLE for order + final position,
- market state permits new risk,
- asset state PRE_IGNITION or stronger,
- confidence >= 0.65,
- no critical contradiction.

## Line 2 fires only if
- non-price thesis confirmation,
- opportunity remains positive,
- liquidity has not deteriorated,
- token-supply risk has not worsened,
- asset state ACCUMULATE.

## Line 3 fires only if
- spot-supported relative strength,
- asset state CONFIRMED_TREND,
- covariance/cluster addition acceptable,
- market state permits scaling,
- confidence >= 0.75.

Lower price alone never authorizes another line.

---

# 14. Actor board

Actors include:
- BTC
- BlackRock / ETF complex
- Strategy
- Fed
- U.S. government / elections
- oil / Brent
- Iran / war risk
- USD / Treasury yields
- whales
- retail
- developers

## Actor schema

```ts
interface Actor {
  actorId: string;
  actorType:
    | "GOVERNMENT"
    | "CENTRAL_BANK"
    | "REGULATOR"
    | "EXCHANGE"
    | "ISSUER"
    | "FOUNDATION"
    | "MARKET_MAKER"
    | "WHALE"
    | "DEVELOPER_GROUP"
    | "SOCIAL_NETWORK"
    | "OTHER";
  jurisdiction?: string;
  observedActions: string[];
  inferredIncentives: string[];
  estimatedCapacity: number; // 0..1
  estimatedTimeHorizon: string;
  constraints: string[];
  affectedMarkets: string[];
  evidenceIds: string[];
  confidence: number;
  lastUpdatedAt: string;
  expiresAt: string;
}
```

Only observed action creates direct actor impulse:

```text
actorImpulse =
  actionMagnitude
* estimatedCapacity
* edgeReliability
* confidence
```

Inferred incentive without observed action:

```text
actorImpulse = 0
```

It may change monitoring priority, not exposure.

---

# 15. Sensor assets

A sensor is an early-warning input, never a direct order trigger.

Examples:
- BTC spot participation -> broad crypto risk
- eligible-alt breadth -> rotation
- BONK/DOGE -> meme appetite
- TAO/RENDER -> AI-cluster appetite
- ONDO -> RWA interest
- funding/OI reset -> deleveraging
- Kraken depth deterioration -> execution stress

A sensor may:
- increase monitoring frequency;
- prepare a conditional order;
- modestly update priors;
- request target-specific confirmation.

It may not:
- satisfy identity/liquidity gates;
- create PRE_IGNITION by itself;
- authorize an execution line;
- count as independent confirmation if dependency roots overlap.

---

# 16. Pre-trade controls

- Spot only.
- No borrowing / leverage.
- Default bounded limits or post-only orders.
- Market order only for explicit emergency liquidation.
- Max participation per active minute: 5% of credible Kraken traded notional.
- Revalidate immediately before submission:
  - spread,
  - depth,
  - eligibility,
  - market state,
  - asset state,
  - capital reservation.
- Cancel stale-book orders.
- Cancel if realized slippage exceeds approved estimate by >20 bps.
- Child orders cannot chase vertical price moves.
- Partial fills update capacity and capital atomically.

---

# 17. Portfolio optimizer — SHADOW MODE until enough data

Long-term target:

```text
maximize:
  sum(size_lot * NDV)
  - gamma * portfolio_variance
  - lambda * CVaR95
```

subject to:
- Q_hard limits,
- deployment authority,
- cluster cap,
- meme cap,
- liquidity capacity,
- cash >= 0,
- active eligibility,
- allowed asset state,
- allowed market state.

Cash has zero expected return and remains a valid result.

Until covariance and posterior-return models are robust, production allocation remains conservative rule-based sizing.

---

# 18. Calibration / point-in-time store

At every decision timestamp store:
- raw evidence,
- exact universe,
- listings/delistings,
- tokenomics known at that time,
- unlock information known at that time,
- publication times,
- revisions,
- market state,
- asset state,
- factor scores,
- evidence dependencies,
- proposed orders,
- rejected orders,
- reasons.

Forward outcomes:
- 1d / 7d / 30d / 90d return,
- max adverse excursion,
- max favorable excursion,
- realized slippage,
- state transition,
- thesis success/failure.

Validation:
- purged walk-forward,
- embargo periods,
- regime-cluster effective sample size,
- Brier/log loss for probability outputs,
- drawdown/CVaR/slippage for sizing outputs,
- shadow deployment before production promotion.

---

# 19. Adversarial requirements

Zobiris must pass at least these classes:

1. token symbol/contract collision
2. stale/crossed Kraken book
3. high volume but shallow exits
4. spoof-like displayed liquidity
5. asymmetric entry/exit depth
6. one flow impulse double-counted across metrics
7. bot-driven meme spike
8. political motive with no observed action
9. contradictory unlock data
10. cluster concentration hidden by project labels
11. regime threshold chatter + emergency integrity event
12. future-data leakage + concurrent capital reservation

---

# 20. Implementation contract

## MarketState

```ts
type MarketStateName =
  | "UNCERTAIN"
  | "DELEVERAGED_ACCUMULATION"
  | "BROAD_EXPANSION"
  | "LEVERAGED_EXPANSION"
  | "EUPHORIA"
  | "DETERIORATION"
  | "CAPITULATION"
  | "SYSTEMIC_BREAK";

interface MarketState {
  asOf: string;
  state: MarketStateName;
  confidence: number;
  axes: {
    btcStructure: number;
    breadth: number;
    spotParticipation: number;
    leverageCrowding: number;
    liquidityStress: number;
    extension: number;
    macroImpulse: number;
  };
  evidenceIds: string[];
  enteredAt: string;
  minimumDwellUntil: string;
  deploymentCapUsd: number;
  riskBudget: number;
}
```

## AssetState

```ts
type AssetStateName =
  | "INELIGIBLE"
  | "RESEARCH"
  | "PRE_IGNITION"
  | "PROBE"
  | "ACCUMULATE"
  | "CONFIRMED_TREND"
  | "EXTENDED"
  | "HARVEST"
  | "DETERIORATING"
  | "QUARANTINED";

interface AssetState {
  assetId: string;
  asOf: string;
  state: AssetStateName;
  confidence: number;
  reasonCodes: string[];
  evidenceIds: string[];
  allowedActions: string[];
}
```

## EligibilityResult

```ts
type EligibilityStatus =
  | "QUARANTINED"
  | "INELIGIBLE"
  | "WATCH_ONLY"
  | "ACTIVE_ELIGIBLE";

interface EligibilityResult {
  assetId: string;
  asOf: string;
  status: EligibilityStatus;
  plannedOrderUsd: number;
  intendedFinalPositionUsd: number;
  maximumOrderUsd: number;
  maximumPositionUsd: number;
  spreadP95Bps?: number;
  entryImpactP95Bps?: number;
  exitImpactP95Bps?: number;
  stressedExitImpactBps?: number;
  failureReasons: string[];
}
```

## OpportunityScore

```ts
interface OpportunityScore {
  assetId: string;
  asOf: string;
  modelVersion: string;
  fundamentalTrajectory?: number;
  executionQuality?: number;
  flowSetup?: number;
  discoveryCatalyst?: number;
  lossResilience?: number;
  coverage: number;
  confidence: number;

  // shadow outputs until calibrated
  expectedNetReturn?: number;
  probabilityPositive?: number;
  bearProbability?: number;
  crashProbability?: number;
  cvar95?: number;
  epistemicStandardError?: number;
  opportunityLCB?: number;
  nextDollarValue?: number;
}
```

## PositionAuthority

```ts
interface PositionAuthority {
  assetId: string;
  asOf: string;
  mandate: "TACTICAL" | "STRATEGIC";
  maxPositionUsd: number;
  maxNextOrderUsd: number;
  deploymentLine: 0 | 1 | 2 | 3;
  concentrationCluster: string[];
  reasons: string[];
  expiresAt: string;
}
```

## StateTransition

```ts
interface StateTransition {
  entityType: "MARKET" | "ASSET";
  entityId: string;
  fromState: string;
  toState: string;
  asOf: string;
  triggerEvidenceIds: string[];
  emergency: boolean;
  reason: string;
}
```

---

# 21. Core service functions

```ts
evaluateMarket(asOf): MarketState

evaluateEligibility(
  assetId,
  plannedOrderUsd,
  intendedFinalPositionUsd,
  asOf
): EligibilityResult

evaluateAsset(
  assetId,
  marketState,
  asOf
): AssetState

calculateOpportunity(
  assetId,
  marketState,
  assetState,
  asOf
): OpportunityScore

calculatePositionAuthority(
  assetId,
  portfolio,
  marketState,
  assetState,
  eligibility,
  opportunity,
  asOf
): PositionAuthority

planStagedExecution(
  assetId,
  positionAuthority,
  marketState,
  assetState,
  asOf
): ExecutionPlan

explainCall(assetId, asOf): ExplainabilityReport
```

---

# 22. Explainability contract

Every investable asset must answer:

```text
What state is the market in?
What state is this asset in?
What evidence supports the call?
Which evidence is contradictory?
What is observed vs inferred?
What is the maximum position allowed?
Why is that maximum allowed?
What would flip the call bullish?
What would flip the call bearish?
What would cancel pending orders?
```

No `BUY=true` without these fields.

---

# 23. Top 10 implementation priorities

## P0
1. Separate market state from asset state.
2. Build evidence dependency registry.
3. Add evidence typing + confidence + freshness.
4. Add exact Kraken identity + fail-closed integrity layer.
5. Build historical Kraken book-depth / slippage service.
6. Replace static volume gate with size-aware eligibility.

## P1
7. Implement five orthogonal production factors.
8. Add separate meme scoring model.
9. Add capital ledger + atomic tactical/strategic reservations.
10. Add timestamped point-in-time calibration store.

## Shadow roadmap
- probabilistic posterior engine,
- NDV,
- covariance optimizer,
- calibrated sensor likelihood ratios,
- learned actor-edge reliability.

---

# 24. Current live-use rule

Zobiris 2.1 must NOT hard-code the earlier candidate allocation:

```text
ONDO 200
KAS 170
NEAR 170
TAO 150
RENDER 145
HBAR 110
SUI 105
BONK 95
SHIB 55
```

That remains a research candidate allocation only.

At execution time the engine must:
1. refresh the market state,
2. refresh Kraken eligibility at each proposed size,
3. recompute asset state and factor evidence,
4. enforce current maneuver-capital authority,
5. regenerate the allocations.

The $1,800 strategic reserve remains untouched until funded and explicitly released.


---

# 25. Behavioral Personality extension

Zobiris includes a first-class **Behavioral Personality** layer for recurring asset-specific market behavior. The canonical design is in `BEHAVIORAL_PERSONALITY_ENGINE.md`.

Rules:
- personality is a rolling behavioral regime, not a permanent asset label;
- Elastic Strength measures BTC-down resilience, support retention, spot persistence and uncrowded leverage;
- `LIQUIDITY_TRAP` may override seductive momentum labels when exit quality deteriorates;
- historical match is categorical until sufficient point-in-time samples exist;
- `calibratedProbability` remains `null` until walk-forward calibration is demonstrated;
- personality reuses declared dependency roots and cannot count as a new independent confirmation;
- current production authority is `DESCRIPTIVE_ONLY`; it cannot bypass eligibility, authorize a line, increase confidence, or increase position size.
