# v0.6.2 Implementation Plan Addendum — Kraken USD Execution Liquidity

This addendum supplements `docs/superpowers/plans/2026-09-05-historical-personality-calibration.md`. It does not change the historical-personality authority boundary.

## Task 2A — Daily turnover certification

**Create:**
- `src/strategy21/liquidity/types.ts`
- `src/strategy21/liquidity/turnover.ts`
- `src/strategy21/tests/liquidityTurnover.test.ts`

**Modify:**
- `src/strategy21/providers/kraken.ts`
- `src/strategy21/storage.ts`

Implementation:

1. collect exact direct Kraken USD daily OHLC or aggregate trades;
2. exclude incomplete UTC day;
3. retain 14 completed valid days;
4. calculate `N_d = VWAP * volume`;
5. calculate median and nearest-rank p10;
6. calculate multiples and `Q_turnover`;
7. store source/provenance and reasons;
8. fail to `INSUFFICIENT` if fewer than 14 valid days.

TDD fixtures include the DYDX 2026-08-22 through 2026-09-04 dataset from the certification document.

## Task 2B — L2 snapshot collector

**Create:**
- `src/strategy21/liquidity/krakenBook.ts`
- `src/strategy21/liquidity/bookStorage.ts`
- `src/strategy21/tests/liquidityBookCollector.test.ts`

Store point-in-time L2 snapshots with:

```ts
interface KrakenBookSnapshot {
  assetId: string;
  pair: string;
  observedAt: string;
  retrievedAt: string;
  bestBid: number;
  bestAsk: number;
  bids: Array<[price:number, quantity:number]>;
  asks: Array<[price:number, quantity:number]>;
  payloadHash: string;
  isValid: boolean;
  validationReasons: string[];
}
```

Requirements:

- reject crossed/empty/non-finite books;
- preserve immutable raw snapshot provenance;
- collection interval/config version explicit;
- do not synthesize historical books from current depth.

## Task 2C — Spread, depth, impact, stressed-exit engine

**Create:**
- `src/strategy21/liquidity/metrics.ts`
- `src/strategy21/liquidity/capacity.ts`
- `src/strategy21/tests/liquidityMetrics.test.ts`

Calculate:

- active-minute coverage;
- current and historical p95 spread;
- p10 50/100-bps bid/ask depth;
- p95 entry/exit impact at proposed size;
- stressed-exit impact for intended final position;
- independent capacity values;
- `Q_liquidity = min(required capacities)`.

Use definitions in `KRAKEN_USD_EXECUTION_LIQUIDITY_SPEC_v0.6.2.md` exactly.

## Task 7A — Eligibility/API/UI wiring

**Modify:**
- existing eligibility/Strategy 2.1 integration module discovered in codebase;
- `src/runtime/refresh.ts`;
- server/API route module;
- `src/ui/api.ts`;
- Asset Case File component.

Rules:

- liquidity can cap/fail execution eligibility;
- missing required book history means `INSUFFICIENT`;
- current spread cannot substitute for p95 spread;
- global CMC volume cannot substitute for direct Kraken USD history;
- personality cannot override a liquidity failure;
- no order submission endpoint.

UI displays Authority/Data Quality/Execution Liquidity before personality.

## Task 8A — Release verification

Add acceptance matrix cases `LIQ-01` through `LIQ-17` and `UI-03` to automated/integration verification where practical.

Document the unavoidable bootstrap limitation: historical p95 book metrics become certifiable only after enough point-in-time snapshots have been collected. During bootstrap, status must remain `INSUFFICIENT` rather than guessed from current order book or daily volume.
