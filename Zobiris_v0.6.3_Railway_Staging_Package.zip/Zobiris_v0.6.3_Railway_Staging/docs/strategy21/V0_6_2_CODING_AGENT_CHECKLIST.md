# v0.6.2 Coding-Agent Checklist

- [ ] Read `ZOBIRIS_2_1_FINAL_SPEC.md`, especially Sections 7, 12, 22, 23.
- [ ] Read `KRAKEN_USD_EXECUTION_LIQUIDITY_SPEC_v0.6.2.md`.
- [ ] Read historical-personality design spec and implementation plan under `docs/superpowers/`.
- [ ] Execute the plan TDD-first; do not write implementation before failing tests.
- [ ] Add Task 2A/2B/2C and 7A/8A from `V0_6_2_IMPLEMENTATION_PLAN_ADDENDUM.md`.
- [ ] Use exact Kraken USD pairs and canonical asset IDs.
- [ ] Store raw historical bars/book snapshots immutably with hashes/provenance.
- [ ] Exclude incomplete daily/hourly candles.
- [ ] Use nearest-rank p10; 14-day p10 = second-lowest.
- [ ] Never use global CMC volume as execution-grade liquidity.
- [ ] Never infer historical book quality from today's book.
- [ ] Keep personality `DESCRIPTIVE_ONLY`.
- [ ] Keep liquidity as an eligibility/capacity gate, not a positive alpha factor.
- [ ] Preserve no-trading boundary and leverage=0.
- [ ] Implement API/UI contract with Data Quality + Liquidity before Personality.
- [ ] Run full acceptance matrix and all existing regression/no-trading gates.
- [ ] Produce `docs/VERIFICATION_v0.6.2.md` with only actual test results.
- [ ] Package release source and SHA256 after clean-unzip verification.
