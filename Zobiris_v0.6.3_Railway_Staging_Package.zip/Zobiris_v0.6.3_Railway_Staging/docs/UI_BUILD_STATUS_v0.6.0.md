# v0.6.0 UI build status

The Strategy Engine 2.1 UI changes are implemented in `src/ui/`.

The bundled `public/assets/` directory is the restored last-known-good v0.4.13 compiled UI because this verification container could not reinstall Vite/React dependencies. Run the following in a networked development environment before deployment:

```bash
npm ci
npm run build:ui
```

Do not describe the bundled `public/assets/` as the compiled v0.6.0 Strategy 2.1 UI until that command succeeds.
