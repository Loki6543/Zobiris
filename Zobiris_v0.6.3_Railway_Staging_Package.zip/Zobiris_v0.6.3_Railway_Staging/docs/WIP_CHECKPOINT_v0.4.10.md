# Zobiris v0.4.10 WIP checkpoint

## Starting point

- Immutable predecessor: `Zobiris_v0.4.9_Source.zip`.
- v0.4.9 SHA-256: `234f78757a43ba31eda8f66794a20fff8043e841cbf6166560026a957797be9c`.

## Milestone goal

Add an address-first investigation boundary for Solana and BNB Smart Chain that resolves only exact chain-and-address identity, persists every result and fails closed without fabricating a ticker, score or action.

## Completed in this checkpoint

- Added strict, chain-specific request validation for Solana base58 and BSC 20-byte hexadecimal addresses.
- Fixed canonical identity normalization so Solana addresses remain case-sensitive while EVM addresses normalize to lowercase.
- Added an `asset_investigations` audit table and repository operations.
- Added `POST /api/investigations/address` and persisted-result retrieval at `GET /api/investigations/:id`.
- Added exact registry resolution for the wrapped-native SOL mint and explicit unresolved semantics for unknown BSC addresses.
- Added a lazy-loaded React Address Investigation workspace with resolved, unresolved, caveat and unknown states.
- Added unit, persistence, real HTTP and rendered interaction coverage.

## Preserved constraints

- Address identity requires a chain namespace and exact address; ticker/name/model guesses are prohibited.
- An unresolved address receives no canonical ID, score, rank, action or allocation.
- A resolved identity does not imply current on-chain verification; the result says so explicitly.
- Deterministic code retains sole authority over identity, scoring, ranking, risk and allocation.
- No wallet, key, order or trade-execution path exists.

## Remaining work

- Add live, vendor-neutral Solana RPC and BNB Chain provider adapters with contract fixtures, health/degradation states and scheduled canaries.
- Enrich resolved investigations with current on-chain metadata only after provider verification.
- Complete cloud-browser desktop/mobile/accessibility QA when the environment permits browser access to a local or deployed listener.
- The optional OpenAI Challenger still needs project quota/credits for a live response; no live result is claimed.
