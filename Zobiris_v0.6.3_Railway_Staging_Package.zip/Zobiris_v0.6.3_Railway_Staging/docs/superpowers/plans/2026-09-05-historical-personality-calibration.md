# Historical Personality & Calibration Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build Zobiris v0.6.2 historical personality infrastructure that derives reproducible behavioral profiles from Kraken-first 1h history, retrieves non-overlapping historical analogs, and records delayed outcomes without giving personality any execution authority.

**Architecture:** Add a deterministic historical-data subsystem beside Strategy 2.1. Kraken 1h bars are ingested into immutable point-in-time storage, synchronized with BTC/USD, transformed into versioned rolling behavioral features, classified by the existing `personality.ts`, and passed through a regime-aware analog engine and append-only outcome ledger. All outputs remain `DESCRIPTIVE_ONLY`; existing executable ranking, capital, eligibility, and staged execution code must be invariant to personality output.

**Tech Stack:** TypeScript, Node.js, SQLite storage already used by Strategy 2.1, native `fetch` provider adapters, Vitest/Node assert Strategy 2.1 test harness, React Asset Case File UI.

**Spec:** `docs/superpowers/specs/2026-09-05-historical-personality-calibration-design.md`

## Global Constraints

- Canonical historical source is Kraken USD spot where available; external/CMC data is context-only and must never masquerade as execution-grade history.
- Only finalized closed 1h bars with point-in-time finalization lag are eligible.
- Asset/BTC comparisons use timestamp intersection; never forward-fill missing returns.
- Canonical asset identity and pair lifecycle intervals must prevent symbol collision or accidental history merges.
- Primary feature windows: 7d, 30d, 90d, 180d; current-state label confidence depends on cross-window stability.
- BTC-relative behavior must include beta-adjusted stress alpha, not only raw USD underperformance/outperformance.
- Stress events are versioned, clustered, non-overlapping episodes; multiple bars from one selloff do not count as independent evidence.
- Analog retrieval uses only past, eligible, regime-compatible setups with embargo/deduplication and missingness-aware distance.
- Historical match is retrieval quality (`HIGH|MEDIUM|LOW|INSUFFICIENT`), never a probability of profit.
- Personality, Elastic Strength, analogs, and outcomes are `DESCRIPTIVE_ONLY` for v0.6.2 and must not change executable rank, size, eligibility, order routing, or Cowpens line authorization.
- Outcome horizons are 1d, 7d, 30d, 90d and resolve only after maturity from the same authority source or become `PENDING`/`UNRESOLVABLE` with reasons.
- Promotion beyond descriptive research requires future purged/embargoed walk-forward evidence of incremental utility over baseline Strategy 2.1.
- No leverage or executable trading paths are introduced.

---

### Task 1: Historical Bar Domain, Pair Lifecycle, and Storage

**Files:**
- Create: `src/strategy21/history/types.ts`
- Create: `src/strategy21/history/storage.ts`
- Modify: `src/strategy21/storage.ts`
- Test: `src/strategy21/tests/historyStorage.test.ts`

**Interfaces:**
- Produces `HistoricalBar`, `HistoricalCoverage`, `PairLifecycle`, `DataAuthority`, `FeatureProvenance`.
- Produces `HistoricalStore` methods: `upsertRawBars`, `listEligibleBars`, `upsertPairLifecycle`, `getCoverage`, `recordSnapshot`.
- Consumers in later tasks must query by canonical `assetId`, venue, pair, interval, and `asOf`.

- [ ] **Step 1: Write failing domain/storage tests**

```ts
import { strict as assert } from "node:assert";
import { createHistoricalStore } from "../history/storage.js";

test("eligible history excludes non-final and post-asOf bars", () => {
  const store = createHistoricalStore(":memory:");
  store.upsertRawBars([
    bar({ openTime:"2026-09-01T00:00:00Z", closeTime:"2026-09-01T01:00:00Z", isFinal:true }),
    bar({ openTime:"2026-09-01T01:00:00Z", closeTime:"2026-09-01T02:00:00Z", isFinal:false }),
  ]);
  const rows = store.listEligibleBars({ assetId:"btc", asOf:"2026-09-01T02:10:00Z", finalizationLagMinutes:5 });
  assert.deepEqual(rows.map(x => x.openTime), ["2026-09-01T00:00:00Z"]);
});

test("pair lifecycle prevents symbol-history merging", () => {
  const store = createHistoricalStore(":memory:");
  store.upsertPairLifecycle({ assetId:"asset-a", venue:"KRAKEN", pair:"ABCUSD", validFrom:"2025-01-01T00:00:00Z", validTo:"2026-01-01T00:00:00Z" });
  store.upsertPairLifecycle({ assetId:"asset-b", venue:"KRAKEN", pair:"ABCUSD", validFrom:"2026-02-01T00:00:00Z" });
  assert.notEqual(store.resolvePairOwner("ABCUSD", "2025-06-01T00:00:00Z"), store.resolvePairOwner("ABCUSD", "2026-06-01T00:00:00Z"));
});
```

- [ ] **Step 2: Run tests and verify RED**

Run: `npm run test:strategy21 -- src/strategy21/tests/historyStorage.test.ts`
Expected: FAIL because `history/types.ts` and `history/storage.ts` do not exist.

- [ ] **Step 3: Implement immutable schemas and storage**

Define point-in-time fields including `sourcePublishedAt`, `retrievedAt`, `isClosed`, `isFinal`, `sourceConfidence`, `ingestionVersion`, canonical payload hash, validation reasons, plus coverage diagnostics (`largestGapHours`, `recentGapHours`, `contiguousTailHours`, zero-volume/invalid/duplicate counts).

- [ ] **Step 4: Run focused tests and full Strategy 2.1 suite**

Run: `npm run test:strategy21 -- src/strategy21/tests/historyStorage.test.ts && npm run test:strategy21`
Expected: PASS.

- [ ] **Step 5: Commit**

```bash
git add src/strategy21/history src/strategy21/storage.ts src/strategy21/tests/historyStorage.test.ts
git commit -m "feat: add point-in-time historical bar storage"
```

---

### Task 2: Kraken-First Bootstrap Collector and Reconciliation

**Files:**
- Create: `src/strategy21/history/krakenHistory.ts`
- Create: `src/strategy21/history/bootstrap.ts`
- Modify: `src/strategy21/providers/kraken.ts`
- Modify: `src/strategy21/collector.ts`
- Test: `src/strategy21/tests/historyCollector.test.ts`

**Interfaces:**
- Consumes `HistoricalStore`, canonical asset mapping, pair lifecycle.
- Produces `collectKrakenHourlyHistory(assetId, pair, since, until)` and `bootstrapHistory(request)` with checkpoint metadata and explicit partial-history status.

- [ ] **Step 1: Write failing collector tests**

```ts
test("collector discards the still-forming Kraken candle", async () => {
  const result = await collectKrakenHourlyHistory(input, fakeKrakenResponseWithOpenTail);
  assert.equal(result.bars.some(b => !b.isFinal), false);
});

test("partial Kraken backfill is marked PARTIAL and checkpointed", async () => {
  const r = await bootstrapHistory({ assetId:"ondo", requestedStart:"2026-01-01T00:00:00Z" }, depsReturningLimitedSpan);
  assert.equal(r.status, "PARTIAL");
  assert.ok(r.checkpoint.nextCursor || r.reasons.includes("requested_span_not_fully_retrieved"));
});
```

- [ ] **Step 2: Verify RED**

Run: `npm run test:strategy21 -- src/strategy21/tests/historyCollector.test.ts`
Expected: FAIL for missing collector.

- [ ] **Step 3: Implement Kraken OHLC parser, bootstrap checkpointing, payload hashing, and reconciliation**

Rules: no silent full-history claim; repeated fetches dedupe by canonical `(assetId, venue, pair, interval, openTime)`; source revisions create traceable snapshot/recompute metadata rather than mutating old observations invisibly.

- [ ] **Step 4: Verify GREEN + regressions**

Run: `npm run test:strategy21 -- src/strategy21/tests/historyCollector.test.ts && npm run test:strategy21`
Expected: PASS.

- [ ] **Step 5: Commit**

```bash
git add src/strategy21/history src/strategy21/providers/kraken.ts src/strategy21/collector.ts src/strategy21/tests/historyCollector.test.ts
git commit -m "feat: add Kraken historical bootstrap collector"
```

---

### Task 3: Synchronized BTC-Relative Feature Engine and Stress Episodes

**Files:**
- Create: `src/strategy21/history/synchronize.ts`
- Create: `src/strategy21/history/stressEpisodes.ts`
- Create: `src/strategy21/history/features.ts`
- Test: `src/strategy21/tests/historyFeatures.test.ts`

**Interfaces:**
- Produces `intersectHourlyBars(assetBars, btcBars)`.
- Produces `detectBtcStressEpisodes(series, configVersion)` returning clustered independent episodes.
- Produces `buildBehavioralProfileInput({ assetBars, btcBars, asOf })` compatible with existing `BehavioralProfileInput` plus research telemetry/provenance.

- [ ] **Step 1: Write synthetic-series failing tests**

```ts
test("timestamp intersection never forward-fills missing asset hours", () => {
  const sync = intersectHourlyBars(assetBarsMissingHour2, btcBarsComplete);
  assert.deepEqual(sync.map(x => x.openTime), [hour1, hour3]);
});

test("low-beta flat asset is not called independent from raw loss avoidance", () => {
  const f = buildBehavioralFeatures(lowVolAsset, fallingBtc);
  assert.ok(f.betaAdjustedStressAlpha <= independentLeaderThreshold);
});

test("one continuous BTC selloff counts as one independent stress cluster", () => {
  const e = detectBtcStressEpisodes(tenDownHoursOneSelloff, stressV1);
  assert.equal(e.independentEpisodes, 1);
});

test("tiny BTC negatives do not explode downside capture", () => {
  const f = buildBehavioralFeatures(asset, btcTinyDeclines);
  assert.equal(f.downsideCapture.status, "INSUFFICIENT");
});
```

- [ ] **Step 2: Verify RED**

Run: `npm run test:strategy21 -- src/strategy21/tests/historyFeatures.test.ts`
Expected: FAIL for missing feature engine.

- [ ] **Step 3: Implement deterministic math**

Use log returns, OLS beta plus research diagnostics (Spearman/winsorized variants where dependency-light), beta-adjusted BTC stress alpha, volatility-scaled downside thresholds, 7/30/90/180d stability, censored dip-recovery metrics, deterministic range breakout definitions, and feature-specific confidence/provenance.

- [ ] **Step 4: Verify synthetic archetypes**

Add fixtures for `INDEPENDENT_LEADER`, `BTC_SHADOW`, gappy/illiquid series, failed-breakout series, and fast dip eater. Run focused and full suites.

- [ ] **Step 5: Commit**

```bash
git add src/strategy21/history src/strategy21/tests/historyFeatures.test.ts
git commit -m "feat: derive BTC-relative behavioral features"
```

---

### Task 4: Historical Elastic Strength and Existing Classifier Integration

**Files:**
- Modify: `src/strategy21/engine/personality.ts`
- Modify: `src/strategy21/integration.ts`
- Create: `src/strategy21/history/personalityService.ts`
- Test: `src/strategy21/tests/historicalPersonality.test.ts`
- Modify: `src/strategy21/tests/integration.test.ts`

**Interfaces:**
- Consumes historical feature output.
- Produces `HistoricalElasticStrength` with components, band, independent stress count, source authority, contradictions, exclusions.
- Produces `buildHistoricalPersonality(assetId, asOf)` which calls existing `classifyBehavioralPersonality` without changing executable opportunity authority.

- [ ] **Step 1: Write failing authority and score-composition tests**

```ts
test("unknown leverage reduces confidence but never boosts elastic strength", () => {
  const r = computeHistoricalElasticStrength(profile({ leverageState:"LEVERAGE_UNKNOWN" }));
  assert.ok(r.confidence < 1);
  assert.equal(r.components.leverageAdjustment, undefined);
});

test("historical personality cannot alter executable next-dollar output", () => {
  const before = integrateStrategy21(baseFixture({ personalityBySymbol:new Map() }));
  const after = integrateStrategy21(baseFixture({ personalityBySymbol:historicalProfiles }));
  assert.deepEqual(executableProjection(after), executableProjection(before));
});
```

- [ ] **Step 2: Verify RED**

Run: `npm run test:strategy21 -- src/strategy21/tests/historicalPersonality.test.ts`
Expected: FAIL.

- [ ] **Step 3: Implement compositional Elastic Strength + profile service**

Publish score only with components and band; require independent stress clusters for `HIGH/MODERATE`; map unstable cross-window results internally to uncertainty; preserve `productionAuthority: "DESCRIPTIVE_ONLY"`.

- [ ] **Step 4: Verify GREEN and authority invariance**

Run focused tests, `npm run test:strategy21`, and `bash scripts/check_no_trading.sh`.

- [ ] **Step 5: Commit**

```bash
git add src/strategy21/engine/personality.ts src/strategy21/integration.ts src/strategy21/history/personalityService.ts src/strategy21/tests
git commit -m "feat: integrate historical personality profiles safely"
```

---

### Task 5: Regime-Conditioned, Embargoed Analog Retrieval

**Files:**
- Create: `src/strategy21/history/analogs.ts`
- Modify: `src/strategy21/history/storage.ts`
- Test: `src/strategy21/tests/historyAnalogs.test.ts`

**Interfaces:**
- Produces `HistoricalAnalogSummary` with `rawSimilarWindowCount`, `independentEpisodeCount`, eligible counts, coverage, distance median/IQR, feature/distance versions, and explanations.
- `findHistoricalAnalogs(current, candidates, policy)` must filter by market-state compatibility and data authority before distance calculation.

- [ ] **Step 1: Write failing leakage/deduplication tests**

```ts
test("24 adjacent matching hours are one independent analog episode", () => {
  const r = findHistoricalAnalogs(current, adjacentMatches24, policy);
  assert.equal(r.rawSimilarWindowCount, 24);
  assert.equal(r.independentEpisodeCount, 1);
});

test("future-bar injection cannot improve an earlier analog result", () => {
  const a = findHistoricalAnalogs(currentAtT, historyThroughTMinus1, policy);
  const b = findHistoricalAnalogs(currentAtT, [...historyThroughTMinus1, futurePerfectMatch], policy);
  assert.deepEqual(b, a);
});

test("missing low-quality dimensions reduce retained weight instead of becoming zero", () => {
  const r = behaviorDistance(aWithNoVolume, b, policy);
  assert.ok(r.retainedWeight < 1);
  assert.notEqual(r.distance, behaviorDistance(aWithVolumeZero, b, policy).distance);
});
```

- [ ] **Step 2: Verify RED**

Run: `npm run test:strategy21 -- src/strategy21/tests/historyAnalogs.test.ts`
Expected: FAIL.

- [ ] **Step 3: Implement candidate gating, prior-data robust normalization, missingness-aware weighted distance, embargo, and contiguous-window clustering**

No probability names in types/UI. `HIGH` retrieval quality requires adequate independent episodes and retained feature weight.

- [ ] **Step 4: Verify overlap, regime mismatch, future leakage, and sparse-history tests**

Run focused + full Strategy 2.1 tests.

- [ ] **Step 5: Commit**

```bash
git add src/strategy21/history/analogs.ts src/strategy21/history/storage.ts src/strategy21/tests/historyAnalogs.test.ts
git commit -m "feat: add embargoed historical analog retrieval"
```

---

### Task 6: Append-Only Observation/Outcome Ledger and Research Evaluation

**Files:**
- Create: `src/strategy21/history/outcomes.ts`
- Create: `src/strategy21/history/evaluation.ts`
- Modify: `src/strategy21/history/storage.ts`
- Test: `src/strategy21/tests/personalityOutcomes.test.ts`
- Test: `src/strategy21/tests/personalityEvaluation.test.ts`

**Interfaces:**
- Produces versioned `PersonalityObservation` with source snapshot IDs and `dataCutoffAt`.
- Produces `PersonalityOutcome` for `1D|7D|30D|90D`, status `PENDING|RESOLVED|UNRESOLVABLE`.
- Produces research-only `compareBaselineVsPersonality()` for purged/embargoed walk-forward reporting; it must not feed production authority.

- [ ] **Step 1: Write failing maturity, provenance, and evaluation tests**

```ts
test("outcome cannot resolve before maturity", () => {
  const r = resolveOutcome(obsAtT, "7D", barsThroughDay6);
  assert.equal(r.status, "PENDING");
});

test("missing maturity mark does not substitute another venue silently", () => {
  const r = resolveOutcome(obs, "30D", krakenGapAtMaturity);
  assert.ok(["PENDING","UNRESOLVABLE"].includes(r.status));
  assert.equal(r.dataAuthority, "KRAKEN_EXECUTION_GRADE");
});

test("walk-forward evaluator purges overlapping feature windows and embargoes outcome horizon", () => {
  const folds = buildPurgedWalkForwardFolds(observations, policy);
  assert.equal(hasOverlapLeakage(folds), false);
});
```

- [ ] **Step 2: Verify RED**

Run: `npm run test:strategy21 -- src/strategy21/tests/personalityOutcomes.test.ts src/strategy21/tests/personalityEvaluation.test.ts`
Expected: FAIL.

- [ ] **Step 3: Implement immutable observations, delayed resolution, MAE/MFE convention, BTC-relative outcome, persistence flags, and research-only baseline comparison**

Predeclare null hypothesis: personality adds no incremental utility beyond Strategy 2.1 roots/market state. Report uncertainty and independent-episode counts; never promote authority automatically.

- [ ] **Step 4: Verify GREEN + full suite**

Run focused tests then `npm run test:strategy21`.

- [ ] **Step 5: Commit**

```bash
git add src/strategy21/history/outcomes.ts src/strategy21/history/evaluation.ts src/strategy21/history/storage.ts src/strategy21/tests
git commit -m "feat: add personality outcome and calibration ledger"
```

---

### Task 7: Runtime/API/UI Exposure with Data-Quality-First Presentation

**Files:**
- Modify: `src/runtime/refresh.ts`
- Modify: `src/server.ts` or current Strategy 2.1 route module discovered during implementation
- Modify: `src/ui/AssetCasePanel.tsx`
- Modify: `src/ui/api.ts`
- Test: `src/strategy21/tests/integration.test.ts`
- Test: `src/tests/server-http-integration.test.ts`
- Test: `src/tests/ui-operator.test.tsx`
- Modify: `scripts/verify_strategy21_integration.mjs`

**Interfaces:**
- Runtime must refresh/bootstrap history opportunistically, derive profile from point-in-time eligible data, persist observation, and expose a read-only historical-personality payload.
- UI ordering: Authority → Data Quality → Personality → Elastic Strength → Analogs → Contradictions/Exclusions.

- [ ] **Step 1: Write failing API/UI disclosure tests**

```ts
test("HIGH analog quality cannot render without independent episode count and descriptive warning", () => {
  const view = renderAssetCase(highAnalogFixture);
  expect(view.getByText(/DESCRIPTIVE ONLY/i)).toBeTruthy();
  expect(view.getByText(/Comparable independent episodes/i)).toBeTruthy();
  expect(view.getByText(/Not a probability/i)).toBeTruthy();
});

test("runtime historical personality leaves executable rank unchanged", async () => {
  const withHistory = await refresh(fixtureWithHistory);
  const withoutHistory = await refresh(fixtureWithoutHistory);
  assert.deepEqual(projectExecutableRanks(withHistory), projectExecutableRanks(withoutHistory));
});
```

- [ ] **Step 2: Verify RED**

Run the focused integration/server/UI tests and confirm failure for missing payload/UI.

- [ ] **Step 3: Wire runtime, API, and Asset Case File**

When history is unavailable, return truthful `INSUFFICIENT`/`UNAVAILABLE`; do not fabricate personality. Display source authority, synchronized coverage, trailing contiguous coverage, stress clusters, feature confidence, Elastic Strength components, independent analog episodes, raw matching windows, contradictions, and exclusions.

- [ ] **Step 4: Update integration verifier**

Add checks for historical collector invocation, point-in-time cutoff, descriptive-only invariant, and Asset Case File fields.

- [ ] **Step 5: Commit**

```bash
git add src/runtime src/ui src/server* src/strategy21/tests src/tests scripts/verify_strategy21_integration.mjs
git commit -m "feat: expose historical personality research in Zobiris"
```

---

### Task 8: Adversarial Verification, Release Packaging, and v0.6.2 Documentation

**Files:**
- Modify: `README.md`
- Create: `docs/VERIFICATION_v0.6.2.md`
- Create: `docs/strategy21/HISTORICAL_PERSONALITY_CALIBRATION.md`
- Modify: `IMPLEMENTATION_LOG.md`
- Modify: `VERIFICATION_REPORT.md`
- Modify: `package.json` only if a new verification script is needed

**Interfaces:**
- Final deliverable must be a reproducible source release and verification report; no trade execution.

- [ ] **Step 1: Run complete verification commands**

```bash
npm run test:strategy21
npm test
npm run typecheck
npm run build
node scripts/verify_strategy21_integration.mjs
bash scripts/check_no_trading.sh
```

Expected: every command exits 0. If dependency/network limitations prevent a command, report the exact limitation and do not claim that gate passed.

- [ ] **Step 2: Run explicit adversarial cases**

Verify bar revisions, pair rename/migration, recent gap, tiny BTC denominator, one-selloff stress clustering, overlapping analog deduplication, missing volume confidence, low-beta false-leader prevention, outcome maturity, future-bar injection, and authority invariance.

- [ ] **Step 3: Document actual results only**

Record exact test counts, build/typecheck status, historical source limitations, current data coverage, and the continuing `DESCRIPTIVE_ONLY` boundary.

- [ ] **Step 4: Build release artifact and checksum**

```bash
npm run build:dist
sha256sum Zobiris_v0.6.2_Historical_Personality_Source.zip > Zobiris_v0.6.2_Historical_Personality_Source.sha256
```

If `build:dist` uses a different naming contract, update the release script first and verify archive contents include source, UI, spec, plan, and verification docs.

- [ ] **Step 5: Final verification after packaging**

Unzip the produced archive into a clean temp directory and rerun the dependency-light Strategy 2.1 verification/integration/no-trading gates from the packaged tree before claiming release completion.
