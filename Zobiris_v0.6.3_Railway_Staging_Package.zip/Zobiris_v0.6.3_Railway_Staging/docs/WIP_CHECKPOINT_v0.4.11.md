# Zobiris v0.4.11 WIP checkpoint

## Starting point

- Immutable predecessor: `Zobiris_v0.4.10_Source.zip`.
- v0.4.10 SHA-256: `7d3217b26f01aaf7f3b02dadbb2270e49570e52fad32c66244109bab5df4b924`.
- This checkpoint addresses the remaining findings from Claude.ai's independent v0.4.9 source execution and review.

## Completed hardening

### Hard risk caps survive normalization

- Replaced unconstrained proportional rescaling with deterministic bounded water-filling.
- Active vetoes remain zero and active size caps remain strict after portfolio normalization.
- Only uncapped assets receive remaining budget after a cap binds.
- When every eligible asset is capped, the remainder is honestly reported as unallocated.
- Replaced the misleading rounding-based `cappedCount` with `bindingRiskCapCount`.
- Added a verifier error, `WEIGHT_EXCEEDS_RISK_CAP`, as an independent post-normalization guard.
- Added direct risk-gate and cap/normalize interaction tests reproducing the reported 1% wash-trading scenario.

### Future timestamps fail closed

- Invalid timestamps return `unavailable` rather than a trusted freshness state.
- Provider timestamps more than 60 seconds in the future return `unavailable`.
- A configurable bounded skew allowance preserves tolerance for small clock differences.

### Promotion overrides cannot bypass governance

- A string-valued `approvedBy` field is no longer treated as authentication.
- Critical-safety overrides may be recorded for immediate protective regression work, but cannot bypass any of the 15 promotion gates.
- `viaOverride` remains false until a future authenticated operator workflow exists.

### Anonymous refresh requires explicit opt-in

- `NODE_ENV=development` no longer enables anonymous refresh implicitly.
- Only `ZOBIRIS_ALLOW_ANONYMOUS_REFRESH=1` enables it.
- Bearer auth, rate limiting, single-flight locking, closed CORS and server-controlled live-provider policy remain intact.

## Preserved authority boundary

- Deterministic Zobiris code alone controls identity, scoring, ranking, risk gates and allocation.
- Agents remain advisory, bounded and read-only.
- No wallet, private-key, order or trade-execution path exists.
