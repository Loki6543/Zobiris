# Zobiris v0.4.11 verification report

Date: 2026-08-26  
Predecessor: Zobiris v0.4.10, SHA-256 `7d3217b26f01aaf7f3b02dadbb2270e49570e52fad32c66244109bab5df4b924`

## Independent-review reproduction

The reported failure was reproduced in shape: a 1% `SUSPICIOUS_VOLUME` cap could be multiplied during proportional normalization. The corrected result preserves the capped asset at exactly 1% and allocates the remaining 89% target budget only to the uncapped peer. No post-normalization path may enlarge an active hard cap.

## Verification gates

| Gate | Result |
| --- | --- |
| Strict TypeScript | Passed with zero errors before version checkpoint |
| Vitest | 64 files passed; 460 tests passed before version checkpoint |
| Production Vite build | Passed; 2,544 modules transformed |
| Static no-trade check | Passed inside the full Vitest suite |

## New regression coverage

- Hard veto always forces zero.
- Suspicious-volume gate binds at 1%.
- The strictest simultaneous size cap wins.
- Confidence-reduction gates do not silently change size.
- Size caps survive portfolio normalization.
- Fully capped portfolios remain explicitly under-allocated.
- The verifier detects any post-normalization cap breach.
- Invalid/materially future timestamps are unavailable; bounded clock skew is configurable.
- Documented safety overrides cannot bypass promotion gates.
- Development mode alone cannot enable anonymous refresh.

## Remaining external limitations

- Browser screenshot QA remains unavailable in this workspace; backend changes have no new visual surface.
- Live provider verification and the optional OpenAI Challenger still depend on external credentials/quota and are not claimed by this checkpoint.
