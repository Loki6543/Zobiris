# Zobiris v0.4.8 verification report

Date: 2026-08-25  
Recovered baseline SHA-256: `31f034e4fbcb500686e06fb768a8a3636556d52623873f2601209c320b48f959`

## Outcome

The archived WIP was reconstructed as an evidence-first operator console and trust pipeline. Deterministic code remains the scoring authority; the OpenAI Challenger is a structured, read-only adversarial reviewer.

## Executable verification

| Gate | Result |
|---|---|
| `npx tsc --noEmit` | Passed with zero errors |
| `npm test` | 61 test files passed; 438 tests passed |
| `npm run build:ui` | Passed; production assets emitted to `public/assets` |
| `scripts/check_no_trading.sh` | Passed |
| HTTP health | Passed |
| HTTP refresh | Passed with a persisted snapshot and outbox event |
| Runtime ↔ storage session continuity | Passed; the transaction retained the runtime session ID |
| Persistence counts | 18 observations and 18 evidence claims in the smoke refresh |
| BTC case-file trace | 7 observations and 7 governed evidence claims |
| Stage 18 persistence | Passed only after the atomic transaction committed |
| Challenger contract/eval | Passed, including rejection of agent-authored score fields |

## OpenAI integration status

The TypeScript Agents SDK path uses a strict output schema and one read-only ledger inspection tool. The live request reached the OpenAI API, which returned HTTP 429 quota/credit exhaustion for the configured project. This is an account quota blocker, not an application fallback; the UI reports the error and Zobiris does not manufacture an advisory result.

## Frontend QA and concept comparison

The command center follows the supplied 1536×1024 dark-dashboard reference. The hosted cloud browser blocked local loopback URLs, and the local Playwright Chromium download was unavailable in this environment. Responsive rendering could therefore not be screenshot-verified here. A jsdom integration test did verify navigation across all three workspaces and a complete demo Challenger interaction with the score remaining unchanged.

Mismatch/intent ledger:

1. Preserved the fixed left navigation, compact header, KPI strip and dense two-column command-center hierarchy.
2. Preserved the ranked asset table and large score-anatomy panel as the primary analytical pair.
3. Preserved the navy/graphite surface system with restrained purple, blue, green, amber and red semantic accents.
4. Replaced the concept's billing, plan and upgrade surfaces with evidence integrity and trust-status information.
5. Added an explicit Evidence Graph because provenance and factor-to-claim traceability are v0.4.8 product requirements absent from the concept.
6. Added a visibly advisory Challenger node/workspace, with deterministic authority and prohibited actions shown in the interface.
7. Added a responsive mobile navigation sheet and stacked content layout; this behavior is code- and interaction-tested but not screenshot-verified in this environment.
8. Changed provider status copy from generic marketing health to freshness, acquisition mode and degraded-state semantics.

## Security and release integrity

- The server loads OpenAI credentials from the environment; the browser never receives the key.
- `.env`, `.env.local` and `.env.*` are excluded by the release generator.
- The package contains no database, logs, dependency directory or credential file.
- No agent or server tool exposes wallet, key, order or trade-execution authority.
- Source ZIP integrity is recorded in `downloads/MANIFEST.json` and `downloads/SHA256SUMS.txt`.

## Remaining external blocker

Enable API credits/quota for the configured OpenAI project, then repeat the live Challenger request. All deterministic application paths and the agent's local contract/eval harness are already verified.
