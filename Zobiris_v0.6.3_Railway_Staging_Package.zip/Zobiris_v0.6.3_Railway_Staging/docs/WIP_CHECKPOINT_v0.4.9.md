# Zobiris v0.4.9 WIP checkpoint

## Starting point

- Immutable predecessor: `Zobiris_v0.4.8_Source.zip`.
- v0.4.8 SHA-256: `7998f830b4d2242f7efebece2ad4cbb418b3bf03dcaed4ebeb761acdd833f65e`.
- The v0.4.8 release remains unchanged in `downloads/`; new work advances the package version to v0.4.9.

## Milestone goal

Production hardening and full-depth asset intelligence:

1. real HTTP/server integration tests against an ephemeral database;
2. reproducible per-asset case files with exact provenance, contradictions and unknowns;
3. explicit deltas against the previous snapshot;
4. a user-facing case-file workspace in the React operator console;
5. browser/deployed-artifact QA when an accessible browser target is available.

## Completed in this checkpoint

- Exported a side-effect-free HTTP server factory while preserving the CLI entry point.
- Added ephemeral-database HTTP integration tests for SPA delivery, health, two fixture refreshes, atomic persistence, stage 18, session continuity, BTC evidence rehydration, snapshot history, case-file provenance, unknown routes and unconfigured Challenger behavior.
- Fixed a root-route regression discovered by the new test: `/` was rejected before `serveStatic()` could map it to `index.html`.
- Expanded the case-file contract with provenance endpoint/hash/request context, analytical eligibility, exact contradictory claim references, governed unknowns and previous-snapshot deltas.
- Added a lazy-loaded React Asset Case File workspace; its production chunk is 10.51 KB (2.90 KB gzip).
- Expanded the operator interaction test through Command Center → Asset Case File → Evidence Graph → Challenger.
- Passed strict TypeScript, the production build, the static no-trade gate and 444 tests across 62 files.

## Remaining external QA blockers

- The workspace refused a local listener for cloud-browser access, so screenshot-based desktop/mobile QA remains blocked. Real HTTP behavior is exercised inside Vitest and the full UI flow is exercised in jsdom.
- The configured OpenAI project still needs API quota/credits before a live Challenger response can complete.

## Preserved constraints

- Deterministic code alone controls scores, ranks, risk gates and allocation.
- Agents remain advisory, read-only and unable to execute trades or access wallets/keys.
- Fallback/synthetic evidence is displayable for audit but cannot affect scoring.
- Canonical asset identity remains UUID-based and cannot be established by ticker-only or model output.
- Every completion claim must be backed by an executable test or reported as a blocker.
