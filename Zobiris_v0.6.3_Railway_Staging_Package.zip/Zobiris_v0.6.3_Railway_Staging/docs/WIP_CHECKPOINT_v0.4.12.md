# Zobiris v0.4.12 WIP checkpoint

## Starting point

- Recovered immutable predecessor: `Zobiris_v0.4.11_Source.zip`.
- v0.4.11 SHA-256: `f6014a3b33edbe9936fb14aaf0baeeb5f367ae7fa01fa6d2dc8f5d8353cd49d8`.

## Implemented

- Vendor-neutral JSON-RPC verification for Solana accounts (`getAccountInfo`) and BNB Smart Chain contract code (`eth_getCode`).
- Endpoints are supplied only through `ZOBIRIS_SOLANA_RPC_URL` and `ZOBIRIS_BSC_RPC_URL`; endpoint values never enter API results or logs.
- Explicit `unconfigured`, `healthy`, `degraded`, and `unavailable` health states, bounded timeout, latency, and redacted failure classification.
- Address investigations persist the on-chain verification result alongside immutable registry identity.
- A missing account/contract adds a critical unknown and disables case-file availability; provider failure never changes identity or creates a score.
- Operator UI exposes capability, method, health, existence, latency, and failure class.

## Preserved boundaries

- Exact chain/address identity only; no ticker guessing.
- RPC evidence cannot assign canonical identity, score, rank, action, or allocation.
- No wallet, signing, order, or trade execution capability.

## Next task

Add scheduled provider canaries and persist chain-RPC health into the common provider-health ledger, then connect one complete live BTC/SOL market-data vertical with stale/degraded browser states.
