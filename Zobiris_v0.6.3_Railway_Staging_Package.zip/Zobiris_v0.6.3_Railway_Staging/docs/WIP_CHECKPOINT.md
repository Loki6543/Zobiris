# Zobiris v0.4.8 — resumed WIP checkpoint

## Recovery record

- Recovered baseline: `Zobiris_v0.4.7_Source.zip`.
- Baseline SHA-256: `31f034e4fbcb500686e06fb768a8a3636556d52623873f2601209c320b48f959`.
- The archived `Unify Apps and Rules` conversation described v0.4.8 work but did not retain its worktree. This release reconstructs that work against the verified v0.4.7 baseline.

## Completed checkpoint

| Area | v0.4.8 result |
|---|---|
| Evidence provenance | Acquisition mode, endpoint, requested market context, provider time, fallback reason, upstream failure and SHA-256 payload hash persist through storage and rehydration. |
| Evidence authority | Claims are created before scoring. Factor scores retain exact evidence-claim IDs. Fallback/synthetic observations are display-only. |
| Identity | Runtime identity is UUID-based and legacy derived/non-UUID persisted identity fails closed. |
| Confidence | Freshness is capability-specific and order-independent. Cross-source agreement requires distinct providers; a lone provider contributes zero corroboration. |
| Refresh persistence | The HTTP refresh route performs the real refresh and atomically persists observations, claims, snapshot, all stages and outbox under the same session ID. |
| Challenger Agent | A read-only OpenAI Agents SDK worker returns strict structured counter-evidence. It can inspect only a bounded evidence ledger and cannot change identity, scores, ranks, allocation or execute trades. |
| Operator UI | React/Vite/Tailwind/shadcn command center, Evidence Graph and Challenger workspace replace the legacy dashboard while retaining the supplied dense dark visual language. |

## Non-negotiable constraints preserved

- Decision support only: no wallet access, private keys, order authority or trade execution.
- Ticker-only or model-derived identity never establishes a canonical asset.
- Deterministic Zobiris code remains the only scoring and allocation authority.
- Model-derived claims require governed evidence parents.
- Unknown, stale, delayed, degraded, fallback, ambiguous and quarantined states remain explicit.
- Release artifacts exclude local environment files and credentials.

## Verification status

- Strict TypeScript: passed.
- Vitest: 438 tests across 61 files passed.
- Vite production build: passed.
- HTTP refresh/persistence smoke test: passed, including session continuity and stage 18 persistence.
- Challenger contract/eval tests: passed.
- Live OpenAI Challenger call: reached the API, but the configured project returned quota/credit exhaustion (HTTP 429); no response was fabricated.
- Browser visual run: blocked by the hosted browser's loopback policy and unavailable local Chromium download. Interaction coverage was completed in jsdom; see `docs/VERIFICATION_v0.4.8.md`.
