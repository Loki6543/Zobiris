# Zobiris v0.4.10 verification report

Date: 2026-08-26  
Predecessor: Zobiris v0.4.9, SHA-256 `234f78757a43ba31eda8f66794a20fff8043e841cbf6166560026a957797be9c`

## Outcome

v0.4.10 introduces an auditable address-first identity workflow. Solana address case is preserved, BSC hexadecimal is normalized, exact registry matches resolve to immutable canonical IDs and unknown addresses fail closed.

## Verification gates

| Gate | Result |
| --- | --- |
| Strict TypeScript | Passed with zero errors |
| Vitest | 63 files passed; 450 tests passed |
| Production Vite build | Passed; 2,544 modules transformed |
| Address Investigation split | 4.44 KB, 1.71 KB gzip lazy chunk |
| Static no-trade check | Passed inside the full Vitest suite |
| Archive credential policy | `.env`, `.env.local` and `.env.*` excluded by the release generator |

## Contract verification

- Valid Solana addresses retain exact base58 case.
- Valid BSC addresses normalize to lowercase for lookup.
- Malformed and extra request fields are rejected.
- Exact SOL mint lookup resolves to the persisted immutable canonical UUID.
- Unknown BSC address returns HTTP 202 with `status=unresolved`, null symbol/canonical ID and no score.
- Every result is persisted and can be retrieved by investigation ID.

## QA limitation

The Browser plugin is not installed and the environment previously refused a browser-accessible local listener. The feature is covered through jsdom interaction tests, real ephemeral HTTP tests and a production build; desktop/mobile screenshot and console QA remain unclaimed.
