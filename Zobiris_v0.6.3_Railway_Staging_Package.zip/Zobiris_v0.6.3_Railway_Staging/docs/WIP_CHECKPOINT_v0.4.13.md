# Zobiris v0.4.13 Checkpoint

Date: 2026-08-27

## Outcome

The application now evaluates one universe only: the canonical CoinMarketCap watchlist at `https://coinmarketcap.com/watchlist/69c01b46aed37c7160053535/`.

## Product changes

- Added a first-class `GET /api/watchlist` boundary with ranked symbol/name membership.
- The command center renders every watchlist member instead of truncating to five rows.
- Persisted snapshot data enriches watchlist rows but cannot add an off-list asset.
- Watchlist members without a persisted result show `Unknown` risk and `Awaiting evaluation`; no demo asset or case file is substituted.
- Asset Case File and Challenger server boundaries reject symbols outside the active watchlist.
- Dashboard KPIs now derive from persisted results. Demo factors, demo change events and fixed presentation totals were removed.
- Fixed-size watchlist tests were replaced with source membership/order and mapping lockstep tests.
- Bottom-of-watchlist risk metadata now derives from the current watchlist size.

## Removed structure

The Solana/BNB address-investigation product surface was retired completely from the current runtime:

- navigation and React page;
- address parsing/domain and investigation service;
- Solana/BSC RPC provider module and endpoint environment variables;
- `POST /api/investigations/address` and `GET /api/investigations/:id`;
- repository insert/read operations and the `asset_investigations` schema;
- feature-specific tests.

Migration removes the obsolete `asset_investigations` table. Any records formerly stored there are recoverable only from a pre-v0.4.13 database backup or older source/release archive.

SOL may still appear if it is a member of the canonical watchlist and may still be evaluated by ordinary market-data providers. The removed feature is the chain/address search workspace, not watchlist membership.

## Source limitation

CoinMarketCap did not expose the public watchlist contents to the available search connection during this session. The release therefore preserves the latest captured canonical source snapshot and does not invent a newer membership list. The application is structured so the source snapshot can change size and order without a code-level `50` invariant.
