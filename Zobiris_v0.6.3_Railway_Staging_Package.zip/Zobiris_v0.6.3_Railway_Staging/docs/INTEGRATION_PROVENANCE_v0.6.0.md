# Zobiris v0.6.0 integration provenance

This source tree was produced by integrating Strategy Engine 2.1 into the real Zobiris source package `Zobiris_v0.4.13_Source.zip`.

The integration intentionally preserves the existing Zobiris watchlist product, provider/evidence architecture, persistence model, verifier/challenger layers and React application source while adding Strategy 2.1 as the strategy/position-authority layer.

It is **not** a replacement standalone demo engine.

The separately created Strategy 2.1 engine artifact was used as implementation input, then adapted to the real application's contracts and refresh flow.

Release version: `0.6.0`  
Strategy policy: `2.1`
