# Zobiris v0.4.13 Verification

Date: 2026-08-27

| Check | Result |
|---|---|
| Strict TypeScript (`npm run typecheck`) | Passed |
| Vitest (`npm test`) | 65 files, 455 tests passed |
| Production Vite build (`npm run build:ui`) | Passed |
| Full watchlist merge semantics | Passed; added regression coverage |
| Off-watchlist asset API rejection | Passed through real HTTP integration test |
| Retired investigation table absent after migration | Passed |
| Operator navigation and Challenger interaction | Passed in jsdom UI test |
| Real HTTP refresh → persistence → case-file rehydration | Passed |
| Cloud-browser rendered inspection | Blocked by loopback-address policy |

## Build output

- `public/index.html`
- `public/assets/index-DA-ad75D.css`
- `public/assets/index-9cQgUZbv.js`
- `public/assets/AssetCasePanel-D7D-F9mo.js`
- shared React and chart chunks

No retired address-investigation chunk is present in the production assets.

## Residual limitation

The cloud browser could not open `http://127.0.0.1:4273` (`ERR_BLOCKED_BY_CLIENT`), so no claim of browser screenshot or responsive visual inspection is made. The built console was exercised through the real HTTP integration suite, while component navigation was exercised with Testing Library/jsdom.
