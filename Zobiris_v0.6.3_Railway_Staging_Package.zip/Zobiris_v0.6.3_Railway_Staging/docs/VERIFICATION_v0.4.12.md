# Zobiris v0.4.12 verification report

**Checkpoint date:** 2026-08-27  
**Package version:** 0.4.12

## Outcome

The checkpoint adds fail-closed, vendor-neutral Solana and BNB Smart Chain address verification without widening deterministic scoring or introducing a trade path.

## Executed gates

| Gate | Result |
|---|---:|
| Full Vitest suite | 463/463 passed across 65 files |
| Strict TypeScript | Passed |
| Production React build | Passed; 2,544 modules transformed |
| Address investigation UI flow | Passed |
| Static no-trade gate | Passed |

## Contract evidence

- Missing RPC configuration returns `unconfigured` with `exists=null`.
- Valid Solana account responses return `healthy` and `exists=true`.
- BSC `0x` bytecode returns `healthy` and `exists=false`.
- HTTP 429 is classified `RATE_LIMITED` without exposing endpoint URLs.
- An RPC failure or unconfigured provider cannot change registry identity or make a score available.

## External activation state

No public RPC endpoint is bundled or silently selected. Live verification activates only when the server operator explicitly configures the relevant environment variable. This release therefore proves the adapter contract and fail-closed behavior; it does not claim a production provider SLA.
