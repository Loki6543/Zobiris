# Zobiris v0.6.0 — Strategy Engine 2.1 Integration Verification

**Verification date:** 2026-09-04  
**Base source:** `Zobiris_v0.4.13_Source.zip`  
**Integrated subsystem:** Zobiris Strategy Engine 2.1  
**Release type:** source integration checkpoint

## Executive status

The Strategy Engine 2.1 source integration is complete across the real v0.4.13 refresh pipeline, persistence, HTTP API, CLI, Asset Case File source, Command Center source and Kraken execution-liquidity collector.

The dependency-light Strategy 2.1 suite and integration wiring checks pass. The inherited full Vitest suite, complete application TypeScript check and Vite UI rebuild could **not** be run in this container because the npm dependency tree could not be restored: online `npm ci` timed out and offline install failed because required packages (for example `zod`) were not cached.

Accordingly, this report does **not** claim a fully rebuilt production UI or a fresh pass of the inherited v0.4.13 455-test suite.

## Verified gates

### Strategy Engine 2.1 focused suite

Command:

```bash
rm -rf .strategy21-dist
npm run test:strategy21
```

Result:

```text
56 tests
56 pass
0 fail
```

Covered behavior includes:

- observation vs narrative/causal evidence typing;
- primary dependency-root deduplication;
- market-state precedence and hysteresis;
- asset lifecycle / PRE_IGNITION requirements;
- $1,200 maneuver capital vs $1,800 future reserve separation;
- per-asset / meme / cluster limits;
- 20% / 30% / 50% staged execution;
- size-adaptive Kraken liquidity;
- stressed-exit capacity;
- crossed-book rejection;
- round-trip fee cost ceiling;
- negative observed actor impulses;
- inferred political incentives carrying zero direct impulse;
- bounded sensor influence;
- research rank vs executable next-dollar rank;
- legacy target-weight independence;
- truthful Kraken warm-up / WATCH_ONLY behavior.

### Integration contract check

Command:

```bash
node scripts/verify_strategy21_integration.mjs
```

Result:

```text
19/19 integration checks passed
```

The check verifies that the real app source contains the Strategy 2.1 refresh invocation, prior-market-state reload, persistence schema extension, API routes, optional Kraken collector, CLI output, Command Center and Asset Case File source integration, capital separation, legacy-weight independence and fail-closed liquidity controls.

### Changed/new TypeScript syntax parse

The global TypeScript parser was run over 39 changed/new `.ts` / `.tsx` files without loading third-party modules.

```text
Parsed 39 changed/new TypeScript files; syntax failures=0
```

This is a syntax gate only. It is **not** a substitute for the full project typecheck.

### No-trading guard

Command:

```bash
bash scripts/check_no_trading.sh
```

Result:

```text
OK: no executable trading paths found in source.
```

A separate literal scan found no embedded `sk-...` OpenAI API key.

## Strategy 2.1 integration map

### Refresh / ranking

`src/runtime/refresh.ts`

- runs legacy evidence/scoring for continuity;
- loads Strategy 2.1 Kraken history;
- reloads the previous Strategy market state for hysteresis;
- invokes `integrateStrategy21()` before verification/publishing;
- stores R rank (research opportunity) separately from N$ rank (executable next dollar).

### Persistence

`src/strategy21/storage.ts`

Adds SQLite storage for:

- Kraken book snapshots;
- daily Kraken notional;
- previous market state;
- collector rotation state.

Asset-level Strategy data is serialized in the existing ranked-asset snapshot payload. The existing top-level snapshot schema was not destructively migrated; current doctrine is also reflected through the existing regime fields for compatibility.

### Kraken execution-liquidity collector

`src/strategy21/collector.ts`

- public Kraken endpoints only;
- exact USD pair resolution;
- order book + ticker + completed recent trades;
- 9 priority slots + 3 rotating wider-watchlist slots by default;
- active-minute evidence based on completed trade notional;
- no exchange authentication and no trading API.

Optional background sampling is disabled by default and can be enabled with:

```text
ZOBIRIS_STRATEGY21_AUTO_COLLECT=1
ZOBIRIS_STRATEGY21_COLLECT_INTERVAL_MS=300000
```

Overlapping collection passes are suppressed and failures degrade without crashing the server.

### HTTP API

Added:

```text
GET  /api/strategy21
GET  /api/strategy21/liquidity/:symbol
POST /api/strategy21/collect
```

The collection route preserves the existing sensitive-route authentication and rate-limit pattern.

### User interface source

The React source now exposes:

- N$ Best Next Dollar rank;
- R Research Opportunity rank;
- Strategy market doctrine;
- asset state / action;
- Kraken readiness and execution capacity;
- five production factors;
- max next order / max final position;
- staged execution lines;
- explanation and flip/cancel conditions.

## Blocked inherited release gates

### `npm test`

Blocked because `vitest` is not installed after the failed dependency restoration.

```text
sh: vitest: not found
exit 127
```

### `npm run build:ui`

Blocked because `vite` is not installed.

```text
sh: vite: not found
exit 127
```

### `npm run typecheck`

The global TypeScript compiler runs, but the project dependency/type graph is unavailable. Errors begin with missing packages/types such as:

```text
Cannot find module '@openai/agents'
Cannot find module 'zod'
Cannot find module 'react'
Cannot find module 'node:crypto'
```

These results cannot distinguish dependency absence from project-level type problems, so the full typecheck remains **unverified**, not failed-on-code.

### Dependency restoration

Online:

```text
npm ci --ignore-scripts --no-audit --no-fund
```

timed out in the container.

Offline:

```text
npm ci --offline --ignore-scripts --no-audit --no-fund
```

failed because required tarballs were not cached (`zod@4.4.3` was one reported example).

## Prebuilt public UI status

A failed `npm run build:ui` invokes the repository's cleanup step before Vite starts. Because Vite was unavailable, the cleanup removed the inherited compiled assets. The original **v0.4.13 public assets were restored byte-for-byte from the base source package** so this source release does not ship a broken static directory.

Therefore:

- `src/ui/*` contains the v0.6.0 Strategy 2.1 UI integration;
- `public/assets/*` remains the last verified v0.4.13 compiled UI;
- after installing dependencies, run `npm run build:ui` to compile the v0.6.0 React source into `public/`.

This distinction is intentional and must not be represented as a rebuilt v0.6.0 UI artifact.

## Recommended verification on a networked Node environment

Use a Node version satisfying all lockfile package engine requirements, then run:

```bash
npm ci
npm run test:strategy21
npm test
npm run typecheck
npm run build:ui
npm run server
```

Then verify:

1. `/api/health` returns 200;
2. `/api/strategy21` returns doctrine/capital state after refresh;
3. `/api/asset/<symbol>` contains `strategy21`;
4. the Command Center shows R and N$ columns;
5. the Asset Case File displays Strategy 2.1 factors and execution authority;
6. collector warm-up remains WATCH_ONLY until sufficient Kraken history exists.

## Release conclusion

**Verified:** Strategy 2.1 subsystem behavior, source-level real-app integration, syntax of changed files, capital separation and no-trading invariant.

**Not yet verified in this container:** inherited full test suite, complete project typecheck, rebuilt v0.6.0 Vite UI, end-to-end browser QA.
