# Zobiris v0.4.9 verification report

Date: 2026-08-25  
Predecessor: Zobiris v0.4.8, SHA-256 `7998f830b4d2242f7efebece2ad4cbb418b3bf03dcaed4ebeb761acdd833f65e`

## Outcome

v0.4.9 advances the archived WIP into production hardening and full-depth asset intelligence. It adds a directly testable HTTP boundary, reproducible case-file deltas, exact acquisition provenance, governed contradictions/unknowns and a dedicated React Asset Case File workspace.

## Verification gates

| Gate                      | Result                                                              |
| ------------------------- | ------------------------------------------------------------------- |
| Strict TypeScript         | Passed with zero errors                                             |
| Vitest                    | 62 files passed; 444 tests passed                                   |
| Production Vite build     | Passed; 2,543 modules transformed                                   |
| Asset Case File split     | 10.51 KB, 2.90 KB gzip lazy chunk                                   |
| Static no-trade check     | Passed                                                              |
| Archive credential policy | `.env`, `.env.local` and `.env.*` excluded by the release generator |

## Real HTTP verification

`src/tests/server-http-integration.test.ts` starts the actual Zobiris server on an ephemeral port with a fresh SQLite database. It verifies:

- built operator-console delivery and API health;
- two fixture-backed HTTP refreshes;
- 18 observations, 18 governed claims and one outbox event per smoke refresh;
- runtime/storage session continuity and persisted snapshot identity;
- stage 18 succeeds only after atomic persistence;
- BTC case-file rehydration with data mode, eligibility and payload hashes;
- previous-snapshot history and deterministic deltas;
- truthful HTTP 503 when the optional OpenAI Challenger is unconfigured;
- typed HTTP 404 behavior.

The new test found and drove a fix for a real regression: the root SPA route was being rejected by the traversal guard before it could resolve to `public/index.html`.

## Case-file contract

Every per-asset case file now exposes:

- deterministic conclusion, score, confidence, ranks, action and allocation target;
- bull/base/bear conditions and invalidation conditions;
- acquisition mode, endpoint, requested market, payload SHA-256 and analytical eligibility for every visible observation;
- exact counter-evidence and conflicted claim IDs when available;
- explicit unknown, stale, unverified-identity and display-only evidence states;
- change in score, confidence and action against the previous snapshot.

Fallback and quarantined evidence remains visible for audit but is labeled display-only and cannot enter scoring or specialist inputs.

## Frontend QA

The tested interaction flow is:

`Command Center → Asset Case File → Evidence Graph → Challenger → deterministic score unchanged`

The jsdom interaction test passed and the production build emitted the Asset Case File as a conditional lazy chunk. Cloud-browser screenshot QA remains blocked because this workspace refused the local server listener before the browser could connect. Desktop/mobile screenshots, console capture and visual-overflow inspection therefore remain an explicit external QA item rather than a claimed pass.

## OpenAI status

The controlled TypeScript Agents SDK contract and local evals remain green. The configured OpenAI project previously returned HTTP 429 quota/credit exhaustion, so no live Challenger result is claimed or fabricated.

## Preserved authority boundary

- Deterministic Zobiris code alone controls identity, scores, ranks, risk gates and allocation.
- Agents can inspect a bounded ledger and return structured advisory counter-evidence only.
- No server, agent or UI tool has wallet, private-key, order or trade-execution authority.
