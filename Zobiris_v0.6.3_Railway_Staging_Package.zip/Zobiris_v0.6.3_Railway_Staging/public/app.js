// Zobiris SPA — vanilla TS-compiled-to-JS. No build step. Single bundle.
// Hash-based router: #/dashboard, #/assets, #/asset/BTC, #/providers, #/audit, #/specialists
//
// API strategy: try the live /api/* endpoint first. If the fetch fails (e.g. when
// served from a static CDN with no Node server), fall back to the pre-baked JSON
// in /data/*.json. The fallback path is what powers the public demo.

const $ = (sel, root = document) => root.querySelector(sel);
const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));

const STATIC_BASE = "/data";

async function tryApiOrStatic(apiPath, staticFile) {
  try {
    const r = await fetch(apiPath);
    if (r.ok) return await r.json();
  } catch {}
  try {
    const r = await fetch(`${STATIC_BASE}/${staticFile}`);
    if (r.ok) return await r.json();
  } catch {}
  return null;
}

const API = {
  health: () => tryApiOrStatic("/api/health", "health.json"),
  regime: () => tryApiOrStatic("/api/regime", "regime.json"),
  snapshotLatest: () => tryApiOrStatic("/api/snapshot/latest", "snapshot_latest.json"),
  snapshots: (limit = 20) => tryApiOrStatic(`/api/snapshots?limit=${limit}`, "snapshots.json"),
  asset: (symbol) => tryApiOrStatic(`/api/asset/${encodeURIComponent(symbol)}`, `asset_${symbol.toUpperCase()}.json`),
  providers: () => tryApiOrStatic("/api/providers", "providers.json"),
  audit: (limit = 50) => tryApiOrStatic(`/api/audit?limit=${limit}`, "audit.json"),
  dbInfo: () => tryApiOrStatic("/api/db-info", "db-info.json"),
  refresh: (live = false) => fetch(`/api/refresh?live=${live ? 1 : 0}`, { method: "POST" }).then(r => r.json()),
  specialistsSummary: () => tryApiOrStatic("/api/specialists/summary", "specialists_summary.json"),
  calibration: () => tryApiOrStatic("/api/calibration", "calibration.json"),
};

function el(tag, attrs = {}, ...children) {
  const node = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) {
    if (k === "class") node.className = v;
    else if (k === "html") node.innerHTML = v;
    else if (k.startsWith("on") && typeof v === "function") node.addEventListener(k.slice(2).toLowerCase(), v);
    else if (v === true) node.setAttribute(k, "");
    else if (v === false || v == null) { /* skip */ }
    else node.setAttribute(k, v);
  }
  for (const c of children.flat()) {
    if (c == null || c === false) continue;
    node.append(c.nodeType ? c : document.createTextNode(String(c)));
  }
  return node;
}

function fmt(n, d = 2) {
  if (n == null || isNaN(n)) return "—";
  if (Math.abs(n) >= 1e9) return (n / 1e9).toFixed(d) + "B";
  if (Math.abs(n) >= 1e6) return (n / 1e6).toFixed(d) + "M";
  if (Math.abs(n) >= 1e3) return (n / 1e3).toFixed(d) + "k";
  return Number(n).toFixed(d);
}

function pct(n, d = 1) {
  if (n == null || isNaN(n)) return "—";
  return Number(n).toFixed(d) + "%";
}

function timeAgo(ms) {
  const s = Math.floor((Date.now() - ms) / 1000);
  if (s < 60) return s + "s ago";
  if (s < 3600) return Math.floor(s / 60) + "m ago";
  if (s < 86400) return Math.floor(s / 3600) + "h ago";
  return Math.floor(s / 86400) + "d ago";
}

function setStatus(msg, kind = "info") {
  const node = $("#status");
  if (!node) return;
  node.textContent = msg;
  node.className = "status-" + kind;
}

// ---- Regime banner ----
async function loadRegimeBanner() {
  const banner = $("#regime-banner");
  if (!banner) return;
  try {
    const [regime, health] = await Promise.all([API.regime(), API.health()]);
    if (!regime) {
      banner.innerHTML = '<span class="pill">No data — run a refresh to see regime.</span>';
      return;
    }
    const livePill = '<span class="pill live">● live</span>';
    const parts = [
      livePill,
      `regime: <strong>${regime.regime}</strong> (${pct(regime.regimeConfidence)} conf)`,
      `alloc: ${pct(regime.totalAllocatedPct)} + reserve: ${pct(regime.reservePct)} + unalloc: ${pct(regime.unallocatedPct)}`,
      `policy: v${regime.policyVersion}`,
      `asOf: ${timeAgo(regime.asOf)}`,
    ];
    banner.innerHTML = parts.join(" &nbsp;·&nbsp; ");
  } catch (e) {
    banner.innerHTML = '<span class="pill">API unavailable</span>';
  }
}

// ---- Views ----

const DashboardView = {
  async render(root) {
    root.innerHTML = '<div class="empty"><span class="spinner"></span> Loading latest snapshot…</div>';
    const data = await API.snapshotLatest();
    if (!data) {
      root.innerHTML = `
        <div class="empty">
          <h2>No snapshot yet</h2>
          <p>The database is empty. Run a refresh to populate it.</p>
          <button onclick="window.refreshNow()">Run refresh</button>
        </div>`;
      return;
    }
    const snap = data.snapshot;
    const ranked = JSON.parse(snap.rankedAssets || "[]");
    const eligible = ranked.filter(a => a.action !== "AVOID");
    const allocated = ranked.filter(a => a.targetWeight && a.targetWeight.pct > 0);
    const gates = new Set();
    for (const a of ranked) for (const g of (a.riskGates || [])) if (g.active) gates.add(g.code);
    const top5 = eligible.slice(0, 5);

    root.innerHTML = "";
    root.append(
      el("div", { class: "grid cols-4" },
        el("div", { class: "card" },
          el("h2", {}, "Regime"),
          el("div", { class: "big" }, snap.regime),
          el("div", { class: "meta" }, `${pct(snap.regimeConfidence)} confidence`),
        ),
        el("div", { class: "card" },
          el("h2", {}, "Allocated"),
          el("div", { class: "big" }, pct(snap.totalAllocatedPct)),
          el("div", { class: "meta" }, `of ${pct(snap.totalAllocatedPct + snap.reservePct + snap.unallocatedPct)} (with reserve ${pct(snap.reservePct)})`),
        ),
        el("div", { class: "card" },
          el("h2", {}, "Eligible"),
          el("div", { class: "big" }, `${eligible.length}`),
          el("div", { class: "meta" }, `of ${ranked.length} ranked`),
        ),
        el("div", { class: "card" },
          el("h2", {}, "Active Risk Gates"),
          el("div", { class: "big" }, `${gates.size}`),
          el("div", { class: "meta" }, Array.from(gates).join(", ") || "—"),
        ),
      ),
      el("div", { class: "grid cols-2", style: "margin-top: 16px" },
        el("div", { class: "card" },
          el("h2", {}, "Top 10 by Opportunity"),
          el("table", {},
            el("thead", {}, el("tr", {},
              el("th", { class: "num" }, "#"),
              el("th", {}, "Symbol"),
              el("th", { class: "num" }, "Score"),
              el("th", { class: "num" }, "Conf"),
              el("th", {}, "Role"),
              el("th", {}, "Action"),
              el("th", { class: "num" }, "Weight"),
              el("th", {}, "State"),
            )),
            el("tbody", {}, ...ranked.slice(0, 10).map(a =>
              el("tr", { onclick: () => location.hash = "#/asset/" + a.symbol, style: "cursor: pointer" },
                el("td", { class: "num" }, a.opportunityRank ?? "—"),
                el("td", {}, el("a", { href: "#/asset/" + a.symbol }, a.symbol)),
                el("td", { class: "num" }, a.opportunity.adjusted.toFixed(1)),
                el("td", { class: "num" }, pct(a.confidence.pct, 0)),
                el("td", { class: "role-" + a.role }, a.role),
                el("td", { class: "action-" + a.action }, a.action),
                el("td", { class: "num" }, pct(a.targetWeight.pct)),
                el("td", { class: "state-" + a.evidenceState }, a.evidenceState),
              )
            )),
          ),
        ),
        el("div", { class: "card" },
          el("h2", {}, "Top 5 Allocation Targets"),
          allocated.length === 0
            ? el("div", { class: "empty" }, "No allocations yet — eligible assets need stronger evidence to clear risk gates and edge threshold.")
            : el("table", {},
                el("thead", {}, el("tr", {},
                  el("th", { class: "num" }, "#"),
                  el("th", {}, "Symbol"),
                  el("th", {}, "Role"),
                  el("th", { class: "num" }, "Score"),
                  el("th", { class: "num" }, "Weight"),
                  el("th", { class: "num" }, "Conf"),
                )),
                el("tbody", {}, ...allocated.slice(0, 5).map(a =>
                  el("tr", { onclick: () => location.hash = "#/asset/" + a.symbol, style: "cursor: pointer" },
                    el("td", { class: "num" }, a.allocationRank ?? "—"),
                    el("td", {}, el("a", { href: "#/asset/" + a.symbol }, a.symbol)),
                    el("td", { class: "role-" + a.role }, a.role),
                    el("td", { class: "num" }, a.opportunity.adjusted.toFixed(1)),
                    el("td", { class: "num" }, pct(a.targetWeight.pct)),
                    el("td", { class: "num" }, pct(a.confidence.pct, 0)),
                  )
                )),
              ),
        ),
      ),
    );
  }
};

const AssetsView = {
  async render(root) {
    root.innerHTML = '<div class="empty"><span class="spinner"></span> Loading…</div>';
    const data = await API.snapshotLatest();
    if (!data) { root.innerHTML = '<div class="empty">No data yet.</div>'; return; }
    const snap = data.snapshot;
    const ranked = JSON.parse(snap.rankedAssets || "[]");

    let filter = "";
    const update = () => {
      const f = filter.toUpperCase();
      const rows = ranked.filter(a => !f || a.symbol.includes(f) || (a.role || "").includes(f));
      const table = el("table", {},
        el("thead", {}, el("tr", {},
          el("th", { class: "num" }, "#"),
          el("th", {}, "Symbol"),
          el("th", { class: "num" }, "Score"),
          el("th", { class: "num" }, "Conf"),
          el("th", {}, "Role"),
          el("th", {}, "Action"),
          el("th", { class: "num" }, "Weight"),
          el("th", {}, "Risk"),
          el("th", {}, "State"),
          el("th", {}, "Active Gates"),
        )),
        el("tbody", {}, ...rows.map(a => {
          const gates = (a.riskGates || []).filter(g => g.active).map(g => g.code);
          return el("tr", { onclick: () => location.hash = "#/asset/" + a.symbol, style: "cursor: pointer" },
            el("td", { class: "num" }, a.opportunityRank ?? "—"),
            el("td", {}, el("a", { href: "#/asset/" + a.symbol }, a.symbol)),
            el("td", { class: "num" }, a.opportunity.adjusted.toFixed(1)),
            el("td", { class: "num" }, pct(a.confidence.pct, 0)),
            el("td", { class: "role-" + a.role }, a.role),
            el("td", { class: "action-" + a.action }, a.action),
            el("td", { class: "num" }, pct(a.targetWeight.pct)),
            el("td", {}, a.risk),
            el("td", { class: "state-" + a.evidenceState }, a.evidenceState),
            el("td", {}, ...gates.map(g => el("span", { class: "badge bad" }, g))),
          );
        })),
      );
      const old = $("#assets-table"); if (old) old.replaceWith(table);
      table.id = "assets-table";
      $("#asset-count").textContent = `${rows.length} / ${ranked.length}`;
    };

    const filterInput = el("input", { type: "text", placeholder: "Filter by symbol or role…", oninput: (e) => { filter = e.target.value; update(); } });
    const refreshBtn = el("button", { onclick: window.refreshNow }, "Refresh");
    const liveBtn = el("button", { class: "secondary", onclick: () => window.refreshNow(true) }, "Refresh (live Kraken)");
    const count = el("span", { id: "asset-count" }, `${ranked.length} / ${ranked.length}`);

    root.innerHTML = "";
    root.append(
      el("div", { class: "filter-bar" },
        filterInput, refreshBtn, liveBtn,
        el("span", { class: "spacer" }),
        count,
      ),
    );
    const table = el("div", { id: "assets-table" }); root.append(table);
    update();
  }
};

const AssetCaseView = {
  async render(root, symbol) {
    root.innerHTML = '<div class="empty"><span class="spinner"></span> Loading case file…</div>';
    let data;
    try { data = await API.asset(symbol); }
    catch (e) {
      root.innerHTML = `<div class="empty">No data for ${symbol}.<br><br><span class="meta">${String(e)}</span></div>`;
      return;
    }
    if (!data) {
      root.innerHTML = `<div class="empty">${symbol} not in latest snapshot. Try running a refresh.</div>`;
      return;
    }
    const a = data.assetAnalysis;
    if (!a) {
      root.innerHTML = `<div class="empty">${symbol} not in latest snapshot. <br><br>
        <div class="card" style="text-align:left;max-width:600px;margin:0 auto">
        <div class="meta">Available keys: ${Object.keys(data).join(", ")}</div>
        </div></div>`;
      return;
    }
    // Wrap the rest in a try/catch so a render bug shows the actual error
    // instead of leaving the user staring at a "Loading…" spinner.
    try {
      await this._render(root, symbol, data, a);
    } catch (e) {
      console.error("AssetCaseView render error", e);
      root.innerHTML = `<div class="empty">Render failed for ${symbol}.<br><br>
        <div class="card" style="text-align:left;max-width:760px;margin:0 auto">
        <pre class="mono" style="white-space:pre-wrap;font-size:11px">${String(e.stack || e)}</pre>
        <div class="meta" style="margin-top:12px">Last fetched data shape: top-level keys = ${Object.keys(data).join(", ")}; assetAnalysis keys = ${Object.keys(a).join(", ")}; caseFile = ${data.caseFile ? "present" : "MISSING"}.</div>
        </div></div>`;
    }
  },
  async _render(root, symbol, data, a) {

    const conclusion = a.conclusion;
    const factors = a.opportunity.factorScores;
    const gates = (a.riskGates || []).filter(g => g.active);

    root.innerHTML = "";
    root.append(
      el("div", { class: "case-header" },
        el("div", {},
          el("a", { class: "back", href: "#/assets" }, "← back to assets"),
          el("h1", { style: "margin: 8px 0 0" }, `${a.symbol} — Case File`),
        ),
        el("div", {},
          el("span", { class: "badge" }, a.role),
          " ",
          el("span", { class: "badge " + (a.action === "AVOID" ? "bad" : a.action === "BUY" || a.action === "ADD" ? "good" : "warn") }, a.action),
        ),
      ),
      el("div", { class: "conclusion" }, conclusion),
      el("div", { class: "grid cols-2", style: "margin-top: 16px" },
        el("div", { class: "card" },
          el("h2", {}, "Score Anatomy"),
          el("div", { class: "score-anatomy" },
            el("div", {},
              el("div", { class: "meta" }, "Adjusted Score"),
              el("div", { class: "big" }, a.opportunity.adjusted.toFixed(1)),
              el("div", { class: "meta" }, `raw ${a.opportunity.raw.toFixed(1)} − penalty ${a.opportunity.evidenceGapPenalty.toFixed(1)}`),
            ),
            el("div", {},
              el("div", { class: "meta" }, "Confidence"),
              el("div", { class: "big" }, pct(a.confidence.pct, 0)),
              el("div", { class: "meta" }, `coverage ${(a.confidence.inputs.coverage * 100).toFixed(0)}%, freshness ${(a.confidence.inputs.freshness * 100).toFixed(0)}%`),
            ),
          ),
          el("div", { style: "margin-top: 16px" },
            ...factors.map(f => el("div", { class: "factor-bar" },
              el("div", { class: "name" }, f.family),
              el("div", { class: "bar" }, el("div", { class: "fill", style: `width: ${f.raw}%` })),
              el("div", { class: "value" }, f.raw.toFixed(1)),
              el("div", { class: "epistemic state-" + f.epistemicState }, f.epistemicState),
            )),
          ),
        ),
        el("div", { class: "card" },
          el("h2", {}, "Risk Gates & Weight"),
          gates.length === 0
            ? el("div", { class: "meta" }, "No active gates.")
            : el("ul", {}, ...gates.map(g =>
                el("li", {}, el("span", { class: "badge bad" }, g.code), " — ", g.reason, " [", g.effect, "]")
              )),
          el("div", { style: "margin-top: 12px" },
            el("div", { class: "meta" }, "Target Weight"),
            el("div", { class: "big" }, pct(a.targetWeight.pct)),
            el("div", { class: "meta" }, a.targetWeight.explanation),
          ),
          el("div", { style: "margin-top: 12px" },
            el("div", { class: "meta" }, "Risk Classification"),
            el("div", { class: "big" }, a.risk),
            el("div", { class: "meta" }, "Evidence coverage: " + pct(a.evidenceCoverage * 100, 0)),
            a.criticalUnknowns > 0
              ? el("div", { class: "meta" }, a.criticalUnknowns + " critical unknowns")
              : null,
          ),
        ),
      ),
      el("div", { class: "card", style: "margin-top: 16px" },
        el("h2", {}, `Evidence Ledger (${(data.evidence || []).length})`),
        (data.evidence || []).length === 0
          ? el("div", { class: "empty" }, "No evidence claims yet for this asset.")
          : el("table", {},
              el("thead", {}, el("tr", {},
                el("th", {}, "Source"),
                el("th", {}, "Family"),
                el("th", { class: "mono" }, "Claim"),
                el("th", {}, "Epistemic"),
                el("th", { class: "num" }, "Conf"),
                el("th", {}, "Age"),
              )),
              el("tbody", {}, ...data.evidence.map(ev =>
                el("tr", {},
                  el("td", {}, ev.source),
                  el("td", {}, ev.factorFamily),
                  el("td", { class: "mono" }, (ev.claim || "").slice(0, 100)),
                  el("td", { class: "state-" + ev.epistemicState }, ev.epistemicState),
                  el("td", { class: "num" }, (ev.evidenceConfidence * 100).toFixed(0) + "%"),
                  el("td", {}, timeAgo(ev.observedAt)),
                )
              )),
            ),
      ),
      el("div", { class: "card", style: "margin-top: 16px" },
        el("h2", {}, `Recent Observations (${(data.observations || []).length})`),
        (data.observations || []).length === 0
          ? el("div", { class: "empty" }, "No observations yet for this asset.")
          : el("table", {},
              el("thead", {}, el("tr", {},
                el("th", {}, "Provider"),
                el("th", {}, "Event"),
                el("th", {}, "Quarantine"),
                el("th", {}, "Epistemic"),
                el("th", { class: "num" }, "Conf"),
                el("th", {}, "Received"),
              )),
              el("tbody", {}, ...data.observations.map(o =>
                el("tr", {},
                  el("td", {}, o.provider),
                  el("td", {}, o.eventType),
                  el("td", {}, o.quarantineState),
                  el("td", { class: "state-" + o.epistemicState }, o.epistemicState),
                  el("td", { class: "num" }, (o.evidenceConfidence * 100).toFixed(0) + "%"),
                  el("td", {}, timeAgo(o.receivedAt)),
                )
              )),
            ),
      ),
      data.caseFile && data.caseFile.specialist
        ? el("div", { class: "card", style: "margin-top: 16px" },
            el("h2", {}, "Cognitive Specialists (v0.4.0)"),
            el("div", { class: "score-anatomy" },
              el("div", {},
                el("div", { class: "meta" }, "Reconciled Direction"),
                el("div", { class: "big" }, data.caseFile.specialist.reconciledDirection),
                el("div", { class: "meta" }, `confidence ${data.caseFile.specialist.reconciledConfidence}, strength ${data.caseFile.specialist.reconciledStrength.toFixed(2)}`),
              ),
              el("div", {},
                el("div", { class: "meta" }, "Allocation Hint"),
                el("div", { class: "big" }, pct(data.caseFile.specialist.targetWeightPct * 100)),
                el("div", { class: "meta" }, data.caseFile.specialist.vetoed ? `VETOED: ${data.caseFile.specialist.vetoReason}` : "Veto-free"),
              ),
            ),
            el("div", { style: "margin-top: 12px" },
              el("div", { class: "meta" }, `Open Challenges: ${data.caseFile.specialist.openChallenges.length}`),
              data.caseFile.specialist.openChallenges.length > 0
                ? el("ul", {}, ...data.caseFile.specialist.openChallenges.map(c =>
                    el("li", {},
                      el("span", { class: "badge warn" }, c.code),
                      " — ", c.summary,
                    )
                  ))
                : el("div", { class: "meta" }, "No open challenges."),
            ),
            el("h3", { style: "margin-top: 12px" }, "Specialist Opinions"),
            el("table", {},
              el("thead", {}, el("tr", {},
                el("th", {}, "Specialist"),
                el("th", {}, "Type"),
                el("th", {}, "Direction"),
                el("th", {}, "Confidence"),
                el("th", { class: "num" }, "Strength"),
                el("th", {}, "Summary"),
              )),
              el("tbody", {}, ...data.caseFile.specialist.specialistOpinions.map(op =>
                el("tr", {},
                  el("td", {}, op.specialistId),
                  el("td", {}, op.type),
                  el("td", {}, op.direction),
                  el("td", {}, op.confidence),
                  el("td", { class: "num" }, op.strength.toFixed(2)),
                  el("td", {}, op.summary),
                )
              )),
            ),
          )
        : null,
      data.caseFile && (data.caseFile.caveats || []).length > 0
        ? el("div", { class: "card", style: "margin-top: 16px" },
            el("h2", {}, "Honest Disclosures (Caveats)"),
            el("ul", {}, ...data.caseFile.caveats.map(c => el("li", {}, c))),
          )
        : null,
    );
  }
};

/* ------------------------------------------------------------------
 * DeepDiveView — maximum analysis page for an anchor asset.
 * Used for BTC, SOL, and any future "anchor" symbol the operator
 * wants treated as a flagship. Renders every available field from
 * the asset endpoint plus cross-references to providers, regimes,
 * and the latest snapshot. Robust to missing data (shows "UNKNOWN"
 * for any field that the engine couldn't compute).
 * ------------------------------------------------------------------ */
function buildDeepDive(symbol, accentColor) {
  return {
    async render(root) {
      root.innerHTML = '<div class="empty"><span class="spinner"></span> Loading deep dive…</div>';
      // Pull everything in parallel: asset data + snapshot + providers.
      const [data, snapData, provData, specialData] = await Promise.all([
        API.asset(symbol).catch(e => ({ __error: String(e) })),
        API.snapshotLatest().catch(e => null),
        API.providers().catch(e => null),
        API.specialistsSummary().catch(e => null),
      ]);
      if (!data || data.__error) {
        root.innerHTML = `<div class="empty">No data for ${symbol}.<br><br>
          <div class="meta">${data && data.__error ? data.__error : "Asset not in latest snapshot. Run a refresh."}</div></div>`;
        return;
      }
      const a = data.assetAnalysis;
      const c = data.canonical;
      const cf = data.caseFile || {};
      const sp = cf.specialist || {};
      const snap = snapData ? snapData.snapshot : null;
      const ranked = snap ? (JSON.parse(snap.rankedAssets || "[]")) : [];
      const myRow = ranked.find(r => r.symbol === symbol) || a;
      const providers = (provData && provData.providers) || [];
      const provByName = Object.fromEntries(providers.map(p => [p.provider, p]));

      // Factor table sorted by contribution descending
      const factors = (a.opportunity && a.opportunity.factorScores) || [];
      const factorsSorted = [...factors].sort((x, y) => (y.contribution || 0) - (x.contribution || 0));
      const maxContribution = Math.max(1, ...factorsSorted.map(f => Math.abs(f.contribution || 0)));
      const totalContribution = factorsSorted.reduce((s, f) => s + (f.contribution || 0), 0);

      // Confidence components
      const ci = (a.confidence && a.confidence.inputs) || {};

      // Risk gates
      const gates = (a.riskGates || []).filter(g => g.active);
      const inactiveGates = (a.riskGates || []).filter(g => !g.active);

      // Per-provider observations for this asset
      const obsForAsset = (data.observations || []);
      const providerHealthForAsset = {};
      for (const o of obsForAsset) {
        if (!providerHealthForAsset[o.provider]) {
          providerHealthForAsset[o.provider] = { count: 0, lastEvent: null, lastAt: 0, quarantined: 0 };
        }
        const s = providerHealthForAsset[o.provider];
        s.count++;
        if ((o.receivedAt || 0) > s.lastAt) { s.lastAt = o.receivedAt; s.lastEvent = o.eventType; }
        if (o.quarantineState && o.quarantineState !== "verified") s.quarantined++;
      }

      // Per-factor evidence (group data.evidence by factor family)
      const evidenceByFamily = {};
      for (const ev of (data.evidence || [])) {
        const fam = ev.factorFamily || "unknown";
        if (!evidenceByFamily[fam]) evidenceByFamily[fam] = [];
        evidenceByFamily[fam].push(ev);
      }

      root.innerHTML = "";
      root.append(
        // ---- Header ----
        el("div", { class: "case-header", style: `border-left: 6px solid ${accentColor}; padding-left: 16px;` },
          el("div", {},
            el("a", { class: "back", href: "#/dashboard" }, "← back to dashboard"),
            el("h1", { style: "margin: 8px 0 4px" }, `${symbol} Deep Dive`),
            el("div", { class: "meta" }, c.name ? c.name + " · " : ""),
            el("div", { class: "meta" },
              `canonical id: `, el("span", { class: "mono" }, c.id.slice(0, 8) + "…"),
              ` · provenance: `, el("span", { class: "mono" }, c.identityProvenance || "UNKNOWN"),
              ` · mapping: `, el("span", { class: "meta" }, c.mappingStatus + ` (${(c.mappingConfidence * 100).toFixed(0)}%)`),
            ),
          ),
          el("div", {},
            el("span", { class: "badge role-" + a.role }, a.role),
            " ",
            el("span", { class: "badge " + (a.action === "AVOID" ? "bad" : a.action === "BUY" || a.action === "ADD" ? "good" : "warn") }, a.action),
            " ",
            el("span", { class: "badge" }, `Score ${a.opportunity.adjusted.toFixed(1)}`),
            " ",
            el("span", { class: "badge" }, `Conf ${pct(a.confidence.pct, 0)}`),
          ),
        ),

        // ---- Headline conclusion ----
        el("div", { class: "conclusion" }, a.conclusion || "(no conclusion recorded)"),

        // ---- Score Anatomy (full breakdown) ----
        el("div", { class: "card", style: "margin-top: 16px" },
          el("h2", {}, "Score Anatomy (full factor decomposition)"),
          el("div", { class: "score-anatomy" },
            el("div", {},
              el("div", { class: "meta" }, "Raw Score"),
              el("div", { class: "big" }, a.opportunity.raw.toFixed(1)),
              el("div", { class: "meta" }, "Before evidence-gap penalty"),
            ),
            el("div", {},
              el("div", { class: "meta" }, "Evidence Penalty"),
              el("div", { class: "big" }, "−" + a.opportunity.evidenceGapPenalty.toFixed(1)),
              el("div", { class: "meta" }, "For missing/low-quality evidence"),
            ),
            el("div", {},
              el("div", { class: "meta" }, "Adjusted Score"),
              el("div", { class: "big" }, a.opportunity.adjusted.toFixed(1)),
              el("div", { class: "meta" }, "The number that drives allocation"),
            ),
            el("div", {},
              el("div", { class: "meta" }, "Confidence"),
              el("div", { class: "big" }, pct(a.confidence.pct, 0)),
              el("div", { class: "meta" }, "Independent of score; reflects evidence quality"),
            ),
          ),
          el("h3", { style: "margin-top: 16px" }, "Per-Factor Contribution (sorted by impact)"),
          factorsSorted.length === 0
            ? el("div", { class: "empty" }, "No factor scores recorded.")
            : el("div", {},
                ...factorsSorted.map(f => {
                  const fam = f.family;
                  const evidenceForFam = evidenceByFamily[fam] || [];
                  return el("div", { style: "margin: 6px 0" },
                    el("div", { style: "display:flex; justify-content:space-between; font-size: 12px; margin-bottom: 2px" },
                      el("div", {},
                        el("span", { class: "mono" }, fam),
                        ` (weight ${(f.weight * 100).toFixed(0)}%, raw ${f.raw.toFixed(1)})`,
                        " ",
                        el("span", { class: `epistemic state-${f.epistemicState}` }, f.epistemicState),
                        " ",
                        el("span", { class: "meta" }, evidenceForFam.length > 0
                          ? `${evidenceForFam.length} claim${evidenceForFam.length === 1 ? "" : "s"}`
                          : "no claims yet"),
                      ),
                      el("div", { class: "num" }, f.contribution.toFixed(2)),
                    ),
                    el("div", { style: "background: var(--border); border-radius: 4px; height: 14px; overflow: hidden" },
                      el("div", {
                        style: `background: ${accentColor}; width: ${(Math.abs(f.contribution) / maxContribution * 100).toFixed(1)}%; height: 100%;`
                      })
                    ),
                  );
                }),
                el("div", { class: "meta", style: "margin-top: 8px" },
                  `Total contribution: ${totalContribution.toFixed(2)} (target weight scalar-adjusted; see Target Weight below)`,
                ),
              ),
        ),

        // ---- Confidence breakdown ----
        el("div", { class: "card", style: "margin-top: 16px" },
          el("h2", {}, "Confidence Breakdown"),
          el("div", { class: "grid cols-2" },
            el("div", {},
              el("h3", {}, "Inputs"),
              el("table", {},
                el("tbody", {}, ...Object.entries(ci).map(([k, v]) =>
                  el("tr", {},
                    el("td", {}, k),
                    el("td", { class: "num" }, typeof v === "number" ? v.toFixed(2) : String(v)),
                  )
                )),
              ),
            ),
            el("div", {},
              el("h3", {}, "Evidence Coverage"),
              el("div", { class: "big" }, pct((a.evidenceCoverage || 0) * 100, 0)),
              el("div", { class: "meta" }, "Critical unknowns: " + (a.criticalUnknowns || 0)),
              el("div", { class: "meta" }, a.evidenceState || "UNKNOWN"),
            ),
          ),
        ),

        // ---- Risk Gates ----
        el("div", { class: "card", style: "margin-top: 16px" },
          el("h2", {}, `Risk Gates (${gates.length} active, ${inactiveGates.length} clear)`),
          gates.length === 0 && inactiveGates.length === 0
            ? el("div", { class: "empty" }, "No risk gates evaluated.")
            : el("div", {},
                el("div", { class: "meta" }, "Active (these are blocking or capping this asset)"),
                gates.length === 0
                  ? el("div", { class: "empty" }, "None.")
                  : el("ul", {}, ...gates.map(g =>
                      el("li", {},
                        el("span", { class: "badge bad" }, g.code),
                        " — ", g.reason,
                        g.effect === "veto"
                          ? el("span", { class: "badge bad", style: "margin-left:8px" }, "VETO")
                          : g.cap !== undefined
                            ? el("span", { class: "badge warn", style: "margin-left:8px" }, `cap ${(g.cap * 100).toFixed(0)}%`)
                            : null,
                      )
                    )),
                inactiveGates.length > 0
                  ? el("div", { style: "margin-top:12px" },
                      el("div", { class: "meta" }, "Clear (these passed)"),
                      el("div", { class: "meta" },
                        ...inactiveGates.map(g => el("span", { class: "badge good", style: "margin-right:6px" }, g.code))
                      ),
                    )
                  : null,
              ),
        ),

        // ---- Target Weight explanation ----
        el("div", { class: "card", style: "margin-top: 16px" },
          el("h2", {}, "Target Weight — how the engine arrived at this number"),
          el("div", { class: "big" }, pct(a.targetWeight.pct)),
          el("div", { class: "meta", style: "margin-top: 8px" }, a.targetWeight.explanation),
          el("div", { style: "margin-top:12px" },
            el("h3", {}, "Allocation scalars (the math)"),
            el("table", {},
              el("thead", {}, el("tr", {},
                el("th", {}, "Scalar"), el("th", { class: "num" }, "Value"),
              )),
              el("tbody", {}, ...Object.entries(a.targetWeight.scalars || {}).map(([k, v]) =>
                el("tr", {},
                  el("td", {}, k),
                  el("td", { class: "num" }, typeof v === "number" ? v.toFixed(2) : String(v)),
                )
              )),
            ),
          ),
        ),

        // ---- Specialists full breakdown ----
        sp.specialistOpinions ? el("div", { class: "card", style: "margin-top: 16px" },
          el("h2", {}, "Specialist Opinions — full breakdown"),
          el("div", { class: "score-anatomy" },
            el("div", {},
              el("div", { class: "meta" }, "Reconciled Direction"),
              el("div", { class: "big" }, sp.reconciledDirection || "—"),
              el("div", { class: "meta" }, `confidence: ${sp.reconciledConfidence}, strength: ${(sp.reconciledStrength || 0).toFixed(2)}`),
            ),
            el("div", {},
              el("div", { class: "meta" }, "Allocation Hint"),
              el("div", { class: "big" }, pct((sp.targetWeightPct || 0) * 100)),
              el("div", { class: "meta" }, sp.vetoed ? `VETOED: ${sp.vetoReason}` : "Veto-free"),
            ),
          ),
          el("h3", { style: "margin-top:12px" }, "Per-specialist detail"),
          el("table", {},
            el("thead", {}, el("tr", {},
              el("th", {}, "Specialist"),
              el("th", {}, "Type"),
              el("th", {}, "Direction"),
              el("th", {}, "Confidence"),
              el("th", { class: "num" }, "Strength"),
              el("th", {}, "Summary"),
            )),
            el("tbody", {}, ...sp.specialistOpinions.map(op =>
              el("tr", {},
                el("td", { class: "mono" }, op.specialistId),
                el("td", {}, op.type),
                el("td", {}, op.direction),
                el("td", {}, op.confidence),
                el("td", { class: "num" }, (op.strength || 0).toFixed(2)),
                el("td", { style: "max-width:380px" }, op.summary),
              )
            )),
          ),
          (sp.openChallenges || []).length > 0
            ? el("div", { style: "margin-top:12px" },
                el("h3", {}, "Open Challenges from the Challenger"),
                el("ul", {}, ...sp.openChallenges.map(c =>
                  el("li", {},
                    el("span", { class: "badge warn" }, c.code),
                    " — ",
                    c.rationale || c.summary,
                  )
                )),
              )
            : null,
        ) : null,

        // ---- Evidence Ledger (full) ----
        el("div", { class: "card", style: "margin-top: 16px" },
          el("h2", {}, `Evidence Ledger (${(data.evidence || []).length} claims for this asset)`),
          (data.evidence || []).length === 0
            ? el("div", { class: "empty" }, "No evidence claims for this asset in the latest refresh.")
            : el("table", {},
                el("thead", {}, el("tr", {},
                  el("th", {}, "Source"),
                  el("th", {}, "Family"),
                  el("th", { class: "mono" }, "Claim"),
                  el("th", {}, "Epistemic"),
                  el("th", {}, "Claim Origin"),
                  el("th", { class: "num" }, "Conf"),
                  el("th", {}, "Age"),
                )),
                el("tbody", {}, ...data.evidence.map(ev =>
                  el("tr", {},
                    el("td", {}, ev.source),
                    el("td", {}, ev.factorFamily || "—"),
                    el("td", { class: "mono", style: "max-width:380px" }, (ev.claim || "").slice(0, 120)),
                    el("td", { class: "state-" + ev.epistemicState }, ev.epistemicState || "—"),
                    el("td", {}, el("span", { class: "badge" }, ev.claimOrigin || "—")),
                    el("td", { class: "num" }, (ev.evidenceConfidence * 100).toFixed(0) + "%"),
                    el("td", {}, timeAgo(ev.observedAt)),
                  )
                )),
              ),
        ),

        // ---- Observations per provider ----
        el("div", { class: "card", style: "margin-top: 16px" },
          el("h2", {}, `Provider Coverage (${obsForAsset.length} observations for this asset)`),
          obsForAsset.length === 0
            ? el("div", { class: "empty" }, "No provider observations for this asset.")
            : el("table", {},
                el("thead", {}, el("tr", {},
                  el("th", {}, "Provider"),
                  el("th", {}, "Status"),
                  el("th", { class: "num" }, "Obs"),
                  el("th", { class: "num" }, "Quarantined"),
                  el("th", {}, "Last Event"),
                  el("th", {}, "Last Seen"),
                )),
                el("tbody", {}, ...Object.entries(providerHealthForAsset).map(([p, h]) => {
                  const ph = provByName[p] || {};
                  return el("tr", {},
                    el("td", { class: "mono" }, p),
                    el("td", {}, el("span", { class: "badge " + (ph.status === "connected" ? "good" : ph.status === "credentials-needed" ? "warn" : "bad") }, ph.status || "—")),
                    el("td", { class: "num" }, h.count),
                    el("td", { class: "num" }, h.quarantined),
                    el("td", { class: "mono" }, h.lastEvent || "—"),
                    el("td", {}, h.lastAt ? timeAgo(h.lastAt) : "—"),
                  );
                }),
              ),
              providers.length > 0
                ? el("div", { class: "meta", style: "margin-top:8px" },
                    "All configured providers: " + providers.map(p => `${p.provider} (${p.status})`).join(", "),
                  )
                : null,
            ),
        ),

        // ---- Scenarios + invalidation ----
        (cf.scenarios && Object.keys(cf.scenarios).length > 0) || (cf.invalidationConditions && cf.invalidationConditions.length > 0)
          ? el("div", { class: "card", style: "margin-top: 16px" },
              el("h2", {}, "Scenarios & Invalidation Conditions"),
              cf.scenarios && Object.keys(cf.scenarios).length > 0
                ? el("div", {},
                    el("h3", {}, "Scenarios"),
                    ...Object.entries(cf.scenarios).map(([name, sc]) => {
                      // sc can be null when no live evidence supports a scenario
                      if (!sc) {
                        return el("div", { style: "margin: 8px 0" },
                          el("div", { class: "meta" },
                            el("b", {}, name.toUpperCase()),
                            " — engine did not produce a scenario thesis (insufficient live evidence)",
                          ),
                        );
                      }
                      return el("div", { style: "margin: 8px 0" },
                        el("div", { class: "meta" },
                          el("b", {}, name.toUpperCase()),
                          sc.probability ? ` · ${(sc.probability * 100).toFixed(0)}% probability` : "",
                        ),
                        sc.thesis ? el("div", {}, sc.thesis) : null,
                        sc.targetWeight ? el("div", { class: "meta" }, `target weight: ${(sc.targetWeight * 100).toFixed(0)}%`) : null,
                      );
                    }),
                  )
                : null,
              (cf.invalidationConditions || []).length > 0
                ? el("div", { style: "margin-top:12px" },
                    el("h3", {}, "What would change this view"),
                    el("ul", {}, ...cf.invalidationConditions.map(c =>
                      el("li", {}, typeof c === "string" ? c : (c.description || c.code || JSON.stringify(c)))
                    )),
                  )
                : null,
            )
          : null,

        // ---- Honest disclosures ----
        (cf.caveats || []).length > 0
          ? el("div", { class: "card", style: "margin-top: 16px" },
              el("h2", {}, "Honest Disclosures (Caveats)"),
              el("ul", {}, ...cf.caveats.map(c => el("li", {}, c))),
            )
          : null,

        // ---- Cross-checks vs other top assets ----
        ranked.length > 1
          ? el("div", { class: "card", style: "margin-top: 16px" },
              el("h2", {}, `Cross-checks (vs top 10 by score)`),
              el("table", {},
                el("thead", {}, el("tr", {},
                  el("th", { class: "num" }, "#"),
                  el("th", {}, "Symbol"),
                  el("th", { class: "num" }, "Score"),
                  el("th", { class: "num" }, "Conf"),
                  el("th", {}, "Role"),
                  el("th", {}, "Action"),
                  el("th", { class: "num" }, "Weight"),
                )),
                el("tbody", {}, ...ranked.slice(0, 10).map(r =>
                  el("tr", { style: r.symbol === symbol ? `background: ${accentColor}22; font-weight: 600;` : "" },
                    el("td", { class: "num" }, r.opportunityRank ?? "—"),
                    el("td", {}, el("a", { href: "#/asset/" + r.symbol }, r.symbol)),
                    el("td", { class: "num" }, r.opportunity.adjusted.toFixed(1)),
                    el("td", { class: "num" }, pct(r.confidence.pct, 0)),
                    el("td", { class: "role-" + r.role }, r.role),
                    el("td", { class: "action-" + r.action }, r.action),
                    el("td", { class: "num" }, pct(r.targetWeight.pct)),
                  )
                )),
              ),
            )
          : null,

        // ---- Footer: link to standard case file page ----
        el("div", { class: "card", style: "margin-top: 16px" },
          el("div", { class: "meta" },
            "Standard case file view: ",
            el("a", { href: "#/asset/" + symbol }, `#/asset/${symbol}`),
            " · ",
            "Last refresh: ",
            el("span", { class: "mono" }, a.asOf ? new Date(a.asOf).toLocaleString() : "—"),
          ),
        ),
      );
    }
  };
}

const BtcDeepDive = buildDeepDive("BTC", "#f7931a");
const SolDeepDive = buildDeepDive("SOL", "#9945ff");

const SpecialistsView = {
  async render(root) {
    root.innerHTML = '<div class="empty"><span class="spinner"></span> Loading…</div>';
    let data;
    try { data = await API.specialistsSummary(); }
    catch (e) { root.innerHTML = `<div class="empty">No specialist data. Run a refresh first.</div>`; return; }
    const agg = data.aggregate || {};
    root.innerHTML = "";
    root.append(
      el("div", { class: "case-header" },
        el("h1", {}, "Cognitive Specialists"),
        el("span", { class: "meta" }, `as of ${data.asOf ? new Date(data.asOf).toLocaleString() : "—"}`),
      ),
      el("div", { class: "grid cols-3", style: "margin-top: 16px" },
        el("div", { class: "card" },
          el("div", { class: "meta" }, "Orchestrated"),
          el("div", { class: "big" }, data.orchestratedAssets),
          el("div", { class: "meta" }, `of ${data.totalAssets} ranked assets`),
        ),
        el("div", { class: "card" },
          el("div", { class: "meta" }, "Specialist Allocation"),
          el("div", { class: "big" }, pct(agg.totalAllocatedPct * 100, 1)),
          el("div", { class: "meta" }, `Reserve ${pct(agg.reservePct * 100, 1)}`),
        ),
        el("div", { class: "card" },
          el("div", { class: "meta" }, "Vetoes / Challenges"),
          el("div", { class: "big" }, `${(agg.vetoedAssets || []).length} / ${agg.challengeCount || 0}`),
          el("div", { class: "meta" }, (agg.vetoedAssets || []).slice(0, 3).join(", ") || "no vetoes"),
        ),
      ),
      el("div", { class: "card", style: "margin-top: 16px" },
        el("h2", {}, `Specialist Verdicts (${(data.results || []).length})`),
        el("table", {},
          el("thead", {}, el("tr", {},
            el("th", {}, "Symbol"),
            el("th", {}, "Direction"),
            el("th", { class: "num" }, "Strength"),
            el("th", {}, "Confidence"),
            el("th", { class: "num" }, "Allocation"),
            el("th", {}, "Vetoed?"),
            el("th", { class: "num" }, "Challenges"),
            el("th", { class: "num" }, "Opinions"),
          )),
          el("tbody", {}, ...(data.results || []).map(r =>
            el("tr", {},
              el("td", {}, el("a", { href: `#/asset/${r.symbol}` }, r.symbol)),
              el("td", {}, r.reconciled ? r.reconciled.direction : "—"),
              el("td", { class: "num" }, r.reconciled ? r.reconciled.strength.toFixed(2) : "—"),
              el("td", {}, r.reconciled ? r.reconciled.confidence : "—"),
              el("td", { class: "num" }, pct((r.allocation?.targetWeightPct || 0) * 100, 2)),
              el("td", {}, r.vetoed ? el("span", { class: "badge bad" }, "VETO") : "—"),
              el("td", { class: "num" }, r.openChallengeCount),
              el("td", { class: "num" }, r.opinionCount),
            )
          )),
        ),
      ),
    );
  }
};

const ProvidersView = {
  async render(root) {
    root.innerHTML = '<div class="empty"><span class="spinner"></span> Loading…</div>';
    const data = await API.providers();
    const providers = data.providers || [];
    root.innerHTML = "";
    root.append(
      el("div", { class: "card" },
        el("h2", {}, "Provider Health & Circuit Breakers"),
        el("table", {},
          el("thead", {}, el("tr", {},
            el("th", {}, "Provider"),
            el("th", {}, "Status"),
            el("th", {}, "Freshness"),
            el("th", {}, "Circuit"),
            el("th", { class: "num" }, "Fails"),
            el("th", {}, "Last Error"),
            el("th", {}, "Last Updated"),
          )),
          el("tbody", {}, ...providers.map(p =>
            el("tr", {},
              el("td", {}, p.provider),
              el("td", {}, el("span", { class: "badge " + (p.status === "connected" ? "good" : p.status === "credentials-needed" ? "warn" : "bad") }, p.status)),
              el("td", {}, p.freshness),
              el("td", { class: "circuit-" + p.circuitState }, p.circuitState),
              el("td", { class: "num" }, p.consecutiveFailures),
              el("td", { class: "mono" }, p.lastErrorClass || "—"),
              el("td", {}, p.updatedAt ? timeAgo(p.updatedAt) : "—"),
            )
          )),
        ),
      ),
    );
  }
};

const AuditView = {
  async render(root) {
    root.innerHTML = '<div class="empty"><span class="spinner"></span> Loading…</div>';
    const data = await API.audit(100);
    const events = data.events || [];
    root.innerHTML = "";
    root.append(
      el("div", { class: "card" },
        el("h2", {}, `Audit Trail (${events.length} most recent)`),
        el("table", {},
          el("thead", {}, el("tr", {},
            el("th", {}, "When"),
            el("th", {}, "Type"),
            el("th", {}, "Session"),
            el("th", { class: "mono" }, "Payload"),
          )),
          el("tbody", {}, ...events.map(e =>
            el("tr", {},
              el("td", {}, new Date(e.at).toLocaleString()),
              el("td", {}, el("span", { class: "badge" }, e.eventType)),
              el("td", { class: "mono" }, (e.sessionId || "—").slice(0, 24)),
              el("td", { class: "mono" }, JSON.stringify(e.payload || {}).slice(0, 80)),
            )
          )),
        ),
      ),
    );
  }
};

// ---- Router ----

const routes = {
  "dashboard": { view: DashboardView, nav: "dashboard" },
  "assets": { view: AssetsView, nav: "assets" },
  "specialists": { view: SpecialistsView, nav: "specialists" },
  "providers": { view: ProvidersView, nav: "providers" },
  "audit": { view: AuditView, nav: "audit" },
  "btc": { view: BtcDeepDive, nav: "btc" },
  "sol": { view: SolDeepDive, nav: "sol" },
};

function navigate() {
  const hash = location.hash.replace(/^#\/?/, "") || "dashboard";
  const [path, ...rest] = hash.split("/");
  $$("nav a").forEach(a => a.classList.toggle("active", a.dataset.route === path));
  const root = $("#view");
  if (path === "asset" && rest[0]) {
    AssetCaseView.render(root, rest[0].toUpperCase());
  } else {
    const route = routes[path] || routes.dashboard;
    route.view.render(root);
  }
}

window.refreshNow = async (live = false) => {
  setStatus(live ? "Refreshing (live Kraken)…" : "Refreshing (fixtures)…");
  try {
    const r = await API.refresh(live);
    setStatus(`Refresh OK in ${r.elapsedMs}ms — ${r.observationCount} obs, ${r.evidenceClaimCount} claims, ${r.providerHealth.length} providers.`, "ok");
    await loadRegimeBanner();
    navigate();
  } catch (e) {
    setStatus("Refresh failed: " + e, "err");
  }
};

window.addEventListener("hashchange", navigate);
window.addEventListener("DOMContentLoaded", () => {
  loadRegimeBanner();
  navigate();
  setInterval(loadRegimeBanner, 30_000); // refresh regime banner every 30s
});
