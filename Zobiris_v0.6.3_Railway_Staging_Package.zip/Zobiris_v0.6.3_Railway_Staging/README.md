# Zobiris Intelligence Engine v0.6.3 — Reconciled Audit-Fix Source

> **Reconciliation provenance (2026-09-06):** this full source tree was reconstructed from the v0.6.2 source archive available in the workspace and the v0.6.3 audit-fix report. The originally reported v0.6.3 full source tree was not present; only report/doc stubs were present. The fixes in this package were re-applied to the v0.6.2 baseline and freshly verified where possible. See `RECONCILIATION_NOTE.md`.

Evidence-first crypto decision support for the user's canonical CoinMarketCap watchlist. v0.6.1 builds on v0.6.0 by integrating a **Behavioral Personality Engine** into **Strategy Engine 2.1** into the existing Zobiris refresh, persistence, case-file, API and React UI architecture.

**Zobiris does not have wallet custody, private-key signing, leverage, order submission or autonomous trade execution. The engine commits to an analysis; the user decides.**

## What changed in v0.6.1

Strategy 2.1 separates questions that older scoring systems often collapse together:

1. **What state is the market in?**
2. **What state is this specific asset in?**
3. **Is the asset executable at the proposed dollar size?**
4. **Is it attractive for research?**
5. **Is it a good next dollar now?**
6. **How much currently funded capital is actually authorized?**
7. **What evidence would change the call?**

The prior deterministic Opportunity Score remains visible for continuity, but it no longer acts as the sole strategy authority.

### Behavioral Personality Engine

Zobiris now models recurring coin behavior as a rolling regime rather than a permanent nickname. Current classes include `INDEPENDENT_LEADER`, `BREAKOUT_SPRINTER`, `DIP_EATER`, `MOMENTUM_CASCADE`, `BTC_SHADOW`, `MEAN_REVERTER`, `SLOW_ACCUMULATOR`, `NARRATIVE_ROCKET`, `CAPITULATION_REBOUNDER`, and the safety-oriented `LIQUIDITY_TRAP`.

The new **Elastic Strength** metric measures whether an asset resists BTC-down pressure while holding support, preserving spot participation, and avoiding leverage crowding. Historical personality match remains `HIGH / MEDIUM / LOW / INSUFFICIENT`; Zobiris does not display a fake probability until point-in-time walk-forward calibration exists.

**Important:** personality is currently `DESCRIPTIVE_ONLY`. It improves explainability and monitoring but cannot increase confidence, bypass eligibility, authorize an execution line, or increase position size.

## Strategy 2.1 pipeline

```text
provider observations / governed evidence
                ↓
primary dependency control
                ↓
market-state engine
                ↓
asset-state engine
                ↓
Kraken size-aware execution eligibility
                ↓
five orthogonal production factors
                ↓
capital + concentration authority
                ↓
PROBE → ACCUMULATE → CONFIRMED TREND
                ↓
behavioral personality / Elastic Strength
                ↓
existing portfolio snapshot / case file / React UI
```

### Market states

| Internal state | UI doctrine |
|---|---|
| `UNCERTAIN` | Reconnaissance |
| `DELEVERAGED_ACCUMULATION` | Ambush / Elastic Defense |
| `BROAD_EXPANSION` | Offensive Rotation |
| `LEVERAGED_EXPANSION` | Elastic Offense |
| `EUPHORIA` | Strategic Retreat |
| `DETERIORATION` | Controlled Retreat |
| `CAPITULATION` | Valley Forge |
| `SYSTEMIC_BREAK` | Regime Break |

### Asset states

`INELIGIBLE → RESEARCH → PRE_IGNITION → PROBE → ACCUMULATE → CONFIRMED_TREND → EXTENDED / HARVEST / DETERIORATING`, with `QUARANTINED` overriding positive setup evidence.

### Five production factors

- Fundamental Trajectory
- Execution Quality
- Flow / Setup
- Discovery / Catalyst
- Loss Resilience

Signals have one primary dependency root (`EXECUTION`, `SPOT_FLOW`, `LEVERAGE`, `PRICE_STRUCTURE`, `FUNDAMENTALS`, `TOKEN_SUPPLY`, `NARRATIVE`, or `MACRO`) so one underlying impulse cannot masquerade as many independent confirmations.

## Research rank vs Best Next Dollar

The Command Center now exposes two separate rankings:

- **R rank — Research Opportunity:** attractiveness worth investigating even if execution evidence is incomplete.
- **N$ rank — Best Next Dollar:** only available when the Strategy 2.1 execution, confidence, state and capital gates authorize incremental exposure.

A legacy `0%` target weight cannot automatically suppress a valid new Strategy 2.1 candidate, and a high legacy score cannot bypass the new execution gates.

## Capital model

The three capital amounts are kept separate:

```text
$1,500  current maneuver capital
$1,800  future strategic reserve (not current buying power)
$3,000  eventual portfolio target after reserve is funded/authorized
```

The market state produces a **ceiling**, not a spending target. Cash is always a valid output.

Strategy 2.1 also enforces concentration limits, including separate meme-asset limits and dependency-cluster caps. Staged execution is:

```text
Line 1  20%  PROBE
Line 2  30%  ACCUMULATE
Line 3  50%  CONFIRMED_TREND
```

A lower price by itself cannot authorize the next line.

## Kraken execution-liquidity warm-up

Headline exchange volume is not treated as proof that a planned position can be exited. Strategy 2.1 stores public Kraken USD order-book snapshots, recent completed-trade activity and daily notional history, then evaluates the proposed order size and full final position.

Until sufficient history exists, the asset remains `WATCH_ONLY` for executable next-dollar purposes instead of fabricating liquidity confidence. Research ranking can still remain available.

### Manual collection

Authenticated server route:

```text
POST /api/strategy21/collect
```

### Optional background collection

Set in `.env.local`:

```bash
ZOBIRIS_STRATEGY21_AUTO_COLLECT=1
ZOBIRIS_STRATEGY21_COLLECT_INTERVAL_MS=300000
ZOBIRIS_KRAKEN_FEE_BPS=40
```

The default collection plan keeps 9 priority slots and rotates 3 slots through the wider watchlist. The interval has a hard one-minute minimum, overlapping collection runs are suppressed, and collector failures do not crash the server.

`ZOBIRIS_KRAKEN_FEE_BPS` is an **estimated fee assumption per side** used in round-trip execution-cost analysis. Set it to the appropriate account/tier assumption; Zobiris does not log into Kraken.

## Actor Board and sensors

The Actor Board distinguishes **observed action** from **inferred incentive**. Inferred political or institutional motives can raise monitoring priority but have direct actor impulse `0` until observable action exists.

Sensor assets/series can request confirmation or modestly update monitoring, but cannot:

- bypass identity or liquidity gates;
- create `PRE_IGNITION` alone;
- authorize an execution line;
- count as independent evidence when they share the target's dependency root.

## Stack

- Node 22, strict TypeScript, Zod, Vitest
- Drizzle ORM + SQLite
- React 18, Vite, Tailwind, shadcn/ui, TanStack Query, Recharts
- OpenAI Agents SDK for the optional server-side Challenger

## Quick start

```bash
npm ci
npm run test:strategy21
npm test
npm run typecheck
npm run build:ui
npm run server
```

Open `http://127.0.0.1:4273`. The server loads `.env.local` when present. Never commit real credentials.

## Operator surfaces

- **Command Center** — watchlist-wide Strategy doctrine, R rank, N$ rank, allocation authority and provider state.
- **Asset Case File** — Strategy state, five factors, Behavioral Personality + Elastic Strength, execution capacity, staged lines, Actor/Sensor evidence, contradictions and explicit flip/cancel conditions.
- **Evidence Graph** — provider → evidence → dependency family → deterministic factor trace.
- **Challenger** — governed OpenAI advisory layer outside deterministic scoring authority.

## HTTP API

```text
GET  /api/health
GET  /api/watchlist
GET  /api/snapshot/latest
GET  /api/snapshot/:id
GET  /api/snapshots?limit=N
GET  /api/asset/:symbol
GET  /api/providers
GET  /api/audit?limit=N
GET  /api/db-info
GET  /api/regime
GET  /api/strategy21
GET  /api/strategy21/liquidity/:symbol
POST /api/strategy21/collect
POST /api/refresh?live=1
POST /api/agents/challenge
```

Sensitive mutation/advisory routes keep the existing Bearer-auth and rate-limit controls.

## Commands

```bash
npm run refresh
npm run test:strategy21      # dependency-light Strategy 2.1 focused suite
npm test                     # inherited complete Vitest suite
npm run typecheck
npm run build:ui
npm run server
npm run release
```

## Verification note

The Strategy 2.1 focused suite is designed to run independently of the UI dependency graph. The full inherited suite, full application typecheck and Vite build still require a complete `npm ci` installation.

The canonical integrated Strategy 2.1 specification is at:

`docs/strategy21/ZOBIRIS_2_1_FINAL_SPEC.md`
