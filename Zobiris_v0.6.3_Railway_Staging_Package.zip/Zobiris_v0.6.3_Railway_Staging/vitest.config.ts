import { defineConfig } from "vitest/config";
import { fileURLToPath, URL } from "node:url";

export default defineConfig({
  resolve: {
    alias: { "@": fileURLToPath(new URL("./src/ui", import.meta.url)) },
  },
  test: {
    environment: "node",
    testTimeout: 15_000,
    include: ["src/tests/**/*.test.{ts,tsx}"],
    globals: false,
  },
});
