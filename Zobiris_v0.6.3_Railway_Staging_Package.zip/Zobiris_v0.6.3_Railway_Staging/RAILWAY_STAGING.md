# Railway Hobby staging — v0.6.3

Prepared September 7, 2026. Hosting choice approved. Hosted release gate remains pending.

## Deploy this folder

Use a Railway Hobby project with an environment named `staging`. Deploy this entire source folder as one Node service. `railway.json` selects `Dockerfile.staging`, one replica in one region, `/api/health`, and a bounded failure-restart policy. Do not add another region or replica. No static-only deployment.

Attach a persistent volume at `/data` before the first deployment. Set these service variables in Railway:

```text
NODE_ENV=production
HOST=0.0.0.0
PORT=3000
ZOBIRIS_DB_PATH=/data/zobiris.sqlite
ZOBIRIS_ALLOW_ANONYMOUS_REFRESH=0
ZOBIRIS_ALLOW_LIVE_PROVIDERS=0
ZOBIRIS_STRATEGY21_AUTO_COLLECT=0
RAILWAY_RUN_UID=0
```

Also set `ZOBIRIS_REFRESH_TOKEN` to a newly generated cryptographically random secret in Railway's variable manager. Never put it in source, logs, browser storage, screenshots, or a URL. No trading credentials are needed. The baseline has live providers disabled, so empty/unavailable data is expected and must be labelled honestly.

Railway mounts volumes as root at runtime, hiding the build-time `/data` permissions. `RAILWAY_RUN_UID=0` follows Railway's documented compatibility option for the existing image's `USER node`. This is a staging-only runtime setting; the server code and token controls are unchanged. Confirm volume writability in deployment logs.

Create the service's Railway HTTPS domain with target port 3000. Keep the entire UI and `/api/*` on this origin. A volume is configured in Railway, not created by `railway.json`. Confirm the dashboard shows exactly one instance and the attached volume before certification.

## Hosted release gate (must be performed on the Railway URL)

1. Save Railway project/environment/service IDs, deployment ID, source checksum, build log, startup log, URL, region and replica count. Verify Node 24 native `better-sqlite3` installation succeeds. Docker has not been built in this workspace.
2. Run `node scripts/check_staging_security.mjs https://YOUR-RAILWAY-ORIGIN` and retain output. It checks health JSON plus anonymous and incorrect-token rejection on all three mutation routes. The origin must be staging: a broken guard could execute a mutation.
3. Repeat with production anonymous-refresh opt-in set to `1`, then restore `0` and repeat. A separate positive test must reach a protected handler with the valid secret, injected securely and never printed. An authorization error on the positive test is a failure.
4. Confirm unknown API routes return JSON errors rather than the SPA. Verify the UI bundle and API responses do not contain the secret.
5. Create a clearly labelled staging-only record through an authorized application flow. Record its ID, restart the Railway service, and prove the same record survives. Confirm `/data/zobiris.sqlite` and SQLite WAL sidecars are on the attached volume. Retain evidence; a health response alone does not prove persistence.
6. After HTTP/security checks pass, use a rendered browser at desktop and mobile widths. Verify the homepage, watchlist, case file, evidence and Challenger controls; inspect empty/error states, console errors, failed requests and readable layouts. Save screenshots and findings, redacting secrets. Public staging must use synthetic test data only; read endpoints are not a private-portfolio boundary.
7. Record every staging-only fix, rerun affected tests, and repeat hosted gates after redeployment. Mark PASS only with actual hosted evidence.

Historical Kraken L2 development stays paused until all hosted gates pass. Existing no-trading and authority separation remain mandatory. A current order book is never historical certification.

## Account and cost

No Railway account connection, CLI login or Railway credential is available in the current workspace. Deployment and billing have not been initiated. Sign in on your computer; do not paste access tokens into chat. The prepared folder can be deployed using Railway's authenticated CLI or a connected source repository.

Hobby has a $5/month minimum credited toward usage; usage can exceed $5. Volume capacity is not a promise of free storage. Confirm the actual project usage limit in Railway before running it continuously. Pro is not required for this checkpoint.

Official references checked September 7, 2026:
- https://docs.railway.com/pricing
- https://docs.railway.com/volumes
- https://docs.railway.com/config-as-code/reference
