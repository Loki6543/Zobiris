#!/usr/bin/env python3
"""Build the v0.4.4 PDF deliverable — audit re-audit close-out."""
import json
from pathlib import Path
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak
from reportlab.lib import colors
from reportlab.lib.units import inch

ROOT = Path("/workspace/zobiris_core")
OUT = ROOT / "downloads" / "Zobiris_v0.4.4_Full_Deliverable.pdf"
OUT.parent.mkdir(exist_ok=True)

# Read the manifest so the PDF reflects the actual verified state.
manifest = json.loads((ROOT / "downloads" / "MANIFEST.json").read_text())
ZIP_SHA = manifest["sourceZipSha256"]
TEST_COUNT = manifest["testCount"]
VERSION = manifest["version"]

styles = getSampleStyleSheet()
H1 = styles["Heading1"]
H2 = styles["Heading2"]
H3 = styles["Heading3"]
BODY = styles["BodyText"]
MONO = ParagraphStyle("mono", parent=styles["Code"], fontSize=8, leading=10, leftIndent=12)

doc = SimpleDocTemplate(str(OUT), pagesize=letter, leftMargin=0.6*inch, rightMargin=0.6*inch, topMargin=0.6*inch, bottomMargin=0.6*inch)
story = []

story.append(Paragraph(f"Zobiris Intelligence Engine v{VERSION}", H1))
story.append(Paragraph("Independent source audit RE-AUDIT close-out", H2))
story.append(Paragraph(
    "Production-quality multi-chain crypto portfolio intelligence. Decision support only — no wallet, no keys, no trade execution. "
    + f"This release closes the v0.4.4 audit re-audit (6 P0 + 8 P1 + 26 required regression tests). v0.4.1 and v0.4.2 are NOT P0-clean per the re-audit; only v{VERSION} has the real fix.",
    BODY
))
story.append(Spacer(1, 0.15*inch))

# Build summary
story.append(Paragraph("Build summary", H2))
summary_data = [
    ["Tests passing", f"{TEST_COUNT} / {TEST_COUNT}", f"typecheck passed, manifest bound to actual run (+{TEST_COUNT - 366} new vs v0.4.2)"],
    ["TypeScript errors", "0", "tsc --noEmit clean (verified by build_manifest.mjs)"],
    ["Live provider paths", "5 + 1", "Kraken, CMC v3, LunarCrush v4, CoinGlass v4, CoinMarketCal v2, Soofi S"],
    ["Watchlist", "50 (current CMC)", "stable from v0.4.2; identity_provenance column added"],
    ["Outbox", "atomic", "persistRefresh still wrapped in db.transaction()"],
    ["Canonical IDs", "IMMUTABLE", "v0.4.4: canonical_asset_aliases + identity_merge_history; id never changes when stronger identity is learned"],
    ["Quarantine", "ENFORCED", "v0.4.4: ambiguous/quarantined observations cannot affect scoring, factor confidence, specialists, ranks, target weights"],
    ["Live fallback", "truthful", "v0.4.4: FetchResult.dataMode = 'live' | 'snapshot' | 'fallback'; fallback is degraded, not succeeded"],
    ["Build artifact", "source ZIP", f"{manifest['sourceZipBytes']:,} bytes, {len(manifest['files'])} files"],
    ["ZIP SHA-256", ZIP_SHA[:32] + "...", "verified against SHA256SUMS.txt"],
]
t = Table(summary_data, colWidths=[2*inch, 2.5*inch, 2.5*inch])
t.setStyle(TableStyle([
    ("BACKGROUND", (0, 0), (-1, 0), colors.lightgrey),
    ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
    ("FONTSIZE", (0, 0), (-1, -1), 9),
    ("VALIGN", (0, 0), (-1, -1), "TOP"),
]))
story.append(t)
story.append(Spacer(1, 0.2*inch))

# P0 fixes
story.append(Paragraph(f"P0 fixes — v{VERSION} audit re-audit (2026-08-22)", H2))
p0_fixes = [
    ("#1 Quarantine enforcement", "v0.4.2 labeled ticker-only matches 'ambiguous' but the downstream buildEvidenceSummaries() and specialist orchestrator still passed them through. v0.4.4 introduces EvidenceEligibility (eligible | display_only_ambiguous | quarantined | rejected) and a partitionObservationsByEligibility() gate. Specialists now record excludedObservations.ambiguous + .quarantined counts. The server rehydration path no longer hard-codes quarantineState='verified'."),
    ("#2 CMC v3 contract", "v0.4.2 called /v1/cryptocurrency/quotes/latest?symbol= and treated the response map key as the numeric CMC id. v0.4.4 wires /v3/cryptocurrency/quotes/latest?id=1,1027,... and uses entry.id (not the map key). When no canonical assets are supplied, the historical symbol=BTC,ETH,SOL fallback is used."),
    ("#3 CoinGlass v4 contract", "v0.4.2 used legacy v2 fields (createTime, fundingRate, exchangeName). v0.4.4 reads the v4 OHLC shape (time, open, high, low, close) for funding and (aggregated_long_liquidation_usd, aggregated_short_liquidation_usd) for liquidations. The v4 funding endpoint requires a per-exchange trading pair (BTCUSDT), which the runtime now appends. Timestamps are auto-detected as ms vs seconds via the new normalizeTimestampToIso() helper. The millisecond-multiply bug is fixed."),
    ("#4 CoinMarketCal v2 contract", "v0.4.2 used ?max=100&page=1 (v1). v0.4.4 uses limit=100 with cursor pagination via meta.cursor. The v2 event.id is a STRING (not number). coins[].slug is the documented identity (tickers collide). For estimated/future events, sourceTimestamp is lastVerifiedAt (NOT event.date) — the event date is kept in the payload."),
    ("#5 LunarCrush v4 contract", "v0.4.2 expected a nested data.coins[].metrics shape. v0.4.4 reads the v4 flat data[] array with v4 field names (social_volume_24h, interactions_24h, percent_change_24h). The list/v1 endpoint is CACHED; v0.4.4 marks freshnessHint='delayed' and uses config.generated as the source timestamp (per-row time is usually absent in v4)."),
    ("#6 Live fallback provenance", "v0.4.2 could fall through to fixture without exposing that to the runtime. v0.4.4 FetchResult carries dataMode (live | snapshot | fallback) + fallbackReason. The runtime forces hadFailure=true when any result is 'fallback', so the stage is 'degraded' not 'succeeded'."),
    ("#7 Immutable canonical IDs", "v0.4.2 IDs were derived from the strongest identity information currently known — when a stronger identity was discovered, the ID changed, orphaning historical observations. v0.4.4 introduces canonical_asset_aliases + identity_merge_history. The canonicalAssetId is IMMUTABLE; new identity is APPENDED to aliases. upsertCanonicalAsset() records identity_provenance; appendCanonicalAlias() adds new aliases without changing the id; identity collisions are recorded in identity_merge_history."),
]
for tag, text in p0_fixes:
    story.append(Paragraph(f"<b>{tag}:</b> {text}", BODY))
    story.append(Spacer(1, 0.05*inch))

story.append(PageBreak())

# Required regression tests
story.append(Paragraph(f"v{VERSION} required regression tests", H2))
audit_tests_data = [
    ["Test file", "Tests", "Audit item covered"],
    ["src/tests/quarantine-enforcement.test.ts", "3", "P0 #1: ambiguous cannot affect scoring, partitioned before specialists"],
    ["src/tests/persistence-symbol-fallback.test.ts", "1", "P0 #1: persistence fallback is quarantined, not verified"],
    ["src/tests/identity-immutable-id.test.ts", "4", "P0 #7: id never changes; alias append; collision recorded"],
    ["src/tests/cmc-v3-real-contract.test.ts", "5", "P0 #2: /v3/ + id=; symbol fallback; entry.id used; degraded on 500"],
    ["src/tests/coinglass-v4-real-shape.test.ts", "5", "P0 #3: OHLC close as rate; ms timestamp; BTCUSDT pair; endpoint tag"],
    ["src/tests/coinmarketcal-v44-real-shape.test.ts", "5", "P0 #4: cursor pagination; string id; slug identity; lastVerifiedAt; degraded"],
    ["src/tests/lunarcrush-v44-real-shape.test.ts", "5", "P0 #5: flat data[]; v4 fields; config.generated; delayed hint; 50-asset coverage"],
    [f"Total new v{VERSION} tests", f"{TEST_COUNT - 366}", "+28 vs v0.4.2, all passing"],
]
t = Table(audit_tests_data, colWidths=[3*inch, 0.7*inch, 3.3*inch])
t.setStyle(TableStyle([
    ("BACKGROUND", (0, 0), (-1, 0), colors.lightgrey),
    ("BACKGROUND", (0, -1), (-1, -1), colors.lightyellow),
    ("FONTNAME", (0, -1), (-1, -1), "Helvetica-Bold"),
    ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
    ("FONTSIZE", (0, 0), (-1, -1), 8.5),
    ("VALIGN", (0, 0), (-1, -1), "TOP"),
]))
story.append(t)
story.append(Spacer(1, 0.2*inch))

# Deferred work
story.append(Paragraph("Deferred to next release (P1 still open)", H2))
deferred = [
    "P1-1: identityConfidence initialization from the canonical registry (verified->mapping, ambiguous->bounded, unmapped/quarantined->0).",
    "P1-2: Build evidence claims before scoring; factor scores reference claim IDs (proof chain).",
    "P1-3: Market reducer - partial coverage = degraded (not failed).",
    "P1-4: Per-capability freshness aggregation (no order-dependent overwrite).",
    "P1-5: Watchlist source artifact = raw source payload + contentHash + extractorVersion (not just list hash).",
    "P1-6: Current identity-coverage metric in manifest.",
    "P1-7: Update package.json description, .env.example, manifest from runtime capability state.",
    "P1-8: SHA256SUMS.txt - use writeFileSync + appendFileSync (DONE in v0.4.4 build_manifest.mjs).",
    "Iyaza wiring - specialist -> snapshot - priors vs evidence - provider fan-out from watchlist - /api/refresh auth - Soofi model capability layer - README/logs - 25-asset cap - forecast-ledger persistence - Postgres deploy - public demo re-deploy.",
]
for item in deferred:
    story.append(Paragraph("- " + item, BODY))
story.append(Spacer(1, 0.2*inch))

# Reproducibility
story.append(Paragraph("Reproducing this release", H2))
story.append(Paragraph("The release manifest is the source of truth, not a manual caption. To verify:", BODY))
story.append(Paragraph(
    "1. sha256sum Zobiris_v" + VERSION + "_Source.zip  -> must equal " + ZIP_SHA,
    MONO,
))
story.append(Paragraph(
    "2. unzip Zobiris_v" + VERSION + "_Source.zip && cd Zobiris_v" + VERSION + "_Source && npm install",
    MONO,
))
story.append(Paragraph("3. npx tsc --noEmit  -> 0 errors", BODY))
story.append(Paragraph(f"4. npx vitest run  -> {TEST_COUNT} / {TEST_COUNT} passing", BODY))
story.append(Paragraph("5. node scripts/build_manifest.mjs  -> re-executes tests, fails on regression", BODY))
story.append(Spacer(1, 0.15*inch))

# Source files of note
story.append(Paragraph(f"Source files of note (v{VERSION})", H2))
sf_data = [
    ["File", "Purpose"],
    ["src/providers/eligibility.ts", "EvidenceEligibility + isObservationEligibleForAnalysis() + partitionObservationsByEligibility() - the v0.4.4 quarantine gate"],
    ["src/providers/timestamps.ts", "normalizeTimestampToIso() - auto-detect ms vs seconds, prevents the v0.4.2 Coinglass ms*1000 bug"],
    ["src/providers/types.ts", "FetchResult extended: endpoint, requestedSymbol, dataMode, fallbackReason, upstreamFailure"],
    ["src/providers/cmc.ts", "/v3/ + id=1,1027,...; entry.id; dataMode on fallback"],
    ["src/providers/coinglass.ts", "v4 OHLC fields; BTCUSDT pair; requestedSymbol; endpoint tag"],
    ["src/providers/coinmarketcal.ts", "/v2/events?limit=100; cursor pagination; coins[].slug; lastVerifiedAt; string id"],
    ["src/providers/lunarcrush.ts", "flat data[]; social_volume_24h; config.generated; freshnessHint='delayed'"],
    ["src/storage/schema.ts", "canonical_asset_aliases + identity_merge_history tables; canonical_assets.identity_provenance column"],
    ["src/storage/repository.ts", "upsertCanonicalAsset appends aliases + records identity_provenance; appendCanonicalAlias() for runtime enrichment; getCanonicalByAlias() lookup"],
    ["src/runtime/refresh.ts", "buildEvidenceSummaries() now skips non-eligible observations; defaultEvidenceSummary() reads from registry; hadFailure forced on fallback"],
    ["src/specialists/orchestrator.ts", "partitionObservationsByEligibility() before specialists; excludedObservations.{ambiguous,quarantined} counts"],
    ["src/server/server.ts", "BOTH rehydration paths now read quarantineState + identityMatchMethod from DB row (not hard-coded verified)"],
    ["scripts/build_manifest.mjs", "writeFileSync + appendFileSync for SHA256SUMS.txt (P1-8 fix); runs tsc + vitest first"],
]
t = Table(sf_data, colWidths=[2.7*inch, 4*inch])
t.setStyle(TableStyle([
    ("BACKGROUND", (0, 0), (-1, 0), colors.lightgrey),
    ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
    ("FONTSIZE", (0, 0), (-1, -1), 8.5),
    ("FONTNAME", (0, 1), (0, -1), "Courier"),
    ("VALIGN", (0, 0), (-1, -1), "TOP"),
]))
story.append(t)
story.append(Spacer(1, 0.2*inch))

story.append(Paragraph("---", BODY))
story.append(Paragraph(f"Source ZIP: Zobiris_v{VERSION}_Source.zip ({manifest['sourceZipBytes']:,} bytes, {len(manifest['files'])} files)", BODY))
story.append(Paragraph(f"ZIP SHA-256: {ZIP_SHA}", MONO))
story.append(Paragraph("Manifest: MANIFEST.json (bound to actual tsc + vitest run)", BODY))
story.append(Paragraph("Per-file SHA-256: SHA256SUMS.txt", BODY))
story.append(Paragraph("Build: 2026-08-23 (America/Los_Angeles)", BODY))

doc.build(story)
print(f"Built {OUT}")
