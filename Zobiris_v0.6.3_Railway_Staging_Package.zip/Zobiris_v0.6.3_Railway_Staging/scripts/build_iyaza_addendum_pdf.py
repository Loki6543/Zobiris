#!/usr/bin/env python3
"""Build a focused PDF of the Iyaza Addendum code shipped in Zobiris.

Covers the 8 modules + 5 addendum regression tests. Each module is
sectioned with a short what-it-is header.
"""
from pathlib import Path
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.lib import colors
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, PageBreak, Preformatted, Table, TableStyle,
)

ROOT = Path("/workspace/zobiris_core")
OUT = ROOT / "downloads" / "Zobiris_Iyaza_Addendum_Code.pdf"
OUT.parent.mkdir(exist_ok=True)

# (Section title, [file paths], description)
SECTIONS = [
    ("A. Capability registry + provider health/degradation contract",
     ["src/capabilities/registry.ts",
      "src/capabilities/health.ts",
      "src/tests/capability-registry.test.ts"],
     "Vendor-neutral capability registry: every provider advertises its "
     "data classes, freshness expectations, and quota profile through a "
     "typed schema. The runtime then resolves a degraded-but-honest state "
     "instead of fabricating live numbers."),

    ("B. Typed refresh TaskSpec + lifecycle (NEW → ACK → RUNNING → COMPLETED)",
     ["src/tasks/spec.ts",
      "src/tasks/lifecycle.ts",
      "src/tasks/result.ts",
      "src/tests/taskspec-lifecycle.test.ts"],
     "Every refresh is a TaskSpec (typed input) that goes through an "
     "explicit lifecycle with state-machine guards. The 19-stage refresh "
     "contract from earlier releases is now a concrete instance of this "
     "generic TaskSpec, so a malformed refresh fails BEFORE any work runs."),

    ("C+D. Strong terminal semantics + OEP (Observation-Event Pairing)",
     ["src/oep/taxonomy.ts",
      "src/verifier/invariants.ts",
      "src/verifier/index.ts",
      "src/tests/result-semantics-oep.test.ts"],
     "Terminal states are typed and exhaustively checked: 'succeeded' / "
     "'failed' / 'skipped' / 'not_configured' / 'degraded' / 'unreachable'. "
     "OEP is the rule that every provider observation must be paired with "
     "a typed event before it can reach a specialist — no implicit joins."),

    ("E+F. Specialist/provider effect calibration + UCE robustness",
     ["src/uce/robustness.ts",
      "src/calibration/store.ts",
      "src/tests/calibration-uce.test.ts"],
     "UCE (Unified Calibration Engine) scores how much signal a specialist "
     "or provider has historically added vs. its prior. Robustness is the "
     "test that scores remain stable under ±20% perturbation of inputs."),

    ("G. Gated memory promotion + reversible improvement lifecycle",
     ["src/learning/forecastLedger.ts",
      "src/learning/lifecycle.ts",
      "src/learning/promotion.ts",
      "src/learning/index.ts",
      "src/tests/learning-promotion.test.ts"],
     "Memory records are NEVER auto-promoted. Promotion goes through a "
     "holdout-tested gate with a revert path, so a regression can be "
     "rolled back atomically. Forecast ledger persists Brier scores per "
     "horizon."),
]

styles = getSampleStyleSheet()
H1 = styles["Heading1"]
H2 = styles["Heading2"]
H3 = styles["Heading3"]
BODY = styles["BodyText"]
COVER_BODY = ParagraphStyle("cover", parent=BODY, fontSize=10, leading=14, spaceAfter=6)
DESC = ParagraphStyle("desc", parent=BODY, fontSize=9.5, leading=13, spaceAfter=6, textColor=colors.HexColor("#333333"))
CODE = ParagraphStyle("code", parent=styles["Code"], fontSize=7, leading=8.5, leftIndent=4, rightIndent=4)
FILE_HDR = ParagraphStyle("filehdr", parent=H2, fontSize=11, leading=13, textColor=colors.HexColor("#003366"))
PATH_NOTE = ParagraphStyle("pathnote", parent=BODY, fontSize=8, leading=10, textColor=colors.grey, spaceAfter=4)
SECTION_HDR = ParagraphStyle("section", parent=H1, fontSize=15, leading=18, textColor=colors.HexColor("#660000"), spaceBefore=10, spaceAfter=6)

doc = SimpleDocTemplate(
    str(OUT),
    pagesize=letter,
    leftMargin=0.5 * inch, rightMargin=0.5 * inch,
    topMargin=0.5 * inch, bottomMargin=0.5 * inch,
    title="Zobiris Iyaza Addendum — Code Reference",
    author="Mavis / Zobiris build",
)
story = []

# Cover
total_files = sum(len(paths) for _, paths, _ in SECTIONS)
total_lines = 0
for _, paths, _ in SECTIONS:
    for p in paths:
        f = ROOT / p
        if f.exists():
            total_lines += sum(1 for _ in f.open("r", encoding="utf-8", errors="replace"))

story.append(Paragraph("Zobiris Intelligence Engine", H1))
story.append(Paragraph("Iyaza Addendum — Code Reference", H2))
story.append(Spacer(1, 0.15 * inch))
story.append(Paragraph(
    "This PDF contains the Iyaza Addendum modules shipped in Zobiris — the "
    "8 typed architecture primitives the addendum specified. Each section "
    "includes the module source + the regression tests that pin its "
    f"behavior. Total: <b>{total_files} files</b> / ~<b>{total_lines:,} lines</b>.",
    COVER_BODY,
))
story.append(Spacer(1, 0.2 * inch))

cover_data = [
    ["Addendum item", "Modules", "Test count"],
    ["A. Capability registry + provider health", "registry.ts, health.ts", "1 file (capability-registry.test.ts)"],
    ["B. Typed TaskSpec + lifecycle", "spec.ts, lifecycle.ts, result.ts", "1 file (taskspec-lifecycle.test.ts)"],
    ["C+D. Terminal semantics + OEP", "taxonomy.ts, invariants.ts, index.ts", "1 file (result-semantics-oep.test.ts)"],
    ["E+F. UCE + calibration", "robustness.ts, store.ts", "1 file (calibration-uce.test.ts)"],
    ["G. Gated memory promotion", "forecastLedger.ts, lifecycle.ts, promotion.ts, index.ts", "1 file (learning-promotion.test.ts)"],
    ["Total", f"{total_files} files, {total_lines:,} lines", "5 test files, all passing"],
]
t = Table(cover_data, colWidths=[2.0 * inch, 2.5 * inch, 2.5 * inch])
t.setStyle(TableStyle([
    ("BACKGROUND", (0, 0), (-1, 0), colors.lightgrey),
    ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
    ("FONTSIZE", (0, 0), (-1, -1), 8.5),
    ("VALIGN", (0, 0), (-1, -1), "TOP"),
    ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
    ("BACKGROUND", (0, -1), (-1, -1), colors.lightyellow),
    ("FONTNAME", (0, -1), (-1, -1), "Helvetica-Bold"),
]))
story.append(t)
story.append(Spacer(1, 0.3 * inch))

# Index
story.append(Paragraph("File index", H2))
idx_lines = []
for section, paths, _ in SECTIONS:
    idx_lines.append(f"## {section}")
    for p in paths:
        full = ROOT / p
        if full.exists():
            n_lines = sum(1 for _ in full.open("r", encoding="utf-8", errors="replace"))
            idx_lines.append(f"  {p}  ({n_lines:,} lines)")
        else:
            idx_lines.append(f"  {p}  (MISSING)")
    idx_lines.append("")
story.append(Preformatted("\n".join(idx_lines), ParagraphStyle(
    "idx", parent=styles["Code"], fontSize=7.5, leading=9.5, leftIndent=4,
)))
story.append(PageBreak())

# Each section
for section, paths, desc in SECTIONS:
    story.append(Paragraph(section, SECTION_HDR))
    story.append(Paragraph(desc, DESC))
    story.append(Spacer(1, 0.1 * inch))
    for rel in paths:
        full = ROOT / rel
        if not full.exists():
            story.append(Paragraph(f"### {rel} &mdash; <b>MISSING</b>", FILE_HDR))
            story.append(PageBreak())
            continue
        content = full.read_text(encoding="utf-8", errors="replace")
        n_lines = content.count("\n") + 1
        story.append(Paragraph(f"### {rel}", FILE_HDR))
        story.append(Paragraph(
            f"<i>{len(content):,} chars &middot; {full.stat().st_size:,} bytes &middot; {n_lines:,} lines</i>",
            PATH_NOTE,
        ))
        MAX_CHUNK = 60_000
        if len(content) <= MAX_CHUNK:
            story.append(Preformatted(content, CODE))
        else:
            for j in range(0, len(content), MAX_CHUNK):
                chunk = content[j:j + MAX_CHUNK]
                story.append(Preformatted(chunk, CODE))
                if j + MAX_CHUNK < len(content):
                    story.append(Paragraph(
                        f"<i>... continued ({j + MAX_CHUNK:,}/{len(content):,} chars)</i>",
                        PATH_NOTE,
                    ))
        story.append(Spacer(1, 0.1 * inch))
    story.append(PageBreak())

doc.build(story)
print(f"[iyaza-pdf] wrote {OUT}  ({OUT.stat().st_size:,} bytes)")
