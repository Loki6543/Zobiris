#!/usr/bin/env bash
# v0.4.4 audit fix (P0 #14): static no-trading-execution release check.
#
# The application is decision support only. This script greps the
# release ZIP for executable paths that would imply live trading:
#   - private key derivation / signing
#   - seed phrase handling
#   - wallet transaction signing
#   - order/buy/sell execution paths
#   - copy-trading primitives
#
# The check is run by build_manifest.mjs after the test gate and
# before the ZIP is renamed to its final form. A hit aborts the
# release.
#
# Exclusion policy: documentation, tests, and explicit allow-lists
# may contain the strings; this script does NOT scan those paths.

set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"

# Walk the source tree directly. We use a stable, find-based approach
# that does not require rsync/cp.
EXCLUDE_PATHS=(
  "./node_modules"
  "./.git"
  "./downloads"
  "./test-results"
  "./.next"
  "./dist"
  "./public"
  "./README.md"
  "./IMPLEMENTATION_LOG.md"
  "./VERIFICATION_REPORT.md"
)

# Collect all .ts / .js files under ROOT, excluding allow-listed paths.
mapfile -t FILES < <(find "$ROOT" -type f \( -name "*.ts" -o -name "*.js" -o -name "*.mjs" -o -name "*.cjs" \) \
  ! -path "*/node_modules/*" ! -path "*/.git/*" ! -path "*/downloads/*" \
  ! -path "*/test-results/*" ! -path "*/.next/*" ! -path "*/dist/*" \
  ! -path "*/public/*" ! -name "*.test.ts" ! -name "*.spec.ts" \
  ! -name "check_no_trading*" ! -name "*README*" \
  ! -path "*/.mavis/*")

# Patterns that imply live trading. Each is a regex; the FIRST match
# in a non-allow-listed file fails the check.
PATTERNS=(
  # Wallet signing primitives
  'ethers\.Wallet.*signTransaction|signTransaction\('
  'web3\.eth\.signTransaction|eth_sendTransaction|eth_sendRawTransaction'
  'bitcoinjs-lib.*sign|signer\.sign\('
  # Order / buy / sell
  'placeOrder\(|submitOrder\(|place_buy\(|place_sell\('
  'exchange\.order\(|brokerOrder\('
  # Private key / seed phrase handling
  'privateKey\.to|seedPhrase|mnemonic\.to|mnemonicToSeedSync'
  # Copy-trading
  'copyTrade|copy_trade|copy-trade'
)

# Allow-listed paths (docs, tests, scripts) — never scanned.
ALLOW='(public/|scripts/check_no_trading|src/tests/|README|IMPLEMENTATION_LOG|VERIFICATION_REPORT|node_modules|test-results|\\.md:|\.test\.ts:|\.spec\.ts:|\.sh:)'

EXIT=0
for pat in "${PATTERNS[@]}"; do
  HITS=$(grep -InE "$pat" "${FILES[@]}" 2>/dev/null || true)
  if [ -n "$HITS" ]; then
    echo "$HITS"
    echo "FAIL: pattern '$pat' found in non-allow-listed source."
    EXIT=1
  fi
done

if [ $EXIT -eq 0 ]; then
  echo "OK: no executable trading paths found in source."
fi
exit $EXIT
