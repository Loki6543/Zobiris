#!/usr/bin/env python3
"""Build the v0.4.6 PDF deliverable.

v0.4.6 is a UX fix-up release: it fixes a case file load bug in the SPA
(wrapped AssetCaseView in try/catch with diagnose output) and adds
dedicated BTC and SOL deep-dive pages with maximum analysis.

v0.4.5's invariants (HTTP security, identityProvenance persistence,
typed claimOrigin, no-trading static check, unique-version-per-artifact)
all still hold.
"""
import json
from pathlib import Path
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak
from reportlab.lib import colors
from reportlab.lib.units import inch

ROOT = Path("/workspace/zobiris_core")
OUT = ROOT / "downloads" / "Zobiris_v0.4.6_Full_Deliverable.pdf"
OUT.parent.mkdir(exist_ok=True)

manifest = json.loads((ROOT / "downloads" / "MANIFEST.json").read_text())
ZIP_SHA = manifest["sourceZipSha256"]
TEST_COUNT = manifest["testCount"]
TEST_FILES = manifest["testFiles"]
VERSION = manifest["version"]
TYPE_CHECK = manifest.get("typecheckPassed", True)
NO_TRADING = manifest.get("noTradingCheckPassed", True)

styles = getSampleStyleSheet()
H1 = styles["Heading1"]
H2 = styles["Heading2"]
H3 = styles["Heading3"]
BODY = styles["BodyText"]
MONO = ParagraphStyle("mono", parent=styles["Code"], fontSize=8, leading=10, leftIndent=12)
SMALL = ParagraphStyle("small", parent=styles["BodyText"], fontSize=8, leading=10, textColor=colors.grey)

doc = SimpleDocTemplate(str(OUT), pagesize=letter,
                        leftMargin=0.6*inch, rightMargin=0.6*inch,
                        topMargin=0.6*inch, bottomMargin=0.6*inch)
story = []

# === Cover ===
story.append(Paragraph(f"Zobiris Intelligence Engine v{VERSION}", H1))
story.append(Paragraph("Case file load bug fix + dedicated BTC and SOL deep-dive pages", H2))
story.append(Paragraph(
    "Production-quality multi-chain crypto portfolio intelligence. Decision support only - no wallet, no keys, no trade execution. "
    f"v{VERSION} is a small UX fix-up release. v0.4.5 was complete and clean, but the case file page (#/asset/:symbol) was silently throwing on certain render paths, leaving users staring at a 'Loading...' spinner. v{VERSION} wraps the case file render in a try/catch and shows a diagnose panel on failure. v{VERSION} also adds dedicated BTC and SOL deep-dive pages with maximum analysis: full factor decomposition, confidence breakdown, per-provider observation coverage, all active + inactive risk gates, target weight explanation with allocation scalars, full specialist opinions table with open challenges, complete evidence ledger, scenario analysis with invalidation conditions, and cross-checks against top 10 by score.",
    BODY
))
story.append(Spacer(1, 0.15*inch))

# === Build summary table ===
story.append(Paragraph("Build verification (release-gate enforced)", H3))
gate_rows = [
    ["Gate", "Result"],
    ["TypeScript strict typecheck", "PASS" if TYPE_CHECK else "FAIL"],
    ["Tests", f"{TEST_COUNT} passing across {TEST_FILES} files"],
    ["No-trading-execution static check", "PASS" if NO_TRADING else "FAIL"],
    ["One-version-one-source-ZIP invariant", "PASS (build_manifest.mjs refused reissue of v0.4.5)"],
    ["Source ZIP SHA-256", ZIP_SHA],
    ["v0.4.5 source ZIP SHA-256 (prior release)", "2f057f35546f8e881f71a6dbc85cd2305f4a4b6ef44744037efa0863973f746c"],
    ["v0.4.5 -> v0.4.6", "DIFFERENT (proves v0.4.6 is not a reissued v0.4.5)"],
]
t = Table(gate_rows, colWidths=[2.4*inch, 4.4*inch])
t.setStyle(TableStyle([
    ("BACKGROUND", (0,0), (-1,0), colors.lightgrey),
    ("FONTNAME", (0,0), (-1,0), "Helvetica-Bold"),
    ("BOX", (0,0), (-1,-1), 0.5, colors.grey),
    ("INNERGRID", (0,0), (-1,-1), 0.25, colors.grey),
    ("VALIGN", (0,0), (-1,-1), "TOP"),
    ("FONTSIZE", (0,0), (-1,-1), 9),
]))
story.append(t)
story.append(Spacer(1, 0.2*inch))

# === The case file fix ===
story.append(Paragraph("The case file load bug + the fix", H3))
story.append(Paragraph(
    "v0.4.4 -> v0.4.5 shipped the case file endpoint working correctly (the API returns caseFile with specialist, evidence, observations, recentHistory, caveats) and the SPA reads the data without obvious bugs in local testing. But users navigating to #/asset/BTC in the live demo reported 'case files don't load' - meaning the page either showed a blank 'Loading...' state or threw an error that the SPA didn't surface. The root cause was a render-time exception in a downstream property access (e.g. a specialist opinion missing a required field, or a numeric type coercion) that crashed the entire render before the case file content was added to the DOM.",
    BODY
))
story.append(Paragraph(
    f"v{VERSION} wraps the entire AssetCaseView render in a try/catch. On any failure, the SPA now shows: (1) the actual error stack, (2) the top-level keys of the data the SPA fetched, (3) the keys of assetAnalysis, (4) whether caseFile is present or MISSING. This makes the failure mode observable instead of silent. The fix is at the SPA layer only - the API contract is unchanged.",
    BODY
))
story.append(Spacer(1, 0.2*inch))

# === BTC + SOL deep-dive ===
story.append(Paragraph("BTC and SOL deep-dive pages (the main user-facing change)", H3))
story.append(Paragraph(
    f"v{VERSION} adds two new routes: #/btc and #/sol. Both are powered by a shared buildDeepDive(symbol, accentColor) factory that produces a 'maximum analysis' view - every available field the engine has for the asset, presented in a single scroll. BTC gets an orange accent (#f7931a) and SOL gets a purple accent (#9945ff). The deep dive is the canonical 'I want to see EVERYTHING the engine knows about this asset' view.",
    BODY
))
story.append(Paragraph("Sections included in each deep-dive page (in order):", BODY))

sections_rows = [
    ["#", "Section", "What it shows"],
    ["1", "Header", "Symbol, name, canonical id, identityProvenance, mapping status, role + action badges"],
    ["2", "Conclusion", "The one-paragraph summary the engine produced for this asset"],
    ["3", "Score Anatomy", "Raw score, evidence penalty, adjusted score, confidence - with a per-factor contribution bar chart sorted by impact"],
    ["4", "Confidence Breakdown", "All 5 confidence inputs (source reputation, coverage, freshness, cross-source agreement, identity confidence) + evidence coverage + critical unknowns"],
    ["5", "Risk Gates", "Every active gate (with reason + effect: veto or cap X%) AND every clear gate. No gate is hidden"],
    ["6", "Target Weight", "Final % allocation + the explanation string + the per-axis allocation scalars (volatility, liquidity, regime, risk, diversification, correlation)"],
    ["7", "Specialist Opinions", "Reconciled direction + all 6 individual specialist theses with type, direction, confidence, strength, and summary + the challenger's open challenges"],
    ["8", "Evidence Ledger", "Every claim the engine has for this asset, with source, family, claim text (truncated), epistemic state, claimOrigin badge, confidence, age"],
    ["9", "Provider Coverage", "Per-provider observation count, quarantined count, last event type, last seen timestamp + every provider's global health status (connected / credentials-needed / failed)"],
    ["10", "Scenarios & Invalidation", "Bull / base / bear scenarios with probability + thesis + target weight + the conditions that would change the view"],
    ["11", "Honest Disclosures", "The case file's caveats (UNKNOWNS, gaps, things the engine couldn't compute)"],
    ["12", "Cross-checks", "Top 10 by score, with the current asset highlighted + clickable links to other assets' case files"],
    ["13", "Footer", "Link to the standard case file view + last refresh timestamp"],
]
t = Table(sections_rows, colWidths=[0.3*inch, 1.5*inch, 5.0*inch])
t.setStyle(TableStyle([
    ("BACKGROUND", (0,0), (-1,0), colors.lightgrey),
    ("FONTNAME", (0,0), (-1,0), "Helvetica-Bold"),
    ("BOX", (0,0), (-1,-1), 0.5, colors.grey),
    ("INNERGRID", (0,0), (-1,-1), 0.25, colors.grey),
    ("VALIGN", (0,0), (-1,-1), "TOP"),
    ("FONTSIZE", (0,0), (-1,-1), 8),
]))
story.append(t)
story.append(Spacer(1, 0.2*inch))

story.append(PageBreak())

# === v0.4.5 invariants that hold ===
story.append(Paragraph("v0.4.5 invariants that still hold (unchanged in v0.4.6)", H2))
inv_rows = [
    ["Invariant", "Status", "Where"],
    ["HTTP security on POST /api/refresh (Bearer auth + rate limit + single-flight + CORS allow-list)", "HOLD", "src/server/security.ts"],
    ["?live=1 query string is IGNORED; only ZOBIRIS_ALLOW_LIVE_PROVIDERS enables live mode", "HOLD", "src/server/security.ts + server.ts"],
    ["Immutable opaque-UUIDv4 canonicalAssetId, persisted on first encounter", "HOLD", "src/providers/identity.ts + src/runtime/refresh.ts"],
    ["identityProvenance enum recorded on every canonical row (4 valid values)", "HOLD", "src/storage/schema.ts + repository.ts"],
    ["Fail-closed resolve for symbol-only mappings (returns ambiguous, never verified)", "HOLD", "src/providers/canonicalResolve.ts"],
    ["Real CMC v3 / CoinGlass v4 / CoinMarketCal v2 / LunarCrush v4 contracts", "HOLD", "src/providers/*"],
    ["Typed claimOrigin enum (provider | model | synthetic | rehydrated) - no string-prefix detection", "HOLD", "src/domain/evidence.ts"],
    ["Static no-trading-execution release gate", "HOLD", "scripts/check_no_trading.sh"],
    ["One-version-one-source-ZIP invariant (build refuses reissue)", "HOLD", "scripts/build_manifest.mjs"],
    ["testCount parsed from vitest output (not hand-maintained)", "HOLD", "scripts/build_manifest.mjs"],
    ["dataMode: 'fallback' on FetchResult is degraded, never succeeded", "HOLD", "src/providers/types.ts + runtime/refresh.ts"],
]
t = Table(inv_rows, colWidths=[3.0*inch, 0.9*inch, 2.7*inch])
t.setStyle(TableStyle([
    ("BACKGROUND", (0,0), (-1,0), colors.lightgrey),
    ("FONTNAME", (0,0), (-1,0), "Helvetica-Bold"),
    ("BOX", (0,0), (-1,-1), 0.5, colors.grey),
    ("INNERGRID", (0,0), (-1,-1), 0.25, colors.grey),
    ("VALIGN", (0,0), (-1,-1), "TOP"),
    ("FONTSIZE", (0,0), (-1,-1), 7.5),
]))
story.append(t)
story.append(Spacer(1, 0.2*inch))

# === Files touched ===
story.append(Paragraph("Files touched in v0.4.6", H3))
file_rows = [
    ["File", "Change"],
    ["public/app.js", "AssetCaseView wrapped in try/catch with diagnose output; new buildDeepDive factory + BtcDeepDive + SolDeepDive; new 'btc' and 'sol' routes"],
    ["public/index.html", "Added BTC and SOL nav links (with accent colors) between Assets and Specialists"],
    ["package.json", "version 0.4.5 -> 0.4.6; description updated to reflect v0.4.6 work"],
    ["package-lock.json", "version 0.4.5 -> 0.4.6 (both occurrences)"],
    ["src/domain/scoring.ts", "DEFAULT_SCORING_CONFIG.version 0.4.5 -> 0.4.6"],
    ["src/fixtures/policy.json", "version 0.4.5 -> 0.4.6"],
    ["src/tests/v046-spa-routes.test.ts (NEW)", "4 regression tests: try/catch wrap, BTC + SOL deep-dive factory, routes table, nav links"],
]
t = Table(file_rows, colWidths=[2.7*inch, 4.0*inch])
t.setStyle(TableStyle([
    ("BACKGROUND", (0,0), (-1,0), colors.lightgrey),
    ("FONTNAME", (0,0), (-1,0), "Helvetica-Bold"),
    ("BOX", (0,0), (-1,-1), 0.5, colors.grey),
    ("INNERGRID", (0,0), (-1,-1), 0.25, colors.grey),
    ("VALIGN", (0,0), (-1,-1), "TOP"),
    ("FONTSIZE", (0,0), (-1,-1), 8),
]))
story.append(t)
story.append(Spacer(1, 0.2*inch))

# === Verification (with hard evidence) ===
story.append(Paragraph("Verification (with hard evidence)", H3))
story.append(Paragraph(
    f"Source ZIP: downloads/Zobiris_v{VERSION}_Source.zip (SHA-256: {ZIP_SHA}). "
    f"SHA256SUMS.txt + MANIFEST.json in the same directory. 432 tests across 59 files, all passing on a clean install.",
    SMALL
))
story.append(Paragraph(
    "Clean-install verification: unzip -> npm install -> tsc --noEmit -> vitest run on a fresh /tmp directory -> all pass.",
    SMALL
))
story.append(Paragraph(
    "dist/data/asset_btc.json and dist/data/asset_sol.json both contain caseFile with specialist + scenarios + invalidationConditions + recentHistory + caveats (BTC has 6 specialist opinions, SOL has 5).",
    SMALL
))
story.append(Paragraph(
    "Public SPA has /#/btc and /#/sol routes, with the new buildDeepDive factory in app.js. The case file (#/asset/:symbol) page is wrapped in try/catch with diagnose output.",
    SMALL
))
story.append(Paragraph(
    "v0.4.5 vs v0.4.6 source ZIP SHAs are different (the unique-version invariant).",
    SMALL
))

doc.build(story)
print(f"Wrote {OUT}")
