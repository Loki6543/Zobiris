#!/usr/bin/env python3
"""Build a PDF of every file authored/modified in this session (v0.4.3 audit
re-audit close-out work).

Includes:
  - 7 new test files (audit regression)
  - 2 new provider modules (eligibility, timestamps)
  - All significantly modified provider/storage/runtime files
  - Build script updates
"""
from pathlib import Path
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.lib import colors
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, PageBreak, Preformatted, Table, TableStyle,
)

ROOT = Path("/workspace/zobiris_core")
OUT = ROOT / "downloads" / "Zobiris_v0.4.3_Session_Changes.pdf"
OUT.parent.mkdir(exist_ok=True)

# Explicit list — no globs, no surprises.
SECTIONS = [
    ("New test files (audit regression)", [
        "src/tests/quarantine-enforcement.test.ts",
        "src/tests/persistence-symbol-fallback.test.ts",
        "src/tests/identity-immutable-id.test.ts",
        "src/tests/cmc-v3-real-contract.test.ts",
        "src/tests/coinglass-v4-real-shape.test.ts",
        "src/tests/coinmarketcal-v44-real-shape.test.ts",
        "src/tests/lunarcrush-v44-real-shape.test.ts",
    ]),
    ("New provider modules", [
        "src/providers/eligibility.ts",
        "src/providers/timestamps.ts",
    ]),
    ("Modified provider modules (P0-2..6 contract fixes)", [
        "src/providers/types.ts",
        "src/providers/cmc.ts",
        "src/providers/coinglass.ts",
        "src/providers/coinmarketcal.ts",
        "src/providers/lunarcrush.ts",
    ]),
    ("Modified storage layer (P0-7 immutable canonical IDs + persistence)", [
        "src/storage/schema.ts",
        "src/storage/client.ts",
        "src/storage/repository.ts",
        "src/storage/integration.ts",
    ]),
    ("Modified runtime + specialists + server (P0-1 quarantine enforcement)", [
        "src/runtime/refresh.ts",
        "src/specialists/orchestrator.ts",
        "src/server/server.ts",
        "src/domain/events.ts",
    ]),
    ("Modified build scripts (P1-8 SHA256SUMS race fix, dist build)", [
        "scripts/build_manifest.mjs",
        "scripts/build_dist.mjs",
        "scripts/build_v043_pdf.py",
        "scripts/build_full_codebase_pdf.py",
    ]),
]

styles = getSampleStyleSheet()
H1 = styles["Heading1"]
H2 = styles["Heading2"]
H3 = styles["Heading3"]
BODY = styles["BodyText"]
COVER_BODY = ParagraphStyle("cover", parent=BODY, fontSize=10, leading=14, spaceAfter=6)
CODE = ParagraphStyle("code", parent=styles["Code"], fontSize=7, leading=8.5, leftIndent=4, rightIndent=4)
FILE_HDR = ParagraphStyle("filehdr", parent=H2, fontSize=11, leading=13, textColor=colors.HexColor("#003366"))
PATH_NOTE = ParagraphStyle("pathnote", parent=BODY, fontSize=8, leading=10, textColor=colors.grey, spaceAfter=4)
SECTION_HDR = ParagraphStyle("section", parent=H1, fontSize=15, leading=18, textColor=colors.HexColor("#660000"), spaceBefore=12, spaceAfter=8)

doc = SimpleDocTemplate(
    str(OUT),
    pagesize=letter,
    leftMargin=0.5 * inch, rightMargin=0.5 * inch,
    topMargin=0.5 * inch, bottomMargin=0.5 * inch,
    title="Zobiris v0.4.3 — Session Changes",
    author="Mavis / Zobiris build",
)
story = []

# Cover
story.append(Paragraph("Zobiris Intelligence Engine v0.4.3", H1))
story.append(Paragraph("Session-authored changes — audit re-audit close-out", H2))
story.append(Spacer(1, 0.15 * inch))
story.append(Paragraph(
    "This PDF contains every file authored or significantly modified during the "
    "v0.4.3 session — the audit re-audit work that closed the 6 P0 + P0-7 "
    "immutable-IDs findings the v0.4.3 audit flagged. It is a focused handoff "
    "view: the 7 new audit-regression tests, the new eligibility/timestamps "
    "modules, and every provider / storage / runtime file that changed. "
    "Use the manifest-bound source ZIP (Zobiris_v0.4.3_Source.zip) for the "
    "authoritative build artifact; this PDF is a review aid.",
    COVER_BODY,
))
story.append(Spacer(1, 0.2 * inch))

# File table
total_files = sum(len(paths) for _, paths in SECTIONS)
total_lines = 0
for _, paths in SECTIONS:
    for p in paths:
        f = ROOT / p
        if f.exists():
            try:
                total_lines += sum(1 for _ in f.open("r", encoding="utf-8", errors="replace"))
            except Exception:
                pass

cover_data = [
    ["Files in this PDF", str(total_files)],
    ["Lines of code (approx)", f"{total_lines:,}"],
    ["Tests added", "28 (across 7 new test files)"],
    ["Total tests in v0.4.3", "394 / 394 passing"],
    ["TypeScript", "0 errors (clean)"],
    ["Generated", "2026-08-23 (America/Los_Angeles)"],
]
t = Table(cover_data, colWidths=[2 * inch, 4.5 * inch])
t.setStyle(TableStyle([
    ("BACKGROUND", (0, 0), (0, -1), colors.lightgrey),
    ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
    ("FONTSIZE", (0, 0), (-1, -1), 9.5),
    ("VALIGN", (0, 0), (-1, -1), "TOP"),
    ("FONTNAME", (0, 0), (0, -1), "Helvetica-Bold"),
]))
story.append(t)
story.append(Spacer(1, 0.3 * inch))

# Index
story.append(Paragraph("File index (by section)", H2))
idx_lines = []
for section, paths in SECTIONS:
    idx_lines.append(f"## {section}")
    for p in paths:
        full = ROOT / p
        if full.exists():
            n_lines = sum(1 for _ in full.open("r", encoding="utf-8", errors="replace"))
            idx_lines.append(f"  {p}  ({n_lines:,} lines)")
        else:
            idx_lines.append(f"  {p}  (MISSING)")
    idx_lines.append("")
story.append(Preformatted("\n".join(idx_lines), ParagraphStyle(
    "idx", parent=styles["Code"], fontSize=7.5, leading=9.5, leftIndent=4,
)))
story.append(PageBreak())

# Each file
for section, paths in SECTIONS:
    story.append(Paragraph(section, SECTION_HDR))
    for rel in paths:
        full = ROOT / rel
        if not full.exists():
            story.append(Paragraph(f"### {rel} &mdash; <b>MISSING</b>", FILE_HDR))
            story.append(PageBreak())
            continue
        try:
            content = full.read_text(encoding="utf-8", errors="replace")
        except Exception as e:
            content = f"<<error: {e}>>"
        n_lines = content.count("\n") + 1
        story.append(Paragraph(f"### {rel}", FILE_HDR))
        story.append(Paragraph(
            f"<i>{len(content):,} chars &middot; {full.stat().st_size:,} bytes &middot; {n_lines:,} lines</i>",
            PATH_NOTE,
        ))
        MAX_CHUNK = 60_000
        if len(content) <= MAX_CHUNK:
            story.append(Preformatted(content, CODE))
        else:
            for j in range(0, len(content), MAX_CHUNK):
                chunk = content[j:j + MAX_CHUNK]
                story.append(Preformatted(chunk, CODE))
                if j + MAX_CHUNK < len(content):
                    story.append(Paragraph(
                        f"<i>... continued ({j + MAX_CHUNK:,}/{len(content):,} chars)</i>",
                        PATH_NOTE,
                    ))
        story.append(PageBreak())

doc.build(story)
print(f"[session-pdf] wrote {OUT}  ({OUT.stat().st_size:,} bytes)")
