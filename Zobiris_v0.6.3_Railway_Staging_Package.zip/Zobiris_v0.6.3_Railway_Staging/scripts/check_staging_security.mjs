#!/usr/bin/env node
// Run only against a staging environment: a broken guard may execute a handler.
import { randomUUID } from 'node:crypto';

const base = process.argv[2];
if (!base) throw new Error('Usage: node scripts/check_staging_security.mjs https://staging.example');
const origin = new URL(base);
if (!['http:', 'https:'].includes(origin.protocol) || origin.username || origin.password || origin.search || origin.hash || origin.pathname !== '/') {
  throw new Error('Supply a plain HTTP(S) staging origin without credentials, path, or query');
}
const checks = [];
async function check(path, options, accepts, label) {
  const response = await fetch(new URL(path, origin), { ...options, redirect: 'manual', signal: AbortSignal.timeout(15000) });
  const contentType = response.headers.get('content-type') ?? '';
  let payload;
  try { payload = await response.json(); } catch { payload = null; }
  const pass = accepts.includes(response.status) && contentType.includes('application/json') && payload !== null;
  checks.push({ label, status: response.status, pass });
  console.log(`${pass ? 'PASS' : 'FAIL'} ${label}: HTTP ${response.status}`);
}
await check('/api/health', {}, [200], 'health returns application JSON');
for (const path of ['/api/refresh', '/api/strategy21/collect', '/api/agents/challenge']) {
  await check(path, { method: 'POST' }, [401, 403], `anonymous POST ${path}`);
  await check(path, { method: 'POST', headers: { Authorization: `Bearer invalid-${randomUUID()}` } }, [401, 403], `wrong-token POST ${path}`);
}
console.log(JSON.stringify({ checkedAt: new Date().toISOString(), origin: origin.origin, checks }, null, 2));
if (checks.some(check => !check.pass)) process.exitCode = 1;
