#!/usr/bin/env python3
"""
Build the v0.4.0 PDF deliverable from the slice 5+ v0.4.0 work.
"""
import sys
from pathlib import Path

# Use reportlab for the PDF
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak
)
from reportlab.lib import colors
from reportlab.lib.units import inch

OUT = Path("/workspace/zobiris_core/downloads/Zobiris_v0.4.0_Full_Deliverable.pdf")
OUT.parent.mkdir(exist_ok=True)

styles = getSampleStyleSheet()
H1 = styles["Heading1"]
H2 = styles["Heading2"]
H3 = styles["Heading3"]
BODY = styles["BodyText"]
MONO = ParagraphStyle("mono", parent=styles["Code"], fontSize=8, leading=10, leftIndent=12)

doc = SimpleDocTemplate(str(OUT), pagesize=letter, leftMargin=0.6 * inch, rightMargin=0.6 * inch, topMargin=0.6 * inch, bottomMargin=0.6 * inch)
story = []

story.append(Paragraph("Zobiris Intelligence Engine", H1))
story.append(Paragraph("v0.4.0 — Cognitive Specialists + Live CoinGlass/CoinMarketCal + Case Files", H2))
story.append(Paragraph(
    "Production-quality multi-chain crypto portfolio intelligence. Decision support only — no wallet, no keys, no trade execution.",
    BODY
))
story.append(Spacer(1, 0.15 * inch))

# Build summary
story.append(Paragraph("Build summary", H2))
summary_data = [
    ["Tests passing", "230 / 230", "(was 177 in v0.3.0; +53 new tests)"],
    ["TypeScript errors", "0", "tsc --noEmit clean"],
    ["Live provider paths", "5", "Kraken, CMC, LunarCrush, CoinGlass, CoinMarketCal"],
    ["Cognitive specialists", "7", "market structure, derivatives, social, risk, reconciler, challenger, portfolio allocator"],
    ["Specialist pipeline", "stage 11 wired", "Every refresh runs all 7 specialists per asset"],
    ["Per-asset case file", "rich, evidence-backed", "score anatomy + scenarios + invalidation + specialist reconciliation + caveats"],
    ["Forecast ledger", "Brier + direction accuracy", "specialist effectiveness tracking"],
    ["Public demo", "https://zud0m8j0vbdfm.space.minimax.io", "static SPA, pre-baked JSON"],
    ["Source ZIP SHA-256", "7e1dc65c50f15ab06afb04da6e3c8d7eebe23c0df928cdf5377f3fe4776b9c2d", ""],
]
t = Table(summary_data, colWidths=[2 * inch, 2.5 * inch, 2.5 * inch])
t.setStyle(TableStyle([
    ("BACKGROUND", (0, 0), (-1, 0), colors.lightgrey),
    ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
    ("FONTSIZE", (0, 0), (-1, -1), 9),
    ("VALIGN", (0, 0), (-1, -1), "TOP"),
]))
story.append(t)
story.append(Spacer(1, 0.2 * inch))

# What ships
story.append(Paragraph("What ships in v0.4.0", H2))
ship_items = [
    "1. <b>Live CoinGlass network path</b> — src/providers/coinglass.ts now supports live mode (X-CoinGlass-Secret header) with AbortController timeout. 401 throws AdapterNormalizationError, 5xx records lastNetworkError. Defaults to fixture mode without a key. 7 new tests.",
    "2. <b>Live CoinMarketCal network path</b> — src/providers/coinmarketcal.ts supports live mode. Same failure semantics as CoinGlass. 6 new tests.",
    "3. <b>Cognitive specialist pool</b> — 7 specialists under src/specialists/ (market structure, derivatives, social, risk, reconciler, challenger, portfolio allocator) with typed opinions, evidence references, and explicit caveats. 22 new tests.",
    "4. <b>Specialist orchestrator</b> — src/specialists/orchestrator.ts runs the full pipeline per asset in dependency order: independent specialists → risk → reconciler → challenger → allocator. Returns per-asset OrchestratorResult + portfolio aggregate. 4 new tests.",
    "5. <b>Wired into Refresh All (stage 11)</b> — src/runtime/refresh.ts now invokes the orchestrator for every watchlist asset. Stage 11 is recorded in the session audit. RefreshResult includes specialistResults and specialistAggregate.",
    "6. <b>Per-asset case file builder</b> — src/portfolio/caseFile.ts builds rich case files with score anatomy, evidence summary, scenarios (bull/base/bear), invalidation conditions, specialist reconciliation, open challenges, recent history, and honest caveats. 5 new tests.",
    "7. <b>Forecast ledger + calibration</b> — src/learning/forecastLedger.ts tracks forecasts with explicit probabilities, resolves them against realized moves, computes Brier scores and direction accuracy, and produces a per-specialist / per-confidence calibration report. 13 new tests.",
    "8. <b>New API endpoints</b> — GET /api/asset/:symbol now returns a rich caseFile. New GET /api/specialists/summary returns the orchestrator aggregate over ranked assets. New GET /api/calibration returns the forecast ledger report.",
    "9. <b>SPA Specialists tab</b> — public/app.js now renders the specialist verdicts table. Asset case file page now includes the specialist reconciliation card with reconciled direction, allocation hint, open challenges, and full opinion breakdown.",
    "10. <b>Package version bumped to 0.4.0</b> — package.json, build_manifest.mjs, IMPLEMENTATION_LOG.md.",
]
for item in ship_items:
    story.append(Paragraph(item, BODY))
    story.append(Spacer(1, 0.05 * inch))

story.append(PageBreak())

# Specialist pipeline
story.append(Paragraph("Cognitive specialist pipeline (stage 11)", H2))
story.append(Paragraph(
    "Per Iyaza addendum, every refresh now runs the full 7-specialist pipeline per asset in dependency order:",
    BODY
))
story.append(Spacer(1, 0.1 * inch))

pipeline_data = [
    ["Step", "Specialist", "Reads", "Emits"],
    ["1", "market_structure", "quote observations (price, 24h change, volume)", "thesis (bullish/bearish/neutral)"],
    ["2", "derivatives_positioning", "funding rates + liquidations", "thesis with long/short asymmetry"],
    ["3", "social_attention", "mentions + sentiment + dominance", "tentative thesis (single-provider penalty)"],
    ["4", "risk_compliance", "canonical mapping + hard gates + factor scores", "risk_flag (veto or warn)"],
    ["5", "evidence_reconciler", "all prior opinions", "reconciliation (opportunity rank signal)"],
    ["6", "challenger", "all prior opinions", "challenge per guardrail violation"],
    ["7", "portfolio_allocator", "all priors + risk vetoes", "allocation_hint (capped at 15%, 27.5% reserve)"],
]
t = Table(pipeline_data, colWidths=[0.5 * inch, 1.6 * inch, 2.4 * inch, 2.4 * inch])
t.setStyle(TableStyle([
    ("BACKGROUND", (0, 0), (-1, 0), colors.lightgrey),
    ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
    ("FONTSIZE", (0, 0), (-1, -1), 8.5),
    ("VALIGN", (0, 0), (-1, -1), "TOP"),
    ("FONTNAME", (0, 1), (0, -1), "Courier"),
]))
story.append(t)
story.append(Spacer(1, 0.2 * inch))

# Per-asset case file
story.append(Paragraph("Per-asset case file (v0.4.0)", H2))
story.append(Paragraph(
    "The /api/asset/:symbol endpoint now returns a rich case file with:",
    BODY
))
story.append(Spacer(1, 0.05 * inch))
cf_items = [
    "<b>Identity</b> — canonical status, chainId, contract address, provider IDs, mapping confidence",
    "<b>Score</b> — opportunity, confidence, target weight, opportunity rank, allocation rank",
    "<b>Scenarios</b> — bull / base / bear text",
    "<b>Invalidation conditions</b> — what would flip the thesis",
    "<b>Evidence</b> — top 30 observations with provider, epistemic state, freshness",
    "<b>Specialist reconciliation</b> — reconciled direction, allocation hint, veto state, open challenges, full opinion breakdown",
    "<b>Recent history</b> — last 5 snapshots for the asset (opportunity, confidence, action over time)",
    "<b>Caveats</b> — honest disclosures about missing data, single-provider risk, etc.",
]
for item in cf_items:
    story.append(Paragraph("• " + item, BODY))
story.append(Spacer(1, 0.15 * inch))

# Forecast ledger
story.append(Paragraph("Forecast ledger + calibration", H2))
story.append(Paragraph(
    "Per Iyaza addendum rule: a learning system must record forecasts with explicit probabilities, resolve them against realized moves, and track Brier scores by specialist and by confidence level.",
    BODY
))
story.append(Spacer(1, 0.05 * inch))
fl_items = [
    "<b>opinionToForecast()</b> — maps a SpecialistOpinion to a Forecast with derived pBullish / pBearish based on direction, confidence, and strength",
    "<b>resolveForecast()</b> — given realized price move, marks correct/incorrect and computes Brier score and direction accuracy",
    "<b>buildCalibrationReport()</b> — aggregates by specialist and by confidence level",
    "<b>ForecastLedger</b> — in-memory ledger with record / resolve / report. (Persistent storage is deferred to slice 6+.)",
    "<b>Calibration rule</b> — high historical effectiveness does NOT bypass capability/freshness/evidence/independence; it is one routing signal only",
]
for item in fl_items:
    story.append(Paragraph("• " + item, BODY))
story.append(Spacer(1, 0.2 * inch))

# Test summary
story.append(Paragraph("Test coverage: 230 / 230 passing", H2))
test_data = [
    ["File", "Tests", "Notes"],
    ["canonicalAsset.test.ts", "12", "pre-existing (slice 1)"],
    ["providerContract.test.ts", "10", "pre-existing (slice 1)"],
    ["scoring.test.ts", "9", "pre-existing (slice 1)"],
    ["portfolio.test.ts", "7", "pre-existing (slice 1)"],
    ["secrets.test.ts", "8", "pre-existing (slice 1)"],
    ["runtime.test.ts", "17", "pre-existing (slice 1)"],
    ["endToEnd.test.ts", "8", "pre-existing (slice 1)"],
    ["storage.test.ts", "15", "pre-existing (slice 2)"],
    ["canonical-mappings.test.ts", "8", "slice 5"],
    ["cmc-live.test.ts", "7", "slice 5"],
    ["lunarcrush-live.test.ts", "10", "slice 5"],
    ["capability-registry.test.ts", "12", "Iyaza addendum (v0.3.0)"],
    ["taskspec-lifecycle.test.ts", "13", "Iyaza addendum (v0.3.0)"],
    ["result-semantics-oep.test.ts", "12", "Iyaza addendum (v0.3.0)"],
    ["calibration-uce.test.ts", "12", "Iyaza addendum (v0.3.0)"],
    ["learning-promotion.test.ts", "12", "Iyaza addendum (v0.3.0)"],
    ["specialists.test.ts", "22", "v0.4.0 NEW"],
    ["caseFile.test.ts", "5", "v0.4.0 NEW"],
    ["coinglass-coinmarketcal-live.test.ts", "13", "v0.4.0 NEW"],
    ["forecastLedger.test.ts", "13", "v0.4.0 NEW"],
    ["TOTAL", "230", "all passing"],
]
t = Table(test_data, colWidths=[3 * inch, 0.7 * inch, 2.8 * inch])
t.setStyle(TableStyle([
    ("BACKGROUND", (0, 0), (-1, 0), colors.lightgrey),
    ("BACKGROUND", (0, -1), (-1, -1), colors.lightyellow),
    ("FONTNAME", (0, -1), (-1, -1), "Helvetica-Bold"),
    ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
    ("FONTSIZE", (0, 0), (-1, -1), 8.5),
    ("VALIGN", (0, 0), (-1, -1), "TOP"),
]))
story.append(t)
story.append(Spacer(1, 0.2 * inch))

# Live provider notes
story.append(Paragraph("Live provider notes", H2))
lp_items = [
    "<b>CoinGlass</b> — live path: GET /api/futures/fundingRate/v2 + /api/futures/liquidation/info. Auth: coinglassSecret header. Timeout: 10s default. Fixture fallback on 5xx.",
    "<b>CoinMarketCal</b> — live path: GET /api/v1/events?key=API_KEY. Timeout: 10s default. Preserves is_estimated and display_date semantics from docs/DATA_PLANE.md.",
    "<b>All 5 live providers</b> — uniform failure semantics: 401 = hard AdapterNormalizationError; 5xx / network drop / timeout = data: null + networkError; degraded state reported via health().",
]
for item in lp_items:
    story.append(Paragraph("• " + item, BODY))
story.append(Spacer(1, 0.15 * inch))

# API endpoints
story.append(Paragraph("API endpoints (v0.4.0)", H2))
api_data = [
    ["Method", "Path", "Purpose"],
    ["GET", "/api/health", "liveness"],
    ["GET", "/api/snapshot/latest", "most recent portfolio decision"],
    ["GET", "/api/snapshot/:id", "specific snapshot"],
    ["GET", "/api/snapshots?limit=N", "recent snapshots (summary)"],
    ["GET", "/api/asset/:symbol", "rich per-asset case file (v0.4.0 expanded)"],
    ["GET", "/api/specialists/summary", "NEW: cognitive specialist aggregate"],
    ["GET", "/api/calibration", "NEW: forecast ledger calibration report"],
    ["GET", "/api/providers", "provider health + circuit-breaker state"],
    ["GET", "/api/audit?limit=N", "recent audit events"],
    ["GET", "/api/db-info", "table counts + mapping status"],
    ["GET", "/api/regime", "current regime + confidence"],
    ["POST", "/api/refresh?live=1", "trigger a refresh"],
]
t = Table(api_data, colWidths=[0.7 * inch, 2.4 * inch, 3.4 * inch])
t.setStyle(TableStyle([
    ("BACKGROUND", (0, 0), (-1, 0), colors.lightgrey),
    ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
    ("FONTSIZE", (0, 0), (-1, -1), 8.5),
    ("FONTNAME", (0, 1), (1, -1), "Courier"),
    ("VALIGN", (0, 0), (-1, -1), "TOP"),
]))
story.append(t)
story.append(Spacer(1, 0.2 * inch))

# Deferred
story.append(Paragraph("Deferred to slice 6+", H2))
def_items = [
    "React UI rewrite (current SPA is vanilla JS static; the specialist/cases view is a stepping stone)",
    "Persistent storage for the forecast ledger (currently in-process)",
    "Per-asset research for the 5 unmapped assets (GRAM, TAG, KAITO, SENT, ONDO)",
    "L2/L3 specialist additions: tokenomics specialist, macro specialist, on-chain specialist",
    "Browser-side smoke test with Playwright",
    "Postgres production deployment (Drizzle schema is portable; SQLite is local)",
    "All-asset specialist runs (currently the /api/specialists/summary endpoint is capped at top 25 for performance)",
    "Specialist calibration routing — feed the per-specialist Brier scores back into the orchestrator to weight opinions",
    "Production hardening: reconnection, crash recovery, deployment automation",
]
for item in def_items:
    story.append(Paragraph("• " + item, BODY))
story.append(Spacer(1, 0.2 * inch))

# Source files
story.append(Paragraph("Source files of note (v0.4.0)", H2))
sf_data = [
    ["File", "Purpose"],
    ["src/providers/coinglass.ts", "live + fixture CoinGlass adapter (7 new tests)"],
    ["src/providers/coinmarketcal.ts", "live + fixture CoinMarketCal adapter (6 new tests)"],
    ["src/specialists/contract.ts", "typed Specialist / SpecialistOpinion / SpecialistContext contracts"],
    ["src/specialists/marketStructure.ts", "reads quotes, emits directional thesis"],
    ["src/specialists/derivatives.ts", "reads funding + liquidations, emits thesis with lopsidedness"],
    ["src/specialists/social.ts", "reads social obs, single-provider penalty"],
    ["src/specialists/risk.ts", "vetoes quarantined + hard-gate-tripped assets"],
    ["src/specialists/reconciler.ts", "aggregates priors into reconciled direction"],
    ["src/specialists/challenger.ts", "5 guardrail challenges: overconfidence, independence, staleness, hope, no-invalidations"],
    ["src/specialists/portfolio.ts", "weighted allocation, per-asset cap, vetoes, reserve rule"],
    ["src/specialists/orchestrator.ts", "per-asset pipeline + portfolio aggregate"],
    ["src/portfolio/caseFile.ts", "rich per-asset case file builder"],
    ["src/learning/forecastLedger.ts", "forecast registration, resolution, Brier + direction accuracy"],
    ["src/server/server.ts", "new endpoints: /api/asset/:symbol caseFile, /api/specialists/summary, /api/calibration"],
    ["public/app.js", "Specialists tab + specialist card on asset case file"],
]
t = Table(sf_data, colWidths=[2.7 * inch, 4 * inch])
t.setStyle(TableStyle([
    ("BACKGROUND", (0, 0), (-1, 0), colors.lightgrey),
    ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
    ("FONTSIZE", (0, 0), (-1, -1), 8.5),
    ("FONTNAME", (0, 1), (0, -1), "Courier"),
    ("VALIGN", (0, 0), (-1, -1), "TOP"),
]))
story.append(t)
story.append(Spacer(1, 0.2 * inch))

story.append(Paragraph("—", BODY))
story.append(Paragraph("Source ZIP: Zobiris_v0.4.0_Source.zip (730 KB)", BODY))
story.append(Paragraph("ZIP SHA-256: 7e1dc65c50f15ab06afb04da6e3c8d7eebe23c0df928cdf5377f3fe4776b9c2d", MONO))
story.append(Paragraph("Public demo: https://zud0m8j0vbdfm.space.minimax.io (will be redeployed with v0.4.0 SPA)", BODY))
story.append(Paragraph("Build: 2026-08-22 07:07 UTC", BODY))

doc.build(story)
print(f"Built {OUT}")
