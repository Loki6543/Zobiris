#!/usr/bin/env python3
"""Build the v0.4.5 PDF deliverable - v0.4.4 invariant close-out."""
import json
from pathlib import Path
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak
from reportlab.lib import colors
from reportlab.lib.units import inch

ROOT = Path("/workspace/zobiris_core")
OUT = ROOT / "downloads" / "Zobiris_v0.4.5_Full_Deliverable.pdf"
OUT.parent.mkdir(exist_ok=True)

manifest = json.loads((ROOT / "downloads" / "MANIFEST.json").read_text())
ZIP_SHA = manifest["sourceZipSha256"]
TEST_COUNT = manifest["testCount"]
TEST_FILES = manifest["testFiles"]
VERSION = manifest["version"]
TYPE_CHECK = manifest.get("typecheckPassed", True)
NO_TRADING = manifest.get("noTradingCheckPassed", True)

styles = getSampleStyleSheet()
H1 = styles["Heading1"]
H2 = styles["Heading2"]
H3 = styles["Heading3"]
BODY = styles["BodyText"]
SMALL = ParagraphStyle("small", parent=styles["BodyText"], fontSize=8, leading=10, textColor=colors.grey)

doc = SimpleDocTemplate(str(OUT), pagesize=letter,
                        leftMargin=0.6*inch, rightMargin=0.6*inch,
                        topMargin=0.6*inch, bottomMargin=0.6*inch)
story = []

story.append(Paragraph(f"Zobiris Intelligence Engine v{VERSION}", H1))
story.append(Paragraph("v0.4.4 invariant close-out + consistency fixes", H2))
story.append(Paragraph(
    "Production-quality multi-chain crypto portfolio intelligence. Decision support only - no wallet, no keys, no trade execution. "
    f"This release is a small fix-up over v0.4.4: v0.4.4 shipped one of its own invariants broken (the persistRefresh bridge was dropping identityProvenance), and 4 metadata fields had drifted. v{VERSION} closes both with 2 new regression tests, no architecture changes, and all 428 tests still passing.",
    BODY
))
story.append(Spacer(1, 0.15*inch))

story.append(Paragraph("Build verification (release-gate enforced)", H3))
gate_rows = [
    ["Gate", "Result"],
    ["TypeScript strict typecheck", "PASS" if TYPE_CHECK else "FAIL"],
    ["Tests", f"{TEST_COUNT} passing across {TEST_FILES} files"],
    ["No-trading-execution static check", "PASS" if NO_TRADING else "FAIL"],
    ["One-version-one-source-ZIP invariant", "PASS (build_manifest.mjs refused reissue of v0.4.4)"],
    ["Source ZIP SHA-256", ZIP_SHA],
    ["v0.4.4 source ZIP SHA-256 (prior release)", "c649c616810df3faacd965c21dcfca7bc2bf0ac1a9f27477d9320b8194d5d109"],
    ["v0.4.4 -> v0.4.5", "DIFFERENT (proves v0.4.5 is not a reissued v0.4.4)"],
]
t = Table(gate_rows, colWidths=[2.4*inch, 4.4*inch])
t.setStyle(TableStyle([
    ("BACKGROUND", (0,0), (-1,0), colors.lightgrey),
    ("FONTNAME", (0,0), (-1,0), "Helvetica-Bold"),
    ("BOX", (0,0), (-1,-1), 0.5, colors.grey),
    ("INNERGRID", (0,0), (-1,-1), 0.25, colors.grey),
    ("VALIGN", (0,0), (-1,-1), "TOP"),
    ("FONTSIZE", (0,0), (-1,-1), 9),
]))
story.append(t)
story.append(Spacer(1, 0.2*inch))

story.append(Paragraph(f"Why v{VERSION} exists (and not just a v0.4.4 patch)", H3))
story.append(Paragraph(
    "Zobiris's build_manifest.mjs enforces a one-version-one-source-ZIP invariant: if a build with the same semantic version already exists in downloads/, the manifest script REFUSES to ship. This is the correct behavior - the v0.4.4 audit spec said reissuing a version was a P0 audit failure (two different hashes sharing one version).",
    BODY
))
story.append(Paragraph(
    f"So v{VERSION} is a new minor version, not a v0.4.4 reissue. v0.4.4's source ZIP is preserved on disk with its original SHA-256 (c649c616810df3faacd965c21dcfca7bc2bf0ac1a9f27477d9320b8194d5d109). v{VERSION}'s source ZIP has a different SHA-256 ({ZIP_SHA[:16]}...) so the two are unambiguously separate artifacts.",
    BODY
))
story.append(Spacer(1, 0.2*inch))

story.append(Paragraph("The actual fix: persistRefresh now threads identityProvenance", H3))
story.append(Paragraph(
    "v0.4.4 P0 #5 said: 'canonicalAssetId is an OPAQUE UUIDv4, NEVER derived from aliases. The runtime persists the canonical map on first encounter when dbPath is given. Loading from storage -> use persisted id EXACTLY. The identityProvenance enum records the strongest identity key at creation time (uuidv4-initial | uuidv4-persisted | persistence-rehydrated | fallback).'",
    BODY
))
story.append(Paragraph(
    f"v{VERSION} found that the runtime's runRefresh() correctly set a.identityProvenance='uuidv4-initial' in the in-memory canonicalMap, but persistRefresh() (the function that writes to the DB) called upsertCanonicalFromWatchlist() in src/providers/identity.ts, which forwarded every field EXCEPT identityProvenance to the underlying upsertCanonicalAsset(). The DB schema column existed (added by the v0.4.4 ALTER TABLE migration), but every row was being written with NULL. The API response showed 'identityProvenance: null' for all 50 canonical assets - the invariant's audit trail was silently broken.",
    BODY
))
story.append(Paragraph(
    f"v{VERSION} adds identityProvenance: ca.identityProvenance to the bridge function. After the fix, every persisted canonical row has identity_provenance set to one of the 4 valid enum values. 2 new regression tests guard against regression: identity-provenance-persisted.test.ts runs persistRefresh end-to-end and asserts (1) every row has identity_provenance set after the first refresh, (2) the second refresh on the same DB reads back identity_provenance='uuidv4-persisted' (the rehydration path).",
    BODY
))
story.append(Spacer(1, 0.2*inch))

story.append(Paragraph("Consistency fixes shipped in v0.4.5", H3))
fix_rows = [
    ["File", "Before", "After"],
    ["src/domain/scoring.ts (DEFAULT_SCORING_CONFIG.version)", '"0.1.0"', f'"{VERSION}"'],
    ["src/fixtures/policy.json (version)", '"0.1.0"', f'"{VERSION}"'],
    ["package.json (description)", "v0.4.1 description", f"{VERSION} description"],
    ["package.json (version)", "0.4.4", f"{VERSION}"],
    ["package-lock.json (version)", "0.4.4", f"{VERSION}"],
    [".env.example", "missing 5 v0.4.4 HTTP-security vars", "all 5 documented"],
    ["src/providers/identity.ts (upsertCanonicalFromWatchlist)", "dropped identityProvenance", "threads identityProvenance through"],
    ["src/tests/identity-provenance-persisted.test.ts (NEW)", "-", "2 regression tests"],
]
t = Table(fix_rows, colWidths=[2.5*inch, 1.8*inch, 2.5*inch])
t.setStyle(TableStyle([
    ("BACKGROUND", (0,0), (-1,0), colors.lightgrey),
    ("FONTNAME", (0,0), (-1,0), "Helvetica-Bold"),
    ("BOX", (0,0), (-1,-1), 0.5, colors.grey),
    ("INNERGRID", (0,0), (-1,-1), 0.25, colors.grey),
    ("VALIGN", (0,0), (-1,-1), "TOP"),
    ("FONTSIZE", (0,0), (-1,-1), 8),
]))
story.append(t)
story.append(Spacer(1, 0.2*inch))

story.append(PageBreak())

story.append(Paragraph("v0.4.4 invariants that still hold (unchanged in v0.4.5)", H2))
inv_rows = [
    ["Invariant", "Status", "Where"],
    ["HTTP security on POST /api/refresh (Bearer auth + rate limit + single-flight + CORS allow-list)", "HOLD", "src/server/security.ts"],
    ["?live=1 query string is IGNORED; only ZOBIRIS_ALLOW_LIVE_PROVIDERS enables live mode", "HOLD", "src/server/security.ts + server.ts"],
    ["Immutable opaque-UUIDv4 canonicalAssetId (now actually persisted thanks to v0.4.5 fix)", "HOLD + FIXED", "src/providers/identity.ts"],
    ["identityProvenance enum recorded on every canonical row (4 valid values)", "HOLD + FIXED", "src/storage/schema.ts + repository.ts"],
    ["Fail-closed resolve for symbol-only mappings (returns ambiguous, never verified)", "HOLD", "src/providers/canonicalResolve.ts"],
    ["Real CMC v3 / CoinGlass v4 / CoinMarketCal v2 / LunarCrush v4 contracts", "HOLD", "src/providers/*"],
    ["Typed claimOrigin enum (provider | model | synthetic | rehydrated) - no string-prefix detection", "HOLD", "src/domain/evidence.ts"],
    ["Static no-trading-execution release gate", "HOLD", "scripts/check_no_trading.sh"],
    ["One-version-one-source-ZIP invariant (build refuses reissue)", "HOLD", "scripts/build_manifest.mjs"],
    ["testCount parsed from vitest output (not hand-maintained)", "HOLD", "scripts/build_manifest.mjs"],
    ["dataMode: 'fallback' on FetchResult is degraded, never succeeded", "HOLD", "src/providers/types.ts + runtime/refresh.ts"],
]
t = Table(inv_rows, colWidths=[3.0*inch, 0.9*inch, 2.7*inch])
t.setStyle(TableStyle([
    ("BACKGROUND", (0,0), (-1,0), colors.lightgrey),
    ("FONTNAME", (0,0), (-1,0), "Helvetica-Bold"),
    ("BOX", (0,0), (-1,-1), 0.5, colors.grey),
    ("INNERGRID", (0,0), (-1,-1), 0.25, colors.grey),
    ("VALIGN", (0,0), (-1,-1), "TOP"),
    ("FONTSIZE", (0,0), (-1,-1), 7.5),
    ("BACKGROUND", (1,3), (1,3), colors.lightyellow),
    ("BACKGROUND", (1,4), (1,4), colors.lightyellow),
]))
story.append(t)
story.append(Spacer(1, 0.2*inch))

story.append(Paragraph("Known limitations not addressed in v0.4.5 (deferred to v0.4.6+)", H3))
story.append(Paragraph(
    "These are by-design limitations or P1/P2 items from the consolidated v0.4.4 spec, not regressions. v0.4.5 deliberately does not bundle them.",
    BODY
))
lim_items = [
    "32 of 50 watchlist assets are still mappingStatus='unmapped' (long-tail memecoins deliberately added in v0.4.3 - AISENTIS, APU, BEE, ESIM, ATR, BLUAI, BMT, DEOD, GIGA, NPC, JCT, PONKE, PYTHIA, TRUTH, UAI, UB, VR, WET, ZEREBRO, ZEST, EVAA, etc.). They correctly trip IDENTITY_UNMAPPED + LIQUIDITY_COLLAPSE risk gates and are quarantined from scoring.",
    "Regime is UNKNOWN on every fixture-mode refresh (no live macro provider wired: FRED requires FRED_API_KEY, Treasury fiscal data is not yet integrated).",
    "Allocated 0% + Reserve 10% = 90% unallocated on fixture mode (correct behavior - without live prices, scoring is too uncertain to recommend positions).",
    "P1-1 (identity confidence from registry) and P1-4 (per-capability freshness TTLs) are deferred. The freshnessBudgets in policy.json are documented but the runtime does not yet enforce per-capability TTLs.",
    "P2 items per spec sections 16-50: Docker multi-stage build, load/concurrency tests, persistent Forecast Ledger, outbox background worker, structured logs, graceful shutdown, /healthz + /readyz, Soofi model capability layer, dynamic specialist compiler, browser/UI acceptance tests, cognitive CI 15-step promotion gate.",
]
for item in lim_items:
    story.append(Paragraph("* " + item, BODY))
story.append(Spacer(1, 0.2*inch))

story.append(Paragraph("Architecture (unchanged from v0.4.4)", H2))
story.append(Paragraph(
    "TypeScript strict + Zod + Vitest + Drizzle ORM + better-sqlite3 + Node 22 (no other runtime deps). Vanilla TypeScript SPA, no build step. 175 files in the source ZIP, 58 test files, 428 tests, 0 typecheck errors.",
    BODY
))
story.append(Spacer(1, 0.1*inch))

story.append(Paragraph("Files touched in v0.4.5", H3))
file_rows = [
    ["File", "Change"],
    ["src/providers/identity.ts", "Added identityProvenance: ca.identityProvenance to upsertCanonicalFromWatchlist"],
    ["src/domain/scoring.ts", "DEFAULT_SCORING_CONFIG.version '0.1.0' -> '0.4.5'"],
    ["src/fixtures/policy.json", "version '0.1.0' -> '0.4.5'"],
    ["package.json", "version '0.4.4' -> '0.4.5'; description updated"],
    ["package-lock.json", "version '0.4.4' -> '0.4.5' (both occurrences)"],
    [".env.example", "Added 5 v0.4.4 HTTP-security env vars"],
    ["src/tests/identity-provenance-persisted.test.ts (NEW)", "2 regression tests for the identityProvenance persistence invariant"],
]
t = Table(file_rows, colWidths=[2.7*inch, 4.0*inch])
t.setStyle(TableStyle([
    ("BACKGROUND", (0,0), (-1,0), colors.lightgrey),
    ("FONTNAME", (0,0), (-1,0), "Helvetica-Bold"),
    ("BOX", (0,0), (-1,-1), 0.5, colors.grey),
    ("INNERGRID", (0,0), (-1,-1), 0.25, colors.grey),
    ("VALIGN", (0,0), (-1,-1), "TOP"),
    ("FONTSIZE", (0,0), (-1,-1), 8),
]))
story.append(t)
story.append(Spacer(1, 0.2*inch))

story.append(Paragraph(
    f"Source ZIP: downloads/Zobiris_v{VERSION}_Source.zip (SHA-256: {ZIP_SHA}). "
    f"SHA256SUMS.txt + MANIFEST.json in the same directory. 428 tests across 58 files, all passing on a clean install.",
    SMALL
))

doc.build(story)
print(f"Wrote {OUT}")
