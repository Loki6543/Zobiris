#!/usr/bin/env node
import { rmSync } from "node:fs";
import { resolve } from "node:path";
import { fileURLToPath } from "node:url";

const scriptDir = resolve(fileURLToPath(import.meta.url), "..");
const generatedAssets = resolve(scriptDir, "../public/assets");

// Vite writes hashed files here while public/ also retains the legacy
// compatibility shell. Clear only generated assets so old hashes cannot
// accumulate across builds or enter a release archive.
rmSync(generatedAssets, { recursive: true, force: true });
