#!/usr/bin/env node
// Build a static SPA bundle from the latest database snapshot.
import { spawn } from 'node:child_process';
import { writeFileSync, mkdirSync, existsSync } from 'node:fs';
import { resolve } from 'node:path';
import http from 'node:http';

const ROOT = resolve(import.meta.dirname ?? new URL('.', import.meta.url).pathname, '..');
const DIST = resolve(ROOT, 'dist');
const DATA = resolve(DIST, 'data');
const DB_PATH = process.env.ZOBIRIS_DB_PATH ?? './zobiris.db';

if (!existsSync(DATA)) mkdirSync(DATA, { recursive: true });

// Start the server
const server = spawn('npx', ['tsx', 'src/server/server.ts'], {
  cwd: ROOT,
  env: { ...process.env, ZOBIRIS_DB_PATH: DB_PATH, PORT: '4273' },
  stdio: ['ignore', 'pipe', 'pipe'],
});

await new Promise((resolve) => setTimeout(resolve, 5000));

const fetch = (path) => new Promise((resolve, reject) => {
  http.get(`http://127.0.0.1:4273${path}`, (res) => {
    let body = '';
    res.on('data', (c) => (body += c));
    res.on('end', () => resolve(body));
  }).on('error', reject);
});

const endpoints = [
  { path: '/api/snapshot/latest', file: 'snapshot_latest.json' },
  { path: '/api/providers', file: 'providers.json' },
  { path: '/api/audit?limit=20', file: 'audit.json' },
  { path: '/api/db-info', file: 'db-info.json' },
  { path: '/api/regime', file: 'regime.json' },
  { path: '/api/specialists/summary', file: 'specialists_summary.json' },
  { path: '/api/calibration', file: 'calibration.json' },
  { path: '/api/snapshots?limit=20', file: 'snapshots.json' },
  { path: '/api/health', file: 'health.json' },
];

for (const { path, file } of endpoints) {
  try {
    const body = await fetch(path);
    writeFileSync(resolve(DATA, file), body);
    console.log(`  ${file} OK`);
  } catch (e) {
    console.log(`  ${file} FAIL: ${e.message}`);
  }
}

// Per-asset JSON for top assets. v0.4.3 watchlist universe — match
// src/fixtures/watchlist.json so the demo reflects the new audit-fixed
// universe.
const TOP_ASSETS = [
  "BTC", "ETH", "SOL", "HYPE", "ZEC", "LINK", "GRAM", "AVAX", "SHIB", "UNI",
  "QNT", "KAS", "VELVET", "COMP", "AKT", "TAG", "CHZ", "KAITO", "SENT", "EGLD",
  "DGB", "BDX", "UB", "Q", "DRV", "UAI", "ALLO", "AISENTIS", "NPC", "JCT",
  "ZEREBRO", "TRUTH", "VR", "AIN", "ARX", "ZEST", "DAG", "SERV", "GIGA", "BLUAI",
  "EVAA", "WET", "BMT", "DEOD", "PYTHIA", "PONKE", "APU", "BEE", "ESIM", "ATR",
];
for (const sym of TOP_ASSETS) {
  try {
    const body = await fetch(`/api/asset/${sym}`);
    writeFileSync(resolve(DATA, `asset_${sym.toLowerCase()}.json`), body);
    console.log(`  asset_${sym.toLowerCase()}.json OK`);
  } catch (e) {
    console.log(`  asset_${sym.toLowerCase()}.json FAIL: ${e.message}`);
  }
}

server.kill();
console.log('Done.');
