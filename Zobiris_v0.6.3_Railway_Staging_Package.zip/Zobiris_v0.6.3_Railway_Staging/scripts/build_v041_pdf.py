#!/usr/bin/env python3
"""Build the v0.4.1 PDF deliverable — audit fixes."""
import json
from pathlib import Path
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak
from reportlab.lib import colors
from reportlab.lib.units import inch

ROOT = Path("/workspace/zobiris_core")
OUT = ROOT / "downloads" / "Zobiris_v0.4.1_Full_Deliverable.pdf"
OUT.parent.mkdir(exist_ok=True)

# Read the manifest so the PDF reflects the actual verified state.
manifest = json.loads((ROOT / "downloads" / "MANIFEST.json").read_text())
ZIP_SHA = manifest["sourceZipSha256"]
TEST_COUNT = manifest["testCount"]
VERSION = manifest["version"]

styles = getSampleStyleSheet()
H1 = styles["Heading1"]
H2 = styles["Heading2"]
H3 = styles["Heading3"]
BODY = styles["BodyText"]
MONO = ParagraphStyle("mono", parent=styles["Code"], fontSize=8, leading=10, leftIndent=12)

doc = SimpleDocTemplate(str(OUT), pagesize=letter, leftMargin=0.6*inch, rightMargin=0.6*inch, topMargin=0.6*inch, bottomMargin=0.6*inch)
story = []

story.append(Paragraph(f"Zobiris Intelligence Engine v{VERSION}", H1))
story.append(Paragraph("Independent source audit — P0 release-blocker fixes", H2))
story.append(Paragraph(
    "Production-quality multi-chain crypto portfolio intelligence. Decision support only — no wallet, no keys, no trade execution. "
    + "This release closes the P0 defects identified in the v0.4.1 independent audit. The release ZIP is the actual repository; "
    + "the release manifest is bound to the executed test run.",
    BODY
))
story.append(Spacer(1, 0.15*inch))

# Build summary
story.append(Paragraph("Build summary", H2))
summary_data = [
    ["Tests passing", f"{TEST_COUNT} / {TEST_COUNT}", f"typecheck passed, manifest bound to actual run"],
    ["TypeScript errors", "0", "tsc --noEmit clean (verified by build_manifest.mjs)"],
    ["Live provider paths", "5 + 1", "Kraken, CMC, LunarCrush, CoinGlass, CoinMarketCal, Soofi S"],
    ["Watchlist", "50 (current CMC)", "stale 30-entry tail removed; watchlist now matches coinmarketcap.com/watchlist/69c01b46aed37c7160053535"],
    ["Outbox", "atomic", "persistRefresh now wrapped in db.transaction() with fault-injection tests"],
    ["Canonical IDs", "stable + deterministic", "no more random UUIDs per refresh"],
    ["buildAdapters wiring", "verified", "COINGLASS_API_KEY / COINMARKETCAL_API_KEY / LUNARCRUSH_API_KEY actually wire live mode"],
    ["Public SPA in ZIP", "yes (public/)", "P0 #2: was previously excluded; now included"],
    ["ZIP SHA-256", ZIP_SHA[:32] + "...", "verified against SHA256SUMS.txt"],
    ["Source ZIP", "Zobiris_v0.4.1_Source.zip", f"{manifest['sourceZipBytes']:,} bytes, {len(manifest['files'])} files"],
]
t = Table(summary_data, colWidths=[2*inch, 2.5*inch, 2.5*inch])
t.setStyle(TableStyle([
    ("BACKGROUND", (0, 0), (-1, 0), colors.lightgrey),
    ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
    ("FONTSIZE", (0, 0), (-1, -1), 9),
    ("VALIGN", (0, 0), (-1, -1), "TOP"),
]))
story.append(t)
story.append(Spacer(1, 0.2*inch))

# P0 fixes
story.append(Paragraph("P0 release-blocker fixes (audit 2026-08-22)", H2))
p0_fixes = [
    ("#1 Watchlist", "Replaced stale 50-item watchlist with the current CMC watchlist (BTC..ATR). New symbols include DGB, BDX, VIRTUAL, TRUTH, DRV, ZEREBRO, EVAA, BEE, ESIM, ATR. The removed 30 entries (AAVE, TRX, ONDO, ARB, APT, SUI, TIA, WIF, JTO, JUP, PYTH, FET, ICP, FIL, PEPE, BONK, OP, MATIC, NEAR, STX, RNDR, MNT, LDO, MKR, GRT, MASK, etc.) are no longer in the canonical-mappings file. syncWatchlist() now marks assets absent from a new source as removed (soft delete; rows remain queryable). The 'count === 50' guard has been replaced with exact-membership comparison in audit-watchlist.test.ts."),
    ("#2 Release artifact", "public/ is no longer excluded from the release ZIP. The delivered archive now contains the actual SPA source (index.html, app.js, style.css) sufficient to reproduce the deployed site. Verified by audit-release-includes-frontend.test.ts."),
    ("#3 Transactional outbox", "persistRefresh() is now wrapped in a single db.transaction() closure. If any of the 11 steps throws, ALL rows from that refresh are rolled back. Six fault-injection tests in audit-transaction-rollback.test.ts prove the rollback behavior (failAfter: 'syncWatchlist' | 'canonical' | 'providerHealth' | 'openSession' | 'observations' | 'evidence' | 'snapshot' | 'outbox' | 'stages' | 'closeSession' | 'audit')."),
    ("#4 Live provider contracts", "buildAdapters() now actually reads COINGLASS_API_KEY, COINMARKETCAL_API_KEY, and LUNARCRUSH_API_KEY and wires them into live mode (previously CoinGlass and CoinMarketCal were never activated regardless of env state). Verified by audit-buildAdapters-wiring.test.ts (8 tests)."),
    ("#5 Specialist evidence wiring", "Provider normalizers now emit the actual canonical asset id, not the 'sym:TICKER' pseudo-id. Specialist routing filters match (canonical.id === obs.canonicalAssetId). Verified by audit-canonical-id.test.ts: when a normalizer emits 'sym:BTC' the test fails — the fix is to use the canonical id."),
    ("#6 Stable canonical IDs", "Canonical assets have stable, deterministic IDs derived from the identity key. Two consecutive refreshes resolve to the same canonical id. Verified by audit-canonical-id.test.ts: two upserts of the same symbol yield the same id; listAllCanonical returns one row per symbol (no duplicates)."),
    ("#7 19-stage contract", "Each stage now records a truthful terminal state. The runtime emits explicit 'succeeded' / 'skipped' / 'not_configured' markers. Skipped stages never report 'succeeded'."),
]
for tag, text in p0_fixes:
    story.append(Paragraph(f"<b>{tag}:</b> {text}", BODY))
    story.append(Spacer(1, 0.05*inch))

story.append(PageBreak())

# New audit regression tests
story.append(Paragraph("New regression tests (added in v0.4.1)", H2))
audit_tests_data = [
    ["Test file", "Tests", "Covers audit item"],
    ["audit-watchlist.test.ts", "10", "P0 #1: stale watchlist, missing mappings, removal handling"],
    ["audit-transaction-rollback.test.ts", "6", "P0 #3: persistRefresh atomicity, fault injection, replay"],
    ["audit-canonical-id.test.ts", "6", "P0 #5 + #6: stable ids, specialist evidence wiring"],
    ["audit-buildAdapters-wiring.test.ts", "8", "P0 #4: env keys actually wire live mode"],
    ["audit-release-includes-frontend.test.ts", "4", "P0 #2: ZIP includes public/"],
    ["audit-release-metadata.test.ts", "2", "P2 #13: package.json ↔ package-lock.json version match"],
    ["Total new audit tests", "36", "All passing"],
]
t = Table(audit_tests_data, colWidths=[3*inch, 0.7*inch, 3.3*inch])
t.setStyle(TableStyle([
    ("BACKGROUND", (0, 0), (-1, 0), colors.lightgrey),
    ("BACKGROUND", (0, -1), (-1, -1), colors.lightyellow),
    ("FONTNAME", (0, -1), (-1, -1), "Helvetica-Bold"),
    ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
    ("FONTSIZE", (0, 0), (-1, -1), 8.5),
    ("VALIGN", (0, 0), (-1, -1), "TOP"),
]))
story.append(t)
story.append(Spacer(1, 0.2*inch))

# Deferred work
story.append(Paragraph("Deferred to next release (audit items still open)", H2))
deferred = [
    "P1 #8: Iyaza/Mavis modules (TaskSpec, Capability Registry, OEP, Learning) written but not all wired into runRefresh as authoritative sources. The modules exist; the integration tests are partial.",
    "P1 #9: Specialist output does not yet modify the deterministic portfolio snapshot. The current architecture runs specialists and returns the result alongside the snapshot, but does not re-derive the final ranking from specialist reconciliation.",
    "P1 #10: Some scoring priors (e.g. liquidityScore() returning 60 when only price is known) still look like observed evidence. The case file should distinguish observed from imputed from prior.",
    "P1 #11: Provider fan-out is still hard-coded to BTC/ETH/SOL for the live network calls (CoinGlass, LunarCrush defaults). The watchlist is now 50, so the live providers see only a subset.",
    "P1 #12: POST /api/refresh is unauthenticated. The release-blocker for paid-provider mode is now auth + rate-limit + in-progress lock.",
    "P2 #13: README, IMPLEMENTATION_LOG.md, VERIFICATION_REPORT.md are still stale. These are documentation, not code, and the next release must regenerate them.",
    "19-stage contract: stages 4-7 (live evidence acquisition) and 19 (telemetry persistence) are partially implemented and require real provider keys to be exercised end-to-end.",
]
for item in deferred:
    story.append(Paragraph("• " + item, BODY))
story.append(Spacer(1, 0.2*inch))

# Reproducibility
story.append(Paragraph("Reproducing this release", H2))
story.append(Paragraph("The release manifest is the source of truth, not a manual caption. To verify:", BODY))
story.append(Paragraph(
    "1. sha256sum Zobiris_v0.4.1_Source.zip  → must equal " + ZIP_SHA,
    MONO,
))
story.append(Paragraph(
    "2. unzip Zobiris_v0.4.1_Source.zip && cd Zobiris_v0.4.1_Source && npm install",
    MONO,
))
story.append(Paragraph("3. npx tsc --noEmit  → 0 errors", BODY))
story.append(Paragraph(f"4. npx vitest run  → {TEST_COUNT} / {TEST_COUNT} passing", BODY))
story.append(Paragraph("5. node scripts/build_manifest.mjs  → re-executes tests, fails on regression", BODY))
story.append(Spacer(1, 0.15*inch))

# Source files of note
story.append(Paragraph("Source files of note (v0.4.1)", H2))
sf_data = [
    ["File", "Purpose"],
    ["src/fixtures/watchlist.json", "50 current CMC symbols (replaced stale 50-entry list)"],
    ["src/fixtures/canonical-mappings.json", "50 entries: 16 verified ERC-20/native + 34 unmapped (research needed)"],
    ["src/storage/repository.ts", "syncWatchlist now marks removals; returns {added, removed, reactivated}"],
    ["src/storage/integration.ts", "persistRefresh now wrapped in db.transaction(); fault-injection faultAfter option"],
    ["src/scripts/_adapters.ts", "buildAdapters now reads COINGLASS_API_KEY / COINMARKETCAL_API_KEY / LUNARCRUSH_API_KEY"],
    ["src/providers/coinglass.ts", "live path: open-api-v4.coinglass.com (audit P0 #4 base URL fix)"],
    ["src/providers/coinmarketcal.ts", "live path: api.coinmarketcal.com/v2/events (audit P0 #4 contract fix)"],
    ["src/providers/lunarcrush.ts", "live path: api.lunarcrush.com/v4 (audit P0 #4 contract fix)"],
    ["src/providers/soofi.ts", "new: Soofi S (German sovereign LLM) via OpenAI-compatible /v1/chat/completions"],
    ["scripts/build_manifest.mjs", "now INCLUDES public/; runs tsc + vitest; refuses release on failure"],
]
t = Table(sf_data, colWidths=[2.7*inch, 4*inch])
t.setStyle(TableStyle([
    ("BACKGROUND", (0, 0), (-1, 0), colors.lightgrey),
    ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
    ("FONTSIZE", (0, 0), (-1, -1), 8.5),
    ("FONTNAME", (0, 1), (0, -1), "Courier"),
    ("VALIGN", (0, 0), (-1, -1), "TOP"),
]))
story.append(t)
story.append(Spacer(1, 0.2*inch))

story.append(Paragraph("—", BODY))
story.append(Paragraph(f"Source ZIP: Zobiris_v0.4.1_Source.zip ({manifest['sourceZipBytes']:,} bytes, {len(manifest['files'])} files)", BODY))
story.append(Paragraph(f"ZIP SHA-256: {ZIP_SHA}", MONO))
story.append(Paragraph("Manifest: MANIFEST.json (bound to actual tsc + vitest run)", BODY))
story.append(Paragraph("Per-file SHA-256: SHA256SUMS.txt", BODY))
story.append(Paragraph("Build: 2026-08-22 (America/Los_Angeles)", BODY))

doc.build(story)
print(f"Built {OUT}")
