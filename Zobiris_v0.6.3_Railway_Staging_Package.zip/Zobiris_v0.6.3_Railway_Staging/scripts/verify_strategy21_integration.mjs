#!/usr/bin/env node
import { readFileSync, existsSync } from 'node:fs';

const checks = [];
const read = (p) => readFileSync(p, 'utf8');
const expect = (name, condition) => {
  checks.push({ name, ok: Boolean(condition) });
  if (!condition) process.exitCode = 1;
};

const pkg = JSON.parse(read('package.json'));
const refresh = read('src/runtime/refresh.ts');
const server = read('src/server/server.ts');
const cli = read('src/scripts/zobiris.ts');
const app = read('src/ui/App.tsx');
const casePanel = read('src/ui/AssetCasePanel.tsx');
const portfolio = read('src/domain/portfolio.ts');
const integration = read('src/strategy21/integration.ts');
const capital = read('src/strategy21/engine/capital.ts');
const liquidity = read('src/strategy21/engine/liquidity.ts');
const actors = read('src/strategy21/engine/actors.ts');
const personality = read('src/strategy21/engine/personality.ts');

expect('release version is 0.6.3', pkg.version === '0.6.3');
expect('canonical Strategy 2.1 spec is bundled', existsSync('docs/strategy21/ZOBIRIS_2_1_FINAL_SPEC.md'));
expect('refresh invokes Strategy 2.1 integration', refresh.includes('integrateStrategy21({'));
expect('refresh reloads previous market state', refresh.includes('loadStrategyMarketState'));
expect('portfolio schema persists asset Strategy payload', portfolio.includes('strategy21: z.unknown().optional()'));
expect('server exposes Strategy summary', server.includes('GET /api/strategy21'));
expect('server exposes size-aware liquidity endpoint', server.includes('GET /api/strategy21/liquidity/:symbol'));
expect('server exposes authenticated collector route', server.includes('POST /api/strategy21/collect'));
expect('optional background collector is wired', server.includes('ZOBIRIS_STRATEGY21_AUTO_COLLECT'));
expect('CLI reports Strategy doctrine', cli.includes('Strategy 2.1'));
expect('Command Center exposes next-dollar ranking', app.includes('Best Next Dollar'));
expect('Asset Case File exposes Strategy 2.1', casePanel.includes('Strategy Engine 2.1'));
expect('behavioral personality engine is bundled', existsSync('docs/strategy21/BEHAVIORAL_PERSONALITY_ENGINE.md'));
expect('Elastic Strength is implemented', personality.includes('computeElasticStrength'));
expect('personality is descriptive-only in production', personality.includes('DESCRIPTIVE_ONLY'));
expect('Strategy integration surfaces personality', integration.includes('personalityBySymbol'));
expect('Asset Case File exposes Behavioral Personality', casePanel.includes('Behavioral Personality'));
expect('$1,500 maneuver capital is encoded', capital.includes('maneuverNavUsd: 1500'));
expect('$1,800 reserve remains separate', capital.includes('strategicTargetUsd: 1800'));
expect('legacy target weight does not size Strategy target', !integration.includes('asset.targetWeight?.pct'));
expect('legacy research score does not synthesize expected return', !integration.includes('researchScore(asset) * 20'));
expect('legacy research score does not size requested target', !integration.includes('rScore *'));
expect('ranking authority is explicit', integration.includes('OPPORTUNITY_HEURISTIC_V1'));
expect('position sizing authority is explicit', integration.includes('RISK_CAPS_ONLY'));
expect('general auth excludes anonymous refresh exception', !read('src/server/security.ts').includes('if (cfg.allowAnonymousRefresh) return true'));
expect('refresh has a dedicated authorization function', read('src/server/security.ts').includes('isRefreshAuthorized'));
expect('server has a centralized mutation guard', server.includes('centralized fail-closed mutation guard'));
expect('Kraken book structural validation is fail-closed', liquidity.includes('isBookStructurallyValid'));
expect('round-trip fee evidence participates in eligibility', liquidity.includes('takerFeeBpsPerSide'));
expect('bearish observed actor impulse is supported', actors.includes('clampSigned'));
expect('no private env file is bundled', !existsSync('.env.local'));

for (const c of checks) console.log(`${c.ok ? 'PASS' : 'FAIL'}  ${c.name}`);
const passed = checks.filter(c => c.ok).length;
console.log(`\n${passed}/${checks.length} integration checks passed.`);
