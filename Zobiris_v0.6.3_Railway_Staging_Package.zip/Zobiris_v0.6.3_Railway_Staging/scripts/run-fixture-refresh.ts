#!/usr/bin/env -S npx tsx
// v0.4.3: bake fresh data using fixture mode (not live mode).
// The default CLI behavior is now live-mode; this wrapper forces
// fixture mode for the demo bake so we have something to show.
import { buildAdapters } from "../src/scripts/_adapters.js";
import { runRefresh } from "../src/runtime/refresh.js";
import { loadWatchlist } from "../src/scripts/_watchlist.js";
import { DEFAULT_SCORING_CONFIG } from "../src/domain/scoring.js";
import { persistRefresh } from "../src/storage/integration.js";
import { openStorage } from "../src/storage/client.js";

(async () => {
  console.log("[bake] building adapters (fixture mode, no live keys)");
  const adapters = buildAdapters({ staleSeconds: 60, live: false });
  console.log("[bake] loading watchlist");
  const watchlist = await loadWatchlist();
  console.log("[bake] running refresh with", watchlist.length, "assets");
  const result = await runRefresh({
    mode: "deep",
    watchlist,
    policy: DEFAULT_SCORING_CONFIG,
    adapters,
  });
  console.log(
    `[bake] refresh done: ${result.snapshot.rankedAssets.length} ranked assets, regime=${result.snapshot.regime}`,
  );
  console.log("[bake] persisting to zobiris.db");
  const db = openStorage({ path: "./zobiris.db" });
  const persistResult = persistRefresh({
    db: db.db,
    session: result.session,
    watchlist,
    observations: result.observations,
    evidenceClaims: result.evidenceClaims,
    snapshot: result.snapshot,
    canonicalMap: result.canonicalMap,
    providerHealthUpdates: result.providerHealthUpdates,
  });
  console.log("[bake] persist:", JSON.stringify(persistResult));
  db.close();
  console.log("[bake] done");
})().catch((e) => {
  console.error(e);
  process.exit(1);
});
