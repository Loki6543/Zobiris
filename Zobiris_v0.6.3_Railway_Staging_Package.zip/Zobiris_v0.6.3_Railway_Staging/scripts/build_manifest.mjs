#!/usr/bin/env node
/**
 * Zobiris — SHA-256 release manifest generator.
 *
 * Usage:
 *   node scripts/build_manifest.mjs [--version=X.Y.Z]
 *
 * Outputs to downloads/:
 *   - Zobiris_v<version>_Source.zip   (the source ZIP, excluding node_modules/dist/.git/...)
 *   - SHA256SUMS.txt                  (one SHA-256 per included file)
 *   - MANIFEST.json                   (version, git commit, ZIP hash, test count, ...)
 */
import { createHash } from "node:crypto";
import {
  createReadStream,
  createWriteStream,
  writeFileSync,
  appendFileSync,
  statSync,
  existsSync,
  mkdirSync,
  readFileSync,
  readdirSync,
} from "node:fs";
import { resolve, relative, join, basename } from "node:path";
import { spawnSync } from "node:child_process";
import { fileURLToPath } from "node:url";
import { createGzip, createBrotliCompress } from "node:zlib";
import { pipeline } from "node:stream/promises";

const __filename = fileURLToPath(import.meta.url);
const __dirname = resolve(__filename, "..");
const ROOT = resolve(__dirname, "..");
const DOWNLOADS = resolve(ROOT, "downloads");

function parseArgs(argv) {
  const args = { version: null };
  for (const a of argv.slice(2)) {
    if (a.startsWith("--version=")) args.version = a.slice("--version=".length);
  }
  return args;
}

function readPackageVersion() {
  try {
    const pkg = JSON.parse(readFileSync(resolve(ROOT, "package.json"), "utf8"));
    return pkg.version ?? "0.0.0";
  } catch {
    return "0.0.0";
  }
}

function getGitCommit() {
  const r = spawnSync("git", ["rev-parse", "HEAD"], {
    cwd: ROOT,
    encoding: "utf8",
  });
  if (r.status === 0 && r.stdout) return r.stdout.trim();
  return "no-git";
}

function sha256File(path) {
  return new Promise((resolveP, rejectP) => {
    const h = createHash("sha256");
    const s = createReadStream(path);
    s.on("data", (c) => h.update(c));
    s.on("end", () => resolveP(h.digest("hex")));
    s.on("error", rejectP);
  });
}

// --- Minimal in-memory ZIP writer (no compression) ---
class ZipWriter {
  constructor() {
    this.entries = [];
    this.parts = [];
    this.offset = 0;
  }
  addFile(path, data) {
    const nameBuf = Buffer.from(path, "utf8");
    const crc = computeCrc32(data);
    const crcBuf = Buffer.alloc(4);
    crcBuf.writeUInt32LE(crc, 0);
    const sizeBuf = Buffer.alloc(8);
    sizeBuf.writeUInt32LE(data.length, 0);
    sizeBuf.writeUInt32LE(data.length >>> 0, 4); // for ZIP64 (not strictly needed here)

    // Local file header
    const lfh = Buffer.alloc(30);
    lfh.writeUInt32LE(0x04034b50, 0); // signature
    lfh.writeUInt16LE(20, 4); // version needed
    lfh.writeUInt16LE(0, 6); // flags
    lfh.writeUInt16LE(0, 8); // compression: stored
    lfh.writeUInt16LE(0, 10); // mod time
    lfh.writeUInt16LE(0, 12); // mod date
    crcBuf.copy(lfh, 14);
    lfh.writeUInt32LE(data.length, 18); // compressed size
    lfh.writeUInt32LE(data.length, 22); // uncompressed size
    lfh.writeUInt16LE(nameBuf.length, 26);
    lfh.writeUInt16LE(0, 28); // extra field length

    const header = Buffer.concat([lfh, nameBuf]);
    this.parts.push(header);
    this.parts.push(data);
    const headerOffset = this.offset;
    this.offset += header.length + data.length;

    this.entries.push({
      name: path,
      crc,
      size: data.length,
      offset: headerOffset,
    });
  }
  finalize() {
    // Central directory
    const cdStart = this.offset;
    const cdParts = [];
    for (const e of this.entries) {
      const nameBuf = Buffer.from(e.name, "utf8");
      const cd = Buffer.alloc(46);
      cd.writeUInt32LE(0x02014b50, 0); // signature
      cd.writeUInt16LE(20, 4); // version made by
      cd.writeUInt16LE(20, 6); // version needed
      cd.writeUInt16LE(0, 8); // flags
      cd.writeUInt16LE(0, 10); // compression
      cd.writeUInt16LE(0, 12); // mod time
      cd.writeUInt16LE(0, 14); // mod date
      cd.writeUInt32LE(e.crc, 16);
      cd.writeUInt32LE(e.size, 20); // compressed
      cd.writeUInt32LE(e.size, 24); // uncompressed
      cd.writeUInt16LE(nameBuf.length, 28);
      cd.writeUInt16LE(0, 30); // extra
      cd.writeUInt16LE(0, 32); // comment
      cd.writeUInt16LE(0, 34); // disk
      cd.writeUInt16LE(0, 36); // internal attrs
      cd.writeUInt32LE(0, 38); // external attrs
      cd.writeUInt32LE(e.offset, 42); // local header offset
      cdParts.push(Buffer.concat([cd, nameBuf]));
    }
    const cdBuf = Buffer.concat(cdParts);
    const cdSize = cdBuf.length;

    // End of central directory
    const eocd = Buffer.alloc(22);
    eocd.writeUInt32LE(0x06054b50, 0);
    eocd.writeUInt16LE(0, 4);
    eocd.writeUInt16LE(0, 6);
    eocd.writeUInt16LE(this.entries.length, 8);
    eocd.writeUInt16LE(this.entries.length, 10);
    eocd.writeUInt32LE(cdSize, 12);
    eocd.writeUInt32LE(cdStart, 16);
    eocd.writeUInt16LE(0, 20);

    return Buffer.concat([...this.parts, cdBuf, eocd]);
  }
}

function computeCrc32(buf) {
  // Use the standard CRC-32 table
  let table = computeCrc32.table;
  if (!table) {
    table = new Uint32Array(256);
    for (let n = 0; n < 256; n++) {
      let c = n;
      for (let k = 0; k < 8; k++) {
        c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
      }
      table[n] = c >>> 0;
    }
    computeCrc32.table = table;
  }
  let crc = 0xffffffff;
  for (let i = 0; i < buf.length; i++) {
    crc = table[(crc ^ buf[i]) & 0xff] ^ (crc >>> 8);
  }
  return (crc ^ 0xffffffff) >>> 0;
}

const EXCLUDE = new Set([
  "node_modules",
  "dist",
  ".git",
  ".env",
  ".env.local",
  "downloads",
  ".DS_Store",
  "*.db",
  "*.db-journal",
  "*.db-wal",
  "*.db-shm",
  "*.log",
  "zobiris.db",
  ".mavis",
  "build", // legacy PDF/HTML scratch dir
  "coverage",
  ".vitest-cache",
  "tmp",
]);
// Note: per the v0.4.1 audit (P0 #2), the previous exclusion of `public/`
// broke the "release ZIP reproduces deployed site" claim. We now INCLUDE
// public/ (the SPA served by the HTTP server) so the release artifact is
// sufficient to reproduce the deployed site.

function shouldExclude(name) {
  if (name.startsWith(".env.")) return true;
  if (EXCLUDE.has(name)) return true;
  for (const pat of EXCLUDE) {
    if (pat.startsWith("*") && name.endsWith(pat.slice(1))) return true;
  }
  return false;
}

function walkFiles(dir, base = dir) {
  const out = [];
  const items = readdirSync(dir, { withFileTypes: true });
  for (const item of items) {
    if (shouldExclude(item.name)) continue;
    const full = join(dir, item.name);
    const rel = relative(base, full);
    if (item.isDirectory()) {
      out.push(...walkFiles(full, base));
    } else if (item.isFile()) {
      out.push({ full, rel });
    }
  }
  return out;
}

async function main() {
  const args = parseArgs(process.argv);
  const version = args.version ?? readPackageVersion();
  const gitCommit = getGitCommit();
  const buildTimestamp = new Date().toISOString();

  if (!existsSync(DOWNLOADS)) mkdirSync(DOWNLOADS, { recursive: true });

  console.log(`[manifest] version=${version} commit=${gitCommit}`);

  // v0.4.2 audit fix (P1): run release gates FIRST, then create the
  // final artifacts. If any gate fails, exit with no production-named
  // artifacts in DOWNLOADS. The previous flow wrote a partial ZIP
  // first, then ran tests, which violated the release-contract promise.
  console.log("[manifest] running typecheck gate...");
  const typecheck = spawnSync("npx", ["tsc", "--noEmit"], {
    cwd: ROOT,
    encoding: "utf8",
  });
  const typecheckPassed = typecheck.status === 0;
  if (!typecheckPassed) {
    console.error(
      "[manifest] typecheck FAILED — no artifacts will be written.",
    );
    console.error(typecheck.stdout || typecheck.stderr);
    process.exit(1);
  }
  console.log("[manifest] typecheck passed");

  console.log("[manifest] running test gate...");
  // Parse the human summary by running with the default reporter too,
  // since the JSON reporter's structure has changed across vitest
  // versions. The test file count is counted from the workspace
  // directly so we never report 0 when tests passed.
  const testRun = spawnSync("npx", ["vitest", "run", "--reporter=default"], {
    cwd: ROOT,
    encoding: "utf8",
  });
  const testCommandOutput =
    (testRun.stdout || "") + "\n" + (testRun.stderr || "");
  if (testRun.status !== 0) {
    console.error("[manifest] tests FAILED — no artifacts will be written.");
    console.error(testCommandOutput.slice(0, 4000));
    process.exit(1);
  }
  // Parse "Test Files  N passed (M)" and "Tests  K passed (L)" from output.
  // v0.4.4 audit fix (P0 #36): counts are calculated from the test
  // run output, never hand-maintained in the report. The audit
  // caught the previous PDF reporting "6 P0 / 26 tests" in the
  // header but "7 P0 / 28 new tests" in the body. Counts now come
  // from one source: the test run output.
  let testCount = 0;
  let testFiles = 0;
  const filesMatch = testCommandOutput.match(/Test Files\s+(\d+)\s+passed/);
  if (filesMatch) testFiles = parseInt(filesMatch[1], 10);
  const testsMatch = testCommandOutput.match(/Tests\s+(\d+)\s+passed/);
  if (testsMatch) testCount = parseInt(testsMatch[1], 10);
  console.log(
    `[manifest] tests passed: ${testCount} across ${testFiles} files`,
  );

  // v0.4.4 audit fix (P0 #15): semantic-version-unique-artifact.
  // Reject the release if another build with the same semantic
  // version is already present in DOWNLOADS. This is the audit's
  // exact failure pattern: two different hashes sharing one version.
  if (existsSync(join(DOWNLOADS, `Zobiris_v${version}_Source.zip`))) {
    console.error(
      `[manifest] FAIL: a build with version ${version} already exists ` +
        `(see Zobiris_v${version}_Source.zip). Each semantic version must correspond ` +
        `to exactly one source ZIP.`,
    );
    process.exit(1);
  }

  // v0.4.4 audit fix (P0 #14): no-trading-execution static check.
  // Run before producing any production-named artifacts.
  console.log("[manifest] running no-trading-execution static check...");
  const tradingCheck = spawnSync("bash", ["scripts/check_no_trading.sh"], {
    cwd: ROOT,
    encoding: "utf8",
  });
  if (tradingCheck.status !== 0) {
    console.error(
      "[manifest] no-trading-execution check FAILED — refusing release.",
    );
    console.error(tradingCheck.stdout || tradingCheck.stderr);
    process.exit(1);
  }
  console.log("[manifest] no-trading-execution check passed");

  // Preserve the previous release's generic metadata before writing the
  // current version. Source ZIPs are already semver-unique; versioning these
  // companion files keeps an older release independently verifiable too.
  const currentManifestPath = join(DOWNLOADS, "MANIFEST.json");
  if (existsSync(currentManifestPath)) {
    try {
      const previousManifest = JSON.parse(
        readFileSync(currentManifestPath, "utf8"),
      );
      const previousVersion = previousManifest.version;
      if (typeof previousVersion === "string" && previousVersion !== version) {
        const archivedManifest = join(
          DOWNLOADS,
          `MANIFEST_v${previousVersion}.json`,
        );
        if (!existsSync(archivedManifest)) {
          writeFileSync(archivedManifest, readFileSync(currentManifestPath));
        }
        const currentSumsPath = join(DOWNLOADS, "SHA256SUMS.txt");
        const archivedSums = join(
          DOWNLOADS,
          `SHA256SUMS_v${previousVersion}.txt`,
        );
        if (existsSync(currentSumsPath) && !existsSync(archivedSums)) {
          writeFileSync(archivedSums, readFileSync(currentSumsPath));
        }
      }
    } catch {
      console.error(
        "[manifest] existing MANIFEST.json is invalid; refusing to overwrite release metadata",
      );
      process.exit(1);
    }
  }

  // GATES PASSED — now create the final release artifacts.
  const files = walkFiles(ROOT);
  console.log(`[manifest] including ${files.length} files`);

  const writer = new ZipWriter();
  const fileHashes = [];
  for (const f of files) {
    const data = readFileSync(f.full);
    writer.addFile(f.rel.split("\\").join("/"), data);
    const sha = createHash("sha256").update(data).digest("hex");
    fileHashes.push({ path: f.rel.split("\\").join("/"), sha256: sha });
  }
  const zipBuf = writer.finalize();

  const zipName = `Zobiris_v${version}_Source.zip`;
  const zipPath = join(DOWNLOADS, zipName);
  createWriteStream(zipPath).write(zipBuf);
  const zipSha = createHash("sha256").update(zipBuf).digest("hex");

  // Write SHA256SUMS.txt (v0.4.4: use writeFileSync + appendFileSync
  // to avoid the race condition with two write streams to the same
  // file; the audit caught that createWriteStream + createWriteStream
  // with flags: "a" can lose data on slow filesystems).
  const sumsLines =
    fileHashes.map((f) => `${f.sha256}  ${f.path}`).join("\n") + "\n";
  const sumsPath = join(DOWNLOADS, "SHA256SUMS.txt");
  writeFileSync(sumsPath, sumsLines);
  appendFileSync(sumsPath, `${zipSha}  ${zipName}\n`);

  // Hash the public/ UI bundle for the manifest.
  const uiHashes = {};
  for (const f of ["public/index.html", "public/app.js", "public/style.css"]) {
    if (existsSync(join(ROOT, f))) {
      const data = readFileSync(join(ROOT, f));
      uiHashes[f] = createHash("sha256").update(data).digest("hex");
    }
  }

  // Write MANIFEST.json
  const manifest = {
    schemaVersion: "0.4.1",
    version,
    gitCommit,
    buildTimestamp,
    sourceZip: zipName,
    sourceZipSha256: zipSha,
    sourceZipBytes: zipBuf.length,
    testCount,
    testFiles,
    typecheckPassed,
    uiHashes,
    files: fileHashes,
    providerStatus: {
      kraken: "live-ready",
      cmc: "live-ready (fixture-fallback)",
      lunarcrush: "live-ready (fixture-fallback)",
      coinglass: "live-ready (fixture-fallback)",
      coinmarketcal: "live-ready (fixture-fallback)",
      soofi: "live-ready (OpenAI-compatible, fixture-fallback)",
    },
    notes: `Zobiris v${version} release manifest. Verify SHA-256 of ZIP before deployment.`,
  };
  const manifestPath = join(DOWNLOADS, "MANIFEST.json");
  createWriteStream(manifestPath).write(
    JSON.stringify(manifest, null, 2) + "\n",
  );

  console.log(`[manifest] wrote ${zipPath}`);
  console.log(`[manifest] wrote ${sumsPath}`);
  console.log(`[manifest] wrote ${manifestPath}`);
  console.log(`[manifest] ZIP sha256: ${zipSha}`);
}

main().catch((e) => {
  console.error("[manifest] failed:", e);
  process.exit(1);
});
