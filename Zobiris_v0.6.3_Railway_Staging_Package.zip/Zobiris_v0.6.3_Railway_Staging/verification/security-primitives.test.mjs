import test from 'node:test';
import assert from 'node:assert/strict';
import { loadSecurityConfig, isAuthenticated, isRefreshAuthorized } from '../src/server/security.ts';

function req(auth) {
  return {
    headers: auth ? { authorization: auth } : {},
    socket: { remoteAddress: '127.0.0.1' },
  };
}

test('production ignores anonymous refresh opt-in', () => {
  const cfg = loadSecurityConfig({
    NODE_ENV: 'production',
    ZOBIRIS_ALLOW_ANONYMOUS_REFRESH: '1',
    ZOBIRIS_REFRESH_TOKEN: 'secret',
  });
  assert.equal(cfg.allowAnonymousRefresh, false);
});

test('general authentication never inherits the anonymous refresh exception', () => {
  const cfg = loadSecurityConfig({
    NODE_ENV: 'development',
    ZOBIRIS_ALLOW_ANONYMOUS_REFRESH: '1',
  });
  assert.equal(cfg.allowAnonymousRefresh, true);
  assert.equal(isAuthenticated(req(), cfg), false);
  assert.equal(isRefreshAuthorized(req(), cfg), true);
});

test('refresh authorization accepts a valid bearer token when anonymous refresh is disabled', () => {
  const cfg = loadSecurityConfig({
    NODE_ENV: 'production',
    ZOBIRIS_REFRESH_TOKEN: 'secret',
  });
  assert.equal(isRefreshAuthorized(req('Bearer secret'), cfg), true);
  assert.equal(isRefreshAuthorized(req('Bearer wrong'), cfg), false);
});
