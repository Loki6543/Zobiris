# v0.6.3 staging baseline

Railway Hobby is the selected host. Follow `RAILWAY_STAGING.md` for the current deployment recipe and hosted release gate. Historical notes below describe local verification only.

This source needs a long-running Node 24 service and a persistent writable SQLite volume. It is not a static-only website or a Cloudflare Workers application. The existing hosted Sites deployment was not modified by this checkpoint.

## Verified local commands

```sh
npm ci --ignore-scripts --no-audit --no-fund
npm run typecheck
npm test
npm run test:strategy21
node --test verification/security-primitives.test.mjs
npm run verify:strategy21-integration
bash scripts/check_no_trading.sh
npm run build:ui
```

The local installation succeeded with the original lockfile. A real better-sqlite3 query and the SQLite integration tests passed. On another host, native dependency installation must also succeed; do not treat a failed native install as a valid baseline.

## Deployment recipe — not yet deployed

`Dockerfile.staging` is a candidate container recipe. Docker is unavailable in the current workspace, so this image has not been built or validated. On the selected Node-compatible staging host:

1. Build the source with `docker build -f Dockerfile.staging -t zobiris-staging:0.6.3 .`.
2. Mount a persistent volume at `/data`, writable by container user `node` (UID 1000).
3. Inject a newly generated `ZOBIRIS_REFRESH_TOKEN` using the hosting provider's secret manager. Never put it in source, browser assets, URLs, or logs.
4. Preserve `NODE_ENV=production`, `HOST=0.0.0.0`, `PORT=3000`, `ZOBIRIS_DB_PATH=/data/zobiris.sqlite`, `ZOBIRIS_ALLOW_ANONYMOUS_REFRESH=0`, `ZOBIRIS_ALLOW_LIVE_PROVIDERS=0`, and `ZOBIRIS_STRATEGY21_AUTO_COLLECT=0` for the baseline security run.
5. Expose the service through the provider's HTTPS endpoint. Route all `/api/*` requests to the same server. Do not use a static fallback for API failures.
6. Run the following against the actual staging origin and retain the complete output:

```sh
node scripts/check_staging_security.mjs https://YOUR-STAGING-ORIGIN
```

The probe checks application JSON health and anonymous/wrong-token rejection on refresh, collection and Challenger routes. Run it only against staging: a broken guard could allow a mutation. Repeat with the anonymous-refresh opt-in set to `1` in production, then restore it to `0`. Use provider-injected valid credentials for a separate positive authentication check without logging the credential. Live-provider data verification is a separate follow-up after the security baseline; disabled providers are not live market coverage.

## Release gate still required

- Validate the actual container/service startup, native SQLite persistence across a restart, and HTTPS API routing.
- Repeat the security probe against the deployed service; local production-mode results are not deployed evidence.
- Browser flow: app loads → meaningful screen renders → watchlist/case file/evidence/Challenger controls respond. Capture desktop/mobile screenshots, console health, and actual interaction results. Check empty/error states as well as retained data.
- Record the immutable deployment revision and logs with this checkpoint.

Historical L2 implementation starts only after these gates pass. No order execution is authorized or implemented.
