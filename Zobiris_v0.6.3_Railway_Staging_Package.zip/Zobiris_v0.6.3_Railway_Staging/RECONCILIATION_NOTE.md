# Zobiris v0.6.3 Reconciliation Note

**Date:** 2026-09-06

## Why this package exists

The workspace contained a full v0.6.2 source archive and a directory named `Zobiris_v0.6.3_Audit_Fixes_Source`, but that v0.6.3 directory was **not** a full source tree. It contained only documentation/report material plus an `index.html`. The production files referenced by the v0.6.3 report (`src/strategy21/engine/liquidity.ts`, `src/strategy21/integration.ts`, `src/server/security.ts`, etc.) were absent from that directory.

This package therefore does **not** pretend the missing original source snapshot was recovered. Instead, it is a **reconciled full source tree** built from:

1. the available `Zobiris_v0.6.2_Source_With_Handoff_Docs.zip` baseline; and
2. the available `V0_6_3_AUDIT_FIX_REPORT.md` requirements.

The reported fixes were re-applied to the v0.6.2 source and verified in this workspace where possible.

## Re-applied v0.6.3 changes

- Kraken liquidity percentile convention changed to nearest-rank.
- Arithmetic median separated from percentile quantiles.
- 14-value p10 now resolves to the second-lowest observation.
- Missing expected-gross-return evidence fails closed to `WATCH_ONLY` once history is otherwise complete.
- Legacy `researchScore * 20` expected-return fallback removed.
- Legacy research-score-driven requested target sizing removed.
- Runtime authority metadata added:
  - `researchAuthority = DESCRIPTIVE_ONLY`
  - `rankingAuthority = OPPORTUNITY_HEURISTIC_V1`
  - `positionSizingAuthority = RISK_CAPS_ONLY`
- Current maneuver capital updated from $1,200 to $1,500.
- Strategy 2.1 policy docs updated for the $1,500 state caps.
- General authentication no longer inherits the anonymous-refresh exception.
- Anonymous refresh is disabled in `NODE_ENV=production` even if the env flag is set.
- Dedicated `isRefreshAuthorized()` added.
- Centralized API mutation guard added for POST/PUT/PATCH/DELETE; only `/api/refresh` may use refresh-specific authorization.
- Decision-line AND-gate regressions added for execution eligibility and opportunity positivity.
- SuperTrend/Bollinger/ATR remain unimplemented and have no production authority.
- Historical Kraken L2 certification remains unfinished; turnover is not relabeled as full execution certification.

## Fresh verification in this package

The following were run after reconstruction:

- Strategy 2.1 focused compile/tests: **71 tests, 71 pass, 0 fail**.
- Security primitive tests: **3 tests, 3 pass, 0 fail**.
- Strategy integration source checks: **31/31 pass**.
- Static no-trading-path check: **pass**.
- Node TypeScript syntax check for `src/server/server.ts` and `src/server/security.ts`: **pass**.

See `docs/strategy21/verification/` for captured outputs.

## Not verified here

The full inherited npm/Vitest/UI/HTTP integration suite was **not** independently completed in this environment because installing/restoring the complete dependency graph did not complete within the available container run. Do not report the old root-level `VERIFICATION_REPORT.md` as current v0.6.3 proof; it is an inherited historical artifact from earlier slices.

The already-public deployment is also **not** proven patched by this source package. It still requires rebuild/redeploy and anonymous mutation-route curl checks against the deployed server.

## Handoff instruction

When reconciling this ZIP with another Zobiris workspace:

1. treat this package as the newest **reconstructed full-source candidate**, not as proof of byte-for-byte recovery of the missing original v0.6.3 workspace;
2. preserve any additional local fixes that are newer or independently verified;
3. diff the files listed in `docs/strategy21/V0_6_3_AUDIT_FIX_REPORT.md` first;
4. rerun the focused Strategy 2.1 suite and security primitive suite after merge;
5. do not promote historical L2 or indicator subsystems beyond their current unfinished status.
