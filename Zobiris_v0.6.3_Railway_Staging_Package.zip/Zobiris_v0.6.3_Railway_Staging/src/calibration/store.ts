/**
 * Iyaza Addendum — Item E: Specialist/provider effectiveness calibration.
 *
 * Maintains a simple Beta posterior per (specialist, task_type, subdomain) or
 * (provider, capability, asset_class) key. Used as one routing signal — high
 * historical effectiveness does NOT bypass capability, freshness, evidence,
 * or independence requirements.
 */
export type EffectivenessKey = `${string}.${string}.${string}`;

export interface BetaPosterior {
  alpha: number;
  beta: number;
  n: number;
  /** Posterior mean = alpha / (alpha + beta). */
  mean: number;
  /** Posterior variance = (alpha*beta) / ((alpha+beta)^2 * (alpha+beta+1)). */
  variance: number;
}

export class CalibrationStore {
  private readonly store = new Map<EffectivenessKey, { alpha: number; beta: number; n: number }>();
  private readonly sink?: (entry: { key: EffectivenessKey; alpha: number; beta: number; success: boolean; at: string }) => void;

  constructor(sink?: typeof this.sink) {
    this.sink = sink;
  }

  /** Record a binary outcome (success or failure) for the given key. */
  recordOutcome(key: EffectivenessKey, success: boolean): void {
    const current = this.store.get(key) ?? { alpha: 1, beta: 1, n: 0 };
    if (success) {
      current.alpha += 1;
    } else {
      current.beta += 1;
    }
    current.n += 1;
    this.store.set(key, current);
    if (this.sink) {
      this.sink({ key, alpha: current.alpha, beta: current.beta, success, at: new Date().toISOString() });
    }
  }

  /** Get the current posterior for a key (uniform prior if not yet observed). */
  getPosterior(key: EffectivenessKey): BetaPosterior {
    const v = this.store.get(key) ?? { alpha: 1, beta: 1, n: 0 };
    const total = v.alpha + v.beta;
    return {
      alpha: v.alpha,
      beta: v.beta,
      n: v.n,
      mean: v.alpha / total,
      variance: (v.alpha * v.beta) / (total * total * (total + 1)),
    };
  }

  /** Get all posteriors keyed by name. */
  getAllPosteriors(): Record<string, BetaPosterior> {
    const out: Record<string, BetaPosterior> = {};
    for (const key of this.store.keys()) {
      out[key] = this.getPosterior(key);
    }
    return out;
  }

  /** Return the given keys sorted by posterior mean (descending). */
  getRanking(keys: EffectivenessKey[]): EffectivenessKey[] {
    return [...keys].sort((a, b) => this.getPosterior(b).mean - this.getPosterior(a).mean);
  }

  /** Number of distinct keys. */
  size(): number {
    return this.store.size;
  }
}
