import type { AssetRow, EvidenceRow, ProviderRow } from "./data";

export async function fetchJson<T>(
  url: string,
  init?: RequestInit,
): Promise<T> {
  const response = await fetch(url, init);
  if (!response.ok) {
    const payload = (await response.json().catch(() => null)) as {
      error?: string;
    } | null;
    throw new Error(
      payload?.error ?? `${response.status} ${response.statusText}`,
    );
  }
  return response.json() as Promise<T>;
}

type SnapshotApi = {
  snapshot: {
    asOf: number | string;
    rankedAssets: string | Array<Record<string, unknown>>;
  };
};

export function mapSnapshot(payload: SnapshotApi): AssetRow[] {
  const source =
    typeof payload.snapshot.rankedAssets === "string"
      ? (JSON.parse(payload.snapshot.rankedAssets) as Array<
          Record<string, unknown>
        >)
      : payload.snapshot.rankedAssets;
  return source.map((item, index) => {
    const opportunity = item.opportunity as { adjusted?: number } | undefined;
    const confidence = item.confidence as { pct?: number } | undefined;
    const risk = String(item.risk ?? "Unknown");
    const evidenceClaimIds = item.evidenceClaimIds as string[] | undefined;
    const strategy21 = item.strategy21 as {
      researchRank?: number | null;
      nextDollarRank?: number | null;
      assetState?: string | null;
      action?: string | null;
      positionAuthority?: { maxNextOrderUsd?: number | null };
    } | undefined;
    return {
      rank: Number(item.opportunityRank ?? index + 1),
      symbol: String(item.symbol ?? "—"),
      name: String(item.symbol ?? "Unknown asset"),
      score: Number(opportunity?.adjusted ?? 0),
      confidence: Number(confidence?.pct ?? 0),
      risk:
        risk === "Low" || risk === "High" || risk === "Unknown"
          ? risk
          : "Medium",
      action: String(item.action ?? "Inspect").replaceAll("_", " "),
      change: 0,
      trend: [
        42,
        48,
        46,
        52,
        55,
        53,
        58,
        61,
        64,
        Number(opportunity?.adjusted ?? 60),
      ],
      evidenceCount: evidenceClaimIds?.length ?? 0,
      evaluated: true,
      strategyResearchRank: strategy21?.researchRank ?? null,
      nextDollarRank: strategy21?.nextDollarRank ?? null,
      strategyState: strategy21?.assetState ?? null,
      strategyAction: strategy21?.action ?? null,
      maxNextOrderUsd: strategy21?.positionAuthority?.maxNextOrderUsd ?? null,
    } satisfies AssetRow;
  });
}

export type WatchlistApi = {
  source: string;
  watchlist: Array<{
    rank: number;
    symbol: string;
    name: string;
  }>;
};

/**
 * The watchlist is the UI universe. Snapshot data enriches those rows but can
 * never add off-watchlist assets or silently remove unevaluated members.
 */
export function mergeWatchlist(
  payload: WatchlistApi,
  evaluatedAssets: AssetRow[],
): AssetRow[] {
  const evaluatedBySymbol = new Map(
    evaluatedAssets.map((asset) => [asset.symbol.toUpperCase(), asset]),
  );
  return payload.watchlist.map((entry) => {
    const evaluated = evaluatedBySymbol.get(entry.symbol.toUpperCase());
    if (evaluated) {
      return {
        ...evaluated,
        rank: entry.rank,
        symbol: entry.symbol,
        name: entry.name,
      };
    }
    return {
      rank: entry.rank,
      symbol: entry.symbol,
      name: entry.name,
      score: 0,
      confidence: 0,
      risk: "Unknown",
      action: "Awaiting evaluation",
      change: 0,
      trend: [],
      evidenceCount: 0,
      evaluated: false,
      strategyResearchRank: null,
      nextDollarRank: null,
      strategyState: null,
      strategyAction: null,
      maxNextOrderUsd: null,
    } satisfies AssetRow;
  });
}

type ProvidersApi = { providers: Array<Record<string, unknown>> };

export function mapProviders(payload: ProvidersApi): ProviderRow[] {
  return payload.providers.map((item) => ({
    name: String(item.provider ?? "Unknown"),
    status:
      item.status === "connected"
        ? "healthy"
        : item.status === "snapshot"
          ? "snapshot"
          : "degraded",
    latency: "—",
    success: item.consecutiveFailures
      ? `${Math.max(0, 100 - Number(item.consecutiveFailures) * 5)}%`
      : "100%",
    freshness: String(item.freshness ?? "unavailable"),
  }));
}

export type AssetCaseFile = {
  symbol: string;
  asOf: string;
  identity: {
    status: string;
    confidence: number;
    chainId: string | null;
    contractAddress: string | null;
    providerIds: Record<string, string>;
  };
  score: {
    opportunity: number;
    confidence: number;
    targetWeightPct: number;
    opportunityRank: number | null;
    allocationRank: number | null;
  };
  conclusion: string;
  role: string;
  action: string;
  risk: string;
  scenarios: { bull: string | null; base: string | null; bear: string | null };
  invalidationConditions: string[];
  evidenceCoverage: number;
  criticalUnknowns: number;
  evidence: Array<{
    provider: string;
    eventType: string;
    observedAt: string | null;
    epistemicState: string;
    confidence: number;
    summary: string;
    dataMode: "live" | "snapshot" | "fallback";
    providerEndpoint: string | null;
    payloadHash: string | null;
    requestedMarket: string | null;
    eligibility:
      "eligible" | "display_only_ambiguous" | "quarantined" | "rejected";
  }>;
  contradictions: Array<{
    code: string;
    summary: string;
    source: string;
    factorFamily: string;
    claimId: string | null;
  }>;
  unknowns: Array<{
    code: string;
    summary: string;
    severity: "critical" | "warning" | "informational";
  }>;
  strategy21: {
    researchScore: number;
    researchRank: number;
    nextDollarScore: number | null;
    nextDollarRank: number | null;
    doctrine: string;
    marketState: string;
    marketEnteredAt: string;
    minimumDwellUntil: string;
    assetState: string;
    action: string;
    dataReadiness: string;
    eligibility: {
      status: string;
      maximumOrderUsd: number;
      maximumPositionUsd: number;
      spreadP95Bps: number;
      entryImpactP95Bps: number | null;
      exitImpactP95Bps: number | null;
      stressedExitImpactBps: number | null;
      failureReasons: string[];
    };
    factors: Record<string, { value: number | null; coverage: number }>;
    positionAuthority: { maxPositionUsd: number; maxNextOrderUsd: number; probeOnly: boolean; reasons: string[] };
    stagedExecution: { targetUsd: number; lines: Array<{line:number;label:string;amountUsd:number;authorized:boolean;reason:string}> };
    explanation: { flipBullish:string[]; flipBearish:string[]; cancelConditions:string[]; contradictions:string[] };
    personality: {
      primary: string;
      secondary: string[];
      elasticStrength: { score: number; band: string; coverage: number };
      confidence: number;
      coverage: number;
      similarSetupCount: number;
      historicalMatch: string;
      calibratedProbability: null;
      warnings: string[];
      productionAuthority: string;
    } | null;
  } | null;
  recentHistory: Array<{
    asOf: string;
    opportunity: number;
    confidence: number;
    action: string;
  }>;
  changeSincePrevious: {
    previousAsOf: string;
    opportunityDelta: number;
    confidenceDelta: number;
    actionChanged: boolean;
    previousAction: string;
  } | null;
  caveats: string[];
};

export type AssetApi = {
  evidence?: Array<Record<string, unknown>>;
  caseFile?: AssetCaseFile;
};

export function mapEvidence(payload: AssetApi): EvidenceRow[] {
  return (payload.evidence ?? []).map((item) => ({
    id: String(item.id),
    claim: String(item.claim ?? "No claim text"),
    source: String(item.source ?? "Unknown source"),
    family: String(item.factorFamily ?? "unclassified"),
    confidence: Number(item.evidenceConfidence ?? 0),
    freshness: String(item.freshness ?? "unavailable"),
    dataMode: String(item.dataMode ?? "live"),
    origin: String(item.claimOrigin ?? "provider"),
    state: String(item.epistemicState ?? "UNKNOWN"),
  }));
}
