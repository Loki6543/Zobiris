import { lazy, Suspense, useMemo, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import {
  Activity,
  AlertTriangle,
  BarChart3,
  Bot,
  BrainCircuit,
  CheckCircle2,
  CircleDot,
  Database,
  FileSearch,
  Fingerprint,
  GitBranch,
  Hexagon,
  Layers3,
  Menu,
  Network,
  RefreshCw,
  Search,
  ShieldCheck,
  Sparkles,
  Target,
  Waypoints,
  XCircle,
} from "lucide-react";
import { Area, AreaChart, ResponsiveContainer } from "recharts";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Progress } from "@/components/ui/progress";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import {
  TooltipProvider,
} from "@/components/ui/tooltip";
import {
  fetchJson,
  mapEvidence,
  mapProviders,
  mapSnapshot,
  mergeWatchlist,
  type WatchlistApi,
} from "./api";
import {
  type AssetRow,
  type EvidenceRow,
  type ProviderRow,
} from "./data";
import { cn } from "@/lib/utils";

const AssetCasePanel = lazy(() =>
  import("./AssetCasePanel").then((module) => ({
    default: module.AssetCasePanel,
  })),
);
type View = "command" | "case" | "evidence" | "challenger";

const navigation = [
  { id: "command" as const, label: "Command Center", icon: BarChart3 },
  { id: "case" as const, label: "Asset Case File", icon: FileSearch },
  { id: "evidence" as const, label: "Evidence Graph", icon: Waypoints },
  { id: "challenger" as const, label: "Challenger", icon: Bot },
];

const secondaryNavigation = [
  { label: "What Changed", icon: Activity },
  { label: "Provider Health", icon: Network },
  { label: "Risk Gates", icon: ShieldCheck },
  { label: "Identity Registry", icon: Fingerprint },
];

const assetColors: Record<string, string> = {
  BTC: "bg-[#f59e0b]",
  ETH: "bg-[#6875f5]",
  SOL: "bg-[#20d9aa]",
  LINK: "bg-[#4778ff]",
  AVAX: "bg-[#ef5350]",
};

function Brand() {
  return (
    <div className="flex h-[74px] items-center gap-3 border-b border-border/70 px-5">
      <div className="relative grid size-9 place-items-center rounded-xl border border-primary/40 bg-primary/15 shadow-[0_0_24px_rgba(139,92,246,.25)]">
        <Hexagon className="size-6 text-primary" strokeWidth={1.5} />
        <span className="absolute text-[11px] font-black text-white">Z</span>
      </div>
      <div>
        <p className="text-[17px] font-black tracking-[0.18em]">ZOBIRIS</p>
        <p className="text-[9px] font-semibold tracking-[0.16em] text-muted-foreground">
          INTELLIGENCE ENGINE
        </p>
      </div>
    </div>
  );
}

function Sidebar({
  view,
  setView,
  mobile = false,
}: {
  view: View;
  setView: (view: View) => void;
  mobile?: boolean;
}) {
  return (
    <aside
      className={cn(
        "flex h-full flex-col bg-[linear-gradient(180deg,hsl(216_47%_9%),hsl(216_45%_7%))]",
        mobile ? "w-full" : "w-[238px] border-r border-border/70",
      )}
    >
      <Brand />
      <nav className="flex-1 px-3 py-4">
        <p className="px-3 pb-2 text-[9px] font-semibold uppercase tracking-[0.13em] text-muted-foreground">
          Workspace
        </p>
        <div className="grid gap-1">
          {navigation.map((item) => (
            <button
              key={item.id}
              onClick={() => setView(item.id)}
              className={cn(
                "flex items-center gap-3 rounded-lg px-3 py-2.5 text-left text-[13px] transition-colors",
                view === item.id
                  ? "bg-gradient-to-r from-primary/25 to-blue-500/10 text-white ring-1 ring-primary/25"
                  : "text-muted-foreground hover:bg-accent/60 hover:text-white",
              )}
            >
              <item.icon
                className={cn("size-4", view === item.id && "text-primary")}
              />
              {item.label}
            </button>
          ))}
        </div>
        <p className="px-3 pb-2 pt-7 text-[9px] font-semibold uppercase tracking-[0.13em] text-muted-foreground">
          Trust & system
        </p>
        <div className="grid gap-1">
          {secondaryNavigation.map((item) => (
            <button
              key={item.label}
              className="flex items-center gap-3 rounded-lg px-3 py-2 text-left text-[13px] text-muted-foreground transition-colors hover:bg-accent/60 hover:text-white"
            >
              <item.icon className="size-4" />
              {item.label}
            </button>
          ))}
        </div>
      </nav>
      <div className="m-4 rounded-xl border border-primary/20 bg-[radial-gradient(circle_at_top_left,rgba(124,92,246,.16),transparent_60%)] p-4">
        <div className="mb-2 flex items-center gap-2 text-xs font-semibold text-emerald-300">
          <ShieldCheck className="size-4" /> Decision-support only
        </div>
        <p className="text-[11px] leading-5 text-muted-foreground">
          Agents challenge evidence. Deterministic policy remains the only
          scoring authority.
        </p>
      </div>
    </aside>
  );
}

function MiniTrend({
  values,
  color = "#4ade80",
}: {
  values: number[];
  color?: string;
}) {
  const data = values.map((value, index) => ({ index, value }));
  const gradient = `spark-${color.replace("#", "")}`;
  return (
    <div className="h-9 w-24" aria-hidden="true">
      <ResponsiveContainer width="100%" height="100%">
        <AreaChart
          data={data}
          margin={{ top: 3, right: 0, bottom: 0, left: 0 }}
        >
          <defs>
            <linearGradient id={gradient} x1="0" y1="0" x2="0" y2="1">
              <stop offset="0" stopColor={color} stopOpacity={0.35} />
              <stop offset="1" stopColor={color} stopOpacity={0} />
            </linearGradient>
          </defs>
          <Area
            type="monotone"
            dataKey="value"
            stroke={color}
            strokeWidth={1.7}
            fill={`url(#${gradient})`}
            isAnimationActive={false}
          />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
}

function KpiCard({
  label,
  value,
  meta,
  trend,
  tone = "green",
  icon: Icon,
}: {
  label: string;
  value: string;
  meta: string;
  trend: number[];
  tone?: "green" | "purple" | "blue" | "amber";
  icon: typeof Activity;
}) {
  const colors = {
    green: "#4ade80",
    purple: "#a855f7",
    blue: "#60a5fa",
    amber: "#f59e0b",
  };
  return (
    <Card className="border-border/80 bg-card/75 shadow-[0_12px_40px_rgba(0,0,0,.12)]">
      <CardHeader className="flex flex-row items-start justify-between gap-2 p-4 pb-1">
        <div>
          <CardDescription className="text-[11px]">{label}</CardDescription>
          <CardTitle className="mt-1 text-[25px] tabular-nums">
            {value}
          </CardTitle>
        </div>
        <Icon className="size-4 text-muted-foreground" />
      </CardHeader>
      <CardContent className="flex items-end justify-between gap-2 px-4 pb-4 pt-0">
        <p className="text-[10px] text-muted-foreground">{meta}</p>
        <MiniTrend values={trend} color={colors[tone]} />
      </CardContent>
    </Card>
  );
}

function RiskBadge({ risk }: { risk: AssetRow["risk"] }) {
  return (
    <Badge
      variant="outline"
      className={cn(
        "text-[10px] font-medium",
        risk === "Low" &&
          "border-emerald-500/40 bg-emerald-500/10 text-emerald-300",
        risk === "Medium" &&
          "border-amber-500/40 bg-amber-500/10 text-amber-300",
        risk === "High" && "border-red-500/40 bg-red-500/10 text-red-300",
        risk === "Unknown" &&
          "border-slate-500/40 bg-slate-500/10 text-slate-300",
      )}
    >
      {risk}
    </Badge>
  );
}

function AssetTable({
  assets,
  selected,
  onSelect,
  onInspect,
}: {
  assets: AssetRow[];
  selected: string;
  onSelect: (symbol: string) => void;
  onInspect: (symbol: string) => void;
}) {
  return (
    <Card className="min-w-0 border-border/80 bg-card/75">
      <CardHeader className="flex flex-row items-center justify-between p-4 pb-2">
        <div>
          <CardTitle className="text-sm">
            Strategy 2.1 — Best Next Dollar
          </CardTitle>
          <CardDescription className="mt-1 text-[10px]">
            N$ = executable next-dollar rank · R = research opportunity rank
          </CardDescription>
        </div>
        <Badge
          variant="outline"
          className="border-primary/30 bg-primary/10 text-[10px] text-primary"
        >
          Score
        </Badge>
      </CardHeader>
      <CardContent className="px-3 pb-1">
        <ScrollArea className="h-[440px]">
          <Table>
          <TableHeader>
            <TableRow className="hover:bg-transparent">
              <TableHead className="w-10 text-[10px]">#</TableHead>
              <TableHead className="w-10 text-[10px]">N$</TableHead>
              <TableHead className="w-10 text-[10px]">R</TableHead>
              <TableHead className="text-[10px]">Asset</TableHead>
              <TableHead className="text-[10px]">Score</TableHead>
              <TableHead className="hidden text-[10px] sm:table-cell">
                Trend
              </TableHead>
              <TableHead className="hidden text-[10px] md:table-cell">
                Confidence
              </TableHead>
              <TableHead className="text-[10px]">Risk</TableHead>
              <TableHead className="text-right text-[10px]">Action</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {assets.map((asset) => (
              <TableRow
                key={asset.symbol}
                onClick={() => onSelect(asset.symbol)}
                className={cn(
                  "cursor-pointer",
                  selected === asset.symbol && "bg-primary/[0.07]",
                )}
              >
                <TableCell className="text-[11px] text-muted-foreground">
                  {asset.rank}
                </TableCell>
                <TableCell className="text-[11px] font-semibold text-emerald-300 tabular-nums">
                  {asset.nextDollarRank ?? "—"}
                </TableCell>
                <TableCell className="text-[11px] text-blue-300 tabular-nums">
                  {asset.strategyResearchRank ?? "—"}
                </TableCell>
                <TableCell>
                  <div className="flex items-center gap-2.5">
                    <div
                      className={cn(
                        "grid size-7 place-items-center rounded-full text-[11px] font-black text-white",
                        assetColors[asset.symbol] ?? "bg-slate-600",
                      )}
                    >
                      {asset.symbol.slice(0, 1)}
                    </div>
                    <div>
                      <p className="text-xs font-medium">{asset.name}</p>
                      <p className="text-[9px] text-muted-foreground">
                        {asset.symbol} · {asset.evidenceCount} claims
                        {asset.strategyState ? ` · ${asset.strategyState.replaceAll("_", " ")}` : ""}
                      </p>
                    </div>
                  </div>
                </TableCell>
                <TableCell className="text-sm font-semibold tabular-nums text-emerald-300">
                  {asset.evaluated ? asset.score.toFixed(1) : "—"}
                </TableCell>
                <TableCell className="hidden sm:table-cell">
                  <MiniTrend values={asset.trend} />
                </TableCell>
                <TableCell className="hidden md:table-cell">
                  <Badge
                    variant="outline"
                    className="border-emerald-500/30 bg-emerald-500/10 text-[10px] text-emerald-300"
                  >
                    {asset.evaluated ? `${asset.confidence}%` : "—"}
                  </Badge>
                </TableCell>
                <TableCell>
                  <RiskBadge risk={asset.risk} />
                </TableCell>
                <TableCell className="text-right">
                  {asset.maxNextOrderUsd != null && asset.maxNextOrderUsd > 0 ? (
                    <p className="mb-1 text-[8px] text-emerald-300">max +${asset.maxNextOrderUsd.toFixed(0)}</p>
                  ) : null}
                  <Button
                    size="sm"
                    variant="outline"
                    className="h-7 border-primary/30 bg-primary/10 px-2 text-[10px] text-primary"
                    onClick={(event) => {
                      event.stopPropagation();
                      onInspect(asset.symbol);
                    }}
                  >
                    Inspect
                  </Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
          </Table>
        </ScrollArea>
      </CardContent>
      <CardFooter className="px-4 py-3">
        <p className="text-[10px] text-muted-foreground">
          {assets.length} watchlist assets · {assets.filter((asset) => asset.evaluated).length} evaluated in the latest snapshot
        </p>
      </CardFooter>
    </Card>
  );
}

function ScoreAnatomy({
  asset,
  onEvidence,
}: {
  asset: AssetRow;
  onEvidence: () => void;
}) {
  const circumference = 2 * Math.PI * 42;
  return (
    <Card className="border-border/80 bg-card/75">
      <CardHeader className="flex flex-row items-center justify-between p-4 pb-2">
        <div>
          <CardTitle className="text-sm">Evaluation Summary: {asset.name}</CardTitle>
          <CardDescription className="mt-1 text-[10px]">
            Persisted watchlist result · no presentation fallback
          </CardDescription>
        </div>
        <Button
          variant="ghost"
          size="sm"
          onClick={onEvidence}
          className="h-7 text-[10px] text-blue-300"
        >
          Open graph
        </Button>
      </CardHeader>
      <CardContent className="grid gap-5 p-4 pt-2 lg:grid-cols-[145px_1fr]">
        <div className="relative mx-auto grid size-[138px] place-items-center">
          <svg
            className="-rotate-90"
            width="138"
            height="138"
            viewBox="0 0 100 100"
          >
            <circle
              cx="50"
              cy="50"
              r="42"
              fill="none"
              stroke="hsl(var(--muted))"
              strokeWidth="9"
            />
            <circle
              cx="50"
              cy="50"
              r="42"
              fill="none"
              stroke="url(#scoreGradient)"
              strokeWidth="9"
              strokeLinecap="round"
              strokeDasharray={circumference}
              strokeDashoffset={circumference * (1 - asset.score / 100)}
            />
            <defs>
              <linearGradient id="scoreGradient">
                <stop stopColor="#4ade80" />
                <stop offset="1" stopColor="#a3e635" />
              </linearGradient>
            </defs>
          </svg>
          <div className="absolute text-center">
            <p className="text-[27px] font-bold tabular-nums">
              {asset.score.toFixed(1)}
            </p>
            <p className="text-[10px] text-muted-foreground">/100 adjusted</p>
          </div>
        </div>
        <div className="grid content-center gap-4">
          <div>
            <div className="mb-2 flex items-center justify-between text-[10px]">
              <span>Confidence</span>
              <span className="tabular-nums">{asset.confidence}%</span>
            </div>
            <Progress value={asset.confidence} className="h-2" />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="rounded-lg border border-border/70 bg-secondary/25 p-3">
              <p className="text-[9px] text-muted-foreground">Action</p>
              <p className="mt-1 text-xs font-semibold">{asset.action}</p>
            </div>
            <div className="rounded-lg border border-border/70 bg-secondary/25 p-3">
              <p className="text-[9px] text-muted-foreground">Risk</p>
              <div className="mt-1"><RiskBadge risk={asset.risk} /></div>
            </div>
          </div>
          <button onClick={onEvidence} className="rounded-lg border border-border/70 bg-secondary/25 p-3 text-left">
            <p className="text-[9px] text-muted-foreground">Linked evidence</p>
            <p className="mt-1 text-xs font-semibold">{asset.evidenceCount} persisted claims</p>
          </button>
        </div>
      </CardContent>
      <CardFooter className="grid grid-cols-3 gap-3 border-t border-border/70 px-4 py-3 text-center">
        <div>
          <p className="text-[9px] text-muted-foreground">Adjusted score</p>
          <p className="mt-1 text-sm font-semibold text-lime-300">
            {asset.score.toFixed(1)}
          </p>
        </div>
        <div>
          <p className="text-[9px] text-muted-foreground">Confidence</p>
          <p className="mt-1 text-sm font-semibold text-emerald-300">
            {asset.confidence}%
          </p>
        </div>
        <div>
          <p className="text-[9px] text-muted-foreground">Evidence claims</p>
          <p className="mt-1 text-sm font-semibold">{asset.evidenceCount}</p>
        </div>
      </CardFooter>
    </Card>
  );
}

function EvaluationCoverageCard({ assets }: { assets: AssetRow[] }) {
  const evaluated = assets.filter((asset) => asset.evaluated).length;
  const percentage = assets.length ? Math.round((evaluated / assets.length) * 100) : 0;
  return (
    <Card className="border-border/80 bg-card/75">
      <CardHeader className="p-4 pb-2">
        <CardTitle className="text-sm">Watchlist Evaluation Coverage</CardTitle>
        <CardDescription className="text-[10px]">
          Source membership and persisted analysis stay separate
        </CardDescription>
      </CardHeader>
      <CardContent className="grid gap-4 px-4 pb-4 pt-3">
        <div className="flex items-end justify-between">
          <div>
            <p className="text-3xl font-semibold tabular-nums">{evaluated} / {assets.length}</p>
            <p className="mt-1 text-[10px] text-muted-foreground">assets evaluated in the latest snapshot</p>
          </div>
          <Badge variant="outline">{percentage}%</Badge>
        </div>
        <Progress value={percentage} className="h-2" />
        <p className="text-[10px] leading-5 text-muted-foreground">
          Pending assets remain visible with unknown scores. They are never replaced by a demo coin or another asset&apos;s case file.
        </p>
      </CardContent>
    </Card>
  );
}

function ProvidersCard({ providers }: { providers: ProviderRow[] }) {
  return (
    <Card className="border-border/80 bg-card/75">
      <CardHeader className="flex flex-row items-center justify-between p-4 pb-2">
        <div>
          <CardTitle className="text-sm">Provider Health</CardTitle>
          <CardDescription className="text-[10px]">
            Connectivity never implies freshness
          </CardDescription>
        </div>
        <Network className="size-4 text-emerald-300" />
      </CardHeader>
      <CardContent className="px-4 pb-3">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="text-[9px]">Provider</TableHead>
              <TableHead className="text-[9px]">State</TableHead>
              <TableHead className="hidden text-[9px] sm:table-cell">
                Latency
              </TableHead>
              <TableHead className="text-right text-[9px]">Freshness</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {providers.slice(0, 5).map((provider) => (
              <TableRow key={provider.name}>
                <TableCell className="text-[10px] font-medium">
                  {provider.name}
                </TableCell>
                <TableCell>
                  <Badge
                    variant="outline"
                    className={cn(
                      "text-[9px]",
                      provider.status === "healthy"
                        ? "border-emerald-500/30 bg-emerald-500/10 text-emerald-300"
                        : provider.status === "snapshot"
                          ? "border-blue-500/30 bg-blue-500/10 text-blue-300"
                          : "border-amber-500/30 bg-amber-500/10 text-amber-300",
                    )}
                  >
                    <CircleDot className="mr-1 size-2.5" />
                    {provider.status}
                  </Badge>
                </TableCell>
                <TableCell className="hidden text-[10px] sm:table-cell">
                  {provider.latency}
                </TableCell>
                <TableCell className="text-right text-[10px] text-muted-foreground">
                  {provider.freshness}
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
}

function CommandCenter({
  assets,
  providers,
  selected,
  setSelected,
  setView,
}: {
  assets: AssetRow[];
  providers: ProviderRow[];
  selected: string;
  setSelected: (symbol: string) => void;
  setView: (view: View) => void;
}) {
  const asset = assets.find((item) => item.symbol === selected) ?? assets[0]!;
  const evaluatedAssets = assets.filter((item) => item.evaluated);
  const highRiskAssets = evaluatedAssets.filter((item) => item.risk === "High").length;
  const evidenceClaims = evaluatedAssets.reduce((sum, item) => sum + item.evidenceCount, 0);
  const averageScore = evaluatedAssets.length
    ? (
        evaluatedAssets.reduce((sum, item) => sum + item.score, 0) /
        evaluatedAssets.length
      ).toFixed(1)
    : "—";
  return (
    <div className="grid gap-4">
      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-5">
        <KpiCard
          label="Watchlist Assets"
          value={String(assets.length)}
          meta="Canonical CoinMarketCap list"
          trend={[45, 48, 47, 51, 53, 52, 56, 58]}
          tone="purple"
          icon={Layers3}
        />
        <KpiCard
          label="Avg. Score"
          value={averageScore}
          meta={`${evaluatedAssets.length} evaluated`}
          trend={[50, 53, 51, 56, 59, 57, 62, 64]}
          tone="blue"
          icon={Target}
        />
        <KpiCard
          label="High Risk"
          value={String(highRiskAssets)}
          meta="Evaluated assets only"
          trend={[8, 7, 7, 8, 6, 7, 5, 7]}
          tone="amber"
          icon={AlertTriangle}
        />
        <KpiCard
          label="Evidence Claims"
          value={String(evidenceClaims)}
          meta="Latest persisted snapshot"
          trend={[40, 45, 43, 51, 49, 57, 55, 62]}
          icon={Database}
        />
        <KpiCard
          label="Providers Healthy"
          value={`${providers.filter((item) => item.status === "healthy").length} / ${providers.length}`}
          meta="Freshness-aware"
          trend={[60, 61, 60, 62, 62, 63, 64, 64]}
          icon={Network}
        />
      </div>
      <div className="grid gap-4 xl:grid-cols-[1.05fr_1fr]">
        <AssetTable
          assets={assets}
          selected={selected}
          onSelect={setSelected}
          onInspect={(symbol) => {
            setSelected(symbol);
            setView("case");
          }}
        />
        {asset.evaluated ? (
          <ScoreAnatomy
            asset={asset}
            onEvidence={() => setView("evidence")}
          />
        ) : (
          <Card className="grid min-h-[440px] place-items-center border-border/80 bg-card/75 p-8 text-center">
            <div className="max-w-sm">
              <FileSearch className="mx-auto size-8 text-primary" />
              <CardTitle className="mt-4 text-base">
                {asset.symbol} is awaiting evaluation
              </CardTitle>
              <CardDescription className="mt-2 leading-6">
                This asset is in your watchlist, but the latest persisted snapshot has not produced an evaluated case yet. Refresh evidence to run the watchlist pipeline.
              </CardDescription>
            </div>
          </Card>
        )}
      </div>
      <div className="grid gap-4 xl:grid-cols-2">
        <EvaluationCoverageCard assets={assets} />
        <ProvidersCard providers={providers} />
      </div>
    </div>
  );
}

function GraphNode({
  icon: Icon,
  title,
  meta,
  tone,
  wide,
}: {
  icon: typeof Database;
  title: string;
  meta: string;
  tone: "blue" | "purple" | "green" | "amber";
  wide?: boolean;
}) {
  const toneClass = {
    blue: "border-blue-400/35 bg-blue-500/10 text-blue-300",
    purple: "border-primary/40 bg-primary/10 text-primary",
    green: "border-emerald-400/35 bg-emerald-500/10 text-emerald-300",
    amber: "border-amber-400/35 bg-amber-500/10 text-amber-300",
  }[tone];
  return (
    <div
      className={cn(
        "relative z-10 rounded-xl border p-3 shadow-xl backdrop-blur",
        toneClass,
        wide && "text-center",
      )}
    >
      <div className={cn("flex items-center gap-2", wide && "justify-center")}>
        <Icon className="size-4" />
        <span className="text-[10px] font-semibold uppercase tracking-wider">
          {title}
        </span>
      </div>
      <p className="mt-2 truncate text-[10px] text-foreground/80">{meta}</p>
    </div>
  );
}

function EvidenceGraph({
  asset,
  evidence,
  selectedClaim,
  onClaim,
  onChallenge,
}: {
  asset: AssetRow;
  evidence: EvidenceRow[];
  selectedClaim: string;
  onClaim: (id: string) => void;
  onChallenge: () => void;
}) {
  const selected =
    evidence.find((item) => item.id === selectedClaim) ?? evidence[0];
  return (
    <div className="grid gap-4 xl:grid-cols-[1.15fr_.85fr]">
      <Card className="border-border/80 bg-card/75">
        <CardHeader className="p-5">
          <div className="flex items-start justify-between gap-3">
            <div>
              <CardTitle className="flex items-center gap-2 text-base">
                <GitBranch className="size-4 text-primary" /> Evidence Graph ·{" "}
                {asset.symbol}
              </CardTitle>
              <CardDescription className="mt-1">
                Provider observations → claims → deterministic factors. Model
                reasoning stays outside scoring.
              </CardDescription>
            </div>
            <Badge
              variant="outline"
              className="border-emerald-500/30 bg-emerald-500/10 text-emerald-300"
            >
              {evidence.length} visible claims
            </Badge>
          </div>
        </CardHeader>
        <CardContent className="p-5 pt-0">
          <div className="relative min-h-[420px] overflow-hidden rounded-xl border border-border/70 bg-[radial-gradient(circle_at_center,rgba(99,102,241,.12),transparent_52%)] p-5">
            <div className="absolute inset-x-12 top-[114px] h-px bg-gradient-to-r from-transparent via-primary/45 to-transparent" />
            <div className="absolute left-1/2 top-[114px] h-[190px] w-px bg-gradient-to-b from-primary/50 to-emerald-400/30" />
            <div className="grid grid-cols-3 gap-4">
              <GraphNode
                icon={Database}
                title="Provider payload"
                meta={selected?.source ?? "Source"}
                tone="blue"
              />
              <GraphNode
                icon={FileSearch}
                title="Evidence claim"
                meta={selected?.state ?? "KNOWN"}
                tone="purple"
              />
              <GraphNode
                icon={ShieldCheck}
                title="Provenance gate"
                meta={selected?.dataMode ?? "live"}
                tone={selected?.dataMode === "fallback" ? "amber" : "green"}
              />
            </div>
            <div className="mx-auto mt-28 max-w-sm">
              <GraphNode
                icon={BrainCircuit}
                title="Deterministic factor"
                meta={selected?.family ?? "Market structure"}
                tone="green"
                wide
              />
            </div>
            <div className="mt-9 grid grid-cols-2 gap-4">
              <GraphNode
                icon={Target}
                title="Adjusted score"
                meta={`${asset.score.toFixed(1)} / 100`}
                tone="green"
              />
              <GraphNode
                icon={Bot}
                title="Challenger"
                meta="Advisory · no score access"
                tone="purple"
              />
            </div>
          </div>
        </CardContent>
      </Card>
      <Card className="border-border/80 bg-card/75">
        <CardHeader className="p-5 pb-3">
          <CardTitle className="text-sm">Evidence Ledger</CardTitle>
          <CardDescription>
            Select a claim to trace its provenance.
          </CardDescription>
        </CardHeader>
        <CardContent className="p-0">
          <ScrollArea className="h-[458px]">
            <div className="grid gap-2 px-4 pb-4">
              {evidence.map((item) => (
                <button
                  key={item.id}
                  onClick={() => onClaim(item.id)}
                  className={cn(
                    "rounded-lg border p-3 text-left transition-colors",
                    selectedClaim === item.id
                      ? "border-primary/50 bg-primary/10"
                      : "border-border/70 bg-secondary/25 hover:bg-secondary/60",
                  )}
                >
                  <div className="mb-2 flex items-center justify-between gap-2">
                    <Badge variant="outline" className="text-[9px]">
                      {item.family}
                    </Badge>
                    <span className="font-mono text-[9px] text-muted-foreground">
                      {item.id.slice(0, 8)}
                    </span>
                  </div>
                  <p className="line-clamp-3 text-[11px] leading-5">
                    {item.claim}
                  </p>
                  <div className="mt-2 flex flex-wrap gap-1.5">
                    <Badge
                      variant="outline"
                      className={cn(
                        "text-[8px]",
                        item.dataMode === "fallback" &&
                          "border-amber-500/40 text-amber-300",
                      )}
                    >
                      {item.dataMode}
                    </Badge>
                    <Badge variant="outline" className="text-[8px]">
                      {item.freshness}
                    </Badge>
                    <span className="ml-auto text-[9px] text-muted-foreground">
                      {Math.round(item.confidence * 100)}%
                    </span>
                  </div>
                </button>
              ))}
            </div>
          </ScrollArea>
        </CardContent>
        <CardFooter className="border-t border-border/70 p-4">
          <Button onClick={onChallenge} className="w-full gap-2">
            <Bot className="size-4" /> Challenge selected claim
          </Button>
        </CardFooter>
      </Card>
    </div>
  );
}

type ChallengeOutput = {
  claimId: string;
  reasoning: string;
  confidence: number;
  requestedEvidence: string[];
  contradictions: Array<{ claimId: string; reason: string; severity: string }>;
};

function ChallengerPanel({
  asset,
  evidence,
  selectedClaim,
  setSelectedClaim,
  liveEvidence,
}: {
  asset: AssetRow;
  evidence: EvidenceRow[];
  selectedClaim: string;
  setSelectedClaim: (id: string) => void;
  liveEvidence: boolean;
}) {
  const [question, setQuestion] = useState(
    "What is the strongest evidence against this claim?",
  );
  const challenge = useMutation({
    mutationFn: async (): Promise<ChallengeOutput> => {
      if (!liveEvidence) {
        await new Promise((resolve) => window.setTimeout(resolve, 650));
        return {
          claimId: selectedClaim,
          reasoning:
            "The target is directionally supported, but its strongest weakness is source concentration. One social claim is delayed and the catalyst fallback is display-only, so neither can independently corroborate the live market observation.",
          confidence: 0.74,
          requestedEvidence: [
            "A fresh independent spot quote",
            "A non-fallback catalyst source",
          ],
          contradictions: evidence
            .filter((item) => item.dataMode === "fallback")
            .slice(0, 1)
            .map((item) => ({
              claimId: item.id,
              reason: "Fallback evidence cannot establish the current fact.",
              severity: "medium",
            })),
        };
      }
      const response = await fetchJson<{ output: ChallengeOutput }>(
        "/api/agents/challenge",
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            symbol: asset.symbol,
            claimId: selectedClaim,
            question,
          }),
        },
      );
      return response.output;
    },
  });
  const selected =
    evidence.find((item) => item.id === selectedClaim) ?? evidence[0];
  return (
    <div className="grid gap-4 xl:grid-cols-[.75fr_1.25fr]">
      <Card className="border-border/80 bg-card/75">
        <CardHeader>
          <CardTitle className="text-sm">Claim under challenge</CardTitle>
          <CardDescription>
            Choose exactly one target from the {asset.symbol} ledger.
          </CardDescription>
        </CardHeader>
        <CardContent className="grid gap-3">
          <ScrollArea className="h-[280px] pr-3">
            <div className="grid gap-2">
              {evidence.map((item) => (
                <button
                  key={item.id}
                  onClick={() => setSelectedClaim(item.id)}
                  className={cn(
                    "rounded-lg border p-3 text-left",
                    selectedClaim === item.id
                      ? "border-primary/50 bg-primary/10"
                      : "border-border/60 bg-secondary/25",
                  )}
                >
                  <p className="line-clamp-2 text-[11px] leading-5">
                    {item.claim}
                  </p>
                  <p className="mt-1 text-[9px] text-muted-foreground">
                    {item.source} · {item.state}
                  </p>
                </button>
              ))}
            </div>
          </ScrollArea>
          <Separator />
          <div className="rounded-lg border border-border/70 bg-background/30 p-3">
            <p className="text-[9px] uppercase tracking-wider text-muted-foreground">
              Selected proof
            </p>
            <p className="mt-2 text-xs leading-5">{selected?.claim}</p>
            <div className="mt-3 flex gap-2">
              <Badge variant="outline" className="text-[9px]">
                {selected?.dataMode}
              </Badge>
              <Badge variant="outline" className="text-[9px]">
                {selected?.freshness}
              </Badge>
            </div>
          </div>
        </CardContent>
      </Card>
      <Card className="border-primary/25 bg-[radial-gradient(circle_at_top_right,rgba(124,92,246,.12),transparent_36%),hsl(var(--card)/.82)]">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2 text-base">
                <Bot className="size-5 text-primary" /> Challenger Agent
              </CardTitle>
              <CardDescription className="mt-1">
                Read-only reasoning worker · structured output · no scoring
                tools
              </CardDescription>
            </div>
            <Badge
              variant="outline"
              className="border-emerald-500/30 bg-emerald-500/10 text-emerald-300"
            >
              <ShieldCheck className="mr-1 size-3" /> Controlled
            </Badge>
          </div>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="challenge">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="challenge">Challenge</TabsTrigger>
              <TabsTrigger value="contract">Authority contract</TabsTrigger>
            </TabsList>
            <TabsContent value="challenge" className="mt-4 grid gap-3">
              <Textarea
                value={question}
                onChange={(event) => setQuestion(event.target.value)}
                className="min-h-24 bg-background/40 text-xs"
              />
              <Button
                onClick={() => challenge.mutate()}
                disabled={challenge.isPending || !selectedClaim}
                className="gap-2"
              >
                {challenge.isPending ? (
                  <RefreshCw className="size-4 animate-spin" />
                ) : (
                  <Sparkles className="size-4" />
                )}
                {challenge.isPending
                  ? "Auditing evidence…"
                  : "Run read-only challenge"}
              </Button>
              {challenge.isError && (
                <div className="rounded-lg border border-red-500/30 bg-red-500/10 p-3 text-xs text-red-200">
                  {challenge.error.message}
                </div>
              )}
              {challenge.data && (
                <div className="grid gap-3 rounded-xl border border-primary/30 bg-background/35 p-4">
                  <div className="flex items-center justify-between">
                    <p className="text-xs font-semibold">Challenge result</p>
                    <Badge
                      variant="outline"
                      className="border-primary/30 text-primary"
                    >
                      {Math.round(challenge.data.confidence * 100)}% confidence
                    </Badge>
                  </div>
                  <p className="text-xs leading-6 text-foreground/85">
                    {challenge.data.reasoning}
                  </p>
                  {challenge.data.contradictions.length > 0 && (
                    <div>
                      <p className="mb-2 text-[9px] font-semibold uppercase tracking-wider text-muted-foreground">
                        Contradictions
                      </p>
                      {challenge.data.contradictions.map((item) => (
                        <div
                          key={item.claimId}
                          className="mb-2 flex gap-2 rounded-lg border border-amber-500/20 bg-amber-500/5 p-2.5"
                        >
                          <AlertTriangle className="mt-0.5 size-3.5 shrink-0 text-amber-300" />
                          <div>
                            <p className="text-[10px]">{item.reason}</p>
                            <p className="mt-1 font-mono text-[8px] text-muted-foreground">
                              {item.claimId}
                            </p>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                  {challenge.data.requestedEvidence.length > 0 && (
                    <div>
                      <p className="mb-2 text-[9px] font-semibold uppercase tracking-wider text-muted-foreground">
                        Requested evidence
                      </p>
                      <ul className="grid gap-1.5">
                        {challenge.data.requestedEvidence.map((item) => (
                          <li
                            key={item}
                            className="flex gap-2 text-[10px] text-muted-foreground"
                          >
                            <Search className="mt-0.5 size-3 shrink-0" />
                            {item}
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                  <div className="flex items-center gap-2 border-t border-border/60 pt-3 text-[9px] text-emerald-300">
                    <CheckCircle2 className="size-3" /> Deterministic score
                    unchanged
                  </div>
                </div>
              )}
            </TabsContent>
            <TabsContent value="contract" className="mt-4">
              <div className="grid gap-2">
                {[
                  "Read evidence by exact claim ID",
                  "Identify contradictions",
                  "Request missing evidence",
                  "Return structured confidence",
                ].map((item) => (
                  <div
                    key={item}
                    className="flex items-center gap-2 rounded-lg bg-emerald-500/5 p-2.5 text-[11px]"
                  >
                    <CheckCircle2 className="size-3.5 text-emerald-300" />
                    {item}
                  </div>
                ))}
                {[
                  "Change a score or confidence",
                  "Set ranks or allocation",
                  "Execute trades or wallet actions",
                ].map((item) => (
                  <div
                    key={item}
                    className="flex items-center gap-2 rounded-lg bg-red-500/5 p-2.5 text-[11px]"
                  >
                    <XCircle className="size-3.5 text-red-300" />
                    {item}
                  </div>
                ))}
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}

export function App() {
  const [view, setView] = useState<View>("command");
  const [selectedSymbol, setSelectedSymbol] = useState("BTC");
  const [selectedClaim, setSelectedClaim] = useState("");
  const [filter, setFilter] = useState("");
  const queryClient = useQueryClient();
  const snapshotQuery = useQuery({
    queryKey: ["snapshot"],
    queryFn: () =>
      fetchJson<Parameters<typeof mapSnapshot>[0]>("/api/snapshot/latest"),
  });
  const watchlistQuery = useQuery({
    queryKey: ["watchlist"],
    queryFn: () => fetchJson<WatchlistApi>("/api/watchlist"),
  });
  const providersQuery = useQuery({
    queryKey: ["providers"],
    queryFn: () =>
      fetchJson<Parameters<typeof mapProviders>[0]>("/api/providers"),
  });
  const evaluatedAssets = snapshotQuery.data
    ? mapSnapshot(snapshotQuery.data)
    : [];
  const assets = watchlistQuery.data
    ? mergeWatchlist(watchlistQuery.data, evaluatedAssets)
    : evaluatedAssets;
  const selectedAsset =
    assets.find((item) => item.symbol === selectedSymbol) ?? assets[0] ?? null;
  const activeSymbol = selectedAsset?.symbol ?? "";
  const evidenceQuery = useQuery({
    queryKey: ["asset", activeSymbol],
    queryFn: () =>
      fetchJson<Parameters<typeof mapEvidence>[0]>(
        `/api/asset/${activeSymbol}`,
      ),
    enabled: Boolean(activeSymbol),
  });
  const refresh = useMutation({
    mutationFn: () => fetchJson("/api/refresh", { method: "POST" }),
    onSuccess: async () => {
      await queryClient.invalidateQueries();
    },
  });
  const providers = providersQuery.data
    ? mapProviders(providersQuery.data)
    : [];
  const liveEvidence = evidenceQuery.data
    ? mapEvidence(evidenceQuery.data)
    : [];
  const evidence = liveEvidence;
  const filteredAssets = useMemo(
    () =>
      filter
        ? assets.filter((item) =>
            `${item.symbol} ${item.name}`
              .toLowerCase()
              .includes(filter.toLowerCase()),
          )
        : assets,
    [assets, filter],
  );
  const selectedLabel = selectedAsset?.symbol ?? "watchlist asset";
  const pageMeta = {
    command: [
      "Command Center",
      "Real-time evidence integrity and decision support",
    ],
    case: [
      "Asset Case File",
      `Reproducible thesis, provenance, unknowns and change history for ${selectedLabel}`,
    ],
    evidence: [
      "Evidence Graph",
      `Trace the proof chain for ${selectedLabel}`,
    ],
    challenger: [
      "Challenger",
      "Audit a claim without changing deterministic outputs",
    ],
  }[view];
  const switchView = (next: View) => {
    setView(next);
    if (
      next !== "command" &&
      !evidence.some((item) => item.id === selectedClaim)
    )
      setSelectedClaim(evidence[0]?.id ?? "");
  };
  return (
    <TooltipProvider>
      <div className="min-h-screen bg-[radial-gradient(circle_at_72%_-10%,rgba(59,130,246,.10),transparent_30%),hsl(var(--background))] text-foreground">
        <div className="fixed inset-y-0 left-0 z-30 hidden lg:block">
          <Sidebar view={view} setView={switchView} />
        </div>
        <main className="min-h-screen lg:pl-[238px]">
          <header className="sticky top-0 z-20 flex h-[74px] items-center gap-4 border-b border-border/70 bg-background/80 px-4 backdrop-blur-xl sm:px-6">
            <Sheet>
              <SheetTrigger asChild>
                <Button
                  aria-label="Open navigation"
                  variant="outline"
                  size="icon"
                  className="lg:hidden"
                >
                  <Menu className="size-4" />
                </Button>
              </SheetTrigger>
              <SheetContent
                side="left"
                className="w-[270px] border-border bg-background p-0"
              >
                <Sidebar view={view} setView={switchView} mobile />
              </SheetContent>
            </Sheet>
            <div className="min-w-0 flex-1">
              <h1 className="truncate text-base font-semibold">
                {pageMeta[0]}
              </h1>
              <p className="truncate text-[10px] text-muted-foreground">
                {pageMeta[1]}
              </p>
            </div>
            <div className="relative hidden w-56 md:block">
              <Search className="absolute left-3 top-1/2 size-3.5 -translate-y-1/2 text-muted-foreground" />
              <Input
                value={filter}
                onChange={(event) => setFilter(event.target.value)}
                placeholder="Search assets or evidence"
                className="h-8 bg-secondary/40 pl-9 text-[10px]"
              />
            </div>
            <div className="hidden items-center gap-2 text-[10px] text-emerald-300 sm:flex">
              <span className="size-2 rounded-full bg-emerald-400 shadow-[0_0_10px_#4ade80]" />{" "}
              {snapshotQuery.data
                ? "Persisted watchlist evaluation"
                : watchlistQuery.data
                  ? "Watchlist loaded · awaiting evaluation"
                  : "Loading watchlist"}
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={() => refresh.mutate()}
              disabled={refresh.isPending}
              className="h-8 gap-2 text-[10px]"
            >
              <RefreshCw
                className={cn("size-3.5", refresh.isPending && "animate-spin")}
              />
              <span className="hidden sm:inline">Refresh evidence</span>
            </Button>
            <button className="grid size-8 place-items-center rounded-full border border-primary/35 bg-gradient-to-br from-primary/50 to-blue-500/40 text-[10px] font-bold">
              ZI
            </button>
          </header>
          <div className="p-4 sm:p-5 xl:p-6">
            {!selectedAsset ? (
              <Card className="border-border/80 bg-card/75 p-8 text-center">
                <FileSearch className="mx-auto size-8 text-primary" />
                <CardTitle className="mt-4 text-base">
                  Loading your watchlist
                </CardTitle>
                <CardDescription className="mt-2">
                  The Asset Case File universe comes only from your canonical CoinMarketCap watchlist.
                </CardDescription>
              </Card>
            ) : null}
            {selectedAsset && view === "command" && (
              <CommandCenter
                assets={filteredAssets.length ? filteredAssets : assets}
                providers={providers}
                selected={activeSymbol}
                setSelected={setSelectedSymbol}
                setView={switchView}
              />
            )}
            {selectedAsset && view === "evidence" && (
              <EvidenceGraph
                asset={selectedAsset}
                evidence={evidence}
                selectedClaim={selectedClaim}
                onClaim={setSelectedClaim}
                onChallenge={() => switchView("challenger")}
              />
            )}
            {selectedAsset && view === "case" && (
              <Suspense
                fallback={
                  <Card className="border-border/80 bg-card/75 p-6 text-sm text-muted-foreground">
                    Loading governed case file…
                  </Card>
                }
              >
                {evidenceQuery.isPending ? (
                  <Card className="border-border/80 bg-card/75 p-8 text-center">
                    <RefreshCw className="mx-auto size-7 animate-spin text-primary" />
                    <CardTitle className="mt-4 text-base">Loading {selectedAsset.symbol} case file</CardTitle>
                  </Card>
                ) : evidenceQuery.data?.caseFile ? (
                  <AssetCasePanel caseFile={evidenceQuery.data.caseFile} />
                ) : (
                  <Card className="border-border/80 bg-card/75 p-8 text-center">
                    <FileSearch className="mx-auto size-8 text-primary" />
                    <CardTitle className="mt-4 text-base">
                      {selectedAsset.symbol} has no evaluated case file yet
                    </CardTitle>
                    <CardDescription className="mx-auto mt-2 max-w-xl leading-6">
                      {selectedAsset.name} is in your CoinMarketCap watchlist. Run Refresh evidence to evaluate the watchlist; unavailable provider coverage will remain explicitly unknown instead of being replaced with Solana or demo data.
                    </CardDescription>
                  </Card>
                )}
              </Suspense>
            )}
            {selectedAsset && view === "challenger" && (
              <ChallengerPanel
                asset={selectedAsset}
                evidence={evidence}
                selectedClaim={selectedClaim}
                setSelectedClaim={setSelectedClaim}
                liveEvidence={liveEvidence.length > 0}
              />
            )}
          </div>
        </main>
      </div>
    </TooltipProvider>
  );
}
