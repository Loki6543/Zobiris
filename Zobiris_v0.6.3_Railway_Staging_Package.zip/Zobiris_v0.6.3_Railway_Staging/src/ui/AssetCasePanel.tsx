import {
  AlertTriangle,
  ArrowDownRight,
  ArrowUpRight,
  CheckCircle2,
  Clock3,
  FileSearch,
  Fingerprint,
  History,
  ShieldCheck,
  XCircle,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import type { AssetCaseFile } from "./api";
import { cn } from "@/lib/utils";

function Delta({ value, suffix = "" }: { value: number; suffix?: string }) {
  const positive = value >= 0;
  const Icon = positive ? ArrowUpRight : ArrowDownRight;
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1 text-[10px]",
        positive ? "text-emerald-300" : "text-red-300",
      )}
    >
      <Icon className="size-3" />
      {positive ? "+" : ""}
      {value.toFixed(1)}
      {suffix}
    </span>
  );
}

function Scenario({
  label,
  text,
  tone,
}: {
  label: string;
  text: string | null;
  tone: "bull" | "base" | "bear";
}) {
  const colors = {
    bull: "border-emerald-500/25 bg-emerald-500/[.06] text-emerald-300",
    base: "border-blue-500/25 bg-blue-500/[.06] text-blue-300",
    bear: "border-red-500/25 bg-red-500/[.06] text-red-300",
  }[tone];
  return (
    <div className={cn("rounded-xl border p-3", colors)}>
      <p className="text-[9px] font-semibold uppercase tracking-[.14em]">
        {label}
      </p>
      <p className="mt-2 text-[11px] leading-5 text-foreground/80">
        {text ?? "Not established"}
      </p>
    </div>
  );
}

export function AssetCasePanel({ caseFile }: { caseFile: AssetCaseFile }) {
  const change = caseFile.changeSincePrevious;
  return (
    <div className="grid gap-4">
      <Card className="overflow-hidden border-primary/25 bg-[radial-gradient(circle_at_top_right,rgba(124,92,246,.13),transparent_35%),hsl(var(--card)/.82)]">
        <CardContent className="grid gap-5 p-5 lg:grid-cols-[1.4fr_.6fr]">
          <div>
            <div className="flex flex-wrap items-center gap-2">
              <Badge
                className="border-emerald-500/30 bg-emerald-500/10 text-emerald-300"
                variant="outline"
              >
                <Fingerprint className="mr-1 size-3" />{" "}
                {caseFile.identity.status} identity
              </Badge>
              <Badge variant="outline">{caseFile.role}</Badge>
              <Badge variant="outline">{caseFile.risk} risk</Badge>
            </div>
            <h2 className="mt-4 text-xl font-semibold">
              {caseFile.symbol} evidence-backed case
            </h2>
            <p className="mt-2 max-w-4xl text-xs leading-6 text-foreground/75">
              {caseFile.conclusion}
            </p>
            <div className="mt-4 flex flex-wrap items-center gap-x-5 gap-y-2 text-[10px] text-muted-foreground">
              <span>As of {new Date(caseFile.asOf).toLocaleString()}</span>
              <span>
                Action:{" "}
                <strong className="text-foreground">
                  {caseFile.action.replaceAll("_", " ")}
                </strong>
              </span>
              <span>
                Coverage: {Math.round(caseFile.evidenceCoverage * 100)}%
              </span>
            </div>
          </div>
          <div className="grid grid-cols-3 gap-2 lg:grid-cols-1 xl:grid-cols-3">
            {[
              ["Score", caseFile.score.opportunity.toFixed(1)],
              ["Confidence", `${caseFile.score.confidence.toFixed(0)}%`],
              ["Target", `${caseFile.score.targetWeightPct.toFixed(1)}%`],
            ].map(([label, value]) => (
              <div
                key={label}
                className="rounded-xl border border-border/70 bg-background/30 p-3 text-center"
              >
                <p className="text-[9px] text-muted-foreground">{label}</p>
                <p className="mt-1 text-lg font-semibold tabular-nums">
                  {value}
                </p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {caseFile.strategy21 ? (
        <Card className="border-violet-500/25 bg-card/75">
          <CardHeader className="p-4 pb-2">
            <CardTitle className="text-sm">Strategy Engine 2.1</CardTitle>
            <CardDescription>
              {caseFile.strategy21.doctrine} · {caseFile.strategy21.assetState.replaceAll("_", " ")} · {caseFile.strategy21.dataReadiness.replaceAll("_", " ")}
            </CardDescription>
          </CardHeader>
          <CardContent className="grid gap-4 p-4 pt-2">
            <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-5">
              {[
                ["Research rank", `#${caseFile.strategy21.researchRank}`],
                ["Next-dollar rank", caseFile.strategy21.nextDollarRank ? `#${caseFile.strategy21.nextDollarRank}` : "Warm-up"],
                ["Action", caseFile.strategy21.action.replaceAll("_", " ")],
                ["Max next order", `$${caseFile.strategy21.positionAuthority.maxNextOrderUsd.toFixed(0)}`],
                ["Max position", `$${caseFile.strategy21.positionAuthority.maxPositionUsd.toFixed(0)}`],
              ].map(([label, value]) => (
                <div key={label} className="rounded-xl border border-border/70 bg-secondary/20 p-3">
                  <p className="text-[8px] uppercase tracking-[.12em] text-muted-foreground">{label}</p>
                  <p className="mt-1 text-xs font-semibold">{value}</p>
                </div>
              ))}
            </div>
            <div className="grid gap-2 sm:grid-cols-5">
              {Object.entries(caseFile.strategy21.factors).map(([name, factor]) => (
                <div key={name} className="rounded-lg bg-background/30 p-2">
                  <p className="text-[8px] capitalize text-muted-foreground">{name}</p>
                  <p className="mt-1 text-sm font-semibold tabular-nums">{factor.value == null ? "—" : (factor.value * 100).toFixed(0)}</p>
                  <p className="text-[8px] text-muted-foreground">coverage {(factor.coverage * 100).toFixed(0)}%</p>
                </div>
              ))}
            </div>
            {caseFile.strategy21.personality ? (
              <div className="rounded-xl border border-sky-500/20 bg-sky-500/[.04] p-3">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div>
                    <p className="text-[9px] font-semibold text-sky-300">Behavioral Personality</p>
                    <p className="mt-1 text-sm font-semibold">{caseFile.strategy21.personality.primary.replaceAll("_", " ")}</p>
                    {caseFile.strategy21.personality.secondary.length ? (
                      <p className="text-[9px] text-foreground/65">Secondary: {caseFile.strategy21.personality.secondary.map((x) => x.replaceAll("_", " ")).join(" · ")}</p>
                    ) : null}
                  </div>
                  <div className="grid grid-cols-2 gap-2 text-right">
                    <div>
                      <p className="text-[8px] uppercase tracking-[.12em] text-muted-foreground">Elastic Strength</p>
                      <p className="text-sm font-semibold tabular-nums">{caseFile.strategy21.personality.elasticStrength.score.toFixed(0)} · {caseFile.strategy21.personality.elasticStrength.band}</p>
                    </div>
                    <div>
                      <p className="text-[8px] uppercase tracking-[.12em] text-muted-foreground">Historical match</p>
                      <p className="text-sm font-semibold">{caseFile.strategy21.personality.historicalMatch}</p>
                    </div>
                  </div>
                </div>
                <div className="mt-2 flex flex-wrap gap-x-4 gap-y-1 text-[9px] text-foreground/65">
                  <span>coverage {(caseFile.strategy21.personality.coverage * 100).toFixed(0)}%</span>
                  <span>confidence {(caseFile.strategy21.personality.confidence * 100).toFixed(0)}%</span>
                  <span>{caseFile.strategy21.personality.similarSetupCount} comparable setups</span>
                  <span>descriptive only — no sizing authority</span>
                </div>
                {caseFile.strategy21.personality.warnings.slice(0,2).map((x) => <p key={x} className="mt-1 text-[9px] text-amber-200/80">• {x}</p>)}
              </div>
            ) : null}
            <div className="grid gap-3 lg:grid-cols-3">
              <div className="rounded-xl border border-emerald-500/20 bg-emerald-500/[.04] p-3">
                <p className="text-[9px] font-semibold text-emerald-300">What improves the call</p>
                <ul className="mt-2 grid gap-1 text-[9px] text-foreground/70">{caseFile.strategy21.explanation.flipBullish.map((x) => <li key={x}>• {x}</li>)}</ul>
              </div>
              <div className="rounded-xl border border-red-500/20 bg-red-500/[.04] p-3">
                <p className="text-[9px] font-semibold text-red-300">What breaks the call</p>
                <ul className="mt-2 grid gap-1 text-[9px] text-foreground/70">{caseFile.strategy21.explanation.flipBearish.map((x) => <li key={x}>• {x}</li>)}</ul>
              </div>
              <div className="rounded-xl border border-amber-500/20 bg-amber-500/[.04] p-3">
                <p className="text-[9px] font-semibold text-amber-300">Execution eligibility</p>
                <p className="mt-2 text-[10px] font-medium">{caseFile.strategy21.eligibility.status.replaceAll("_", " ")}</p>
                {caseFile.strategy21.eligibility.failureReasons.slice(0,3).map((x) => <p key={x} className="mt-1 text-[9px] text-foreground/65">• {x}</p>)}
              </div>
            </div>
          </CardContent>
        </Card>
      ) : null}

      <div className="grid gap-4 xl:grid-cols-[1.15fr_.85fr]">
        <div className="grid gap-4">
          <Card className="border-border/80 bg-card/75">
            <CardHeader className="p-4 pb-2">
              <CardTitle className="text-sm">Scenario envelope</CardTitle>
              <CardDescription>
                Conditions, not forecasts or promises
              </CardDescription>
            </CardHeader>
            <CardContent className="grid gap-3 p-4 pt-2 md:grid-cols-3">
              <Scenario
                label="Bull"
                text={caseFile.scenarios.bull}
                tone="bull"
              />
              <Scenario
                label="Base"
                text={caseFile.scenarios.base}
                tone="base"
              />
              <Scenario
                label="Bear"
                text={caseFile.scenarios.bear}
                tone="bear"
              />
            </CardContent>
          </Card>

          <Card className="border-border/80 bg-card/75">
            <CardHeader className="flex flex-row items-start justify-between p-4 pb-2">
              <div>
                <CardTitle className="flex items-center gap-2 text-sm">
                  <FileSearch className="size-4 text-blue-300" /> Provenance
                  ledger
                </CardTitle>
                <CardDescription className="mt-1">
                  Every visible observation shows its analytical eligibility
                </CardDescription>
              </div>
              <Badge variant="outline">
                {caseFile.evidence.length} observations
              </Badge>
            </CardHeader>
            <CardContent className="p-0">
              <ScrollArea className="h-[390px]">
                <div className="grid gap-2 p-4 pt-2">
                  {caseFile.evidence.map((item, index) => (
                    <div
                      key={`${item.provider}-${item.eventType}-${index}`}
                      className="rounded-xl border border-border/70 bg-secondary/20 p-3 [content-visibility:auto]"
                    >
                      <div className="flex flex-wrap items-center gap-2">
                        <Badge variant="outline" className="text-[8px]">
                          {item.provider}
                        </Badge>
                        <Badge variant="outline" className="text-[8px]">
                          {item.eventType}
                        </Badge>
                        <Badge
                          variant="outline"
                          className={cn(
                            "text-[8px]",
                            item.eligibility === "eligible"
                              ? "border-emerald-500/30 text-emerald-300"
                              : "border-amber-500/30 text-amber-300",
                          )}
                        >
                          {item.eligibility.replaceAll("_", " ")}
                        </Badge>
                        <Badge
                          variant="outline"
                          className={cn(
                            "text-[8px]",
                            item.dataMode === "fallback" &&
                              "border-amber-500/30 text-amber-300",
                          )}
                        >
                          {item.dataMode}
                        </Badge>
                        <span className="ml-auto text-[9px] text-muted-foreground">
                          {Math.round(item.confidence * 100)}%
                        </span>
                      </div>
                      <p className="mt-2 text-[11px] leading-5">
                        {item.summary}
                      </p>
                      <div className="mt-2 grid gap-1 font-mono text-[8px] text-muted-foreground sm:grid-cols-2">
                        <span className="truncate">
                          endpoint: {item.providerEndpoint ?? "unavailable"}
                        </span>
                        <span className="truncate">
                          sha256: {item.payloadHash ?? "unavailable"}
                        </span>
                        <span>
                          market: {item.requestedMarket ?? "not recorded"}
                        </span>
                        <span>state: {item.epistemicState}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </ScrollArea>
            </CardContent>
          </Card>
        </div>

        <div className="grid content-start gap-4">
          <Card className="border-border/80 bg-card/75">
            <CardHeader className="p-4 pb-2">
              <CardTitle className="flex items-center gap-2 text-sm">
                <History className="size-4 text-primary" /> Since previous
                snapshot
              </CardTitle>
            </CardHeader>
            <CardContent className="p-4 pt-2">
              {change ? (
                <div className="grid grid-cols-2 gap-3">
                  <div className="rounded-lg bg-secondary/30 p-3">
                    <p className="text-[9px] text-muted-foreground">
                      Opportunity
                    </p>
                    <div className="mt-1">
                      <Delta value={change.opportunityDelta} />
                    </div>
                  </div>
                  <div className="rounded-lg bg-secondary/30 p-3">
                    <p className="text-[9px] text-muted-foreground">
                      Confidence
                    </p>
                    <div className="mt-1">
                      <Delta value={change.confidenceDelta} suffix="%" />
                    </div>
                  </div>
                  <div className="col-span-2 rounded-lg bg-secondary/30 p-3 text-[10px]">
                    Previous action:{" "}
                    <span className="font-semibold">
                      {change.previousAction.replaceAll("_", " ")}
                    </span>
                    {change.actionChanged ? (
                      <Badge
                        className="ml-2 border-amber-500/30 text-amber-300"
                        variant="outline"
                      >
                        changed
                      </Badge>
                    ) : null}
                  </div>
                </div>
              ) : (
                <p className="text-[11px] text-muted-foreground">
                  No earlier comparable snapshot.
                </p>
              )}
              <Separator className="my-4" />
              <div className="grid gap-2">
                {caseFile.recentHistory.map((item) => (
                  <div
                    key={item.asOf}
                    className="grid grid-cols-[1fr_auto] items-center gap-3 text-[10px]"
                  >
                    <span className="text-muted-foreground">
                      {new Date(item.asOf).toLocaleString()}
                    </span>
                    <span className="tabular-nums">
                      {item.opportunity.toFixed(1)} ·{" "}
                      {item.confidence.toFixed(0)}% · {item.action}
                    </span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card className="border-amber-500/20 bg-card/75">
            <CardHeader className="p-4 pb-2">
              <CardTitle className="flex items-center gap-2 text-sm">
                <AlertTriangle className="size-4 text-amber-300" /> Unknowns &
                contradictions
              </CardTitle>
              <CardDescription>
                Uncertainty remains visible instead of being averaged away
              </CardDescription>
            </CardHeader>
            <CardContent className="grid gap-2 p-4 pt-2">
              {caseFile.unknowns.length === 0 &&
              caseFile.contradictions.length === 0 ? (
                <div className="flex items-center gap-2 rounded-lg bg-emerald-500/[.06] p-3 text-[11px] text-emerald-300">
                  <CheckCircle2 className="size-4" /> No governed conflicts
                  recorded.
                </div>
              ) : null}
              {caseFile.unknowns.map((item) => (
                <div
                  key={`${item.code}-${item.summary}`}
                  className="flex gap-2 rounded-lg border border-amber-500/20 bg-amber-500/[.05] p-3"
                >
                  <Clock3 className="mt-0.5 size-3.5 shrink-0 text-amber-300" />
                  <div>
                    <p className="text-[9px] font-semibold text-amber-300">
                      {item.code}
                    </p>
                    <p className="mt-1 text-[10px] leading-5 text-foreground/75">
                      {item.summary}
                    </p>
                  </div>
                </div>
              ))}
              {caseFile.contradictions.map((item) => (
                <div
                  key={`${item.code}-${item.claimId ?? item.summary}`}
                  className="flex gap-2 rounded-lg border border-red-500/20 bg-red-500/[.05] p-3"
                >
                  <XCircle className="mt-0.5 size-3.5 shrink-0 text-red-300" />
                  <div>
                    <p className="text-[9px] font-semibold text-red-300">
                      {item.code} · {item.source}
                    </p>
                    <p className="mt-1 text-[10px] leading-5 text-foreground/75">
                      {item.summary}
                    </p>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>

          <Card className="border-emerald-500/20 bg-card/75">
            <CardHeader className="p-4 pb-2">
              <CardTitle className="flex items-center gap-2 text-sm">
                <ShieldCheck className="size-4 text-emerald-300" /> Invalidation
                conditions
              </CardTitle>
            </CardHeader>
            <CardContent className="grid gap-2 p-4 pt-2">
              {caseFile.invalidationConditions.map((condition) => (
                <div
                  key={condition}
                  className="flex gap-2 text-[10px] leading-5 text-foreground/75"
                >
                  <span className="mt-2 size-1.5 shrink-0 rounded-full bg-red-400" />
                  {condition}
                </div>
              ))}
              <Progress
                value={caseFile.evidenceCoverage * 100}
                className="mt-2 h-1.5"
              />
              <p className="text-[9px] text-muted-foreground">
                Evidence coverage {Math.round(caseFile.evidenceCoverage * 100)}%
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
