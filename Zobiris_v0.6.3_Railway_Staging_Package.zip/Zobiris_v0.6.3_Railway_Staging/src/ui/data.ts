export type AssetRow = {
  rank: number;
  symbol: string;
  name: string;
  score: number;
  confidence: number;
  risk: "Low" | "Medium" | "High" | "Unknown";
  action: string;
  change: number;
  trend: number[];
  evidenceCount: number;
  evaluated: boolean;
  strategyResearchRank?: number | null;
  nextDollarRank?: number | null;
  strategyState?: string | null;
  strategyAction?: string | null;
  maxNextOrderUsd?: number | null;
};

export type ProviderRow = {
  name: string;
  status: "healthy" | "degraded" | "snapshot";
  latency: string;
  success: string;
  freshness: string;
};

export type EvidenceRow = {
  id: string;
  claim: string;
  source: string;
  family: string;
  confidence: number;
  freshness: string;
  dataMode: string;
  origin: string;
  state: string;
};
