import { Agent, run, tool } from "@openai/agents";
import { z } from "zod";
import {
  challengerRequestSchema,
  challengerResultSchema,
  type ChallengerRequest,
  type ChallengerResult,
  type LedgerClaim,
} from "./contracts.js";

export interface ChallengeEvidenceInput extends ChallengerRequest {
  claims: LedgerClaim[];
}

/** Run a bounded, read-only challenge over the evidence ledger. */
export async function challengeEvidence(
  input: ChallengeEvidenceInput,
): Promise<ChallengerResult> {
  const request = challengerRequestSchema.parse({
    symbol: input.symbol,
    claimId: input.claimId,
    question: input.question,
  });
  const claimById = new Map(input.claims.map((claim) => [claim.id, claim]));
  if (!claimById.has(request.claimId)) {
    throw new Error(
      `Claim ${request.claimId} is not present in the ${request.symbol} evidence ledger.`,
    );
  }

  const inspectEvidenceLedger = tool({
    name: "inspect_evidence_ledger",
    description:
      "Read evidence claims by exact claim id. This tool cannot change scores or state.",
    parameters: z.strictObject({
      claimIds: z.array(z.string().uuid()).min(1).max(25),
    }),
    strict: true,
    execute: async ({ claimIds }) => ({
      claims: claimIds
        .map((id) => claimById.get(id))
        .filter((claim): claim is LedgerClaim => Boolean(claim)),
    }),
  });

  const challenger = new Agent({
    name: "Zobiris Challenger",
    model: process.env.OPENAI_CHALLENGER_MODEL ?? "gpt-5.4-mini",
    instructions: [
      "You are a skeptical evidence auditor inside Zobiris.",
      "Inspect only the supplied ledger through the read-only tool.",
      "Challenge the target using provenance, freshness, data mode, epistemic state, confidence and contradictions.",
      "Fallback or synthetic claims are display-only and cannot establish a market fact.",
      "Never calculate, change, recommend or imply a Zobiris score, rank, allocation, trade or portfolio action.",
      "Every contradiction must cite an exact claim id from the ledger.",
      "If evidence is insufficient, list the exact additional evidence needed.",
    ].join(" "),
    tools: [inspectEvidenceLedger],
    outputType: challengerResultSchema,
  });

  const result = await run(
    challenger,
    JSON.stringify({
      task: "Challenge this claim without altering deterministic engine outputs.",
      target: claimById.get(request.claimId),
      availableClaimIds: input.claims.map((claim) => claim.id),
      operatorQuestion:
        request.question ??
        "What is the strongest evidence against this claim?",
    }),
    { maxTurns: 4 },
  );

  const output = challengerResultSchema.parse(result.finalOutput);
  if (output.claimId !== request.claimId)
    throw new Error("Challenger returned a different claim id.");
  return output;
}
