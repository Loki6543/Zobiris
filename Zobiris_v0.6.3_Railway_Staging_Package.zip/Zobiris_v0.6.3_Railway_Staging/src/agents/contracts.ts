import { z } from "zod";

export const challengerRequestSchema = z.strictObject({
  symbol: z
    .string()
    .min(1)
    .max(16)
    .transform((value) => value.toUpperCase()),
  claimId: z.string().uuid(),
  question: z.string().min(3).max(500).optional(),
});

export const challengerResultSchema = z.strictObject({
  claimId: z.string().uuid(),
  reasoning: z.string().min(20).max(4_000),
  confidence: z.number().min(0).max(1),
  requestedEvidence: z.array(z.string().min(3).max(300)).max(8),
  contradictions: z
    .array(
      z.strictObject({
        claimId: z.string().uuid(),
        reason: z.string().min(3).max(500),
        severity: z.enum(["low", "medium", "high"]),
      }),
    )
    .max(12),
});

export type ChallengerRequest = z.infer<typeof challengerRequestSchema>;
export type ChallengerResult = z.infer<typeof challengerResultSchema>;

export const ledgerClaimSchema = z.strictObject({
  id: z.string().uuid(),
  symbol: z.string(),
  factorFamily: z.string(),
  claim: z.string(),
  source: z.string(),
  epistemicState: z.string(),
  evidenceConfidence: z.number(),
  freshness: z.string(),
  dataMode: z.string(),
  claimOrigin: z.string(),
  parentClaimIds: z.array(z.string()),
});

export type LedgerClaim = z.infer<typeof ledgerClaimSchema>;
