import { challengerResultSchema, type ChallengerResult } from "./contracts.js";

export interface ChallengerEvalCase {
  name: string;
  targetClaimId: string;
  output: unknown;
  expectedContradictionIds?: string[];
}

export function evaluateChallengerOutput(testCase: ChallengerEvalCase): {
  passed: boolean;
  failures: string[];
  output?: ChallengerResult;
} {
  const parsed = challengerResultSchema.safeParse(testCase.output);
  if (!parsed.success)
    return { passed: false, failures: ["structured_output_invalid"] };
  const failures: string[] = [];
  if (parsed.data.claimId !== testCase.targetClaimId)
    failures.push("target_claim_mismatch");
  const actual = new Set(
    parsed.data.contradictions.map((item) => item.claimId),
  );
  for (const expected of testCase.expectedContradictionIds ?? []) {
    if (!actual.has(expected))
      failures.push(`missing_contradiction:${expected}`);
  }
  return { passed: failures.length === 0, failures, output: parsed.data };
}
