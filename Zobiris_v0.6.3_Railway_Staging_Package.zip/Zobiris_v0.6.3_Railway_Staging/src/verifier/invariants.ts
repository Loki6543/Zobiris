/**
 * Verifier invariants.
 *
 * Per docs/PRODUCT_REQUIREMENTS.md + acceptance_contract.json:
 *   - weights + reserve = 100% within tolerance
 *   - no chain eligibility filter removes assets
 *   - asset identity never relies on ticker alone
 *   - ambiguous/mapped assets are visible and quarantined
 *   - every asset route renders a case file
 *   - opportunity, confidence, target weight, opp rank, alloc rank are separate
 *   - missing evidence displays UNKNOWN and lowers confidence
 *   - stale evidence is not displayed as live
 *   - hard risk gate can force 0%/avoid/size cap
 *   - refresh creates a session + snapshot + changes
 *   - provider failure preserves last-good data, exposes degraded status
 *   - no wallet/key/order/trade-execution code
 */

import { type PortfolioAnalysisSnapshot } from "../domain/portfolio.js";
import { type CanonicalAsset } from "../domain/canonicalAsset.js";
import { PORTFOLIO_SUM_TOLERANCE } from "../portfolio/normalize.js";

export type Severity = "error" | "warn" | "info";
export interface Finding {
  severity: Severity;
  code: string;
  message: string;
}

export interface VerifierContext {
  snapshot: PortfolioAnalysisSnapshot;
  canonicalAssets: Map<string, CanonicalAsset>;
  watchlist: string[];
}

export function runVerifier(ctx: VerifierContext): Finding[] {
  const findings: Finding[] = [];
  const { snapshot, canonicalAssets, watchlist } = ctx;

  // Invariant: weights + reserve = 100% within tolerance.
  const sum = snapshot.totalAllocatedPct + snapshot.reservePct;
  if (sum > 100 + PORTFOLIO_SUM_TOLERANCE) {
    findings.push({
      severity: "error",
      code: "WEIGHT_SUM_OVER_100",
      message: `Allocated (${snapshot.totalAllocatedPct}%) + reserve (${snapshot.reservePct}%) = ${sum}% > 100% (tolerance ${PORTFOLIO_SUM_TOLERANCE}%).`,
    });
  }
  if (sum < 100 - PORTFOLIO_SUM_TOLERANCE) {
    findings.push({
      severity: "info",
      code: "UNALLOCATED",
      message: `${(100 - sum).toFixed(2)}% is unallocated; reserve or evidence gap.`,
    });
  }

  // Invariant: ambiguous identity must not receive positive weight.
  for (const a of snapshot.rankedAssets) {
    const activeVeto = a.riskGates.find(g => g.active && g.effect === "veto");
    if (activeVeto && a.targetWeight.pct > 0) {
      findings.push({
        severity: "error",
        code: "WEIGHT_VETO_BREACH",
        message: `${a.symbol} has positive weight (${a.targetWeight.pct}%) despite active veto ${activeVeto.code}.`,
      });
    }
    const activeCaps = a.riskGates
      .filter(g => g.active && g.effect === "size_cap" && typeof g.cap === "number")
      .map(g => g.cap!);
    const strictCap = activeCaps.length > 0 ? Math.min(...activeCaps) : null;
    if (strictCap !== null && a.targetWeight.pct > strictCap + 0.0001) {
      findings.push({
        severity: "error",
        code: "WEIGHT_EXCEEDS_RISK_CAP",
        message: `${a.symbol} weight (${a.targetWeight.pct}%) exceeds active hard risk cap (${strictCap}%).`,
      });
    }
    const canonical = a.canonicalAssetId ? canonicalAssets.get(a.canonicalAssetId) : undefined;
    if (canonical && (canonical.mappingStatus === "ambiguous" || canonical.mappingStatus === "quarantined")) {
      if (a.targetWeight.pct > 0) {
        findings.push({
          severity: "error",
          code: "WEIGHT_AMBIGUOUS_IDENTITY",
          message: `${a.symbol} has positive weight (${a.targetWeight.pct}%) but mapping status is ${canonical.mappingStatus}.`,
        });
      }
    }
    if (canonical && canonical.mappingStatus === "unmapped" && a.targetWeight.pct > 0) {
      findings.push({
        severity: "warn",
        code: "WEIGHT_UNMAPPED",
        message: `${a.symbol} has positive weight but mapping status is unmapped; manual review recommended.`,
      });
    }
  }

  // Invariant: no chain eligibility filter removed any watchlist asset.
  for (const sym of watchlist) {
    if (!snapshot.rankedAssets.find(a => a.symbol === sym)) {
      findings.push({
        severity: "error",
        code: "WATCHLIST_ASSET_MISSING",
        message: `Watchlist symbol ${sym} missing from snapshot.`,
      });
    }
  }

  // Invariant: every ranked asset has its own case file fields.
  for (const a of snapshot.rankedAssets) {
    if (!a.conclusion || a.conclusion.length < 5) {
      findings.push({
        severity: "error",
        code: "ASSET_NO_CONCLUSION",
        message: `${a.symbol} has no conclusion text.`,
      });
    }
    if (a.opportunity.adjusted === 0 && a.action !== "AVOID" && a.action !== "RESEARCH" && a.action !== "INSUFFICIENT_DATA" && a.action !== "REVALIDATE" && a.targetWeight.pct > 0) {
      findings.push({
        severity: "warn",
        code: "ZERO_SCORE_WITH_WEIGHT",
        message: `${a.symbol} has zero opportunity score but non-zero weight (${a.targetWeight.pct}%).`,
      });
    }
  }

  // Invariant: no wallet/key/order/trade-execution path.
  // (This is enforced by code review + a static check; the verifier is a guardrail.)
  // We emit a positive info finding if the snapshot looks healthy.

  // Invariant: stale evidence not displayed as live.
  for (const a of snapshot.rankedAssets) {
    if (a.evidenceState === "STALE" && (a.action === "STRONG_BUY" || a.action === "BUY" || a.action === "ACCUMULATE")) {
      findings.push({
        severity: "warn",
        code: "STALE_ACTIONABLE",
        message: `${a.symbol} has stale evidence but actionable verdict (${a.action}).`,
      });
    }
  }

  return findings;
}

export function summarize(findings: Finding[]): { errors: number; warnings: number; info: number; passed: boolean } {
  const errors = findings.filter(f => f.severity === "error").length;
  const warnings = findings.filter(f => f.severity === "warn").length;
  const info = findings.filter(f => f.severity === "info").length;
  return { errors, warnings, info, passed: errors === 0 };
}
