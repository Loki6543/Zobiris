/**
 * 19-stage refresh contract — the complete list of stages with their
 * truthful terminal status.
 *
 * Per the v0.4.3 audit (P0-7A): every stage must receive exactly one
 * terminal record based on the ACTUAL acquisition result, not the
 * adapter's `health()` status. A normalization failure must not allow
 * a stage to be marked succeeded while the health check still reports
 * "connected".
 *
 * Per the v0.4.3 audit (P0-7B): missing stage outcomes are integrity
 * errors. composeStages() now requires every stage to have an explicit
 * outcome; if any stage is missing, it throws.
 */

export const STAGE_NAMES = [
  "open-session",
  "provider-health",
  "watchlist-sync",
  "acquire-market",
  "acquire-social",
  "acquire-derivatives",
  "acquire-catalysts-macro",
  "acquire-onchain",
  "normalize-dedup",
  "regime",
  "specialists",
  "risk-gates",
  "score",
  "universe-compare",
  "allocate",
  "verify-challenge",
  "publish",
  "snapshot",
  "telemetry",
] as const;

export type StageName = (typeof STAGE_NAMES)[number];

export type StageStatus =
  | "pending"
  | "running"
  | "succeeded"
  | "failed"
  | "skipped"
  | "not_configured"
  | "degraded";

export interface StageRecord {
  index: number;
  name: string;
  status: StageStatus;
  notes?: string;
  startedAt?: string;
  completedAt?: string;
}

export interface StageOutcome {
  name: StageName;
  status: StageStatus;
  notes?: string;
}

/**
 * Compose the final 19-stage record list from the per-stage outcomes.
 * v0.4.3 audit fix (P0-7B): every stage must have an explicit outcome.
 * Missing stages raise StageSetIntegrityError instead of silently being
 * synthesized as "not_configured". The runtime must explicitly record a
 * status for every stage.
 */
export class StageSetIntegrityError extends Error {
  readonly missing: string[];
  constructor(missing: string[]) {
    super(`Stage set is missing explicit outcomes for: ${missing.join(", ")}`);
    this.name = "StageSetIntegrityError";
    this.missing = missing;
  }
}

export function composeStages(outcomes: StageOutcome[]): StageRecord[] {
  const byName = new Map(outcomes.map(o => [o.name, o]));
  const missing: string[] = [];
  for (const name of STAGE_NAMES) {
    if (!byName.has(name)) missing.push(name);
  }
  if (missing.length > 0) {
    throw new StageSetIntegrityError(missing);
  }
  return STAGE_NAMES.map((name, i) => {
    const o = byName.get(name)!;
    return {
      index: i + 1,
      name,
      status: o.status,
      notes: o.notes,
      startedAt: new Date().toISOString(),
      completedAt: new Date().toISOString(),
    };
  });
}

/**
 * Verify the stage record list contains exactly the 19 stages in order.
 * Returns the missing / extra / out-of-order indexes for diagnostics.
 */
export function verifyStageSet(records: StageRecord[]): {
  ok: boolean;
  missing: number[];
  extra: number[];
  wrongStatus: { index: number; name: string; status: StageStatus }[];
} {
  const seen = new Map<number, StageRecord>();
  for (const r of records) seen.set(r.index, r);
  const missing: number[] = [];
  const wrongStatus: { index: number; name: string; status: StageStatus }[] = [];
  for (let i = 0; i < STAGE_NAMES.length; i++) {
    const expected = STAGE_NAMES[i]!;
    const r = seen.get(i + 1);
    if (!r) {
      missing.push(i + 1);
      continue;
    }
    if (r.name !== expected) {
      wrongStatus.push({ index: i + 1, name: r.name, status: r.status });
    }
    if (r.status === "pending" || r.status === "running") {
      wrongStatus.push({ index: i + 1, name: r.name, status: r.status });
    }
  }
  const extra: number[] = [];
  for (const idx of seen.keys()) {
    if (idx < 1 || idx > STAGE_NAMES.length) extra.push(idx);
  }
  return {
    ok: missing.length === 0 && extra.length === 0 && wrongStatus.length === 0,
    missing,
    extra,
    wrongStatus,
  };
}
