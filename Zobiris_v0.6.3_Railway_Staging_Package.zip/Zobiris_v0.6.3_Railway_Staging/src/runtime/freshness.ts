/**
 * Freshness states.
 *
 * Per docs/DATA_PLANE.md:
 *   - connected ≠ fresh
 *   - UI freshness states: live | delayed | stale | backfilling | unavailable
 *   - A connected socket with no recent valid events is delayed/stale, not live.
 */

import { type FreshnessState } from "../domain/index.js";

export interface FreshnessInput {
  lastEventAt?: string | undefined;
  /** Maximum age in seconds for "live". Beyond that, "delayed". Beyond 2x, "stale". */
  liveBudgetSeconds: number;
  /** Optional: flag the provider as currently backfilling. */
  backfilling?: boolean;
  /** Maximum tolerated provider clock skew into the future. Default 60s. */
  maxFutureSkewSeconds?: number;
}

export function computeFreshness(input: FreshnessInput): FreshnessState {
  if (input.backfilling) return "backfilling";
  if (!input.lastEventAt) return "unavailable";
  const eventMs = new Date(input.lastEventAt).getTime();
  if (!Number.isFinite(eventMs)) return "unavailable";
  const ageMs = Date.now() - eventMs;
  const allowedFutureSkewMs = Math.max(0, input.maxFutureSkewSeconds ?? 60) * 1000;
  if (ageMs < -allowedFutureSkewMs) return "unavailable";
  if (ageMs < 0) return "live";
  const ageSec = ageMs / 1000;
  if (ageSec <= input.liveBudgetSeconds) return "live";
  if (ageSec <= input.liveBudgetSeconds * 2) return "delayed";
  return "stale";
}
