/**
 * Bounded exponential backoff with full jitter.
 *
 * Per docs/DATA_PLANE.md: exponential backoff + full jitter; bounded retries;
 * no infinite reconnect loops.
 *
 * Reference: AWS Architecture Blog "Exponential Backoff and Jitter".
 */

export interface BackoffPolicy {
  baseMs: number;
  maxMs: number;
  maxAttempts: number;
  /** Multiplier per attempt. */
  factor: number;
}

export const DEFAULT_BACKOFF: BackoffPolicy = {
  baseMs: 500,
  maxMs: 30_000,
  maxAttempts: 6,
  factor: 2,
};

/** Sleep helper that returns the actual duration slept. */
export function sleep(ms: number): Promise<void> {
  return new Promise(res => setTimeout(res, ms));
}

/** Compute the next backoff delay (full jitter: random in [0, cappedBase]). */
export function nextBackoffDelay(
  attempt: number,
  policy: BackoffPolicy = DEFAULT_BACKOFF,
  rng: () => number = Math.random,
): number {
  if (attempt < 0) return 0;
  const exponential = Math.min(policy.maxMs, policy.baseMs * Math.pow(policy.factor, attempt));
  return Math.floor(rng() * exponential);
}

/** Should we retry? */
export function shouldRetry(
  attempt: number,
  policy: BackoffPolicy = DEFAULT_BACKOFF,
): boolean {
  return attempt < policy.maxAttempts;
}
