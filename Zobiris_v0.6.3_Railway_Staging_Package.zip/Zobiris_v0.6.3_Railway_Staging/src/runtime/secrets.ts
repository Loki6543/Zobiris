/**
 * Secret redaction.
 *
 * Per SECURITY_GOVERNANCE.md: never write credentials into logs, metrics,
 * event payloads, error responses, screenshots, or test fixtures. Redact
 * query strings/headers for providers that authenticate via URL.
 */

const REDACTED = "REDACTED";

const PATTERNS: Array<{ re: RegExp; replace: (m: string) => string }> = [
  // Standard auth headers
  { re: /\b(Bearer|Authorization)\s+[A-Za-z0-9._\-+/=]{8,}/g, replace: (_m) => `${_m.split(/\s+/)[0]} ${REDACTED}` },
  // URL query params
  { re: /([?&](?:api_key|access_token|token|key|apikey|api-key|password|secret)=)([^&\s]+)/gi, replace: (_m) => `${_m.split("=")[0]}=${REDACTED}` },
  // Common API key shapes
  { re: /\bsk-[A-Za-z0-9_\-]{20,}\b/g, replace: () => REDACTED },
  { re: /\bAIza[0-9A-Za-z_\-]{35}\b/g, replace: () => REDACTED },
  // Generic 32+ char hex
  { re: /\b[0-9a-f]{32,}\b/gi, replace: () => REDACTED },
  // UUIDs
  { re: /\b[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\b/gi, replace: () => `${REDACTED}-UUID` },
  // Email
  { re: /\b[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}\b/g, replace: () => `${REDACTED}@` },
];

/** Redact a string for safe inclusion in logs/test outputs. Idempotent. */
export function redact(s: string): string {
  let out = s;
  for (const { re, replace } of PATTERNS) {
    out = out.replace(re, replace);
  }
  return out;
}

/** Redact every value in an object recursively (handles strings only; non-strings are passed through). */
export function redactObject<T>(value: T): T {
  if (typeof value === "string") return redact(value) as unknown as T;
  if (Array.isArray(value)) return value.map(v => redactObject(v)) as unknown as T;
  if (value && typeof value === "object") {
    const out: Record<string, unknown> = {};
    for (const [k, v] of Object.entries(value)) {
      out[k] = redactObject(v);
    }
    return out as unknown as T;
  }
  return value;
}
