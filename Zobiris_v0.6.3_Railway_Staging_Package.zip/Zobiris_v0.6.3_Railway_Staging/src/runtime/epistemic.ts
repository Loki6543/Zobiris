/**
 * Epistemic state utilities.
 *
 * Re-exports + helpers for the 6 epistemic states. The states are the
 * language the UI uses to describe what is and isn't known.
 */

import { type EpistemicState } from "../domain/index.js";

export { type EpistemicState, EPISTEMIC_STATES } from "../domain/index.js";

/** Promote an evidence to the most informative state possible given its inputs. */
export function classifyEpistemicState(input: {
  hasSource: boolean;
  hasTimestamp: boolean;
  ageSeconds: number;
  freshBudgetSeconds: number;
  conflictingSources?: boolean;
}): EpistemicState {
  if (!input.hasSource) return "UNKNOWN";
  if (input.conflictingSources) return "CONFLICTED";
  if (!input.hasTimestamp) return "INFERRED";
  if (input.ageSeconds > input.freshBudgetSeconds) return "STALE";
  if (input.ageSeconds > input.freshBudgetSeconds * 0.5) return "UNCERTAIN";
  return "KNOWN";
}

/** Higher = more displayable in a fact card. */
export function displayability(state: EpistemicState): number {
  switch (state) {
    case "KNOWN": return 1.0;
    case "INFERRED": return 0.7;
    case "UNCERTAIN": return 0.5;
    case "CONFLICTED": return 0.4;
    case "STALE": return 0.2;
    case "UNKNOWN": return 0.0;
  }
}
