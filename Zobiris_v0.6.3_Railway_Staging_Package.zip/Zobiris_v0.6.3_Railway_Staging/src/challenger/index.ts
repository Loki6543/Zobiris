export * from "./runChallenger.js";
