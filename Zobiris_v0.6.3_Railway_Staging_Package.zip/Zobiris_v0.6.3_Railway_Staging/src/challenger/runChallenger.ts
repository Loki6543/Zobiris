/**
 * Challenger: counter-evidence pass per top-N asset.
 *
 * Per docs/AI_COGNITIVE_ENGINE.md:
 *   "Challenger/Skeptic: asks what credible evidence would make the current
 *    thesis wrong or incomplete, checks stale data, conflicts, leakage,
 *    unsupported causal claims, narrative overfitting, and stronger
 *    alternative explanations."
 *
 *   "Do not have the same generation path simply grade itself with
 *    `looks good`."
 */

import { type AssetAnalysisSnapshot } from "../domain/portfolio.js";

export interface ChallengerQuestion {
  symbol: string;
  question: string;
  priority: "High" | "Medium" | "Low";
}

export function runChallenger(assets: AssetAnalysisSnapshot[], topN = 5): ChallengerQuestion[] {
  const ranked = assets
    .filter(a => a.opportunityRank != null)
    .slice(0, topN);
  return ranked.map(a => ({
    symbol: a.symbol,
    question: buildQuestion(a),
    priority: priorityFor(a),
  }));
}

function buildQuestion(a: AssetAnalysisSnapshot): string {
  if (a.evidenceState === "UNKNOWN") {
    return `What minimum source-backed evidence is needed before ${a.symbol} may be scored or allocated?`;
  }
  if (a.evidenceState === "STALE") {
    return `${a.symbol} has stale evidence — what fresh observation would revalidate the current ${a.action} verdict?`;
  }
  if (a.confidence.pct < 50) {
    return `Would ${a.symbol} still rank this highly after its confidence moves above 50%?`;
  }
  if (a.risk === "High") {
    return `What makes the High risk on ${a.symbol} tolerable at the current target weight (${a.targetWeight.pct.toFixed(2)}%)?`;
  }
  const activeGateCodes = a.riskGates.map(g => g.code);
  if (activeGateCodes.length > 0) {
    return `${a.symbol} has active risk gates (${activeGateCodes.join(", ")}). What evidence would deactivate them?`;
  }
  return `What evidence would most likely falsify the current ${a.symbol} thesis at score ${a.opportunity.adjusted.toFixed(1)}?`;
}

function priorityFor(a: AssetAnalysisSnapshot): ChallengerQuestion["priority"] {
  if (a.evidenceState === "STALE" || a.evidenceState === "UNKNOWN") return "High";
  if (a.risk === "High") return "High";
  if (a.confidence.pct < 60) return "High";
  if (a.riskGates.length > 0) return "Medium";
  return "Low";
}
