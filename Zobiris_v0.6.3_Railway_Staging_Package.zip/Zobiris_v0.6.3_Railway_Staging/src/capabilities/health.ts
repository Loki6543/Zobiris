/**
 * Iyaza Addendum — Item A: Provider Health extension.
 *
 * The existing ProviderHealth (src/domain/events.ts) is a 4-state enum.
 * The Iyaza addendum requires a 9-state taxonomy:
 *   unconfigured | configured | healthy | degraded |
 *   rate_limited | quota_exhausted | auth_failed | unavailable | recovering
 *
 * This module provides the extended type and a mapping function so the existing
 * provider adapters' health() method can be lifted onto the new taxonomy
 * without breaking the existing tests.
 */
import type { ProviderHealthExtended } from "./registry.js";

/** The 9-state taxonomy. */
export type { ProviderHealthExtended };

/** Map the existing 4-state health value onto the new 9-state. */
export function upgradeHealth(existing: string): ProviderHealthExtended {
  switch (existing) {
    case "snapshot":
      return "configured";
    case "connected":
      return "healthy";
    case "degraded":
      return "degraded";
    case "credentials-needed":
      return "unconfigured";
    default:
      const VALID: ProviderHealthExtended[] = [
        "unconfigured",
        "configured",
        "healthy",
        "degraded",
        "rate_limited",
        "quota_exhausted",
        "auth_failed",
        "unavailable",
        "recovering",
      ];
      if (VALID.includes(existing as ProviderHealthExtended)) {
        return existing as ProviderHealthExtended;
      }
      return "unavailable";
  }
}
