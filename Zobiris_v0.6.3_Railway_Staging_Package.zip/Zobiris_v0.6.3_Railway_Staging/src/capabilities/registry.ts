/**
 * Iyaza Addendum — Item A: Vendor-neutral Capability Registry.
 *
 * Capabilities are abstract verbs (market.quotes, derivs.funding, etc.).
 * Providers are concrete implementations that can advertise one or more capabilities.
 *
 * Per the Iyaza/Mavis supplement: upper layers depend on capabilities, not vendor names.
 */
import { z } from "zod";

/** All known capability identifiers. */
export const CAPABILITY_IDS = [
  "market.quotes",
  "market.candles",
  "market.orderbook",
  "derivs.funding",
  "derivs.open_interest",
  "derivs.basis",
  "derivs.liquidations",
  "social.attention",
  "social.sentiment",
  "onchain.flows",
  "events.unlocks",
  "events.calendar",
  "news.timeline",
  "macro.liquidity",
  "identity.metadata",
  "research.search",
  "research.multimodal",
  "memory.retrieve",
  "memory.write_candidate",
  "eval.replay",
] as const;

export type CapabilityId = (typeof CAPABILITY_IDS)[number];

/** Side-effect class of a capability. Determines whether it can be called from a sandbox. */
export type SideEffectClass = "read" | "write_candidate" | "write_durable" | "network";

/**
 * Extended provider health state (per the Iyaza addendum). Replaces the 4-state
 * ("snapshot" | "connected" | "degraded" | "credentials-needed") with 9 explicit states.
 */
export type ProviderHealthExtended =
  | "unconfigured"
  | "configured"
  | "healthy"
  | "degraded"
  | "rate_limited"
  | "quota_exhausted"
  | "auth_failed"
  | "unavailable"
  | "recovering";

/** A capability descriptor is a frozen registration record. */
export interface CapabilityDescriptor {
  capabilityId: CapabilityId;
  version: string;
  inputSchemaVersion: string;
  outputSchemaVersion: string;
  /** Provider names that implement this capability. */
  providers: string[];
  /** Required permissions (typed; e.g. "network.egress:pro-api.coinmarketcap.com"). */
  requiredPermissions: string[];
  sideEffectClass: SideEffectClass;
  /** Hostnames the capability is allowed to make requests to. */
  allowedHosts: string[];
  timeoutMs: number;
  /** Free-text retry policy description (typed enum in production). */
  retryPolicy: string;
  /** Free-text idempotency policy description. */
  idempotencyPolicy: string;
  healthState: ProviderHealthExtended;
  /** Free-text evidence obligations. */
  evidenceObligations: string[];
  /** Free-text degradation policy. */
  degradationPolicy: string;
}

/** Zod schema for runtime validation of descriptors loaded from config. */
export const capabilityDescriptorSchema = z.object({
  capabilityId: z.enum(CAPABILITY_IDS),
  version: z.string().min(1),
  inputSchemaVersion: z.string().min(1),
  outputSchemaVersion: z.string().min(1),
  providers: z.array(z.string()),
  requiredPermissions: z.array(z.string()),
  sideEffectClass: z.enum(["read", "write_candidate", "write_durable", "network"]),
  allowedHosts: z.array(z.string()),
  timeoutMs: z.number().int().min(1000).max(60_000),
  retryPolicy: z.string().min(1),
  idempotencyPolicy: z.string().min(1),
  healthState: z.enum([
    "unconfigured",
    "configured",
    "healthy",
    "degraded",
    "rate_limited",
    "quota_exhausted",
    "auth_failed",
    "unavailable",
    "recovering",
  ]),
  evidenceObligations: z.array(z.string()),
  degradationPolicy: z.string().min(1),
});

/**
 * Map the legacy 4-state provider health onto the new 9-state extended health.
 * Used so the new capability registry can coexist with the existing ProviderHealth.
 */
export function upgradeHealth(existing: string): ProviderHealthExtended {
  switch (existing) {
    case "snapshot":
      return "configured";
    case "connected":
      return "healthy";
    case "degraded":
      return "degraded";
    case "credentials-needed":
      return "unconfigured";
    default:
      // If already in extended form, pass through.
      const VALID: ProviderHealthExtended[] = [
        "unconfigured",
        "configured",
        "healthy",
        "degraded",
        "rate_limited",
        "quota_exhausted",
        "auth_failed",
        "unavailable",
        "recovering",
      ];
      if (VALID.includes(existing as ProviderHealthExtended)) {
        return existing as ProviderHealthExtended;
      }
      return "unavailable";
  }
}

/**
 * The CapabilityRegistry. A typed in-memory map from CapabilityId -> descriptor
 * with health-state tracking.
 */
export class CapabilityRegistry {
  private readonly descriptors = new Map<CapabilityId, CapabilityDescriptor>();
  private readonly healthByProvider = new Map<string, ProviderHealthExtended>();

  /** Register a capability descriptor. The descriptor is frozen. Throws on duplicate id. */
  register(descriptor: CapabilityDescriptor): void {
    if (this.descriptors.has(descriptor.capabilityId)) {
      throw new Error(`capability already registered: ${descriptor.capabilityId}`);
    }
    // Validate via Zod for runtime safety.
    capabilityDescriptorSchema.parse(descriptor);
    // Freeze the descriptor so consumers cannot mutate it.
    this.descriptors.set(descriptor.capabilityId, Object.freeze({ ...descriptor }));
  }

  /** Get a capability by id. Returns null if not registered. */
  get(id: CapabilityId): CapabilityDescriptor | null {
    return this.descriptors.get(id) ?? null;
  }

  /** List all registered capabilities. */
  list(): CapabilityDescriptor[] {
    return Array.from(this.descriptors.values());
  }

  /** Get all capabilities advertised by a particular provider. */
  forProvider(name: string): CapabilityDescriptor[] {
    return this.list().filter((c) => c.providers.includes(name));
  }

  /** Get the current health state of a capability (returns "unconfigured" if not set). */
  getHealth(id: CapabilityId): ProviderHealthExtended {
    const desc = this.descriptors.get(id);
    if (!desc) return "unconfigured";
    // Health is the worst-case across the providers that advertise this capability.
    // A provider with no recorded health state is treated as "unconfigured".
    const states = desc.providers.map((p) => this.healthByProvider.get(p) ?? "unconfigured");
    return worstHealth(states);
  }

  /** Update the health state of a provider (affects all capabilities the provider advertises). */
  markHealth(provider: string, state: ProviderHealthExtended): void {
    this.healthByProvider.set(provider, state);
  }

  /** Number of registered capabilities. */
  size(): number {
    return this.descriptors.size;
  }
}

/** Compute the worst (least healthy) state from a list. */
function worstHealth(states: ProviderHealthExtended[]): ProviderHealthExtended {
  // Priority order from worst to best.
  const priority: ProviderHealthExtended[] = [
    "unavailable",
    "auth_failed",
    "quota_exhausted",
    "rate_limited",
    "degraded",
    "recovering",
    "unconfigured",
    "configured",
    "healthy",
  ];
  for (const p of priority) {
    if (states.includes(p)) return p;
  }
  return "unconfigured";
}

/**
 * Build a default registry pre-populated with all 21 capability IDs and
 * reasonable default timeouts/policies. Providers are not auto-registered
 * (callers add them as they're enabled).
 */
export function buildDefaultRegistry(): CapabilityRegistry {
  const reg = new CapabilityRegistry();
  const DEFAULT_TIMEOUT = 10_000;
  const SLOW_TIMEOUT = 30_000;

  // Market data
  reg.register({
    capabilityId: "market.quotes",
    version: "1.0.0",
    inputSchemaVersion: "1.0.0",
    outputSchemaVersion: "1.0.0",
    providers: ["kraken", "cmc"],
    requiredPermissions: ["network.egress:api.kraken.com", "network.egress:pro-api.coinmarketcap.com"],
    sideEffectClass: "network",
    allowedHosts: ["api.kraken.com", "pro-api.coinmarketcap.com"],
    timeoutMs: DEFAULT_TIMEOUT,
    retryPolicy: "exponential-backoff(max=3, base=1s)",
    idempotencyPolicy: "deterministic sha256(provider,symbol,ts)",
    healthState: "unconfigured",
    evidenceObligations: ["price,volume_24h,change_24h with source timestamp"],
    degradationPolicy: "fall through to fixture if 401/5xx; surface networkError",
  });
  reg.register({
    capabilityId: "market.candles",
    version: "1.0.0",
    inputSchemaVersion: "1.0.0",
    outputSchemaVersion: "1.0.0",
    providers: ["kraken"],
    requiredPermissions: ["network.egress:api.kraken.com"],
    sideEffectClass: "network",
    allowedHosts: ["api.kraken.com"],
    timeoutMs: DEFAULT_TIMEOUT,
    retryPolicy: "exponential-backoff(max=3, base=1s)",
    idempotencyPolicy: "deterministic sha256(pair,interval,since)",
    healthState: "unconfigured",
    evidenceObligations: ["ohlcv array with source timestamp"],
    degradationPolicy: "fixture fallback",
  });
  reg.register({
    capabilityId: "market.orderbook",
    version: "1.0.0",
    inputSchemaVersion: "1.0.0",
    outputSchemaVersion: "1.0.0",
    providers: ["kraken"],
    requiredPermissions: ["network.egress:api.kraken.com"],
    sideEffectClass: "network",
    allowedHosts: ["api.kraken.com"],
    timeoutMs: DEFAULT_TIMEOUT,
    retryPolicy: "no-retry (high-frequency)",
    idempotencyPolicy: "timestamp-window",
    healthState: "unconfigured",
    evidenceObligations: ["bids/asks arrays with depth"],
    degradationPolicy: "snapshot only",
  });

  // Derivatives
  for (const id of ["derivs.funding", "derivs.open_interest", "derivs.basis", "derivs.liquidations"] as const) {
    reg.register({
      capabilityId: id,
      version: "1.0.0",
      inputSchemaVersion: "1.0.0",
      outputSchemaVersion: "1.0.0",
      providers: ["coinglass"],
      requiredPermissions: ["network.egress:api.coinglass.com"],
      sideEffectClass: "network",
      allowedHosts: ["api.coinglass.com"],
      timeoutMs: SLOW_TIMEOUT,
      retryPolicy: "exponential-backoff(max=3, base=2s)",
      idempotencyPolicy: "deterministic sha256(symbol,exchange,ts)",
      healthState: "unconfigured",
      evidenceObligations: ["rate,open_interest,volume with source timestamp"],
      degradationPolicy: "fixture fallback; circuit breaker on repeated 5xx",
    });
  }

  // Social
  for (const id of ["social.attention", "social.sentiment"] as const) {
    reg.register({
      capabilityId: id,
      version: "1.0.0",
      inputSchemaVersion: "1.0.0",
      outputSchemaVersion: "1.0.0",
      providers: ["lunarcrush"],
      requiredPermissions: ["network.egress:api.lunarcrush.com"],
      sideEffectClass: "network",
      allowedHosts: ["api.lunarcrush.com"],
      timeoutMs: DEFAULT_TIMEOUT,
      retryPolicy: "exponential-backoff(max=3, base=1s)",
      idempotencyPolicy: "deterministic sha256(symbol,ts)",
      healthState: "unconfigured",
      evidenceObligations: ["galaxy_score,alt_rank,sentiment,social_volume with source timestamp"],
      degradationPolicy: "fixture fallback",
    });
  }

  // On-chain
  reg.register({
    capabilityId: "onchain.flows",
    version: "1.0.0",
    inputSchemaVersion: "1.0.0",
    outputSchemaVersion: "1.0.0",
    providers: ["bitquery"],
    requiredPermissions: ["network.egress:graphql.bitquery.io"],
    sideEffectClass: "network",
    allowedHosts: ["graphql.bitquery.io"],
    timeoutMs: SLOW_TIMEOUT,
    retryPolicy: "exponential-backoff(max=2, base=3s)",
    idempotencyPolicy: "block-number tagged",
    healthState: "unconfigured",
    evidenceObligations: ["tx hash,block,from,to,value,asset"],
    degradationPolicy: "skip on auth failure; circuit breaker",
  });

  // Events
  for (const id of ["events.unlocks", "events.calendar"] as const) {
    reg.register({
      capabilityId: id,
      version: "1.0.0",
      inputSchemaVersion: "1.0.0",
      outputSchemaVersion: "1.0.0",
      providers: ["coinmarketcal"],
      requiredPermissions: ["network.egress:api.coinmarketcal.com"],
      sideEffectClass: "network",
      allowedHosts: ["api.coinmarketcal.com"],
      timeoutMs: DEFAULT_TIMEOUT,
      retryPolicy: "exponential-backoff(max=2, base=2s)",
      idempotencyPolicy: "by event id",
      healthState: "unconfigured",
      evidenceObligations: ["date, title, source URL, is_estimated"],
      degradationPolicy: "fixture fallback",
    });
  }

  // News
  reg.register({
    capabilityId: "news.timeline",
    version: "1.0.0",
    inputSchemaVersion: "1.0.0",
    outputSchemaVersion: "1.0.0",
    providers: ["cryptopanic"],
    requiredPermissions: ["network.egress:cryptopanic.com"],
    sideEffectClass: "network",
    allowedHosts: ["cryptopanic.com"],
    timeoutMs: DEFAULT_TIMEOUT,
    retryPolicy: "exponential-backoff(max=2, base=2s)",
    idempotencyPolicy: "by article id",
    healthState: "unconfigured",
    evidenceObligations: ["title, body, source, published_at"],
    degradationPolicy: "skip on auth failure",
  });

  // Macro
  reg.register({
    capabilityId: "macro.liquidity",
    version: "1.0.0",
    inputSchemaVersion: "1.0.0",
    outputSchemaVersion: "1.0.0",
    providers: ["fred", "treasury"],
    requiredPermissions: ["network.egress:api.stlouisfed.org", "network.egress:fiscaldata.treasury.gov"],
    sideEffectClass: "network",
    allowedHosts: ["api.stlouisfed.org", "fiscaldata.treasury.gov"],
    timeoutMs: DEFAULT_TIMEOUT,
    retryPolicy: "exponential-backoff(max=3, base=2s)",
    idempotencyPolicy: "by series id + observation date",
    healthState: "unconfigured",
    evidenceObligations: ["release_date, observation_date, value, vintage"],
    degradationPolicy: "vintage-aware fall-through",
  });

  // Identity
  reg.register({
    capabilityId: "identity.metadata",
    version: "1.0.0",
    inputSchemaVersion: "1.0.0",
    outputSchemaVersion: "1.0.0",
    providers: ["cmc", "coingecko"],
    requiredPermissions: ["network.egress:pro-api.coinmarketcap.com", "network.egress:api.coingecko.com"],
    sideEffectClass: "network",
    allowedHosts: ["pro-api.coinmarketcap.com", "api.coingecko.com"],
    timeoutMs: DEFAULT_TIMEOUT,
    retryPolicy: "exponential-backoff(max=3, base=1s)",
    idempotencyPolicy: "by provider id",
    healthState: "unconfigured",
    evidenceObligations: ["symbol,name,chain,contract,decimals,logo"],
    degradationPolicy: "fall back to local canonical-mappings.json",
  });

  // Research
  for (const id of ["research.search", "research.multimodal"] as const) {
    reg.register({
      capabilityId: id,
      version: "1.0.0",
      inputSchemaVersion: "1.0.0",
      outputSchemaVersion: "1.0.0",
      providers: ["llm"],
      requiredPermissions: ["network.egress:api.openai.com"],
      sideEffectClass: "network",
      allowedHosts: ["api.openai.com", "api.anthropic.com"],
      timeoutMs: SLOW_TIMEOUT,
      retryPolicy: "exponential-backoff(max=2, base=2s)",
      idempotencyPolicy: "content-hash key",
      healthState: "unconfigured",
      evidenceObligations: ["model version, response content, token usage"],
      degradationPolicy: "fail-closed; circuit breaker",
    });
  }

  // Memory
  for (const id of ["memory.retrieve", "memory.write_candidate"] as const) {
    reg.register({
      capabilityId: id,
      version: "1.0.0",
      inputSchemaVersion: "1.0.0",
      outputSchemaVersion: "1.0.0",
      providers: ["zobiris"],
      requiredPermissions: ["db.read" + (id === "memory.write_candidate" ? ",db.write_candidate" : "")],
      sideEffectClass: id === "memory.write_candidate" ? "write_candidate" : "read",
      allowedHosts: [],
      timeoutMs: 1_000,
      retryPolicy: "no-retry",
      idempotencyPolicy: "candidate id is uuid",
      healthState: "configured",
      evidenceObligations: ["provenance,source_session_id,evaluation_refs"],
      degradationPolicy: "fail-closed on db error",
    });
  }

  // Eval
  reg.register({
    capabilityId: "eval.replay",
    version: "1.0.0",
    inputSchemaVersion: "1.0.0",
    outputSchemaVersion: "1.0.0",
    providers: ["zobiris"],
    requiredPermissions: ["db.read,snapshot.replay"],
    sideEffectClass: "read",
    allowedHosts: [],
    timeoutMs: SLOW_TIMEOUT,
    retryPolicy: "no-retry (deterministic)",
    idempotencyPolicy: "by snapshot id",
    healthState: "configured",
    evidenceObligations: ["policy_version,evaluator_version,source_session_id,result"],
    degradationPolicy: "fail-closed",
  });

  return reg;
}
