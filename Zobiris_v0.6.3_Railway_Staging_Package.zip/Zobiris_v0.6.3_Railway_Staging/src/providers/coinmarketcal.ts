/**
 * CoinMarketCal adapter — fixture-driven only in slice 1.
 *
 * Provides scheduled project catalysts / events with editorially dated
 * metadata. Per docs/DATA_PLANE.md: respect `isEstimated` and render
 * `displayedDate`; do not convert an estimated window into a falsely
 * precise timestamp.
 */

import { z } from "zod";
import {
  type CanonicalAsset,
  type NormalizedObservation,
  type ProviderHealth,
  type FreshnessState,
} from "../domain/index.js";
import {
  type ProviderAdapter,
  type FetchResult,
  AdapterContractError,
  AdapterNormalizationError,
} from "./types.js";
import { loadFixture, makeIdempotencyKey } from "./identity.js";
import { resolveCanonicalIdentity, lookupCanonicalIdentity } from "./canonicalResolve.js";
import { randomUUID } from "node:crypto";

const COINMARKETCAL_RAW_SCHEMA_VERSION = "2.0.0";
const COINMARKETCAL_NORMALIZER_VERSION = "0.4.4";

/**
 * v0.4.4 audit fix (P0-4): CoinMarketCal moved to v2 in 2024. The v2
 * response uses camelCase fields (`date`, `displayedDate`, `isEstimated`,
 * `categories[]`, `sourceUrl`, `snapshotUrl`, `lastVerifiedAt`) and
 * cursor pagination via `meta.cursor`. Legacy snake_case fields are
 * still accepted for fixture compatibility, but new responses use v2.
 *
 * v0.4.4 critical change: event `id` is a STRING in v2 (e.g.
 * `"48291"`), not a number. v0.4.3 incorrectly typed it as `number`,
 * which would reject real current responses.
 */
const cmcEventSchema = z.object({
  // v1 + v2: event identifier. v0.4.4 fix: id is a string in v2.
  id: z.union([z.string(), z.number()]).optional(),
  title: z.string(),
  // v0.4.4 fix: coins[].slug is the safer identity than the symbol.
  // The v2 coin object also exposes id (provider-native) and full
  // name; the slug is the stable key the docs recommend.
  coins: z.array(z.object({
    id: z.union([z.string(), z.number()]).optional(),
    name: z.string().optional(),
    symbol: z.string().optional(),
    slug: z.string().optional(),
  })).optional(),
  // v1 (legacy, still accepted)
  date_event: z.string().optional(),
  display_date: z.string().optional(),
  is_estimated: z.boolean().optional(),
  category: z.string().optional(),
  proof: z.string().optional(),
  source: z.string().optional(),
  // v2 (current documented contract)
  date: z.string().optional(),
  dateEnd: z.string().optional(),
  dateType: z.string().optional(),
  displayedDate: z.string().optional(),
  isEstimated: z.boolean().optional(),
  categories: z.array(z.string()).optional(),
  sourceUrl: z.string().optional(),
  snapshotUrl: z.string().optional(),
  // v0.4.4 fix: this is the source-freshness timestamp, not the
  // event date. The runtime should use it for `sourceTimestamp`.
  lastVerifiedAt: z.string().optional(),
});

// v0.4.4 audit fix (P0-4): the v2 response envelope includes a
// `meta` block with cursor pagination. The next page is fetched by
// passing the `meta.cursor` value back as `page=<cursor>` (or
// `cursor=<cursor>` depending on the API). v1 had no meta block.
// cursor is nullable: when the response is the last page, cursor
// is `null`.
const coinglassCalResponseSchema = z.object({
  data: z.array(cmcEventSchema).optional(),
  meta: z.object({
    cursor: z.union([z.string(), z.number()]).nullable().optional(),
    total: z.number().optional(),
    page: z.number().optional(),
    limit: z.number().optional(),
  }).optional(),
});

export interface CoinMarketCalAdapterConfig {
  baseUrl: string;
  apiKey?: string;
  fixturePath?: string;
  forceFixtures?: boolean;
  liveConfig?: {
    apiKey: string;
    timeoutMs?: number;
  };
}

const COINMARKETCAL_LIVE_TIMEOUT_MS = 10_000;

export class CoinMarketCalAdapter implements ProviderAdapter<CoinMarketCalAdapterConfig> {
  readonly id = "coinmarketcal";
  readonly capabilities = {
    provider: "coinmarketcal",
    displayName: "CoinMarketCal",
    requiresApiKey: true,
    supported: "live" as const,
    dataClasses: ["catalysts" as const],
    notes: "Slice 5+: live path wired. Preserves is_estimated and display_date.",
  };

  private config: CoinMarketCalAdapterConfig = { baseUrl: "https://api.coinmarketcal.com" };
  lastNetworkError?: string;

  configure(config: CoinMarketCalAdapterConfig): void {
    this.config = config;
  }

  validateRaw(raw: unknown, ctx: { endpoint: string }): unknown {
    const parsed = coinglassCalResponseSchema.safeParse(raw);
    if (!parsed.success) {
      // v0.4.4: include the full Zod issue list (not just the
      // truncated summary) so the contract error is debuggable.
      const full = JSON.stringify(parsed.error.issues, null, 2);
      throw new AdapterContractError(this.id, ctx.endpoint, full.slice(0, 2000), undefined);
    }
    return parsed.data;
  }

  normalize(
    raw: unknown,
    ctx: { canonicalAssets: Map<string, CanonicalAsset>; endpoint: string; receivedAt: string; rawSchemaVersion: string },
  ): NormalizedObservation[] {
    const validated = this.validateRaw(raw, ctx);
    const out: NormalizedObservation[] = [];
    const data = (validated as z.infer<typeof coinglassCalResponseSchema>).data ?? [];
    for (const event of data) {
      // v0.4.4 audit fix (P0-4): use the coin's `slug` as the
      // provider-native identity, NOT the symbol. The CoinMarketCal
      // docs explicitly warn that tickers collide; the slug is the
      // stable key the v2 API recommends. Fall back to symbol only
      // when slug is missing.
      for (const coin of event.coins ?? []) {
        const slug = (coin.slug ?? coin.symbol ?? "").toLowerCase();
        if (!slug) continue;
        const symbol = (coin.symbol ?? slug).toUpperCase();
        // v0.4.3 fix: do NOT use event.date as occurredAt for future
        // catalysts. The audit caught that for estimated events,
        // event.date is a deadline/window end, not the time Zobiris
        // learned the information. The runtime should use the
        // retrieval timestamp (`receivedAt`) for occurredAt and the
        // lastVerifiedAt timestamp for sourceTimestamp.
        const providerAssetId = slug;  // slug-first identity
        const existing = lookupCanonicalIdentity(
          { provider: "coinmarketcal", providerAssetId, symbol },
          Array.from(ctx.canonicalAssets.values()),
        );
        const resolved = existing ?? resolveCanonicalIdentity({
          provider: "coinmarketcal",
          providerAssetId,
          symbol,
        });
        const assetId = resolved.canonicalAssetId;
        out.push({
          id: randomUUID(),
          idempotencyKey: makeIdempotencyKey({
            provider: this.id,
            // providerEventId is the event id, NOT the providerAssetId.
            // v0.4.4 fix: stringify to handle v2 string ids.
            providerEventId: String(event.id ?? event.title),
            canonicalAssetId: assetId,
            eventType: "catalyst",
            sourceTimestamp: event.lastVerifiedAt,
          }),
          provider: this.id,
          providerEventId: String(event.id ?? event.title),
          eventType: "catalyst",
          schemaVersion: COINMARKETCAL_RAW_SCHEMA_VERSION,
          canonicalAssetId: assetId,
          // v0.4.3 fix: quarantineState reflects the resolver.
          quarantineState: resolved.mappingStatus,
          identityMatchMethod: resolved.matchMethod,
          // v0.4.4 audit fix (P0-4): sourceTimestamp is the
          // information-retrieved time (`lastVerifiedAt`), NOT the
          // event date. occurredAt is also NOT the event date; it
          // is the retrieval time. The event date itself is stored
          // in the payload as `eventDate` so the UI can render it.
          sourceTimestamp: event.lastVerifiedAt,
          occurredAt: event.lastVerifiedAt ?? ctx.receivedAt,
          receivedAt: ctx.receivedAt,
          retrievedAt: ctx.receivedAt,
          normalizerVersion: COINMARKETCAL_NORMALIZER_VERSION,
          payload: {
            symbol,
            slug,
            coinId: coin.id,
            title: event.title,
            // v0.4.4: the event's `date` is the event-domain field
            // (when the event is scheduled / its window ends), kept
            // in the payload. The runtime does NOT use it as
            // sourceTimestamp or occurredAt.
            eventDate: event.date_event ?? event.date ?? null,
            dateEnd: event.dateEnd ?? null,
            dateType: event.dateType ?? null,
            displayDate: event.display_date ?? event.displayedDate ?? null,
            isEstimated: event.is_estimated ?? event.isEstimated ?? false,
            category: event.category ?? null,
            categories: event.categories ?? null,
            proof: event.proof ?? null,
            source: event.source ?? null,
            sourceUrl: event.sourceUrl ?? null,
            snapshotUrl: event.snapshotUrl ?? null,
            lastVerifiedAt: event.lastVerifiedAt ?? null,
            identityMatchMethod: resolved.matchMethod,
            mappingConfidence: resolved.mappingConfidence,
          },
          epistemicState: (event.is_estimated ?? event.isEstimated) ? "INFERRED" : "KNOWN",
          evidenceConfidence: (event.is_estimated ?? event.isEstimated)
            ? 0.6 * resolved.mappingConfidence
            : 0.85 * resolved.mappingConfidence,
          licenseClass: "display-only",
        });
      }
    }
    return out;
  }

  async fetch(_ctx: { canonicalAssets: Map<string, CanonicalAsset> }): Promise<FetchResult<unknown>[]> {
    const receivedAt = new Date().toISOString();
    const live = this.config.liveConfig;

    if (live && live.apiKey && !this.config.forceFixtures) {
      try {
        const controller = new AbortController();
        const timeoutMs = live.timeoutMs ?? COINMARKETCAL_LIVE_TIMEOUT_MS;
        const timer = setTimeout(() => controller.abort(), timeoutMs);
        // v0.4.4 audit fix (P0-4): CoinMarketCal v2 uses cursor
        // pagination via `meta.cursor`. The first request has no
        // cursor; subsequent pages append `&page=<meta.cursor>`. We
        // currently only fetch the first page (limit=100). The
        // runtime can extend the loop if the response includes a
        // next cursor.
        const url = `${this.config.baseUrl}/v2/events?limit=100`;
        const headers: Record<string, string> = { Accept: "application/json" };
        if (live.apiKey) headers["x-api-key"] = live.apiKey;
        let response: Response;
        try {
          response = await fetch(url, { method: "GET", headers, signal: controller.signal });
        } finally {
          clearTimeout(timer);
        }
        if (response.status === 401) {
          throw new AdapterNormalizationError(this.id, "coinmarketcal http 401: invalid or missing API key");
        }
        if (!response.ok) {
          this.lastNetworkError = `coinmarketcal http ${response.status}`;
          // fall through to fixture
        } else {
          const raw = await response.json();
          return [{ raw, data: raw, receivedAt, endpoint: "events", dataMode: "live" }];
        }
      } catch (e) {
        if (e instanceof AdapterNormalizationError) throw e;
        this.lastNetworkError = e instanceof Error ? e.message : String(e);
        // fall through to fixture
      }
    }

    // v0.4.4 audit fix (P0-6): when live produced no results and we
    // fall through to fixture, mark the dataMode as "fallback" so
    // the runtime can mark the stage degraded. Do NOT silently
    // pretend the data is live.
    if (!this.config.fixturePath) {
      return [{ raw: null, data: null, receivedAt, networkError: this.lastNetworkError }];
    }
    const raw = await loadFixture(this.config.fixturePath);
    const isLiveMode = live && live.apiKey && !this.config.forceFixtures;
    return [{
      raw,
      data: raw,
      receivedAt,
      endpoint: "events",
      dataMode: isLiveMode ? "fallback" : "snapshot",
      fallbackReason: isLiveMode ? `live http ${this.lastNetworkError ?? "no-response"}` : undefined,
    }];
  }

  health(): ProviderHealth {
    let status: ProviderHealth["status"];
    if (this.lastNetworkError && this.config.liveConfig) {
      status = "degraded";
    } else if (this.config.liveConfig && this.config.liveConfig.apiKey) {
      status = "connected";
    } else if (this.config.fixturePath) {
      status = "snapshot";
    } else {
      status = "credentials-needed";
    }
    return {
      provider: this.id,
      status,
      reconnectAttempt: 0,
      lastErrorAt: this.lastNetworkError ? new Date().toISOString() : undefined,
      lastErrorClass: this.lastNetworkError ? "network" : undefined,
      freshness: this.freshness(),
    };
  }

  freshness(): FreshnessState {
    if (this.lastNetworkError && this.config.liveConfig) return "delayed";
    if (this.config.liveConfig && this.config.liveConfig.apiKey) return "live";
    if (this.config.fixturePath) return "unavailable";
    return "unavailable";
  }
}
