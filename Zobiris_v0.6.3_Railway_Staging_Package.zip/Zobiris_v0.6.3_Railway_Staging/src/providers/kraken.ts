/**
 * Kraken public REST adapter.
 *
 * Slice 1 scope: BTC + SOL ticker only. Uses fixtures by default (no network
 * calls in CI). Network path is in slice 3.
 *
 * Kraken response shape (documented):
 *   GET /0/public/Ticker?pair=XBTUSD
 *   { "error": [], "result": { "XXBTZUSD": { "c": ["<price>", ...], "o": "<open>", ... } } }
 */

import { z } from "zod";
import {
  type CanonicalAsset,
  type NormalizedObservation,
  type ProviderHealth,
  type FreshnessState,
} from "../domain/index.js";
import {
  type ProviderAdapter,
  type FetchResult,
  AdapterContractError,
  AdapterNormalizationError,
} from "./types.js";
import { loadFixture, makeIdempotencyKey } from "./identity.js";
import { resolveCanonicalIdentity, lookupCanonicalIdentity } from "./canonicalResolve.js";
import { randomUUID } from "node:crypto";

const KRAKEN_RAW_SCHEMA_VERSION = "1.0.0";
const KRAKEN_NORMALIZER_VERSION = "0.1.0";

/** Kraken ticker inner object — only fields we use. */
const krakenTickerItemSchema = z.object({
  c: z.tuple([z.string(), z.string()]).optional(),    // last trade closed [price, lot]
  o: z.string().optional(),                            // today's opening price
  h: z.tuple([z.string(), z.string()]).optional(),     // 24h high
  l: z.tuple([z.string(), z.string()]).optional(),     // 24h low
  v: z.tuple([z.string(), z.string()]).optional(),     // 24h volume
});

const krakenResponseSchema = z.object({
  error: z.array(z.unknown()).default([]),
  result: z.record(z.string(), krakenTickerItemSchema).optional(),
});

/** Internal: flat ticker row. */
export interface KrakenTickerRow {
  symbol: string;        // canonical symbol (BTC, SOL)
  providerPair: string;  // "XBTUSD", "SOLUSD"
  providerAssetId: string; // "XBT" or "SOL"
  priceUsd: number;
  open24hUsd: number;
  change24hPct: number;
  receivedAt: string;
  sourceTimestamp?: string;
}

export interface KrakenAdapterConfig {
  baseUrl: string;
  /** Map from canonical symbol -> provider pair (e.g. BTC -> XBTUSD). */
  pairMap: Record<string, string>;
  /** Map of Kraken result-key → symbol. Kraken may normalize pair names (e.g. XBTUSD → XXBTZUSD). */
  resultKeyToSymbol?: Record<string, string>;
  /** Optional: load fixtures from these paths. */
  fixturePaths?: Partial<Record<"BTC" | "SOL", string>>;
  /** Force fixture mode (no fetch). */
  forceFixtures?: boolean;
  /** If non-zero, simulate a "stale" response by aging the source timestamp. */
  staleSeconds?: number;
  /** Optional: canonical assets map for id resolution (v0.4.2 audit fix). */
  canonicalAssets?: Map<string, import("../domain/index.js").CanonicalAsset>;
  /** Network timeout in ms (default 10000). */
  timeoutMs?: number;
}

export class KrakenAdapter implements ProviderAdapter<KrakenAdapterConfig> {
  readonly id = "kraken";
  readonly capabilities = {
    provider: "kraken",
    displayName: "Kraken",
    requiresApiKey: false,
    supported: "live" as const,
    dataClasses: ["market" as const],
    notes: "Public REST ticker. Live path shipped in slice 3 (single batch call to /0/public/Ticker); falls back to fixtures when forceFixtures is true.",
  };

  private config: KrakenAdapterConfig = {
    baseUrl: "https://api.kraken.com",
    pairMap: { BTC: "XBTUSD", SOL: "SOLUSD" },
    /** Map of Kraken result-key → symbol (since Kraken may return XXBTZUSD even when XBTUSD was requested). */
    resultKeyToSymbol: { XBTUSD: "BTC", XXBTZUSD: "BTC", SOLUSD: "SOL" } as Record<string, string>,
    timeoutMs: 10_000,
  };

  /** Most recent network error (set when the live fetch fails). */
  lastNetworkError?: string;

  configure(config: KrakenAdapterConfig): void {
    this.config = config;
  }

  validateRaw(raw: unknown, ctx: { endpoint: string }): unknown {
    const parsed = krakenResponseSchema.safeParse(raw);
    if (!parsed.success) {
      throw new AdapterContractError(this.id, ctx.endpoint, parsed.error.message.slice(0, 200), undefined);
    }
    if (parsed.data.error.length > 0) {
      throw new AdapterContractError(this.id, ctx.endpoint, `Kraken error[]: ${JSON.stringify(parsed.data.error).slice(0, 200)}`, undefined);
    }
    if (!parsed.data.result || Object.keys(parsed.data.result).length === 0) {
      throw new AdapterContractError(this.id, ctx.endpoint, "empty result", undefined);
    }
    return parsed.data;
  }

  normalize(
    raw: unknown,
    ctx: { canonicalAssets: Map<string, CanonicalAsset>; endpoint: string; receivedAt: string; rawSchemaVersion: string },
  ): NormalizedObservation[] {
    const validated = this.validateRaw(raw, ctx);
    const out: NormalizedObservation[] = [];
    const pairToSymbol = new Map<string, string>();
    for (const [symbol, pair] of Object.entries(this.config.pairMap)) {
      pairToSymbol.set(pair, symbol);
    }
    if (this.config.resultKeyToSymbol) {
      for (const [key, sym] of Object.entries(this.config.resultKeyToSymbol)) {
        pairToSymbol.set(key, sym);
      }
    }
    const result = (validated as { result: Record<string, z.infer<typeof krakenTickerItemSchema>> }).result;
    for (const [pair, item] of Object.entries(result)) {
      const symbol = pairToSymbol.get(pair);
      if (!symbol) {
        // Unknown pair — quarantine as unmapped.
        out.push(this.makeObservation({
          symbol: "UNKNOWN",
          providerAssetId: pair,
          ticker: undefined,
          priceUsd: null,
          change24hPct: null,
          open24hUsd: null,
          receivedAt: ctx.receivedAt,
          sourceTimestamp: undefined,
          quarantine: "unmapped",
        }));
        continue;
      }
      const c = item.c?.[0];
      const o = item.o;
      if (!c || !o) {
        out.push(this.makeObservation({
          symbol,
          providerAssetId: pair,
          ticker: symbol,
          priceUsd: null,
          change24hPct: null,
          open24hUsd: null,
          receivedAt: ctx.receivedAt,
          sourceTimestamp: undefined,
          quarantine: "unmapped",
        }));
        continue;
      }
      const priceUsd = Number(c);
      const openUsd = Number(o);
      if (!Number.isFinite(priceUsd) || !Number.isFinite(openUsd)) {
        throw new AdapterNormalizationError(this.id, `non-numeric price/open at ${pair}`, raw);
      }
      out.push(this.makeObservation({
        symbol,
        providerAssetId: pair,
        ticker: symbol,
        priceUsd,
        change24hPct: openUsd ? ((priceUsd - openUsd) / openUsd) * 100 : 0,
        open24hUsd: openUsd,
        receivedAt: ctx.receivedAt,
        sourceTimestamp: ctx.receivedAt,
        quarantine: "verified",
      }));
    }
    return out;
  }

  async fetch(_ctx: { canonicalAssets: Map<string, CanonicalAsset> }): Promise<FetchResult<unknown>[]> {
    const out: FetchResult<unknown>[] = [];
    const symbols = Object.keys(this.config.pairMap);
    if (!this.config.forceFixtures) {
      // Live path: batch all pairs into one Kraken call.
      const pairParam = symbols
        .map((s) => this.config.pairMap[s as keyof typeof this.config.pairMap])
        .filter((p): p is string => Boolean(p))
        .join(",");
      if (pairParam.length > 0) {
        try {
          const url = `${this.config.baseUrl}/0/public/Ticker?pair=${encodeURIComponent(pairParam)}`;
          const controller = new AbortController();
          const timeoutMs = this.config.timeoutMs ?? 10_000;
          const timer = setTimeout(() => controller.abort(), timeoutMs);
          let response: Response;
          try {
            response = await fetch(url, { method: "GET", signal: controller.signal });
          } finally {
            clearTimeout(timer);
          }
          if (!response.ok) {
            throw new Error(`kraken http ${response.status}`);
          }
          const raw = await response.json();
          // Kraken returns the response under a JSON object whose `result` is keyed by Kraken's pair name (e.g. "XXBTZUSD").
          // We re-emit one combined payload shaped like the fixture so the existing normalize() path
          // (which expects { error, result: { <pair>: <item> } }) works unchanged.
          const resultObj = (raw as { result?: Record<string, unknown> }).result ?? {};
          const wrapped = { error: [], result: resultObj };
          const receivedAt = new Date().toISOString();
          out.push({ raw: wrapped, data: wrapped, receivedAt, endpoint: "0/public/Ticker", dataMode: "live" });
          return out;
        } catch (e) {
          // Network failure: surface as a single null-result so the runtime can record the failure.
          // The provider circuit breaker (slice 2) will track these.
          const receivedAt = new Date().toISOString();
          this.lastNetworkError = e instanceof Error ? e.message : String(e);
          for (const _symbol of symbols) {
            out.push({ raw: { error: this.lastNetworkError }, data: null, receivedAt, networkError: this.lastNetworkError });
          }
          return out;
        }
      }
    }
    // Fixture path
    for (const symbol of symbols) {
      const fixturePath = this.config.fixturePaths?.[symbol as "BTC" | "SOL"];
      if (!fixturePath) {
        out.push({
          raw: null,
          data: null,
          receivedAt: new Date().toISOString(),
        });
        continue;
      }
      let raw = await loadFixture(fixturePath);
      if (this.config.staleSeconds && this.config.staleSeconds > 0) {
        // Simulate staleness by aging the timestamp in the fixture.
        raw = ageFixtureTimestamps(raw, this.config.staleSeconds);
      }
      const receivedAt = new Date().toISOString();
      const sourceTimestamp = ageIso(receivedAt, this.config.staleSeconds ?? 0);
      out.push({ raw, data: raw, receivedAt, sourceTimestamp, endpoint: "0/public/Ticker", dataMode: "snapshot" });
    }
    return out;
  }

  health(): ProviderHealth {
    let status: ProviderHealth["status"];
    if (this.lastNetworkError) status = "degraded";
    else if (this.config.forceFixtures) status = "snapshot";
    else status = "connected";
    return {
      provider: this.id,
      status,
      reconnectAttempt: 0,
      lastMessageAt: undefined,
      lastEventAt: undefined,
      lastErrorAt: this.lastNetworkError ? new Date().toISOString() : undefined,
      lastErrorClass: this.lastNetworkError ? "network" : undefined,
      freshness: this.freshness(),
    };
  }

  freshness(): FreshnessState {
    if (this.config.staleSeconds && this.config.staleSeconds > 900) return "stale";
    if (this.config.staleSeconds && this.config.staleSeconds > 0) return "delayed";
    return "live";
  }

  private makeObservation(input: {
    symbol: string;
    providerAssetId: string;
    ticker: string | undefined;
    priceUsd: number | null;
    change24hPct: number | null;
    open24hUsd: number | null;
    receivedAt: string;
    sourceTimestamp?: string;
    quarantine: "verified" | "ambiguous" | "unmapped" | "quarantined" | "unmapped";
  }): NormalizedObservation {
    // v0.4.3 audit fix (P0-1, P0-2): use the typed resolver. Kraken's
    // provider-native identity is the trading pair (e.g. "XBTUSD"). The
    // resolver tries the `krakenPair` field first; if the registered
    // canonical asset has a matching pair, the join is verified.
    // Otherwise the resolver falls through to symbol-only (ambiguous).
    let assetId: string | null = null;
    let identityMatchMethod: import("../domain/events.js").NormalizedObservation["identityMatchMethod"] = undefined;
    if (input.quarantine !== "unmapped" && input.symbol !== "UNKNOWN") {
      const canonicalMap = this.config.canonicalAssets ?? new Map();
      // First try the kraken pair (e.g. "XBTUSD") for stronger identity
      const existingPair = lookupCanonicalIdentity(
        { provider: "kraken", providerAssetId: input.providerAssetId, symbol: input.symbol },
        Array.from(canonicalMap.values()),
      );
      const existingSymbol = existingPair ?? lookupCanonicalIdentity(
        { provider: "kraken", providerAssetId: input.symbol, symbol: input.symbol },
        Array.from(canonicalMap.values()),
      );
      const resolved = existingSymbol ?? resolveCanonicalIdentity({
        provider: "kraken",
        providerAssetId: input.providerAssetId,
        symbol: input.symbol,
      });
      assetId = resolved.canonicalAssetId;
      identityMatchMethod = resolved.matchMethod;
    }
    return {
      id: randomUUID(),
      idempotencyKey: makeIdempotencyKey({
        provider: this.id,
        providerEventId: input.providerAssetId,
        canonicalAssetId: assetId,
        eventType: "ticker",
        sourceTimestamp: input.sourceTimestamp,
      }),
      provider: this.id,
      providerEventId: input.providerAssetId,
      eventType: "ticker",
      schemaVersion: KRAKEN_RAW_SCHEMA_VERSION,
      canonicalAssetId: assetId,
      // v0.4.3 fix: quarantineState flows from the resolver, not from
      // the caller's input. The caller passes an upstream "unmapped" /
      // "ambiguous" hint; the resolver's mappingStatus is the canonical
      // truth for the observation.
      quarantineState: input.quarantine,
      identityMatchMethod,
      sourceTimestamp: input.sourceTimestamp,
      occurredAt: input.sourceTimestamp ?? input.receivedAt,
      receivedAt: input.receivedAt,
      retrievedAt: input.receivedAt,
      normalizerVersion: KRAKEN_NORMALIZER_VERSION,
      payload: {
        symbol: input.symbol,
        priceUsd: input.priceUsd,
        change24hPct: input.change24hPct,
        open24hUsd: input.open24hUsd,
        identityMatchMethod,
      },
      epistemicState: input.priceUsd == null ? "UNKNOWN" : "KNOWN",
      evidenceConfidence: input.priceUsd == null ? 0 : 1,
      licenseClass: "display-only",
    };
  }
}

/** Helper: build the internal row from an observation. Used by the engine. */
export function observationToKrakenRow(obs: NormalizedObservation): KrakenTickerRow | null {
  if (obs.eventType !== "ticker") return null;
  const p = obs.payload as Record<string, unknown> | null;
  if (!p) return null;
  const price = p.priceUsd;
  const open = p.open24hUsd;
  const chg = p.change24hPct;
  if (typeof price !== "number" || typeof open !== "number" || typeof chg !== "number") return null;
  return {
    symbol: typeof p.symbol === "string" ? p.symbol : "UNKNOWN",
    providerPair: obs.providerEventId ?? "?",
    providerAssetId: obs.providerEventId ?? "?",
    priceUsd: price,
    open24hUsd: open,
    change24hPct: chg,
    receivedAt: obs.receivedAt,
    sourceTimestamp: obs.sourceTimestamp,
  };
}

function ageIso(iso: string, seconds: number): string {
  if (!seconds) return iso;
  return new Date(new Date(iso).getTime() - seconds * 1000).toISOString();
}

function ageFixtureTimestamps(raw: unknown, _seconds: number): unknown {
  if (!raw || typeof raw !== "object") return raw;
  const r = raw as Record<string, unknown>;
  const result = r.result;
  if (!result || typeof result !== "object") return raw;
  // Kraken doesn't return timestamps; we synthesize one.
  // The caller can override sourceTimestamp in `fetch` after this transform.
  return raw;
}
