/**
 * Observation eligibility policy — the single authoritative gate that
 * decides whether a normalized observation can influence analytical
 * results (scoring, factor confidence, specialists, target weights).
 *
 * v0.4.4 audit fix (P0-1): a normalized observation may be labeled
 * `quarantineState: "ambiguous"` or `quarantineState: "quarantined"`,
 * but the v0.4.3 runtime was still passing those observations into
 * buildEvidenceSummaries(), specialists, and case files. The audit
 * called this out as the biggest remaining defect — Zobiris was
 * correctly discovering "I'm not sure this is the right asset" and
 * then effectively turning that into "verified" downstream.
 *
 * The invariant this module enforces:
 *   "Ambiguous/quarantined evidence can be DISPLAYED for investigation,
 *    but it cannot affect scoring, factor confidence, specialist
 *    opinion, ranks, or target weights."
 *
 * Persisted observations are loaded with their quarantineState intact
 * (the audit caught a hard-coded `quarantineState: "verified"` in
 * server.ts). The eligibility check is the gate, not the field value
 * itself — the field records provenance; this function decides use.
 */

import type { NormalizedObservation } from "../domain/index.js";

/**
 * Eligibility states:
 *   - "eligible"               : observation can drive scoring, coverage, specialists
 *   - "display_only_ambiguous" : identity is ambiguous; observation is shown but excluded
 *   - "quarantined"            : identity is quarantined; observation is shown but excluded
 *   - "rejected"               : observation is unparseable / unknown identity; not shown
 */
export type EvidenceEligibility =
  | "eligible"
  | "display_only_ambiguous"
  | "quarantined"
  | "rejected";

/**
 * Decide whether a normalized observation is eligible to influence
 * scoring, factor confidence, specialist opinion, ranks, and weights.
 *
 * Quarantine state drives the result:
 *   - verified → eligible (only if a strong identity match was used)
 *   - ambiguous → display_only_ambiguous
 *   - unmapped   → display_only_ambiguous (no canonical anchor at all)
 *   - quarantined → quarantined
 *
 * The identityMatchMethod is also inspected: a "symbol-only" match
 * is treated as ambiguous even if the observation's quarantineState
 * was hand-set to "verified" elsewhere.
 *
 * "rejected" is reserved for observations that lack a usable canonical
 * id and have no symbol in the payload (i.e. they cannot be attributed
 * to any tracked asset at all).
 */
export function isObservationEligibleForAnalysis(o: NormalizedObservation): EvidenceEligibility {
  if (!o.canonicalAssetId) {
    // No canonical anchor — cannot be attributed to any tracked asset.
    return "rejected";
  }
  // Hard quarantine states.
  if (o.quarantineState === "quarantined") return "quarantined";
  // ambiguous identity, including symbol-only joins, are display-only.
  if (o.quarantineState === "ambiguous") return "display_only_ambiguous";
  if (o.quarantineState === "unmapped") return "display_only_ambiguous";
  // Even if quarantineState === "verified", a symbol-only identity
  // match is not analytically safe. The audit caught that symbol-only
  // joins were being labeled verified by older code paths.
  if (o.identityMatchMethod === "symbol-only") return "display_only_ambiguous";
  if (o.identityMatchMethod === "fallback") return "display_only_ambiguous";
  // Fallback payloads are useful for display and audit continuity, but a
  // failed live request must never become new analytical signal.
  if (o.dataMode === "fallback") return "display_only_ambiguous";
  // Otherwise the observation is verified through a strong identity
  // path (id, provider-id, provider-slug, contract, chain+symbol) and
  // can drive scoring.
  return "eligible";
}

/** A short convenience helper: is this observation analytically safe? */
export function isAnalyticallyEligible(o: NormalizedObservation): boolean {
  return isObservationEligibleForAnalysis(o) === "eligible";
}

/**
 * Filter a list of observations to only those eligible for analysis.
 * Specialists and buildEvidenceSummaries() must use this filter.
 */
export function eligibleObservations(observations: NormalizedObservation[]): NormalizedObservation[] {
  return observations.filter(isAnalyticallyEligible);
}

/**
 * Split observations into the four buckets. The runtime displays all
 * four in the case file but only the eligible list drives scoring.
 */
export function partitionObservationsByEligibility(
  observations: NormalizedObservation[],
): {
  eligible: NormalizedObservation[];
  displayOnlyAmbiguous: NormalizedObservation[];
  quarantined: NormalizedObservation[];
  rejected: NormalizedObservation[];
} {
  const out = {
    eligible: [] as NormalizedObservation[],
    displayOnlyAmbiguous: [] as NormalizedObservation[],
    quarantined: [] as NormalizedObservation[],
    rejected: [] as NormalizedObservation[],
  };
  for (const o of observations) {
    const e = isObservationEligibleForAnalysis(o);
    if (e === "eligible") out.eligible.push(o);
    else if (e === "display_only_ambiguous") out.displayOnlyAmbiguous.push(o);
    else if (e === "quarantined") out.quarantined.push(o);
    else out.rejected.push(o);
  }
  return out;
}
