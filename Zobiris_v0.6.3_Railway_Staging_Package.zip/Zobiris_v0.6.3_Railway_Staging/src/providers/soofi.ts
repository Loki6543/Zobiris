/**
 * Soofi S provider adapter.
 *
 * Soofi S 30B-A3B is Germany's sovereign open-source LLM (KI Bundesverband,
 * Deutsche Telekom Industrial AI Cloud, Munich). The consortium ships the
 * weights on Hugging Face plus a Docker image that exposes an OpenAI-
 * compatible /v1/chat/completions endpoint on port 8081. As of August 2026
 * the HF repo is gated, but the OpenAI-compatible contract is the supported
 * production path.
 *
 * This adapter targets that OpenAI-compatible surface, which means it also
 * works against:
 *   - Soofi-S-Instruct-Preview via the official Docker image
 *   - vLLM serving any Soofi-S variant
 *   - Ollama with a Soofi modelfile
 *   - llama.cpp with LiteLLM gateway
 *   - Any other OpenAI-compatible model (drop-in replacement for baseUrl)
 *
 * Failure semantics (per Zobiris contract, uniform across all providers):
 *   - 401 -> AdapterNormalizationError (hard credential failure, do NOT
 *     fall through to fixture)
 *   - 5xx / network drop / AbortController timeout -> data: null +
 *     lastNetworkError recorded, fixture fallback if configured
 *   - health() reports 'connected' / 'degraded' / 'snapshot' / 'credentials-needed'
 *     based on mode + last network outcome
 *
 * Data shape:
 *   - One NormalizedObservation per chat-completion request
 *   - eventType: "llm_completion"
 *   - payload: { prompt, model, response, usage, finishReason }
 *   - canonicalAssetId: set when the prompt targets a specific asset
 *   - epistemicState: KNOWN when finishReason === "stop" else INFERRED
 *
 * Slice 5+ v0.4.x addendum: this adapter extends the provider data plane
 * with the LLM class, allowing the same orchestrator, scoring, and case
 * file pipeline to consume LLM-derived signals.
 */

import { z } from "zod";
import { randomUUID } from "node:crypto";
import {
  type CanonicalAsset,
  type NormalizedObservation,
  type ProviderHealth,
  type FreshnessState,
} from "../domain/index.js";
import {
  type ProviderAdapter,
  type FetchResult,
  AdapterContractError,
  AdapterNormalizationError,
} from "./types.js";
import { loadFixture, makeIdempotencyKey } from "./identity.js";
import { resolveCanonicalIdentity, lookupCanonicalIdentity } from "./canonicalResolve.js";

const SOOFI_RAW_SCHEMA_VERSION = "1.0.0";
const SOOFI_NORMALIZER_VERSION = "0.1.0";
const SOOFI_LIVE_TIMEOUT_MS = 60_000;

// OpenAI-compatible chat-completion response schema (subset).
const soofiUsageSchema = z
  .object({
    prompt_tokens: z.number().int().nonnegative().optional(),
    completion_tokens: z.number().int().nonnegative().optional(),
    total_tokens: z.number().int().nonnegative().optional(),
  })
  .optional();

const soofiChoiceSchema = z.object({
  index: z.number().int().nonnegative(),
  message: z.object({
    role: z.string().min(1),
    content: z.string(),
  }),
  finish_reason: z.string().nullable().optional(),
});

const soofiChatResponseSchema = z.object({
  id: z.string().min(1),
  object: z.string().optional(),
  created: z.number().int().optional(),
  model: z.string().min(1),
  choices: z.array(soofiChoiceSchema).min(1),
  usage: soofiUsageSchema,
});

/** A single prompt/asset pair the caller wants the model to respond to. */
export interface SoofiPrompt {
  /** Stable id for idempotency; e.g. canonical asset id + specialist id + prompt template hash. */
  promptId: string;
  /** Symbol of the asset this prompt is about, if any. Used to set canonicalAssetId. */
  symbol?: string;
  /** The full chat-completion messages array (system + user). */
  messages: Array<{ role: "system" | "user" | "assistant"; content: string }>;
  /** Optional sampling parameters; default to 0.2 temperature, 512 max_tokens. */
  temperature?: number;
  maxTokens?: number;
  /** Free-form tag the caller can use to identify the use case (e.g. "specialist.reconciler"). */
  tag?: string;
}

export interface SoofiAdapterConfig {
  /** OpenAI-compatible base URL. Default: http://localhost:8081 (Soofi Docker image). */
  baseUrl: string;
  /** API key. Empty string is allowed by some local servers; pass undefined to skip. */
  apiKey?: string;
  /** Model name to request. Default: "soofi-s-instruct-preview". */
  model: string;
  /** Default timeout in ms. Default: 60_000. */
  timeoutMs?: number;
  /** When true, never hit the network. */
  forceFixtures?: boolean;
  /** Path to a fixture file containing an array of pre-baked chat completions (one per prompt). */
  fixturePath?: string;
  /** Live config block. When set AND forceFixtures===false, fetch() hits the live API. */
  liveConfig?: {
    apiKey?: string;
    timeoutMs?: number;
  };
}

export class SoofiAdapter implements ProviderAdapter<SoofiAdapterConfig> {
  readonly id = "soofi";
  readonly capabilities = {
    provider: "soofi",
    displayName: "Soofi S (German Sovereign LLM)",
    requiresApiKey: false,
    supported: "live" as const,
    dataClasses: ["llm" as const],
    notes:
      "OpenAI-compatible /v1/chat/completions adapter for Soofi S 30B-A3B. " +
      "Default baseUrl targets the official Soofi Docker image (port 8081). " +
      "Hit a local vLLM/Ollama/llama.cpp/LiteLLM gateway by overriding baseUrl.",
  };

  private config: SoofiAdapterConfig = {
    baseUrl: "http://localhost:8081",
    model: "soofi-s-instruct-preview",
  };
  /** Most recent network error from the live fetch (used by health()). */
  lastNetworkError?: string;

  configure(config: SoofiAdapterConfig): void {
    this.config = config;
  }

  /**
   * Validate a single raw chat-completion response. Throws AdapterContractError
   * on schema mismatch.
   */
  validateRaw(raw: unknown, ctx: { endpoint: string }): unknown {
    const parsed = soofiChatResponseSchema.safeParse(raw);
    if (!parsed.success) {
      throw new AdapterContractError(this.id, ctx.endpoint, parsed.error.message.slice(0, 200), raw);
    }
    return parsed.data;
  }

  /**
   * Normalize a chat-completion response plus the originating prompts into
   * NormalizedObservations. One observation per prompt. The response is
   * matched to prompts positionally (the i-th response corresponds to the
   * i-th prompt in the original batch).
   */
  normalize(
    rawResponses: unknown,
    ctx: {
      canonicalAssets: Map<string, CanonicalAsset>;
      endpoint: string;
      receivedAt: string;
      rawSchemaVersion: string;
      /** Prompts the caller sent — required to attribute responses back to assets. */
      prompts?: SoofiPrompt[];
    },
  ): NormalizedObservation[] {
    // Fixture mode: rawResponses may be a bare array (one entry per prompt).
    if (Array.isArray(rawResponses)) {
      const prompts = ctx.prompts ?? [];
      const out: NormalizedObservation[] = [];
      for (let i = 0; i < rawResponses.length; i++) {
        const r = rawResponses[i];
        const prompt = prompts[i];
        out.push(this.toObservation(r, prompt, ctx));
      }
      return out;
    }

    // Live mode: single response (we send one prompt at a time in fetch()).
    const validated = this.validateRaw(rawResponses, ctx);
    const prompt = ctx.prompts?.[0];
    return [this.toObservation(validated, prompt, ctx)];
  }

  private toObservation(
    raw: unknown,
    prompt: SoofiPrompt | undefined,
    ctx: {
      canonicalAssets: Map<string, CanonicalAsset>;
      endpoint: string;
      receivedAt: string;
      rawSchemaVersion: string;
    },
  ): NormalizedObservation {
    const parsed = this.validateRaw(raw, ctx) as z.infer<typeof soofiChatResponseSchema>;
    const choice = parsed.choices[0]!;
    const finishReason = choice.finish_reason ?? null;
    const content = choice.message.content;
    // ctx is referenced through validateRaw above; keep param to make
    // intent explicit (overriders may want to inspect endpoint / receivedAt).
    void ctx;

    let canonicalAssetId: string | null = null;
    let identityMatchMethod: import("../domain/events.js").NormalizedObservation["identityMatchMethod"] = undefined;
    let resolverConfidence = 0;
    if (prompt?.symbol) {
      const upper = prompt.symbol.toUpperCase();
      // v0.4.3 audit fix (P0-1, P0-2): use the typed resolver. Soofi is
      // a symbol-only provider (the LLM has no native asset id), so
      // the lookup will always fall through to symbol-only. The
      // resulting `mappingStatus: "ambiguous"` and `mappingConfidence:
      // 0.7` flow into the observation's quarantineState and
      // evidenceConfidence, so a Soofi LLM completion cannot masquerade
      // as verified analytical evidence.
      const existing = lookupCanonicalIdentity(
        { provider: "soofi", providerAssetId: upper, symbol: upper },
        Array.from(ctx.canonicalAssets.values()),
      );
      const resolved = existing ?? resolveCanonicalIdentity({
        provider: "soofi",
        providerAssetId: upper,
        symbol: upper,
      });
      canonicalAssetId = resolved.canonicalAssetId;
      identityMatchMethod = resolved.matchMethod;
      resolverConfidence = resolved.mappingConfidence;
    }

    const providerEventId = `${parsed.id}:${choice.index}`;
    return {
      id: randomUUID(),
      idempotencyKey: makeIdempotencyKey({
        provider: this.id,
        providerEventId,
        canonicalAssetId: canonicalAssetId ?? "n/a",
        eventType: "llm_completion",
        sourceTimestamp: parsed.created ? new Date(parsed.created * 1000).toISOString() : undefined,
      }),
      provider: this.id,
      providerEventId,
      eventType: "llm_completion",
      schemaVersion: SOOFI_RAW_SCHEMA_VERSION,
      canonicalAssetId: canonicalAssetId ?? "n/a",
      // v0.4.3 fix: quarantineState reflects the resolver. A
      // symbol-only join (the only kind Soofi can produce) is
      // `ambiguous`, not `verified`. The LLM completion remains
      // analytically useful but cannot masquerade as verified.
      quarantineState: canonicalAssetId ? "ambiguous" : "quarantined",
      identityMatchMethod,
      sourceTimestamp: parsed.created ? new Date(parsed.created * 1000).toISOString() : undefined,
      occurredAt: parsed.created ? new Date(parsed.created * 1000).toISOString() : ctx.receivedAt,
      receivedAt: ctx.receivedAt,
      retrievedAt: ctx.receivedAt,
      normalizerVersion: SOOFI_NORMALIZER_VERSION,
      payload: {
        promptId: prompt?.promptId ?? null,
        symbol: prompt?.symbol ?? null,
        tag: prompt?.tag ?? null,
        model: parsed.model,
        response: content,
        finishReason,
        usage: parsed.usage ?? null,
        promptMessages: prompt?.messages ?? null,
        identityMatchMethod,
        mappingConfidence: resolverConfidence,
      },
      epistemicState: finishReason === "stop" ? "KNOWN" : "INFERRED",
      // v0.4.3 fix: bound evidenceConfidence by the resolver's
      // mapping confidence. A Soofi symbol-only join (0.7) caps the
      // claim at 0.7 even when the model finished cleanly.
      evidenceConfidence: (finishReason === "stop" ? 0.9 : 0.6) * Math.max(resolverConfidence, 0.1),
      licenseClass: "internal-only",
    };
  }

  /**
   * Send a batch of prompts to the model. Live mode hits /v1/chat/completions
   * per prompt (the OpenAI-compatible surface accepts a single chat request,
   * not a batch). Fixture mode reads from a JSON file.
   */
  async fetch(
    _ctx: { canonicalAssets: Map<string, CanonicalAsset> },
    prompts: SoofiPrompt[] = [],
  ): Promise<FetchResult<unknown>[]> {
    const receivedAt = new Date().toISOString();
    const live = this.config.liveConfig;
    const useLive = !!(live && !this.config.forceFixtures);

    if (!useLive) {
      if (!this.config.fixturePath) {
        return [{ raw: null, data: null, receivedAt }];
      }
      const raw = await loadFixture(this.config.fixturePath);
      // Fixture file may be either a single response or an array of responses.
      return [{ raw, data: raw, receivedAt }];
    }

    // Live path
    const out: FetchResult<unknown>[] = [];
    const headers: Record<string, string> = {
      "Content-Type": "application/json",
    };
    if (live?.apiKey) headers["Authorization"] = `Bearer ${live.apiKey}`;
    const timeoutMs = live?.timeoutMs ?? this.config.timeoutMs ?? SOOFI_LIVE_TIMEOUT_MS;
    const model = this.config.model;
    const baseUrl = this.config.baseUrl.replace(/\/$/, "");

    for (const prompt of prompts) {
      try {
        const controller = new AbortController();
        const timer = setTimeout(() => controller.abort(), timeoutMs);
        let response: Response;
        try {
          response = await fetch(`${baseUrl}/v1/chat/completions`, {
            method: "POST",
            headers,
            body: JSON.stringify({
              model,
              messages: prompt.messages,
              temperature: prompt.temperature ?? 0.2,
              max_tokens: prompt.maxTokens ?? 512,
            }),
            signal: controller.signal,
          });
        } finally {
          clearTimeout(timer);
        }
        if (response.status === 401) {
          throw new AdapterNormalizationError(this.id, "soofi http 401: invalid or missing API key");
        }
        if (!response.ok) {
          this.lastNetworkError = `soofi http ${response.status}`;
          continue; // skip this prompt, do NOT abort the whole batch
        }
        const raw = (await response.json()) as unknown;
        out.push({ raw, data: raw, receivedAt });
      } catch (e) {
        if (e instanceof AdapterNormalizationError) throw e;
        this.lastNetworkError = e instanceof Error ? e.message : String(e);
        // Continue with the next prompt; the runtime will record a circuit-breaker failure.
      }
    }

    if (out.length === 0) {
      // All prompts failed — return a single empty result with the error.
      out.push({ raw: null, data: null, receivedAt, networkError: this.lastNetworkError });
    }
    return out;
  }

  health(): ProviderHealth {
    let status: ProviderHealth["status"];
    const live = this.config.liveConfig;
    if (this.lastNetworkError && live && !this.config.forceFixtures) {
      status = "degraded";
    } else if (live && !this.config.forceFixtures) {
      status = "connected";
    } else if (this.config.fixturePath) {
      status = "snapshot";
    } else {
      status = "credentials-needed";
    }
    return {
      provider: this.id,
      status,
      reconnectAttempt: 0,
      lastErrorAt: this.lastNetworkError ? new Date().toISOString() : undefined,
      lastErrorClass: this.lastNetworkError ? "network" : undefined,
      freshness: this.freshness(),
    };
  }

  freshness(): FreshnessState {
    const live = this.config.liveConfig;
    if (this.lastNetworkError && live && !this.config.forceFixtures) return "delayed";
    if (live && !this.config.forceFixtures) return "live";
    if (this.config.fixturePath) return "unavailable";
    return "unavailable";
  }
}
