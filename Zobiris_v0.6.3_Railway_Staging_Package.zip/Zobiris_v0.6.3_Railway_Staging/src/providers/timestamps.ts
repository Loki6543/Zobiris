/**
 * v0.4.4 audit fix (P0-3): shared timestamp normalizer that
 * detects seconds vs milliseconds and produces an ISO 8601 string.
 *
 * CoinGlass v4 returns `time` in milliseconds; v0.4.3 multiplied by
 * 1000 (treating it as seconds), producing far-future timestamps.
 * CoinMarketCal v2 returns `lastVerifiedAt` as an ISO string.
 * Kraken returns unix seconds.
 * CMC returns ISO strings.
 *
 * This helper:
 *   - if the value is a 13+ digit number, treats it as milliseconds;
 *   - if the value is a 10-12 digit number, treats it as seconds;
 *   - if the value is a string, tries Date.parse and returns ISO or
 *     passes through.
 *   - returns undefined for null/undefined/empty.
 */
export function normalizeTimestampToIso(v: unknown): string | undefined {
  if (v == null) return undefined;
  if (typeof v === "number") {
    if (!isFinite(v) || v <= 0) return undefined;
    // Heuristic: > 10^12 = ms (year 2001+ in seconds; year 33658 in ms)
    if (v > 1e12) return new Date(v).toISOString();
    // 10^9 to 10^12 = seconds (year 2001 to 33658)
    if (v > 1e9) return new Date(v * 1000).toISOString();
    // Treat anything smaller as seconds too (defensive).
    return new Date(v * 1000).toISOString();
  }
  if (typeof v === "string") {
    const trimmed = v.trim();
    if (trimmed.length === 0) return undefined;
    // Numeric string: same heuristic as above.
    if (/^\d+$/.test(trimmed)) return normalizeTimestampToIso(Number(trimmed));
    // ISO-like string: try Date.parse, fall back to passing through.
    const t = Date.parse(trimmed);
    if (!isNaN(t)) return new Date(t).toISOString();
    return trimmed;  // pass through; downstream consumers can decide
  }
  return undefined;
}
