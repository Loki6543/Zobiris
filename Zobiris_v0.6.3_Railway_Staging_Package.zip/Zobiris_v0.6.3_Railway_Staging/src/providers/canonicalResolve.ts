/**
 * Canonical identity resolver — the single authoritative source of canonical
 * asset identity in the system.
 *
 * v0.4.3 audit fix (P0-1): ticker-only joins are now EXPLICITLY AMBIGUOUS,
 * never "verified". The product contract is "ticker-only joins are forbidden;
 * ambiguous/unmapped identity must quarantine." This file enforces that
 * invariant: every caller that lands on a symbol-only match sees
 * `mappingStatus: "ambiguous"` and `mappingConfidence <= 0.7`. Verified
 * identity requires either a canonical-id match, a chain+contract match, an
 * exact provider-native asset id, or (for the providers that guarantee slug
 * uniqueness) an exact provider slug. Symbol-only matches survive only as a
 * join helper for UI discovery and are quarantined before they can reach the
 * scoring layer.
 *
 * v0.4.3 audit fix (P0-1, P0-2): `providerIds` is now an explicit, typed
 * object with named provider fields. v0.4.2 stored a flat record, which
 * meant CMC numeric ids and CMC slugs collided, and providers like CoinGlass
 * (which uses `exchange:symbol`) had to be awkwardly stringified into
 * `providerIds.coinglass`. The new shape forces callers to declare which
 * provider-native identity field they have.
 *
 * Contract:
 *   - Input: CanonicalIdentityInput with explicit provider field
 *   - Output: { canonicalAssetId, mappingStatus, mappingConfidence } | null
 *   - Same inputs always yield the same id (deterministic SHA-256).
 *   - Pseudo-ids (`sym:BTC`) never appear in the normalized evidence boundary.
 *   - Ticker-only joins: `mappingStatus: "ambiguous"`, `mappingConfidence <= 0.7`.
 */

import { createHash } from "node:crypto";

function normalizeContractAddress(chainId: string | number, address: string): string {
  const chain = String(chainId).toLowerCase();
  return chain === "solana" ? address.trim() : address.trim().toLowerCase();
}

/** Stable identity sources, in priority order. */
export interface CanonicalIdentityInput {
  /** Provider name (e.g. "cmc", "coingecko", "kraken", "coinglass"). */
  provider: string;
  /** Provider-native asset id, e.g. CMC slug "bitcoin" or CMC numeric id "1". */
  providerAssetId: string;
  /** Ticker symbol, used as a tie-breaker / fallback. NEVER the primary key. */
  symbol?: string;
  /** Optional chain id (1=ETH mainnet, 43114=AVAX, etc.). */
  chainId?: string | number | null;
  /** Optional contract address (0x... for EVM, base58 for Solana). */
  contractAddress?: string | null;
}

/**
 * Provider-native identity fields, declared per provider.
 * A provider-asset-id is "exact" when it is guaranteed unique within the
 * provider's namespace (e.g. CMC numeric id, CMC slug, CoinMarketCal id).
 * v0.4.3 fix: this is the typed contract; v0.4.2 had an untyped record.
 */
export interface ProviderIds {
  cmcSlug?: string;            // "bitcoin"
  cmcNumericId?: string;       // "1" (as string for stable hashing)
  coingeckoId?: string;        // "bitcoin"
  krakenPair?: string;         // "XBTUSD"
  lunarcrushId?: string;       // LunarCrush coin id (provider-native)
  coinmarketcalId?: string;    // CoinMarketCal coin id (provider-native)
  coinglassId?: string;        // CoinGlass-specific identifier, if any
  // Future: more providers added by extending this object.
  [k: string]: string | undefined;
}

export interface ResolvedIdentity {
  canonicalAssetId: string;
  mappingStatus: "verified" | "ambiguous" | "unmapped" | "quarantined";
  mappingConfidence: number;
  /** The identity key used to derive the canonical id (for debugging). */
  identityKey: string;
  /** How the match was made (for observability). */
  matchMethod:
    | "id"
    | "provider-id"
    | "provider-slug"
    | "contract"
    | "chain+symbol"
    | "symbol-only"
    | "fallback";
}

const PREFIX = "cn";

/**
 * Build the stable identity key for a given input. The key is the most
 * specific available signal: contract > chainId+symbol > provider+providerAssetId
 * > symbol alone.
 */
export function buildIdentityKey(input: CanonicalIdentityInput): string {
  if (input.contractAddress && input.chainId != null) {
    return `chain:${input.chainId}:contract:${normalizeContractAddress(input.chainId, input.contractAddress)}`;
  }
  if (input.providerAssetId && input.provider && input.provider !== "_by_id" && input.provider !== "fallback") {
    return `provider:${input.provider}:${input.providerAssetId}`;
  }
  if (input.symbol) {
    return `symbol:${input.symbol.toUpperCase()}`;
  }
  return `unknown:${input.provider}`;
}

/**
 * Derive a stable canonical asset id from an identity key. Uses SHA-256 of
 * the key (deterministic, collision-resistant) prefixed with a recognisable
 * short token. The id is stable across processes, hosts, and time.
 */
export function canonicalIdFromKey(identityKey: string): string {
  const h = createHash("sha256").update(identityKey).digest("hex");
  // 16 hex chars is plenty (2^64 combinations) and keeps ids short.
  return `${PREFIX}-${h.slice(0, 16)}`;
}

/**
 * Resolve a canonical identity for a single input. The result carries the
 * same id for the same input forever, so two refreshes of BTC always yield
 * the same canonical id.
 *
 * v0.4.3 fix: this function now also returns `matchMethod` so callers can
 * see how the id was derived, and confidence is bounded by match method
 * (chain+contract: 0.99, provider-id: 0.85, symbol-only: 0.5).
 */
export function resolveCanonicalIdentity(input: CanonicalIdentityInput): ResolvedIdentity {
  const key = buildIdentityKey(input);
  const id = canonicalIdFromKey(key);
  let confidence: number;
  let matchMethod: ResolvedIdentity["matchMethod"];
  if (input.contractAddress && input.chainId != null) {
    confidence = 0.99;
    matchMethod = "contract";
  } else if (input.providerAssetId && input.provider && input.provider !== "fallback") {
    confidence = 0.85;
    matchMethod = "provider-id";
  } else if (input.symbol) {
    confidence = 0.5;
    matchMethod = "symbol-only";
  } else {
    confidence = 0;
    matchMethod = "fallback";
  }
  return {
    canonicalAssetId: id,
    mappingStatus: confidence >= 0.8 ? "verified" : confidence >= 0.5 ? "ambiguous" : "quarantined",
    mappingConfidence: confidence,
    identityKey: key,
    matchMethod,
  };
}

/**
 * Look up an existing canonical asset by its most-specific identity signal.
 * Used when a provider emits a known provider-id (e.g. CMC slug "bitcoin")
 * and we want to find the canonical row that was first registered.
 *
 * v0.4.3 audit fix (P0-1): lookup order is now:
 *   1. canonical id (most specific; runtime short-circuit)
 *   2. chain + contract
 *   3. exact provider-native asset id
 *   4. exact provider slug (when the provider guarantees slug uniqueness)
 *   5. chain + symbol (only when chain is known)
 *   6. symbol-only -> `ambiguous` (mappingConfidence 0.7), NEVER `verified`.
 *      A symbol-only join is useful for UI discovery but it must not cross
 *      the normalized evidence boundary as verified analytical evidence.
 *
 * Returns null if no canonical asset in `assets` matches the input. Caller
 * should fall back to resolveCanonicalIdentity() in that case.
 */
export function lookupCanonicalIdentity(
  input: CanonicalIdentityInput,
  assets: Array<{
    id: string;
    providerIds: ProviderIds;
    symbol: string;
    chainId?: string;
    contractAddress?: string;
  }>,
): ResolvedIdentity | null {
  // 1. By id (most specific — used by the runtime to short-circuit)
  if (input.providerAssetId && input.provider === "_by_id") {
    for (const a of assets) {
      if (a.id === input.providerAssetId) {
        return {
          canonicalAssetId: a.id,
          mappingStatus: "verified",
          mappingConfidence: 1.0,
          identityKey: `match:id:${a.id}`,
          matchMethod: "id",
        };
      }
    }
    return null;
  }
  // 2. chain + contract match (strongest cross-source signal)
  if (input.contractAddress && input.chainId != null) {
    for (const a of assets) {
      if (
        a.contractAddress &&
        normalizeContractAddress(input.chainId, a.contractAddress) ===
          normalizeContractAddress(input.chainId, input.contractAddress) &&
        a.chainId === String(input.chainId)
      ) {
        return {
          canonicalAssetId: a.id,
          mappingStatus: "verified",
          mappingConfidence: 1.0,
          identityKey: `match:contract:${input.chainId}:${normalizeContractAddress(input.chainId, input.contractAddress)}`,
          matchMethod: "contract",
        };
      }
    }
  }
  // 3. Exact provider-native asset id (CMC numeric id, CoinMarketCal id, etc.)
  // The provider field tells us which key in providerIds to look at.
  if (input.providerAssetId && input.provider) {
    const providerKey = providerIdFieldFor(input.provider);
    if (providerKey) {
      for (const a of assets) {
        if (a.providerIds?.[providerKey] === input.providerAssetId) {
          return {
            canonicalAssetId: a.id,
            mappingStatus: "verified",
            mappingConfidence: 1.0,
            identityKey: `match:provider-id:${input.provider}:${input.providerAssetId}`,
            matchMethod: "provider-id",
          };
        }
      }
    }
  }
  // 4. Exact provider slug (when the provider guarantees slug uniqueness).
  // For CMC, the slug ("bitcoin") is also a provider asset id, so this is
  // usually redundant with step 3; but for some providers (CoinGecko) the
  // slug and id are stored separately. We look up by slug, then promote to
  // verified only if the slug field is set in the canonical.
  if (input.providerAssetId && input.provider) {
    const slugKey = providerSlugFieldFor(input.provider);
    if (slugKey) {
      for (const a of assets) {
        if (a.providerIds?.[slugKey] === input.providerAssetId) {
          return {
            canonicalAssetId: a.id,
            mappingStatus: "verified",
            mappingConfidence: 0.95,
            identityKey: `match:provider-slug:${input.provider}:${input.providerAssetId}`,
            matchMethod: "provider-slug",
          };
        }
      }
    }
  }
  // 5. chain + symbol (only when chain is known)
  if (input.symbol && input.chainId != null) {
    for (const a of assets) {
      if (a.symbol === input.symbol.toUpperCase() && a.chainId === String(input.chainId)) {
        return {
          canonicalAssetId: a.id,
          mappingStatus: "verified",
          mappingConfidence: 0.95,
          identityKey: `match:chain:${input.chainId}:symbol:${input.symbol.toUpperCase()}`,
          matchMethod: "chain+symbol",
        };
      }
    }
  }
  // 6. Symbol-only fallback. v0.4.3 audit fix: this is "ambiguous", NOT
  // "verified", and confidence is capped at 0.7. A symbol-only join is
  // useful for UI discovery but must NOT cross the normalized evidence
  // boundary as verified analytical evidence.
  if (input.symbol) {
    for (const a of assets) {
      if (a.symbol === input.symbol.toUpperCase()) {
        return {
          canonicalAssetId: a.id,
          // v0.4.3 fix: was "verified" + 0.9; now "ambiguous" + 0.7.
          // Per the audit: "ticker-only joins are forbidden; ambiguous
          // identity must quarantine." This join still returns a match
          // so the runtime can find the asset, but downstream consumers
          // (scoring, specialists) must treat the result as quarantined.
          mappingStatus: "ambiguous",
          mappingConfidence: 0.7,
          identityKey: `match:symbol:${a.symbol}`,
          matchMethod: "symbol-only",
        };
      }
    }
  }
  return null;
}

/**
 * The providerId field name for a given provider. v0.4.3: this is the
 * field that stores the provider's *native* asset id, which is what an
 * adapter passes in `input.providerAssetId`.
 */
function providerIdFieldFor(provider: string): keyof ProviderIds | null {
  switch (provider) {
    case "cmc":
      // The CMC normalizer passes the numeric id as providerAssetId.
      return "cmcNumericId";
    case "coingecko":
      return "coingeckoId";
    case "kraken":
      return "krakenPair";
    case "lunarcrush":
      return "lunarcrushId";
    case "coinmarketcal":
      // The CoinMarketCal normalizer passes the event/coin id.
      return "coinmarketcalId";
    case "coinglass":
      return "coinglassId";
    default:
      return null;
  }
}

/**
 * The providerSlug field name for a given provider. This is the field that
 * stores the provider's *slug*, which is guaranteed unique within the
 * provider's namespace. For CMC, the slug ("bitcoin") and the numeric id
 * ("1") are both stable, so we have separate fields.
 */
function providerSlugFieldFor(provider: string): keyof ProviderIds | null {
  switch (provider) {
    case "cmc":
      return "cmcSlug";
    default:
      // Most providers do not distinguish slug from id; treat the
      // provider-id field as authoritative.
      return providerIdFieldFor(provider);
  }
}

/**
 * v0.4.3 audit fix: a helper for callers that want to know whether a
 * resolved identity is "analytically safe" to use as verified evidence.
 * A symbol-only join returns `ambiguous` and is never safe.
 */
export function isVerifiedResolution(r: ResolvedIdentity): boolean {
  return r.mappingStatus === "verified" && r.matchMethod !== "symbol-only";
}
