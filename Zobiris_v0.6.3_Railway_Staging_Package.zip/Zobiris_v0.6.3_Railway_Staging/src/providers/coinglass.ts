/**
 * CoinGlass adapter — fixture-driven only in slice 1.
 * Slice 5+ (v0.4.0): live network path wired with mock-fetchable tests.
 *
 * Provides derivatives intelligence: funding rates, open interest, basis,
 * liquidations, leverage, options/orderbook/ETF flow.
 */

import { z } from "zod";
import {
  type CanonicalAsset,
  type NormalizedObservation,
  type ProviderHealth,
  type FreshnessState,
} from "../domain/index.js";
import {
  type ProviderAdapter,
  type FetchResult,
  AdapterContractError,
  AdapterNormalizationError,
} from "./types.js";
import { loadFixture, makeIdempotencyKey } from "./identity.js";
import { resolveCanonicalIdentity, lookupCanonicalIdentity } from "./canonicalResolve.js";
import { normalizeTimestampToIso } from "./timestamps.js";
import { randomUUID } from "node:crypto";

const COINGLASS_RAW_SCHEMA_VERSION = "1.0.0";
const COINGLASS_NORMALIZER_VERSION = "0.1.0";
const COINGLASS_LIVE_TIMEOUT_MS = 10_000;

// v0.4.4 audit fix (P0-3): CoinGlass v4 funding-rate/history returns
// OHLC points with fields { time, open, high, low, close }. The
// "funding rate" we observe is the close of the funding-rate bar.
// v2 fields are still accepted for backward compat.
const fundingPointSchema = z.object({
  // v2 fields
  symbol: z.string().optional(),
  exchange: z.string().optional(),
  rate: z.number().optional(),
  nextFundingTime: z.number().optional(),
  time: z.union([z.string(), z.number()]).optional(),
  // v4 fields (OHLC)
  createTime: z.number().optional(),
  fundingRate: z.number().optional(),
  exchangeName: z.string().optional(),
  // v4 OHLC funding rate bar
  open: z.union([z.string(), z.number()]).optional(),
  high: z.union([z.string(), z.number()]).optional(),
  low: z.union([z.string(), z.number()]).optional(),
  close: z.union([z.string(), z.number()]).optional(),
});

const coinglassFundingResponseSchema = z.object({
  code: z.string().optional(),
  msg: z.string().optional(),
  data: z.array(fundingPointSchema).optional(),
});

const liquidationPointSchema = z.object({
  // v2 fields
  symbol: z.string().optional(),
  side: z.enum(["long", "short", "buy", "sell"]).optional(),
  price: z.number().optional(),
  volumeUsd: z.number().optional(),
  time: z.union([z.string(), z.number()]).optional(),
  exchange: z.string().optional(),  // v2 also has this
  // v4 fields (aggregated-history)
  longVolumeUsd: z.number().optional(),
  shortVolumeUsd: z.number().optional(),
  createTime: z.number().optional(),
  exchangeName: z.string().optional(),
  // v4 documented aggregated-long / aggregated-short in USD
  aggregated_long_liquidation_usd: z.number().optional(),
  aggregated_short_liquidation_usd: z.number().optional(),
  aggregated_long_liquidation_volume: z.number().optional(),
  aggregated_short_liquidation_volume: z.number().optional(),
});

const coinglassLiquidationsResponseSchema = z.object({
  code: z.string().optional(),
  msg: z.string().optional(),
  data: z.array(liquidationPointSchema).optional(),
});

export interface CoinGlassAdapterConfig {
  baseUrl: string;
  apiKey?: string;
  fundingFixturePath?: string;
  liquidationsFixturePath?: string;
  /** Force fixture mode (no network). Defaults to true when no live key is configured. */
  forceFixtures?: boolean;
  /** Live-mode config. When set AND forceFixtures===false, fetch() hits the live API. */
  liveConfig?: {
    apiKey: string;
    timeoutMs?: number;
    symbols?: string[];
  };
}

export class CoinGlassAdapter implements ProviderAdapter<CoinGlassAdapterConfig> {
  readonly id = "coinglass";
  readonly capabilities = {
    provider: "coinglass",
    displayName: "CoinGlass",
    requiresApiKey: true,
    supported: "live" as const,
    dataClasses: ["derivatives" as const],
    notes: "Live path wired in slice 5+; defaults to fixture mode without API key.",
  };

  private config: CoinGlassAdapterConfig = { baseUrl: "https://open-api.coinglass.com" };
  /** Most recent network error from the live fetch. */
  lastNetworkError?: string;

  configure(config: CoinGlassAdapterConfig): void {
    this.config = config;
  }

  validateRaw(raw: unknown, ctx: { endpoint: string }): unknown {
    let parsed;
    if (ctx.endpoint === "funding") {
      parsed = coinglassFundingResponseSchema.safeParse(raw);
    } else if (ctx.endpoint === "liquidations") {
      parsed = coinglassLiquidationsResponseSchema.safeParse(raw);
    } else {
      throw new AdapterContractError(this.id, ctx.endpoint, "unknown endpoint");
    }
    if (!parsed.success) {
      throw new AdapterContractError(this.id, ctx.endpoint, parsed.error.message.slice(0, 200), undefined);
    }
    if (parsed.data.code && parsed.data.code !== "0") {
      throw new AdapterContractError(this.id, ctx.endpoint, parsed.data.msg ?? "unknown", undefined);
    }
    return parsed.data;
  }

  normalize(
    raw: unknown,
    ctx: { canonicalAssets: Map<string, CanonicalAsset>; endpoint: string; receivedAt: string; rawSchemaVersion: string },
  ): NormalizedObservation[] {
    const validated = this.validateRaw(raw, ctx);
    const out: NormalizedObservation[] = [];
    if (ctx.endpoint === "funding") {
      const data = (validated as z.infer<typeof coinglassFundingResponseSchema>).data ?? [];
      // v0.4.4 audit fix (P0-3): the v4 funding-rate/history endpoint
      // does NOT include a per-row symbol. The symbol is part of the
      // query string (e.g. symbol=BTCUSDT). The runtime should pass
      // it via ctx; until then, fall back to a query-derived symbol
      // from the raw payload's `config` or the canonical map.
      const querySymbol = (raw as any)?.data?.symbol
        ?? (raw as any)?.config?.symbol
        ?? (ctx as any).requestedSymbol;
      for (const entry of data) {
        // Prefer the per-row symbol (v2) but fall back to the
        // query-derived symbol (v4). The per-row symbol is the
        // underlying ticker (e.g. "BTC"); the query is the pair
        // (e.g. "BTCUSDT"). Strip the USDT suffix for canonical
        // resolution.
        const rowSymbol = entry.symbol?.toUpperCase()
          ?? querySymbol?.toUpperCase()
          ?? null;
        const symbol = rowSymbol?.endsWith("USDT")
          ? rowSymbol.replace(/USDT$/, "")
          : rowSymbol;
        if (!symbol) continue;
        // v0.4.3 audit fix (P0-1, P0-2): use the typed resolver. CoinGlass
        // providers observations keyed by (exchange, symbol). The
        // exchange is part of the provider's namespace, not a
        // canonical asset attribute, so it is recorded in the payload
        // for observability but not used for identity resolution.
        const existing = lookupCanonicalIdentity(
          { provider: "coinglass", providerAssetId: symbol, symbol },
          Array.from(ctx.canonicalAssets.values()),
        );
        const resolved = existing ?? resolveCanonicalIdentity({
          provider: "coinglass",
          providerAssetId: symbol,
          symbol,
        });
        const assetId = resolved.canonicalAssetId;
        // v0.4.3 fix (P0-5): v4 funding-rate history uses
        // `createTime` + `fundingRate` + `exchangeName`; v2 used
        // v0.4.4 audit fix (P0-3): v4 OHLC funding-rate points have
        //   { time, open, high, low, close } (the rate is the close of
        //   the funding-rate bar). v2 used { time, rate }. Read both.
        const entryTime = entry.time ?? entry.createTime;
        const parseRate = (v: unknown): number | null => {
          if (v == null) return null;
          const n = typeof v === "string" ? Number(v) : (v as number);
          return typeof n === "number" && isFinite(n) ? n : null;
        };
        const entryRate = parseRate(entry.rate) ?? parseRate(entry.fundingRate) ?? parseRate(entry.close);
        const entryExchange = entry.exchange ?? entry.exchangeName ?? null;
        out.push({
          id: randomUUID(),
          idempotencyKey: makeIdempotencyKey({
            provider: this.id,
            providerEventId: `${entryExchange ?? "?"}:${entry.symbol}:${entryTime ?? "?"}`,
            canonicalAssetId: assetId,
            eventType: "funding",
            sourceTimestamp: entryTime ? String(entryTime) : undefined,
          }),
          provider: this.id,
          providerEventId: `${entryExchange ?? "?"}:${entry.symbol}:${entryTime ?? "?"}`,
          eventType: "funding",
          schemaVersion: COINGLASS_RAW_SCHEMA_VERSION,
          canonicalAssetId: assetId,
          // v0.4.3 fix: quarantineState reflects the resolver.
          quarantineState: resolved.mappingStatus,
          identityMatchMethod: resolved.matchMethod,
          sourceTimestamp: entryTime ? normalizeTimestampToIso(entryTime) ?? ctx.receivedAt : undefined,
          occurredAt: entryTime ? normalizeTimestampToIso(entryTime) ?? ctx.receivedAt : ctx.receivedAt,
          receivedAt: ctx.receivedAt,
          retrievedAt: ctx.receivedAt,
          normalizerVersion: COINGLASS_NORMALIZER_VERSION,
          payload: {
            symbol,
            exchange: entryExchange,
            rate: entryRate,
            nextFundingTime: entry.nextFundingTime ? new Date(entry.nextFundingTime * 1000).toISOString() : null,
            identityMatchMethod: resolved.matchMethod,
            mappingConfidence: resolved.mappingConfidence,
          },
          epistemicState: entryRate == null ? "UNKNOWN" : "KNOWN",
          evidenceConfidence: entryRate == null ? 0 : Math.min(0.95, resolved.mappingConfidence * 0.95),
          licenseClass: "display-only",
        });
      }
    } else if (ctx.endpoint === "liquidations") {
      const data = (validated as z.infer<typeof coinglassLiquidationsResponseSchema>).data ?? [];
      // v0.4.4 audit fix (P0-3): same as funding path — the v4
      // liquidation response also does not repeat the symbol per
      // row; the runtime must supply it via the query context.
      const querySymbol = (raw as any)?.data?.symbol
        ?? (raw as any)?.config?.symbol
        ?? (ctx as any).requestedSymbol;
      for (const entry of data) {
        const rowSymbol = entry.symbol?.toUpperCase()
          ?? querySymbol?.toUpperCase()
          ?? null;
        const symbol = rowSymbol?.endsWith("USDT")
          ? rowSymbol.replace(/USDT$/, "")
          : rowSymbol;
        if (!symbol) continue;
        // v0.4.3 fix: same as funding path. Use symbol as the
        // providerAssetId so the resolver hits the cmcSlug/symbol-only
        // paths in the typed lookup.
        const existing = lookupCanonicalIdentity(
          { provider: "coinglass", providerAssetId: symbol, symbol },
          Array.from(ctx.canonicalAssets.values()),
        );
        const resolved = existing ?? resolveCanonicalIdentity({
          provider: "coinglass",
          providerAssetId: symbol,
          symbol,
        });
        const assetId = resolved.canonicalAssetId;
        // v0.4.4 audit fix (P0-3): v4 aggregated-history uses
        //   { time, aggregated_long_liquidation_usd,
        //     aggregated_short_liquidation_usd }
        // v3/v2 used { createTime, longVolumeUsd, shortVolumeUsd }
        // or { time, side, volumeUsd }. Read all three.
        const entryTime = entry.time ?? entry.createTime;
        const liqExchange = entry.exchange ?? entry.exchangeName ?? null;
        const aggLong = entry.aggregated_long_liquidation_usd ?? entry.longVolumeUsd ?? null;
        const aggShort = entry.aggregated_short_liquidation_usd ?? entry.shortVolumeUsd ?? null;
        const liqSide = entry.side ?? (aggLong != null && aggShort != null
          ? (aggLong > aggShort ? "long" : "short")
          : null);
        const liqVolume = entry.volumeUsd
          ?? (aggLong != null && aggShort != null
            ? aggLong + aggShort
            : null);
        out.push({
          id: randomUUID(),
          idempotencyKey: makeIdempotencyKey({
            provider: this.id,
            providerEventId: `${entryTime ?? "?"}:${liqSide ?? "?"}:${entry.price ?? "?"}`,
            canonicalAssetId: assetId,
            eventType: "liquidation",
            sourceTimestamp: entryTime ? String(entryTime) : undefined,
          }),
          provider: this.id,
          providerEventId: `${entryTime ?? "?"}:${liqSide ?? "?"}:${entry.price ?? "?"}`,
          eventType: "liquidation",
          schemaVersion: COINGLASS_RAW_SCHEMA_VERSION,
          canonicalAssetId: assetId,
          quarantineState: resolved.mappingStatus,
          identityMatchMethod: resolved.matchMethod,
          sourceTimestamp: entryTime ? normalizeTimestampToIso(entryTime) ?? ctx.receivedAt : undefined,
          occurredAt: entryTime ? normalizeTimestampToIso(entryTime) ?? ctx.receivedAt : ctx.receivedAt,
          receivedAt: ctx.receivedAt,
          retrievedAt: ctx.receivedAt,
          normalizerVersion: COINGLASS_NORMALIZER_VERSION,
          payload: {
            symbol,
            side: liqSide,
            exchange: liqExchange,
            price: entry.price ?? null,
            volumeUsd: liqVolume,
            identityMatchMethod: resolved.matchMethod,
            mappingConfidence: resolved.mappingConfidence,
          },
          epistemicState: entry.price == null ? "UNKNOWN" : "KNOWN",
          evidenceConfidence: entry.price == null ? 0 : Math.min(0.95, resolved.mappingConfidence * 0.95),
          licenseClass: "display-only",
        });
      }
    }
    return out;
  }

  async fetch(_ctx: { canonicalAssets: Map<string, CanonicalAsset> }): Promise<FetchResult<unknown>[]> {
    const receivedAt = new Date().toISOString();
    const live = this.config.liveConfig;

    // Live path: requires both forceFixtures===false and a valid apiKey
    if (live && live.apiKey && !this.config.forceFixtures) {
      const out: FetchResult<unknown>[] = [];
      const symbols = live.symbols && live.symbols.length > 0 ? live.symbols : ["BTC", "ETH", "SOL"];
      // v0.4.4 audit fix (P0-3): the v4 funding/liquidations endpoints
      // require a per-exchange trading pair (e.g. BTCUSDT). The runtime
      // may pass either form; we normalize by appending USDT if the
      // symbol does not end in USDT/USDC/USD. The normalizer strips
      // the suffix before canonical resolution.
      const symbolParam = symbols[0] ?? "BTCUSDT";
      const normalizedPair = /USDT$|USDC$|USD$/.test(symbolParam)
        ? symbolParam
        : `${symbolParam}USDT`;
      const timeoutMs = live.timeoutMs ?? COINGLASS_LIVE_TIMEOUT_MS;
      // v0.4.2 audit fix (P0 BLOCKER 3): CoinGlass v4 docs require
      // `CG-API-KEY: <key>` header (not `coinglassSecret`). See
      // https://docs.coinglass.com/reference/authentication
      const headers: Record<string, string> = { Accept: "application/json" };
      if (live.apiKey) headers["CG-API-KEY"] = live.apiKey;

      // Fetch funding rates
      // v0.4.3 audit fix (P0-5): CoinGlass v4 documented endpoints are
      //   GET /api/futures/funding-rate/history
      //   GET /api/futures/funding-rate/vol-weight-history
      // The previous v2 endpoint (`/api/futures/fundingRate/v2`) is
      // removed in v4. The `history` endpoint requires `exchange` and
      // `symbol` (single, not comma-joined) plus an `interval` (1h|4h|12h|1d).
      try {
        const controller = new AbortController();
        const timer = setTimeout(() => controller.abort(), timeoutMs);
        // v4 requires single-symbol calls. v0.4.4 audit fix (P0-3):
        // the symbol here is an exchange pair, e.g. BTCUSDT, not
        // just the underlying ticker. Without the USDT suffix the v4
        // endpoint returns an error. The exchange param is the
        // single-exchange filter.
        // v4 endpoint: GET /api/futures/funding-rate/history
        // v4 response: OHLC points { time, open, high, low, close }
        // The "rate" we use is the close of the funding-rate bar.
        const url = `${this.config.baseUrl}/api/futures/funding-rate/history?exchange=Binance&symbol=${encodeURIComponent(normalizedPair)}&interval=1h&limit=100`;
        // v0.4.4: attach the requested symbol to the result so the
        // normalizer can attach observations to the canonical asset
        // even though the v4 response does not repeat the symbol.
        let response: Response;
        try {
          response = await fetch(url, { method: "GET", headers, signal: controller.signal });
        } finally {
          clearTimeout(timer);
        }
        if (response.status === 401) {
          throw new AdapterNormalizationError(this.id, "coinglass http 401: invalid or missing API key");
        }
        if (!response.ok) {
          this.lastNetworkError = `coinglass funding http ${response.status}`;
          // fall through to fixture for this endpoint
        } else {
          const raw = await response.json();
          out.push({ raw, data: raw, receivedAt, endpoint: "funding", dataMode: "live", requestedSymbol: normalizedPair });
        }
      } catch (e) {
        if (e instanceof AdapterNormalizationError) throw e;
        this.lastNetworkError = e instanceof Error ? e.message : String(e);
        // fall through to fixture
      }

      // Fetch liquidations (best-effort)
      // v0.4.3 audit fix (P0-5): CoinGlass v4 documented endpoints are
      //   GET /api/futures/liquidation/order
      //   GET /api/futures/liquidation/coin-list
      //   GET /api/futures/liquidation/history
      //   GET /api/futures/liquidation/aggregated-history
      // The v2 `liquidation/info` endpoint is removed. We use
      // aggregated-history which is the closest fit to the previous
      // behaviour and returns a paginated series.
      try {
        const controller = new AbortController();
        const timer = setTimeout(() => controller.abort(), timeoutMs);
        // v0.4.4 audit fix (P0-3): aggregated liquidation history
        // uses `exchange_list` (multi-exchange filter) per the v4
        // docs. The `exchange` (singular) param was the v2 form.
        // The response fields are
        //   time, aggregated_long_liquidation_usd, aggregated_short_liquidation_usd
        // (not the old `longVolumeUsd` / `shortVolumeUsd`).
        const url = `${this.config.baseUrl}/api/futures/liquidation/aggregated-history?exchange_list=Binance&symbol=${encodeURIComponent(normalizedPair)}&interval=1h&limit=100`;
        let response: Response;
        try {
          response = await fetch(url, { method: "GET", headers, signal: controller.signal });
        } finally {
          clearTimeout(timer);
        }
        if (response.status === 401) {
          // Already reported in funding; ignore
        } else if (!response.ok) {
          this.lastNetworkError = `coinglass liquidations http ${response.status}`;
        } else {
          const raw = await response.json();
          out.push({ raw, data: raw, receivedAt, endpoint: "liquidations", dataMode: "live", requestedSymbol: normalizedPair });
        }
      } catch (e) {
        if (e instanceof AdapterNormalizationError) throw e;
        this.lastNetworkError = e instanceof Error ? e.message : String(e);
      }

      // v0.4.4 audit fix (P0-6): when live produced no results and we
      // fall through to fixture, mark the dataMode as "fallback" so
      // the runtime can mark the stage degraded. Do NOT silently
      // pretend the data is live.
      if (out.length === 0) {
        if (this.config.fundingFixturePath) {
          const raw = await loadFixture(this.config.fundingFixturePath);
          out.push({
            raw,
            data: raw,
            receivedAt,
            endpoint: "funding",
            dataMode: "fallback",
            fallbackReason: `live http ${this.lastNetworkError ?? "no-response"}`,
          });
        }
        if (this.config.liquidationsFixturePath) {
          const raw = await loadFixture(this.config.liquidationsFixturePath);
          out.push({
            raw,
            data: raw,
            receivedAt,
            endpoint: "liquidations",
            dataMode: "fallback",
            fallbackReason: `live http ${this.lastNetworkError ?? "no-response"}`,
          });
        }
      }
      if (out.length === 0) {
        out.push({ raw: null, data: null, receivedAt, networkError: this.lastNetworkError });
      }
      return out;
    }

    // Fixture path: mark dataMode as "snapshot" (not "fallback")
    // because the operator explicitly chose fixture mode. The runtime
    // can still mark the stage "snapshot" rather than "live".
    const out: FetchResult<unknown>[] = [];
    if (this.config.fundingFixturePath) {
      const raw = await loadFixture(this.config.fundingFixturePath);
      out.push({ raw, data: raw, receivedAt, endpoint: "funding", dataMode: "snapshot" });
    }
    if (this.config.liquidationsFixturePath) {
      const raw = await loadFixture(this.config.liquidationsFixturePath);
      out.push({ raw, data: raw, receivedAt, endpoint: "liquidations", dataMode: "snapshot" });
    }
    if (out.length === 0) {
      out.push({ raw: null, data: null, receivedAt });
    }
    return out;
  }

  health(): ProviderHealth {
    const hasAny = Boolean(this.config.fundingFixturePath || this.config.liquidationsFixturePath);
    let status: ProviderHealth["status"];
    if (this.lastNetworkError && this.config.liveConfig) {
      status = "degraded";
    } else if (this.config.liveConfig && this.config.liveConfig.apiKey) {
      status = "connected";
    } else if (hasAny) {
      status = "snapshot";
    } else {
      status = "credentials-needed";
    }
    return {
      provider: this.id,
      status,
      reconnectAttempt: 0,
      lastErrorAt: this.lastNetworkError ? new Date().toISOString() : undefined,
      lastErrorClass: this.lastNetworkError ? "network" : undefined,
      freshness: this.freshness(),
    };
  }

  freshness(): FreshnessState {
    if (this.lastNetworkError && this.config.liveConfig) return "delayed";
    if (this.config.liveConfig && this.config.liveConfig.apiKey) return "live";
    if (this.config.fundingFixturePath || this.config.liquidationsFixturePath) return "unavailable";
    return "unavailable";
  }
}
