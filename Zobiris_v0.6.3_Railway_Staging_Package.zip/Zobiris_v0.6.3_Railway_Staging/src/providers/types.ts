/**
 * Provider adapter contract.
 *
 * Per CoinGlass/Bitquery blueprint and docs/DATA_PLANE.md: each provider adapter
 * owns authentication and transport only. It must:
 *   1. connect/fetch
 *   2. validate raw contract
 *   3. normalize into internal event/observation
 *   4. emit to the ingest boundary
 *   5. expose health
 *
 * It must NOT directly write UI state, make portfolio decisions, or bypass
 * the event store.
 */

import { z } from "zod";
import {
  type CanonicalAsset,
  type MappingStatus,
  type NormalizedObservation,
  type ProviderHealth,
  type FreshnessState,
} from "../domain/index.js";

/** Adapter transport options. */
export interface AdapterTransport {
  baseUrl: string;
  apiKey?: string;
  /** Override fetch implementation (used in tests with fake-indexeddb / fixtures). */
  fetchImpl?: typeof fetch;
  /** Default timeout in ms. */
  timeoutMs?: number;
}

/** Output of a single fetch call. */
export interface FetchResult<T> {
  raw: unknown;
  data: T | null;
  providerEventId?: string;
  receivedAt: string;
  sourceTimestamp?: string;
  /** Set when the network call failed; the runtime will record a circuit-breaker failure. */
  networkError?: string;
  /** v0.4.4 audit fix (P0-3, P0-6): the endpoint tag identifies which
   *  provider endpoint produced this result, so the runtime can
   *  route the right normalizer without try/catch inference. */
  endpoint?: string;
  /** v0.4.4 audit fix (P0-3): the requested symbol (per-row
   *  fallback when the response doesn't include one). e.g. for
   *  CoinGlass funding, the query was `?symbol=BTCUSDT`, so the
   *  normalizer strips the USDT suffix to get "BTC" for canonical
   *  resolution. */
  requestedSymbol?: string;
  /** Requested exchange when the provider endpoint is exchange-scoped. */
  requestedExchange?: string;
  /** Provider/config timestamp distinct from local receive time. */
  providerGeneratedAt?: string;
  /** v0.4.4 audit fix (P0-6): dataMode + fallback provenance. A
   *  fallback result must always make the stage `degraded`, never
   *  `succeeded`. The audit caught that adapters could fall through
   *  to fixture without exposing that to the runtime. */
  dataMode?: "live" | "snapshot" | "fallback";
  /** Set when dataMode is "fallback". */
  fallbackReason?: string;
  /** Set when dataMode is "fallback" due to a live network failure. */
  upstreamFailure?: {
    class: "network" | "auth" | "rate_limit" | "schema_mismatch" | "server_error";
    status?: number;
    message?: string;
  };
}

/** Provider capability advertisement. */
export const providerCapabilitiesSchema = z.object({
  provider: z.string(),
  displayName: z.string(),
  requiresApiKey: z.boolean(),
  supported: z.enum(["live", "fixture-only", "disabled"]),
  dataClasses: z.array(z.enum([
    "market",
    "social",
    "derivatives",
    "onchain",
    "catalysts",
    "news",
    "macro",
    "identity",
    "llm",
  ])),
  notes: z.string().optional(),
});
export type ProviderCapabilities = z.infer<typeof providerCapabilitiesSchema>;

/** Provider adapter contract. */
export interface ProviderAdapter<TConfig> {
  readonly id: string;
  readonly capabilities: ProviderCapabilities;
  configure(config: TConfig): void;
  /** Validate raw response shape. Throws AdapterContractError on schema mismatch. */
  validateRaw(raw: unknown, ctx: { endpoint: string }): unknown;
  /** Map raw to NormalizedObservation[]. Throws AdapterNormalizationError on unrecoverable issue. */
  normalize(raw: unknown, ctx: { canonicalAssets: Map<string, CanonicalAsset>; endpoint: string; receivedAt: string; rawSchemaVersion: string }): NormalizedObservation[];
  /** Optional: fetch from upstream. Default impl in tests uses fixture file. */
  fetch(ctx: { canonicalAssets: Map<string, CanonicalAsset> }): Promise<FetchResult<unknown>[]>;
  health(): ProviderHealth;
  freshness(): FreshnessState;
}

/** Errors a provider can raise. */
export class AdapterContractError extends Error {
  constructor(provider: string, endpoint: string, reason: string, public readonly receivedRaw?: unknown) {
    super(`[${provider}] contract error at ${endpoint}: ${reason}`);
    this.name = "AdapterContractError";
  }
}
export class AdapterNormalizationError extends Error {
  constructor(provider: string, reason: string, public readonly receivedRaw?: unknown) {
    super(`[${provider}] normalization error: ${reason}`);
    this.name = "AdapterNormalizationError";
  }
}
export class AdapterAuthError extends Error {
  constructor(provider: string, reason: string) {
    super(`[${provider}] auth error: ${reason}`);
    this.name = "AdapterAuthError";
  }
}

/** Resolve canonical asset by provider id (or by ticker fallback when no other signal). */
export function resolveCanonicalByProviderId(
  providerAssetId: string,
  provider: string,
  assets: Map<string, CanonicalAsset>,
  ticker?: string,
): { asset: CanonicalAsset | null; status: MappingStatus } {
  // Preferred: look up via provider id in canonical asset.providerIds map.
  for (const asset of assets.values()) {
    if (asset.providerIds[provider] === providerAssetId) {
      return { asset, status: asset.mappingStatus };
    }
  }
  // Fallback: ticker lookup. If a ticker maps to multiple canonical assets, quarantine.
  if (ticker) {
    const matches: CanonicalAsset[] = [];
    for (const asset of assets.values()) {
      if (asset.symbol === ticker.toUpperCase()) matches.push(asset);
    }
    if (matches.length === 1) {
      const only = matches[0]!;
      return { asset: only, status: only.mappingStatus };
    }
    if (matches.length > 1) {
      return { asset: null, status: "ambiguous" };
    }
  }
  return { asset: null, status: "unmapped" };
}
