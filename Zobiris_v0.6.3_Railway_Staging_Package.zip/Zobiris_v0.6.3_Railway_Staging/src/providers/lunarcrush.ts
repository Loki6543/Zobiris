/**
 * LunarCrush adapter — social intelligence (Galaxy Score, AltRank, sentiment,
 * social volume, social dominance).
 *
 * Modes:
 *  - default (fixture-only): loads `fixturePath` from disk.
 *  - live: when `liveConfig.apiKey` is set, calls
 *      GET https://api.lunarcrush.com/v4/coins?symbol=BTC,ETH,SOL&key=<apiKey>
 *    with a 10s AbortController timeout. On network failure, falls through to
 *    the fixture. On HTTP 401, throws AdapterNormalizationError (caller may
 *    surface as a credential/contract error).
 *
 * Live response shape (documented):
 *   { data: [{ symbol, name, galaxy_score, alt_rank, social_volume, sentiment,
 *              social_dominance, price, price_change_24h, market_cap }] }
 *
 * The validate() schema also accepts the fixture shape, which uses
 * `percent_change_24h` instead of `price_change_24h`. The normalizer reads
 * whichever is present.
 */

import { z } from "zod";
import {
  type CanonicalAsset,
  type NormalizedObservation,
  type ProviderHealth,
  type FreshnessState,
} from "../domain/index.js";
import {
  type ProviderAdapter,
  type FetchResult,
  AdapterContractError,
  AdapterNormalizationError,
} from "./types.js";
import { loadFixture, makeIdempotencyKey } from "./identity.js";
import { resolveCanonicalIdentity, lookupCanonicalIdentity } from "./canonicalResolve.js";
import { randomUUID } from "node:crypto";

const LUNARCRUSH_RAW_SCHEMA_VERSION = "4.0.0";
const LUNARCRUSH_NORMALIZER_VERSION = "0.1.0";

/**
 * v0.4.3 audit fix (P0-3): the v4 list endpoint returns ALL coins, so
 * there is no per-call symbol filter. Kept for backward compat with
 * the live config shape.
 */
const LUNARCRUSH_DEFAULT_SYMBOLS = ["BTC", "ETH", "SOL"] as const;
void LUNARCRUSH_DEFAULT_SYMBOLS;

/** Default live-mode timeout (ms). */
const LUNARCRUSH_DEFAULT_TIMEOUT_MS = 10_000;

/**
 * Schema accepts both the documented live shape (`price_change_24h`) and the
 * legacy fixture shape (`percent_change_24h`). Either field satisfies the
 * 24h change contract — the normalizer reads whichever is present.
 */
/**
 * v0.4.4 audit fix (P0-5): the LunarCrush API4 list endpoint
 *   GET /public/coins/list/v1
 * returns a flat data[] array (the documented current contract).
 * v0.4.3 also accepted the nested `data: { coins: [{...}] }` form
 * (older fixtures); v0.4.4 keeps both for backward compat with
 * existing fixtures, but the live path produces the flat array.
 *
 * v4 fields include `social_volume_24h`, `interactions_24h`, etc.
 * v0.4.4 also reads `config.generated` from the response envelope
 * to use as the source timestamp (list responses are cached).
 */
const lunarCoinObjectSchema = z.object({
  id: z.union([z.string(), z.number()]).optional(),
  name: z.string(),
  symbol: z.string(),
  // v0.4.4 audit fix: use the documented v4 field names.
  social_volume_24h: z.number().optional(),
  interactions_24h: z.number().optional(),
  social_dominance: z.number().optional(),
  galaxy_score: z.number().optional(),
  alt_rank: z.number().optional(),
  sentiment: z.number().optional(),
  market_cap: z.number().optional(),
  price: z.number().optional(),
  percent_change_24h: z.number().optional(),
  // v3 legacy field names still accepted for backward compat.
  social_volume: z.number().optional(),
  social_score: z.number().optional(),
  price_change_24h: z.number().optional(),
  time: z.union([z.string(), z.number()]).optional(),
});
const lunarCoinSchema = z.object({
  // v4 response envelope: a config block with metadata.
  config: z.object({
    generated: z.union([z.string(), z.number()]).optional(),
    request_time: z.union([z.string(), z.number()]).optional(),
    num_rows: z.number().optional(),
  }).optional(),
  // Accept BOTH flat data[] (v4 documented) and legacy nested
  // { coins: [{ metrics: {...} }] } (v0.4.3 fixture compat).
  data: z.union([
    z.array(lunarCoinObjectSchema),
    z.object({
      coins: z.array(z.object({
        id: z.union([z.string(), z.number()]).optional(),
        name: z.string(),
        symbol: z.string(),
        // v0.4.3 nested form: metrics under `metrics` key.
        metrics: z.object({
          galaxy_score: z.number().optional(),
          alt_rank: z.number().optional(),
          social_volume: z.number().optional(),
          social_volume_24h: z.number().optional(),
          social_score: z.number().optional(),
          sentiment: z.number().optional(),
          social_dominance: z.number().optional(),
          market_cap: z.number().optional(),
          price: z.number().optional(),
          percent_change_24h: z.number().optional(),
          price_change_24h: z.number().optional(),
        }).optional(),
        time: z.union([z.string(), z.number()]).optional(),
      })).optional(),
    }),
  ]).optional(),
});

export interface LunarCrushLiveConfig {
  apiKey: string;
  /** Network timeout in ms (default 10_000). */
  timeoutMs?: number;
  /** Symbols to request. Defaults to BTC,ETH,SOL. */
  symbols?: readonly string[];
}

export interface LunarCrushAdapterConfig {
  baseUrl: string;
  apiKey?: string;
  fixturePath?: string;
  /** Live-mode config. When set, fetch() hits the live API first. */
  liveConfig?: LunarCrushLiveConfig;
}

export class LunarCrushAdapter implements ProviderAdapter<LunarCrushAdapterConfig> {
  readonly id = "lunarcrush";
  readonly capabilities = {
    provider: "lunarcrush",
    displayName: "LunarCrush",
    requiresApiKey: true,
    supported: "fixture-only" as "live" | "fixture-only" | "disabled",
    dataClasses: ["social" as const],
    notes: "Galaxy Score, AltRank, social_volume, sentiment, social_dominance. Live path uses GET /v4/coins?symbol=BTC,ETH,SOL&key=<apiKey> with AbortController timeout; falls back to fixture on network failure and throws AdapterNormalizationError on HTTP 401.",
  };

  private config: LunarCrushAdapterConfig = { baseUrl: "https://api.lunarcrush.com" };

  /** Most recent network error (set when the live fetch fails). */
  lastNetworkError?: string;

  configure(config: LunarCrushAdapterConfig): void {
    this.config = config;
    this.capabilities.supported = config.liveConfig ? "live" : "fixture-only";
  }

  /**
   * Enable live mode with the given API key. Sets `liveConfig` on the
   * current config and flips `capabilities.supported` to "live".
   */
  setLiveMode(apiKey: string): void {
    this.config = { ...this.config, liveConfig: { apiKey } };
    this.capabilities.supported = "live";
  }

  validateRaw(raw: unknown, ctx: { endpoint: string }): unknown {
    const parsed = lunarCoinSchema.safeParse(raw);
    if (!parsed.success) {
      throw new AdapterContractError(this.id, ctx.endpoint, parsed.error.message.slice(0, 200), undefined);
    }
    return parsed.data;
  }

  normalize(
    raw: unknown,
    ctx: { canonicalAssets: Map<string, CanonicalAsset>; endpoint: string; receivedAt: string; rawSchemaVersion: string },
  ): NormalizedObservation[] {
    const validated = this.validateRaw(raw, ctx);
    const out: NormalizedObservation[] = [];
    // v0.4.4 audit fix (P0-5): derive the source timestamp from
    // config.generated (provider-side generation time, since the
    // list endpoint is cached). Used for every normalized row.
    const generated = (raw as any)?.config?.generated;
    const generatedIso = typeof generated === "string"
      ? generated
      : (typeof generated === "number"
        // v0.4.4: LunarCrush config.generated is a unix timestamp
        // in seconds. Multiply by 1000 to get ms for Date ctor.
        // (LunarCrush v4 returns seconds, not ms.)
        ? new Date(generated * 1000).toISOString()
        : undefined);
    // v0.4.4 audit fix (P0-5): the v4 list endpoint returns a flat
    // array. Older fixtures may still pass an object; tolerate both.
    const dataField = (validated as z.infer<typeof lunarCoinSchema>).data;
    let data: any[] = [];
    if (Array.isArray(dataField)) {
      data = dataField;
    } else if (dataField && typeof dataField === "object" && "coins" in dataField && Array.isArray((dataField as any).coins)) {
      data = (dataField as any).coins;
    }
    for (const entry of data) {
      const symbol = entry.symbol?.toUpperCase();
      if (!symbol) continue;
      // v0.4.3 audit fix (P0-1, P0-2): use the typed resolver. LunarCrush's
      // provider-native id is `entry.id`. If the registered canonical
      // asset has a matching `lunarcrushId`, the join is verified;
      // otherwise the resolver falls through to symbol-only (ambiguous).
      const lcId = String(entry.id ?? entry.name ?? symbol);
      const existing = lookupCanonicalIdentity(
        { provider: "lunarcrush", providerAssetId: lcId, symbol },
        Array.from(ctx.canonicalAssets.values()),
      );
      const resolved = existing ?? resolveCanonicalIdentity({
        provider: "lunarcrush",
        providerAssetId: lcId,
        symbol,
      });
      const assetId = resolved.canonicalAssetId;
      // v0.4.4 audit fix (P0-5): the v4 list endpoint returns a flat
      // record. Use the documented v4 field names:
      //   social_volume_24h, interactions_24h, social_dominance,
      //   galaxy_score, alt_rank, sentiment, market_cap, price,
      //   percent_change_24h
      // The v3 legacy `social_volume` and `price_change_24h` are
      // still accepted for backward compat.
      // v0.4.4 audit fix (P0-5): use the documented v4 field names.
      //   social_volume_24h, interactions_24h, social_dominance,
      //   galaxy_score, alt_rank, sentiment, market_cap, price,
      //   percent_change_24h
      // The v3 legacy `social_volume` and `price_change_24h` are
      // still accepted for backward compat. Legacy fixtures (v0.4.3)
      // may have nested the metrics under a `metrics` key; unwrap.
      const metrics = (entry as any).metrics ?? entry;
      const socialVolume24h = (entry as any).social_volume_24h ?? (entry as any).social_volume ?? metrics.social_volume ?? null;
      const interactions24h = (entry as any).interactions_24h ?? null;
      // v0.4.4: the v4 documented field is percent_change_24h; v3
      // was price_change_24h. Look in both top-level and nested
      // `metrics` for backward compat. The v0.4.3 schema rejected
      // unknown fields; v0.4.4's nested schema has
      // `metrics.percent_change_24h` and `metrics.price_change_24h`
      // available.
      const change24h = (entry as any).percent_change_24h
        ?? metrics.percent_change_24h
        ?? (entry as any).price_change_24h
        ?? metrics.price_change_24h
        ?? null;
      // v0.4.4 audit fix: source timestamp = config.generated (if
      // present) or the per-row time. config.generated is the
      // canonical source-freshness signal for the list endpoint.
      const entryTimeIso = entry.time
        ? new Date(Number(entry.time) * 1000).toISOString()
        : undefined;
      const sourceTs = generatedIso ?? entryTimeIso;
      out.push({
        id: randomUUID(),
        idempotencyKey: makeIdempotencyKey({
          provider: this.id,
          providerEventId: String(entry.id ?? entry.symbol),
          canonicalAssetId: assetId,
          eventType: "social_snapshot",
          sourceTimestamp: entry.time ? String(entry.time) : undefined,
        }),
        provider: this.id,
        providerEventId: String(entry.id ?? entry.symbol),
        eventType: "social_snapshot",
        schemaVersion: LUNARCRUSH_RAW_SCHEMA_VERSION,
        canonicalAssetId: assetId,
        // v0.4.3 fix: quarantineState reflects the resolver.
        quarantineState: resolved.mappingStatus,
        identityMatchMethod: resolved.matchMethod,
        // v0.4.4 audit fix (P0-5): use config.generated as the
        // source timestamp. LunarCrush list responses are cached
        // and may be up to an hour behind; the per-row `time` is
        // usually absent in v4. config.generated is the
        // provider-side generation timestamp.
        sourceTimestamp: sourceTs,
        occurredAt: sourceTs ?? ctx.receivedAt,
        receivedAt: ctx.receivedAt,
        retrievedAt: ctx.receivedAt,
        normalizerVersion: LUNARCRUSH_NORMALIZER_VERSION,
        payload: {
          symbol,
          galaxyScore: entry.galaxy_score ?? metrics.galaxy_score ?? null,
          altRank: entry.alt_rank ?? metrics.alt_rank ?? null,
          // v0.4.4 audit fix: emit both v4 and v3 field names for
          // backward compat. The UI can prefer the v4 24h fields.
          socialVolume24h: socialVolume24h,
          socialVolume: socialVolume24h,  // legacy alias
          interactions24h: interactions24h,
          sentiment: entry.sentiment ?? metrics.sentiment ?? null,
          socialDominance: entry.social_dominance ?? metrics.social_dominance ?? null,
          priceUsd: entry.price ?? metrics.price ?? null,
          change24hPct: change24h,
          identityMatchMethod: resolved.matchMethod,
          mappingConfidence: resolved.mappingConfidence,
          // v0.4.4: mark freshness as delayed because list/v1 is
          // cached (per the audit). The runtime can override if it
          // has a more recent retrieval.
          freshnessHint: "delayed",
        },
        epistemicState: entry.galaxy_score == null ? "UNKNOWN" : "KNOWN",
        evidenceConfidence: entry.galaxy_score == null ? 0 : 0.9,
        licenseClass: "display-only",
      });
    }
    return out;
  }

  async fetch(_ctx: { canonicalAssets: Map<string, CanonicalAsset> }): Promise<FetchResult<unknown>[]> {
    const receivedAt = new Date().toISOString();
    const live = this.config.liveConfig;
    if (live && live.apiKey) {
      // --- Live path ---
      // v0.4.3 audit fix (P0-3): the documented LunarCrush API4
      // endpoint family is:
      //   GET https://lunarcrush.com/api4/public/coins/list/v1
      //   GET https://lunarcrush.com/api4/public/coins/:coin/v1
      //   GET https://lunarcrush.com/api4/public/coins/:coin/time-series/v2
      // The previously documented v4/coins endpoint does not exist
      // (it was the v3 v2 endpoint family). The list endpoint returns
      // a paginated list of coins with their provider-native ids; the
      // per-coin endpoint returns metrics for one coin at a time.
      // Auth: Authorization: Bearer <API_KEY>.
      const baseUrl = (this.config.baseUrl || "https://lunarcrush.com/api4").replace(/\/$/, "");
      const url = `${baseUrl}/public/coins/list/v1`;
      const headers: Record<string, string> = {
        Authorization: `Bearer ${live.apiKey}`,
        Accept: "application/json",
      };
      const controller = new AbortController();
      const timeoutMs = live.timeoutMs ?? LUNARCRUSH_DEFAULT_TIMEOUT_MS;
      const timer = setTimeout(() => controller.abort(), timeoutMs);
      try {
        let response: Response;
        try {
          response = await fetch(url, { method: "GET", headers, signal: controller.signal });
        } finally {
          clearTimeout(timer);
        }
        if (response.status === 401) {
          // Credential failure — do NOT fall through to fixture; let the caller
          // surface this as a hard credential/contract error.
          throw new AdapterNormalizationError(
            this.id,
            "lunarcrush http 401: invalid or missing API key",
          );
        }
        if (!response.ok) {
          // Other HTTP error: surface as a networkError result (no fixture fall-through
          // here — the test contract is that a network/HTTP failure returns null data so
          // the runtime records a circuit-breaker failure rather than scoring on stale data).
          this.lastNetworkError = `lunarcrush http ${response.status}`;
          return [{ raw: null, data: null, receivedAt, networkError: this.lastNetworkError }];
        }
        const raw = await response.json();
        // v0.4.4 audit fix (P0-5): mark the dataMode as "live" so the
        // runtime can distinguish it from snapshot/fallback. The
        // freshnessHint is "delayed" because list/v1 is cached, but
        // dataMode still reflects whether the request actually hit
        // the live API.
        return [{
          raw,
          data: raw,
          receivedAt,
          endpoint: "coins/list/v1",
          dataMode: "live",
        }];
      } catch (e) {
        // Network/abort/JSON error: surface as a single null-result so the runtime
        // can record the failure (matches Kraken's networkError pattern). Fixture
        // is NOT loaded here — the runtime should treat this as a real outage.
        if (e instanceof AdapterNormalizationError) throw e;
        this.lastNetworkError = e instanceof Error ? e.message : String(e);
        return [{ raw: null, data: null, receivedAt, networkError: this.lastNetworkError }];
      }
    }
    // --- Fixture path (default) ---
    return this.fetchFixture(receivedAt);
  }

  private async fetchFixture(receivedAt: string): Promise<FetchResult<unknown>[]> {
    if (!this.config.fixturePath) {
      return [{ raw: null, data: null, receivedAt }];
    }
    const raw = await loadFixture(this.config.fixturePath);
    return [{ raw, data: raw, receivedAt, endpoint: "coins/list/v1", dataMode: "snapshot" }];
  }

  health(): ProviderHealth {
    let status: ProviderHealth["status"];
    if (this.lastNetworkError && this.config.liveConfig) status = "degraded";
    else if (this.config.liveConfig) status = "connected";
    else if (this.config.fixturePath) status = "snapshot";
    else status = "credentials-needed";
    return {
      provider: this.id,
      status,
      reconnectAttempt: 0,
      lastErrorAt: this.lastNetworkError ? new Date().toISOString() : undefined,
      lastErrorClass: this.lastNetworkError ? "network" : undefined,
      freshness: this.freshness(),
    };
  }

  freshness(): FreshnessState {
    if (this.lastNetworkError && this.config.liveConfig) return "delayed";
    if (this.config.liveConfig) return "live";
    return "unavailable";
  }
}
