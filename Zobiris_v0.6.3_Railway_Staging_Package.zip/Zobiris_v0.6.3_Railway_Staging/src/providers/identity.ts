/**
 * Provider identity helpers.
 *
 * Helpers for:
 *   - building deterministic idempotency keys
 *   - loading fixtures safely (with file-size cap, JSON parse, schema check)
 *   - redacting secrets from log/test output
 */

import { readFile } from "node:fs/promises";
import { resolve } from "node:path";
import { makeIdempotencyKey as domainMakeIdempotencyKey, type CanonicalAsset } from "../domain/index.js";

export { domainMakeIdempotencyKey as makeIdempotencyKey };

import type { DBTx } from "../storage/repository.js";
import { upsertCanonicalAsset } from "../storage/repository.js";

/**
 * Bridge a runtime `CanonicalAsset` to the storage layer.
 *
 * Returns the persisted id. Storage layer handles the upsert logic.
 */
export function upsertCanonicalFromWatchlist(db: DBTx, ca: CanonicalAsset): string {
  return upsertCanonicalAsset(db, {
    id: ca.id,
    symbol: ca.symbol,
    name: ca.name,
    chainId: ca.chainId,
    contractAddress: ca.contractAddress,
    sector: undefined,
    mappingStatus: ca.mappingStatus,
    mappingConfidence: ca.mappingConfidence,
    providerIds: ca.providerIds,
    // v0.4.4 audit fix: identityProvenance must be threaded through the
    // persistRefresh bridge too. Without this, every persisted canonical
    // asset had identityProvenance = null, breaking the immutable-id
    // invariant's audit trail.
    identityProvenance: ca.identityProvenance,
  });
}

/**
 * Load a fixture file. Caps file size at 256 KB to prevent accidental DoS
 * from a bad fixture. Throws with redacted context if parsing fails.
 */
export async function loadFixture(relativePath: string): Promise<unknown> {
  if (!relativePath) {
    throw new Error("loadFixture: empty path (adapter is disabled in this mode)");
  }
  const fullPath = resolve(process.cwd(), relativePath);
  const buf = await readFile(fullPath);
  if (buf.byteLength > 256 * 1024) {
    throw new Error(`Fixture too large (>256KB): ${redactPath(relativePath)}`);
  }
  try {
    return JSON.parse(buf.toString("utf8"));
  } catch (e) {
    throw new Error(`Fixture JSON parse error in ${redactPath(relativePath)}: ${(e as Error).message}`);
  }
}

/** Redact a file path so secrets in the path aren't logged. */
export function redactPath(p: string): string {
  return p
    .replace(/([?&])(api_key|access_token|token|key)=[^&]+/gi, "$1$2=REDACTED")
    .replace(/([A-Z0-9]{20,})/g, "REDACTED$1".slice(0, 8) + "…");
}

/** Redact a string for safe inclusion in logs/tests. */
export function redact(s: string): string {
  return s
    .replace(/([?&])(api_key|access_token|token|key|apikey)=[^&]+/gi, "$1$2=REDACTED")
    .replace(/\b(Bearer|Authorization)\s+[A-Za-z0-9._\-+/=]{8,}/g, "$1 REDACTED")
    .replace(/\b[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\b/gi, "REDACTED-UUID")
    // Common API key formats
    .replace(/\bsk-[A-Za-z0-9_\-]{20,}\b/g, "REDACTED-KEY")
    .replace(/\bAIza[0-9A-Za-z_\-]{35}\b/g, "REDACTED-KEY");
}

/** A short, redacted summary safe for log lines. */
export function summarize<T>(value: T, maxLen = 200): string {
  const s = typeof value === "string" ? value : JSON.stringify(value);
  const r = redact(s);
  return r.length > maxLen ? r.slice(0, maxLen) + "…" : r;
}
