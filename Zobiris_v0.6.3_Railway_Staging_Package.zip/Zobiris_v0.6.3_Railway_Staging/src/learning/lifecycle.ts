/**
 * Iyaza Addendum — Item G: Gated memory promotion + reversible improvement lifecycle.
 *
 * State machine for self-improvement candidates. A single run creates a
 * candidate, not a permanent rule. Promotion requires all 15 gates per the
 * addendum (recurrence, sessions, provenance, evaluation, etc.).
 */
export const PROMOTION_STATES = [
  "PROPOSED",
  "IMPLEMENTED_IN_SANDBOX",
  "UNIT_TESTED",
  "POINT_IN_TIME_REPLAYED",
  "COUNTERFACTUAL_OR_PAIRED_TESTED",
  "HOLDOUT_EVALUATED",
  "SHADOW_OBSERVED",
  "CROSS_SESSION_RECURRING",
  "INDEPENDENTLY_VERIFIED",
  "HUMAN_APPROVED",
  "PROMOTED",
  "MONITORED",
  "RETAINED",
  "ROLLED_BACK",
  "RETIRED",
] as const;
export type PromotionState = (typeof PROMOTION_STATES)[number];

const STATE_ORDER: PromotionState[] = [
  "PROPOSED",
  "IMPLEMENTED_IN_SANDBOX",
  "UNIT_TESTED",
  "POINT_IN_TIME_REPLAYED",
  "COUNTERFACTUAL_OR_PAIRED_TESTED",
  "HOLDOUT_EVALUATED",
  "SHADOW_OBSERVED",
  "CROSS_SESSION_RECURRING",
  "INDEPENDENTLY_VERIFIED",
  "HUMAN_APPROVED",
  "PROMOTED",
  "MONITORED",
  "RETAINED",
  "RETIRED",
];

const TERMINAL_PROMOTION_STATES: ReadonlySet<PromotionState> = new Set(["RETAINED", "RETIRED"]);

// ROLLED_BACK is reachable from any non-terminal state.
const ROLLBACK_TARGETS: ReadonlySet<PromotionState> = new Set([
  "PROPOSED",
  "IMPLEMENTED_IN_SANDBOX",
  "UNIT_TESTED",
  "POINT_IN_TIME_REPLAYED",
  "COUNTERFACTUAL_OR_PAIRED_TESTED",
  "HOLDOUT_EVALUATED",
  "SHADOW_OBSERVED",
  "CROSS_SESSION_RECURRING",
  "INDEPENDENTLY_VERIFIED",
  "HUMAN_APPROVED",
  "PROMOTED",
  "MONITORED",
]);

function isLegalForwardTransition(from: PromotionState, to: PromotionState): boolean {
  if (TERMINAL_PROMOTION_STATES.has(from)) return false;
  if (to === "ROLLED_BACK") return ROLLBACK_TARGETS.has(from);
  // MONITORED can transition to RETAINED (good) or stay (allowed)
  if (from === to) return true;
  const fi = STATE_ORDER.indexOf(from);
  const ti = STATE_ORDER.indexOf(to);
  if (fi < 0 || ti < 0) return false;
  // Only allow forward by 1 step
  return ti === fi + 1;
}

export interface PromotionEvidence {
  /** Optional reference to a test report, evaluation, or replay run. */
  ref: string;
  at: string;
  note?: string;
}

export interface CandidateHistoryEntry {
  from: PromotionState;
  to: PromotionState;
  at: string;
  evidence?: PromotionEvidence;
}

export class IllegalCandidateTransitionError extends Error {
  constructor(public readonly from: PromotionState, public readonly to: PromotionState, public readonly candidateId: string) {
    super(`illegal candidate transition for ${candidateId}: ${from} -> ${to}`);
    this.name = "IllegalCandidateTransitionError";
  }
}

export class CandidateLifecycle {
  readonly candidateId: string;
  private current: PromotionState;
  private readonly _history: CandidateHistoryEntry[] = [];

  constructor(candidateId: string, initial: PromotionState = "PROPOSED") {
    this.candidateId = candidateId;
    this.current = initial;
    this._history.push({ from: initial, to: initial, at: new Date().toISOString() });
  }

  currentState(): PromotionState {
    return this.current;
  }

  history(): CandidateHistoryEntry[] {
    return [...this._history];
  }

  isPromotable(): boolean {
    return this.current === "HUMAN_APPROVED" || this.current === "PROMOTED" || this.current === "MONITORED";
  }

  isTerminal(): boolean {
    return TERMINAL_PROMOTION_STATES.has(this.current);
  }

  record(to: PromotionState, evidence?: PromotionEvidence): void {
    const from = this.current;
    if (!isLegalForwardTransition(from, to)) {
      throw new IllegalCandidateTransitionError(from, to, this.candidateId);
    }
    this.current = to;
    this._history.push({ from, to, at: new Date().toISOString(), evidence });
  }

  /** Roll back to the previous state, marking ROLLED_BACK in the history. */
  rollback(evidence?: PromotionEvidence): PromotionState {
    if (TERMINAL_PROMOTION_STATES.has(this.current)) {
      throw new IllegalCandidateTransitionError(this.current, "ROLLED_BACK", this.candidateId);
    }
    // Find the previous non-ROLLED_BACK state in the history
    let previous: PromotionState = "PROPOSED";
    for (let i = this._history.length - 1; i >= 0; i--) {
      const entry = this._history[i]!;
      if (entry.to !== "ROLLED_BACK" && entry.to !== this.current) {
        previous = entry.to;
        break;
      }
    }
    const from = this.current;
    this._history.push({ from, to: "ROLLED_BACK", at: new Date().toISOString(), evidence });
    this.current = previous;
    return previous;
  }
}
