/**
 * Forecast ledger — slice 5+ v0.4.0.
 *
 * Per the Iyaza addendum, learning requires:
 *  - forecasts must be registered with explicit timestamps and inputs
 *  - outcomes must be measured against forecasts in a defined window
 *  - Brier scores and calibration must be tracked
 *  - results feed back into the calibration store
 *
 * This module implements the minimal ledger needed to:
 *  1. record a forecast (specialist opinion snapshot at time T)
 *  2. evaluate it once outcomes are observed (T+window)
 *  3. compute Brier score / directional accuracy
 *  4. aggregate to a calibration report
 *
 * In-memory for now; the persistence layer is the same outbox pattern
 * already in use for snapshots.
 */

import { randomUUID } from "node:crypto";
import { type Direction, type ConfidenceLevel } from "../specialists/contract.js";

export type ForecastKind = "directional" | "allocation_target" | "risk_flag";

export interface Forecast {
  id: string;
  kind: ForecastKind;
  /** Asset this forecast is about. */
  symbol: string;
  /** When the forecast was made. */
  madeAt: string;
  /** The specialist's stated direction (or "neutral" for allocation). */
  direction: Direction;
  /** Confidence level. */
  confidence: ConfidenceLevel;
  /** Numeric probability assigned to the bullish outcome (0-1). */
  pBullish: number;
  /** Numeric probability assigned to the bearish outcome (0-1). */
  pBearish: number;
  /** SpecialistId. */
  specialistId: string;
  /** Reasoning summary (≤ 200 chars). */
  rationale: string;
  /** Window at which the forecast should be evaluated. */
  evaluateAt: string;
  /** Optional explicit target weight (for allocation_target). */
  targetWeightPct?: number;
  /** Optional veto (for risk_flag). */
  veto?: boolean;
  /** Whether the forecast has been evaluated. */
  evaluated: boolean;
  /** Resolution. */
  outcome?: "correct" | "incorrect" | "neutral_correct" | "abstain";
  /** Brier score (0=perfect, 1=worst). */
  brierScore?: number;
  /** Direction accuracy (1 if direction matched, 0 otherwise). */
  directionAccuracy?: number;
  /** Resolution timestamp. */
  resolvedAt?: string;
  /** Actual realized move (%) for the asset over the window. */
  realizedMovePct?: number;
}

/** Convert a SpecialistOpinion to a Forecast. */
export function opinionToForecast(input: {
  opinion: { specialistId: string; direction: Direction; confidence: ConfidenceLevel; strength: number; summary: string };
  symbol: string;
  windowDays: number;
  madeAt?: string;
}): Forecast {
  // Map direction → pBullish / pBearish
  // Use direction score [-1, +1] + strength to estimate probabilities.
  const DIRECTION_SCORE: Record<Direction, number> = {
    strongly_bearish: -1.0,
    bearish: -0.7,
    mildly_bearish: -0.3,
    neutral: 0.0,
    mildly_bullish: 0.3,
    bullish: 0.7,
    strongly_bullish: 1.0,
  };
  const dirScore = DIRECTION_SCORE[input.opinion.direction];
  const baseProb = (dirScore + 1) / 2; // 0..1
  // Apply confidence + strength: scale the probability away from 0.5
  const CONFIDENCE_WEIGHT: Record<ConfidenceLevel, number> = {
    speculative: 0.05,
    tentative: 0.15,
    directional: 0.3,
    strong: 0.4,
    definitive: 0.45,
  };
  const confWeight = CONFIDENCE_WEIGHT[input.opinion.confidence];
  const strength = input.opinion.strength;
  const bullishProb = 0.5 + (baseProb - 0.5) * (1 + confWeight) * strength;
  const pBullish = Math.max(0.01, Math.min(0.99, bullishProb));
  const pBearish = 1 - pBullish;
  const madeAt = input.madeAt ?? new Date().toISOString();
  const evaluateAt = new Date(new Date(madeAt).getTime() + input.windowDays * 24 * 60 * 60 * 1000).toISOString();
  return {
    id: randomUUID(),
    kind: "directional",
    symbol: input.symbol,
    madeAt,
    direction: input.opinion.direction,
    confidence: input.opinion.confidence,
    pBullish,
    pBearish,
    specialistId: input.opinion.specialistId,
    rationale: input.opinion.summary.slice(0, 200),
    evaluateAt,
    evaluated: false,
  };
}

/** Resolution: pass the realized price change. */
export function resolveForecast(
  forecast: Forecast,
  realizedMovePct: number,
  threshold = 0.0, // 0 means any direction matters; > 0 means only moves > threshold count
): Forecast {
  if (forecast.evaluated) return forecast;
  const now = new Date().toISOString();
  // What did the market actually do?
  const actuallyBullish = realizedMovePct > threshold;
  const actuallyBearish = realizedMovePct < -threshold;
  const actuallyNeutral = !actuallyBullish && !actuallyBearish;
  // What did the forecast predict?
  const predictedBullish = forecast.pBullish > 0.5;
  const predictedBearish = forecast.pBearish > 0.5;
  // Direction accuracy
  const directionAccuracy =
    actuallyBullish && predictedBullish ? 1 :
    actuallyBearish && predictedBearish ? 1 :
    actuallyNeutral && forecast.direction === "neutral" ? 1 :
    0;
  // Brier score for the bullish prediction
  const realizedBinary = actuallyBullish ? 1 : 0;
  const brierScore = Math.pow(forecast.pBullish - realizedBinary, 2);
  const outcome =
    actuallyNeutral && forecast.direction === "neutral" ? "neutral_correct" :
    actuallyBullish && predictedBullish ? "correct" :
    actuallyBearish && predictedBearish ? "correct" :
    "incorrect";
  return {
    ...forecast,
    evaluated: true,
    outcome,
    brierScore,
    directionAccuracy,
    resolvedAt: now,
    realizedMovePct,
  };
}

/** Compute a calibration report from a list of resolved forecasts. */
export interface CalibrationReport {
  total: number;
  resolved: number;
  pending: number;
  correct: number;
  incorrect: number;
  neutralCorrect: number;
  /** Mean Brier score (0=perfect). */
  meanBrierScore: number;
  /** Direction accuracy (0..1). */
  directionAccuracy: number;
  /** Per-specialist breakdown. */
  bySpecialist: Record<string, {
    total: number;
    correct: number;
    meanBrierScore: number;
    directionAccuracy: number;
  }>;
  /** Per-confidence-level breakdown. */
  byConfidence: Record<string, {
    total: number;
    correct: number;
    meanBrierScore: number;
  }>;
}

export function buildCalibrationReport(forecasts: Forecast[]): CalibrationReport {
  const resolved = forecasts.filter(f => f.evaluated);
  const pending = forecasts.filter(f => !f.evaluated);
  const correct = resolved.filter(f => f.outcome === "correct").length;
  const incorrect = resolved.filter(f => f.outcome === "incorrect").length;
  const neutralCorrect = resolved.filter(f => f.outcome === "neutral_correct").length;
  const meanBrier = resolved.length > 0 ? resolved.reduce((acc, f) => acc + (f.brierScore ?? 0), 0) / resolved.length : 0;
  const directionAccuracy = resolved.length > 0 ? resolved.reduce((acc, f) => acc + (f.directionAccuracy ?? 0), 0) / resolved.length : 0;
  const bySpecialist: CalibrationReport["bySpecialist"] = {};
  for (const f of resolved) {
    const entry = bySpecialist[f.specialistId] ?? { total: 0, correct: 0, meanBrierScore: 0, directionAccuracy: 0 };
    entry.total++;
    if (f.outcome === "correct") entry.correct++;
    entry.meanBrierScore += f.brierScore ?? 0;
    entry.directionAccuracy += f.directionAccuracy ?? 0;
    bySpecialist[f.specialistId] = entry;
  }
  for (const k of Object.keys(bySpecialist)) {
    const e = bySpecialist[k]!;
    e.meanBrierScore = e.total > 0 ? e.meanBrierScore / e.total : 0;
    e.directionAccuracy = e.total > 0 ? e.directionAccuracy / e.total : 0;
  }
  const byConfidence: CalibrationReport["byConfidence"] = {};
  for (const f of resolved) {
    const entry = byConfidence[f.confidence] ?? { total: 0, correct: 0, meanBrierScore: 0 };
    entry.total++;
    if (f.outcome === "correct") entry.correct++;
    entry.meanBrierScore += f.brierScore ?? 0;
    byConfidence[f.confidence] = entry;
  }
  for (const k of Object.keys(byConfidence)) {
    const e = byConfidence[k]!;
    e.meanBrierScore = e.total > 0 ? e.meanBrierScore / e.total : 0;
  }
  return {
    total: forecasts.length,
    resolved: resolved.length,
    pending: pending.length,
    correct,
    incorrect,
    neutralCorrect,
    meanBrierScore: meanBrier,
    directionAccuracy,
    bySpecialist,
    byConfidence,
  };
}

/** In-memory ledger (single-process). Production would persist. */
export class ForecastLedger {
  private forecasts: Map<string, Forecast> = new Map();
  record(forecast: Forecast): Forecast {
    this.forecasts.set(forecast.id, forecast);
    return forecast;
  }
  recordMany(forecasts: Forecast[]): Forecast[] {
    for (const f of forecasts) this.forecasts.set(f.id, f);
    return forecasts;
  }
  resolve(forecastId: string, realizedMovePct: number, threshold = 0.0): Forecast | null {
    const f = this.forecasts.get(forecastId);
    if (!f) return null;
    const updated = resolveForecast(f, realizedMovePct, threshold);
    this.forecasts.set(forecastId, updated);
    return updated;
  }
  get(id: string): Forecast | undefined {
    return this.forecasts.get(id);
  }
  all(): Forecast[] {
    return [...this.forecasts.values()];
  }
  pending(): Forecast[] {
    return [...this.forecasts.values()].filter(f => !f.evaluated);
  }
  report(): CalibrationReport {
    return buildCalibrationReport(this.all());
  }
}
