/**
 * Iyaza Addendum — Item G: Gated memory promotion.
 *
 * Promotion requires all 15 gates per the addendum. Critical engineering safety
 * issues may receive a documented severity override for immediate protective
 * regression tests, but an override cannot promote a learned rule around the
 * fifteen gates. Authentication belongs at a future operator workflow boundary.
 */
import type { CandidateLifecycle } from "./lifecycle.js";

// Re-exported for convenience; not directly used in this file.
export type { CandidateLifecycle };

export const PROMOTION_GATE_NAMES = [
  "recurrence_at_least_3",
  "at_least_2_distinct_sessions",
  "source_session_provenance",
  "source_diversity",
  "multiple_assets_and_regimes_for_general_rules",
  "point_in_time_replay",
  "hidden_holdout_evaluation",
  "independent_verifier",
  "challenger_objections_addressed",
  "no_unresolved_conflict",
  "measurable_improvement_vs_baseline",
  "no_unacceptable_regression",
  "shadow_canary_observation",
  "human_approval",
  "rollback_path",
] as const;
export type PromotionGateName = (typeof PROMOTION_GATE_NAMES)[number];

export interface CandidateForGates {
  recurrenceCount: number;
  distinctSessionCount: number;
  sourceSessionIds: string[];
  sourceDiversity: "single_source" | "multi_source";
  /** True if the rule applies to multiple assets or regimes. */
  generalizesAcrossAssetsAndRegimes: boolean;
  hasPointInTimeReplay: boolean;
  hasHiddenHoldoutEvaluation: boolean;
  hasIndependentVerifier: boolean;
  challengerObjectionsAddressed: boolean;
  hasUnresolvedConflict: boolean;
  measurableImprovementVsBaseline: number; // 0..1
  hasUnacceptableRegression: boolean;
  hasShadowCanaryObservation: boolean;
  hasHumanApproval: boolean;
  hasRollbackPath: boolean;
  /** Optional severity override for critical safety issues. */
  criticalSafetyOverride?: {
    reason: string;
    approvedBy: string;
    at: string;
  };
}

export interface PromotionGateEvaluation {
  pass: boolean;
  missing: PromotionGateName[];
  /** Reserved for a future authenticated workflow; always false today. */
  viaOverride: boolean;
  /** An override was documented but was not allowed to bypass promotion. */
  overrideRecorded: boolean;
}

export function evaluatePromotionGates(candidate: CandidateForGates): PromotionGateEvaluation {
  const missing: PromotionGateName[] = [];

  if (candidate.recurrenceCount < 3) missing.push("recurrence_at_least_3");
  if (candidate.distinctSessionCount < 2) missing.push("at_least_2_distinct_sessions");
  if (candidate.sourceSessionIds.length === 0) missing.push("source_session_provenance");
  if (candidate.sourceDiversity !== "multi_source") missing.push("source_diversity");
  if (!candidate.generalizesAcrossAssetsAndRegimes) missing.push("multiple_assets_and_regimes_for_general_rules");
  if (!candidate.hasPointInTimeReplay) missing.push("point_in_time_replay");
  if (!candidate.hasHiddenHoldoutEvaluation) missing.push("hidden_holdout_evaluation");
  if (!candidate.hasIndependentVerifier) missing.push("independent_verifier");
  if (!candidate.challengerObjectionsAddressed) missing.push("challenger_objections_addressed");
  if (candidate.hasUnresolvedConflict) missing.push("no_unresolved_conflict");
  if (candidate.measurableImprovementVsBaseline <= 0) missing.push("measurable_improvement_vs_baseline");
  if (candidate.hasUnacceptableRegression) missing.push("no_unacceptable_regression");
  if (!candidate.hasShadowCanaryObservation) missing.push("shadow_canary_observation");
  if (!candidate.hasHumanApproval) missing.push("human_approval");
  if (!candidate.hasRollbackPath) missing.push("rollback_path");

  // A string-valued `approvedBy` field is not authentication. Critical issues
  // may trigger protective regression tests immediately, but promotion remains
  // fail-closed until every ordinary gate passes.
  return {
    pass: missing.length === 0,
    missing,
    viaOverride: false,
    overrideRecorded: Boolean(candidate.criticalSafetyOverride),
  };
}
