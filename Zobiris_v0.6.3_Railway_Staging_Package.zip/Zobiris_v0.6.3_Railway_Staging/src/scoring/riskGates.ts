/**
 * Hard risk gates.
 *
 * Per docs/SCORING_AND_PORTFOLIO.md:
 *   "A hard gate can force 0%, AVOID, or a strict size cap. It cannot be
 *    neutralized by a high social or momentum score."
 *
 * Each gate takes an asset context and returns either inactive or active
 * with effect (veto | size_cap | confidence_reduction) and optional cap.
 */

import { type RiskGate, type RiskLevel } from "../domain/portfolio.js";

export interface RiskGateContext {
  symbol: string;
  mappingStatus: "verified" | "ambiguous" | "unmapped" | "quarantined";
  hasMarketData: boolean;
  /** Optional downstream: exploit/contract incident flag. */
  exploitFlagged?: boolean;
  /** Optional downstream: large unlock in next 30d. */
  upcomingUnlockPct?: number;
  /** Optional: holder concentration (HHI-style 0-1). */
  holderConcentration?: number;
  /** Optional: volume vs marketcap (manipulation proxy). */
  volumeToMcRatio?: number;
  /** Optional: stale evidence flag. */
  criticalEvidenceStale?: boolean;
  /** Optional: critical evidence conflict flag. */
  criticalEvidenceConflicted?: boolean;
  /** Optional: project integrity. */
  projectIntegrityOk?: boolean;
}

export type RiskGateEvaluator = (ctx: RiskGateContext) => RiskGate;

const identityAmbiguous: RiskGateEvaluator = (ctx) => ({
  code: "IDENTITY_AMBIGUOUS",
  active: ctx.mappingStatus === "ambiguous" || ctx.mappingStatus === "quarantined",
  reason: ctx.mappingStatus === "ambiguous"
    ? "Ticker matches multiple canonical assets; manual review required."
    : "Asset is quarantined (ticker collision or integrity issue).",
  effect: "veto",
});

const identityUnmapped: RiskGateEvaluator = (ctx) => ({
  code: "IDENTITY_UNMAPPED",
  active: ctx.mappingStatus === "unmapped",
  reason: "No provider id found; cross-provider joins not safe.",
  effect: "veto",
});

const severeLiquidityCollapse: RiskGateEvaluator = (ctx) => ({
  code: "LIQUIDITY_COLLAPSE",
  active: !ctx.hasMarketData,
  reason: "No current market data; size cap is binding.",
  effect: "size_cap",
  cap: 0.5,
});

const exploitIncident: RiskGateEvaluator = (ctx) => ({
  code: "EXPLOIT_INCIDENT",
  active: Boolean(ctx.exploitFlagged),
  reason: "Exploit / contract security incident flagged.",
  effect: "veto",
});

const largeUpcomingUnlock: RiskGateEvaluator = (ctx) => ({
  code: "LARGE_UPCOMING_UNLOCK",
  active: typeof ctx.upcomingUnlockPct === "number" && ctx.upcomingUnlockPct > 5,
  reason: `Upcoming unlock > 5% of supply in next 30d (${ctx.upcomingUnlockPct?.toFixed(1)}%).`,
  effect: "size_cap",
  cap: Math.max(0.5, 1 - (ctx.upcomingUnlockPct ?? 0) / 100 * 2),
});

const holderConcentration: RiskGateEvaluator = (ctx) => ({
  code: "HOLDER_CONCENTRATION",
  active: typeof ctx.holderConcentration === "number" && ctx.holderConcentration > 0.7,
  reason: `Holder concentration > 0.7 (${ctx.holderConcentration?.toFixed(2)}).`,
  effect: "size_cap",
  cap: 1.5,
});

const suspiciousVolume: RiskGateEvaluator = (ctx) => ({
  code: "SUSPICIOUS_VOLUME",
  active: typeof ctx.volumeToMcRatio === "number" && ctx.volumeToMcRatio > 5,
  reason: `Volume/MC ratio > 5 (${ctx.volumeToMcRatio?.toFixed(1)}x) — possible wash trading.`,
  effect: "size_cap",
  cap: 1.0,
});

const staleCriticalEvidence: RiskGateEvaluator = (ctx) => ({
  code: "STALE_CRITICAL_EVIDENCE",
  active: Boolean(ctx.criticalEvidenceStale),
  reason: "Critical evidence (price, identity, or major risk input) is stale.",
  effect: "confidence_reduction",
});

const conflictedEvidence: RiskGateEvaluator = (ctx) => ({
  code: "CONFLICTED_EVIDENCE",
  active: Boolean(ctx.criticalEvidenceConflicted),
  reason: "Critical evidence sources disagree.",
  effect: "confidence_reduction",
});

const projectIntegrity: RiskGateEvaluator = (ctx) => ({
  code: "PROJECT_INTEGRITY",
  active: ctx.projectIntegrityOk === false,
  reason: "Project integrity (legal / governance / team) failed.",
  effect: "veto",
});

/** All evaluators. */
export const RISK_GATE_EVALUATORS: RiskGateEvaluator[] = [
  identityAmbiguous,
  identityUnmapped,
  severeLiquidityCollapse,
  exploitIncident,
  largeUpcomingUnlock,
  holderConcentration,
  suspiciousVolume,
  staleCriticalEvidence,
  conflictedEvidence,
  projectIntegrity,
];

/** Run all gates against a context and return the active set. */
export function evaluateRiskGates(ctx: RiskGateContext): RiskGate[] {
  return RISK_GATE_EVALUATORS.map(evaluator => evaluator(ctx)).filter(g => g.active);
}

/** Apply gates to an existing target weight. Vetoes force 0, caps clamp. */
export function applyRiskGates(weight: number, gates: RiskGate[]): number {
  let w = weight;
  for (const g of gates) {
    if (g.effect === "veto") return 0;
    if (g.effect === "size_cap" && typeof g.cap === "number") {
      w = Math.min(w, g.cap);
    }
  }
  return w;
}

/** Heuristic risk level from data presence + gates + market-derived volatility. */
export function classifyRisk(input: { gates: RiskGate[]; hasMarketData: boolean; change24hPct: number | null }): RiskLevel {
  if (input.gates.some(g => g.effect === "veto")) return "High";
  if (!input.hasMarketData) return "Unknown";
  if (input.change24hPct == null) return "Unknown";
  if (Math.abs(input.change24hPct) > 10) return "High";
  if (Math.abs(input.change24hPct) > 4) return "Moderate";
  return "Low";
}
