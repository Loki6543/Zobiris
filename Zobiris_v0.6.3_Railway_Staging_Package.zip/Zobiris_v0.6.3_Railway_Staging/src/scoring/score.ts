/**
 * Raw opportunity score.
 *
 * Per docs/SCORING_AND_PORTFOLIO.md:
 *   "A score is not a verdict, confidence is not a score, and a portfolio
 *    weight is not a score scaled to 100."
 *
 * Formula:
 *   raw = sum(factor.raw * factor.weight) for each factor family
 *   adjusted = clamp(raw - evidenceGapPenalty * (1 - coverage), 0, 100)
 */

import { type ScoringConfig, type FactorScore, DEFAULT_SCORING_CONFIG, clamp } from "../domain/scoring.js";
import { epistemicWeight } from "../domain/evidence.js";
import { type EpistemicState } from "../domain/events.js";

export interface RawFactorInput {
  family: FactorScore["family"];
  raw: number;                     // 0-100 from specialist
  epistemicState: EpistemicState;
  /** Optional: how many distinct sources contributed to this factor. */
  sourceCount?: number;
  /** Exact provider/model claims used to produce this factor. */
  evidenceClaimIds?: string[];
}

export interface RawScoreInput {
  factors: RawFactorInput[];
  /** Fraction of expected evidence that was actually present (0-1). */
  evidenceCoverage: number;
  config?: ScoringConfig;
}

export interface RawScoreOutput {
  raw: number;                     // unadjusted weighted score
  adjusted: number;                // after coverage penalty
  evidenceGapPenalty: number;
  factorScores: FactorScore[];
}

export function computeRawScore(input: RawScoreInput): RawScoreOutput {
  const cfg = input.config ?? DEFAULT_SCORING_CONFIG;
  const weights = cfg.factorWeights;
  const factors: FactorScore[] = [];
  let weightedSum = 0;
  for (const f of input.factors) {
    const w = weights[f.family];
    // Apply epistemic discount to the raw factor value.
    const epiFactor = epistemicWeight(f.epistemicState);
    const adjustedRaw = clamp(f.raw * epiFactor, 0, 100);
    const contribution = adjustedRaw * w;
    weightedSum += contribution;
    factors.push({
      family: f.family,
      raw: f.raw,
      weight: w,
      contribution: round(contribution, 4),
      evidenceClaimIds: f.evidenceClaimIds ?? [],
      epistemicState: f.epistemicState,
    });
  }
  const raw = clamp(weightedSum, 0, 100);
  const evidenceGapPenalty = Math.max(0, cfg.evidenceGapPenalty * (1 - clamp(input.evidenceCoverage, 0, 1)));
  const adjusted = clamp(raw - evidenceGapPenalty, 0, 100);
  return {
    raw: round(raw, 2),
    adjusted: round(adjusted, 2),
    evidenceGapPenalty: round(evidenceGapPenalty, 2),
    factorScores: factors,
  };
}

function round(n: number, places: number): number {
  const f = Math.pow(10, places);
  return Math.round(n * f) / f;
}
