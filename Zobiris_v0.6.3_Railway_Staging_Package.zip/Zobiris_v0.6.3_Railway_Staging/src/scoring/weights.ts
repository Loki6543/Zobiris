/**
 * Portfolio weight computation.
 *
 * Per docs/SCORING_AND_PORTFOLIO.md:
 *   rawWeight = rawEdge × confidence × volatilityScalar × liquidityScalar
 *             × regimeScalar × riskGate × diversificationScalar × correlationScalar
 *
 * Then: impose per-asset/role/sector limits, reserve, normalize.
 *
 * This module exposes a deterministic, no-side-effect calculation. It does
 * NOT enforce a 100% sum (that's the verifier's job).
 */

import { type ScoringConfig, type RiskLevel, clamp } from "../domain/scoring.js";
import { type RiskGate, type TargetWeight } from "../domain/portfolio.js";
import { applyRiskGates } from "./riskGates.js";

export interface WeightInput {
  symbol: string;
  adjustedScore: number;        // 0-100 (from computeRawScore)
  confidencePct: number;        // 0-100
  risk: RiskLevel;
  gates: RiskGate[];
  scalars: {
    volatility: number;          // 0-1
    liquidity: number;           // 0-1
    regime: number;              // 0-1
    diversification: number;      // 0-1
    correlation: number;         // 0-1
  };
  config?: ScoringConfig;
}

export function computeTargetWeight(input: WeightInput): TargetWeight {
  const cfg = input.config ?? { version: "0.1.0" } as ScoringConfig;
  const riskScalar = input.risk === "High"
    ? cfg.highRiskScalar
    : input.risk === "Moderate"
      ? cfg.moderateRiskScalar
      : 1;
  const rawEdge = clamp(input.adjustedScore - 50, 0, 50);  // only count score > 50
  const conf = clamp(input.confidencePct, 0, 100) / 100;
  const w = rawEdge * conf
    * input.scalars.volatility
    * input.scalars.liquidity
    * input.scalars.regime
    * input.scalars.diversification
    * input.scalars.correlation
    * riskScalar;
  const capped = applyRiskGates(w, input.gates);
  return {
    pct: round(capped, 4),
    rawEdge: round(rawEdge, 2),
    scalars: {
      volatility: round(input.scalars.volatility, 3),
      liquidity: round(input.scalars.liquidity, 3),
      regime: round(input.scalars.regime, 3),
      risk: round(riskScalar, 3),
      diversification: round(input.scalars.diversification, 3),
      correlation: round(input.scalars.correlation, 3),
    },
    explanation: explain(input, riskScalar, w, capped),
  };
}

function explain(input: WeightInput, riskScalar: number, raw: number, capped: number): string {
  const parts: string[] = [];
  parts.push(`rawEdge=${input.adjustedScore - 50} (score - 50)`);
  parts.push(`conf=${(input.confidencePct).toFixed(0)}%`);
  parts.push(`riskScalar=${riskScalar.toFixed(2)} (${input.risk})`);
  parts.push(`vol=${input.scalars.volatility.toFixed(2)} liq=${input.scalars.liquidity.toFixed(2)} reg=${input.scalars.regime.toFixed(2)} div=${input.scalars.diversification.toFixed(2)} cor=${input.scalars.correlation.toFixed(2)}`);
  parts.push(`raw=${raw.toFixed(2)}`);
  if (capped !== raw) parts.push(`capped=${capped.toFixed(2)}`);
  return parts.join("; ");
}

function round(n: number, places: number): number {
  const f = Math.pow(10, places);
  return Math.round(n * f) / f;
}
