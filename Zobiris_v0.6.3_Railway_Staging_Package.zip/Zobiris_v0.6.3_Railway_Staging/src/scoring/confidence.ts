/**
 * Confidence model.
 *
 * Per docs/SCORING_AND_PORTFOLIO.md:
 *   "Confidence should reflect evidence quality, not optimism. Inputs include
 *    source reputation, coverage, freshness, cross-source agreement, identity
 *    confidence, unresolved conflicts, and uncertainty."
 *
 * Formula (composable 0-100%):
 *   pct = 100 * (0.25 * sourceReputation + 0.25 * coverage + 0.20 * freshness
 *               + 0.20 * crossSourceAgreement + 0.10 * identityConfidence
 *               - 0.05 * unresolvedConflicts/10)
 *
 * The constant 0.10 identity weight is non-negotiable: ambiguous identity
 * drops confidence sharply (V5.4-style).
 */

import { type Confidence } from "../domain/portfolio.js";

export interface ConfidenceInput {
  sourceReputation: number;          // 0-1
  coverage: number;                  // 0-1
  freshness: number;                 // 0-1
  crossSourceAgreement: number;      // 0-1
  identityConfidence: number;        // 0-1
  unresolvedConflicts: number;       // int >= 0
}

export function computeConfidence(input: ConfidenceInput): Confidence {
  const conflictPenalty = Math.min(0.5, input.unresolvedConflicts * 0.05);
  const c = (n: number) => clamp(n, 0, 1);
  const base = 0.25 * c(input.sourceReputation)
             + 0.25 * c(input.coverage)
             + 0.20 * c(input.freshness)
             + 0.20 * c(input.crossSourceAgreement)
             + 0.10 * c(input.identityConfidence);
  const adjusted = Math.max(0, base - conflictPenalty);
  return {
    pct: round(adjusted * 100, 1),
    inputs: {
      sourceReputation: round(input.sourceReputation, 3),
      coverage: round(input.coverage, 3),
      freshness: round(input.freshness, 3),
      crossSourceAgreement: round(input.crossSourceAgreement, 3),
      identityConfidence: round(input.identityConfidence, 3),
      unresolvedConflicts: input.unresolvedConflicts,
    },
  };
}

function clamp(n: number, lo: number, hi: number): number {
  return Math.max(lo, Math.min(hi, n));
}
function round(n: number, places: number): number {
  const f = Math.pow(10, places);
  return Math.round(n * f) / f;
}
