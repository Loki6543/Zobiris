/**
 * Hypothesis + forecast + evaluation result.
 *
 * Per docs/AI_COGNITIVE_ENGINE.md: hypotheses must be falsifiable, with
 * pre-declared cutoffs, mechanisms, counter-evidence and invalidation.
 * Forecasts must have pre-declared probabilities and a measurable resolution
 * rule. Evaluation must be deterministic and replayable.
 */

import { z } from "zod";

export const hypothesisStatusSchema = z.enum([
  "open",
  "confirmed",
  "refuted",
  "expired",
  "retired",
]);
export type HypothesisStatus = z.infer<typeof hypothesisStatusSchema>;

export const hypothesisSchema = z.object({
  id: z.string().uuid(),
  symbol: z.string().min(1).max(16),
  statement: z.string().min(10).max(2000),
  cutoff: z.string().datetime(),          // point-in-time when stated
  mechanism: z.string().min(1).max(1000),
  invalidationConditions: z.array(z.string()).default([]),
  counterEvidence: z.array(z.string()).default([]),
  status: hypothesisStatusSchema.default("open"),
  resolvedAt: z.string().datetime().optional(),
  lineage: z.array(z.string().uuid()).default([]),
});
export type Hypothesis = z.infer<typeof hypothesisSchema>;

export const forecastSchema = z.object({
  id: z.string().uuid(),
  symbol: z.string(),
  statement: z.string(),
  probability: z.number().min(0).max(1),
  horizon: z.object({
    startAt: z.string().datetime(),
    endAt: z.string().datetime(),
    label: z.string(),
  }),
  resolutionRule: z.string().min(1).max(2000),
  resolved: z.boolean().default(false),
  outcome: z.boolean().optional(),
  brierScore: z.number().min(0).max(2).optional(),
  createdAt: z.string().datetime(),
});
export type Forecast = z.infer<typeof forecastSchema>;

/** Brier score = (forecast_prob - outcome)^2. Lower is better; 0 = perfect, 0.25 = climatology baseline for binary. */
export function brierScore(forecastProb: number, outcome: boolean): number {
  const p = forecastProb;
  const o = outcome ? 1 : 0;
  return (p - o) ** 2;
}

export const evaluationResultSchema = z.object({
  version: z.string(),
  asOf: z.string().datetime(),
  metrics: z.object({
    brierAvg: z.number().min(0).max(2).optional(),
    brierLastN: z.number().min(0).max(2).optional(),
    forecastCount: z.number().int().nonnegative(),
    closedForecastCount: z.number().int().nonnegative(),
    hitRate: z.number().min(0).max(1).optional(),
    uptimePct: z.number().min(0).max(1).optional(),
    rankStability: z.number().min(0).max(1).optional(),
  }),
  notes: z.string().optional(),
});
export type EvaluationResult = z.infer<typeof evaluationResultSchema>;
