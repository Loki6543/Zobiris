/**
 * Memory classes.
 *
 * Per docs/AI_COGNITIVE_ENGINE.md, memory is split into 7 classes:
 *   1. Episodic event ledger     — append-only analyses, tool events, outcomes
 *   2. Semantic knowledge        — versioned protocol/mechanism/entity facts
 *   3. Regime memory              — historical conditions + outcomes
 *   4. Procedural playbooks      — verified reusable research procedures
 *   5. Hypothesis registry        — hypotheses, tests, lineage, failures
 *   6. Entity/event graph         — time-stamped relationships
 *   7. User preference memory     — explicit preferences only
 *
 * Generated memories enter as CANDIDATE; promotion is gated by provenance,
 * time scope, confidence, usefulness, contradiction handling, retirement.
 */

import { z } from "zod";

export const MEMORY_CLASSES = [
  "episodic",
  "semantic",
  "regime",
  "procedural",
  "hypothesis",
  "graph",
  "userPreference",
] as const;
export type MemoryClass = (typeof MEMORY_CLASSES)[number];

export const MEMORY_STATES = ["candidate", "active", "retired", "rejected"] as const;
export type MemoryState = (typeof MEMORY_STATES)[number];

export const memoryEntrySchema = z.object({
  id: z.string().uuid(),
  class: z.enum(MEMORY_CLASSES),
  state: z.enum(MEMORY_STATES).default("candidate"),
  content: z.string().min(1),
  provenance: z.array(z.string()).min(1),     // observation ids, urls, file refs
  timeScope: z.object({
    validFrom: z.string().datetime(),
    validUntil: z.string().datetime().optional(),
  }),
  confidence: z.number().min(0).max(1),
  contradictions: z.array(z.string()).default([]),
  promotedAt: z.string().datetime().optional(),
  promotedBy: z.string().optional(),
  retiredAt: z.string().datetime().optional(),
  retirementReason: z.string().optional(),
});
export type MemoryEntry = z.infer<typeof memoryEntrySchema>;

/** Promotion gate: candidate memory must have provenance, valid time scope, non-zero confidence. */
export function canPromoteMemory(entry: MemoryEntry): { ok: boolean; reason?: string } {
  if (entry.state !== "candidate") return { ok: false, reason: `state is ${entry.state}, not candidate` };
  if (entry.provenance.length === 0) return { ok: false, reason: "no provenance" };
  if (entry.confidence <= 0) return { ok: false, reason: "confidence must be > 0" };
  if (entry.contradictions.length > 0) return { ok: false, reason: `unresolved contradictions: ${entry.contradictions.join("; ")}` };
  return { ok: true };
}
