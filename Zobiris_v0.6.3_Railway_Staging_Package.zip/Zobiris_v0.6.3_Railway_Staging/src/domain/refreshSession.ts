/**
 * Refresh session + decision contract.
 *
 * Per docs/PRODUCT_REQUIREMENTS.md: a refresh opens a session with point-in-time
 * cutoff, runs the 19-stage contract, persists a snapshot, computes What Changed.
 *
 * The decision contract is what the user actually trusts: it carries the
 * declared confidence, ruin gate, reversibility, retries and counterfactuals
 * for the current portfolio decision.
 */

import { z } from "zod";
import { portfolioAnalysisSnapshotSchema } from "./portfolio.js";

export const REFRESH_MODES = ["daily", "deep", "challenge"] as const;
export type RefreshMode = (typeof REFRESH_MODES)[number];

export const refreshSessionSchema = z.object({
  id: z.string().uuid(),
  mode: z.enum(REFRESH_MODES),
  startedAt: z.string().datetime(),
  completedAt: z.string().datetime().optional(),
  pointInTimeCutoff: z.string().datetime(),
  policyVersion: z.string(),
  specialistRoster: z.array(z.string()).default([]),
  stages: z.array(z.object({
    index: z.number().int().nonnegative(),
    name: z.string(),
    // v0.4.2 audit fix: the stage status enum now includes `not_configured`
    // and `degraded` so the runtime can record a truthful terminal state
    // for every one of the 19 stages. A stage that was skipped because
    // its work was not configured is now distinguishable from a stage
    // that succeeded.
    status: z.enum(["pending", "running", "succeeded", "failed", "skipped", "not_configured", "degraded"]),
    startedAt: z.string().datetime().optional(),
    completedAt: z.string().datetime().optional(),
    notes: z.string().optional(),
  })).default([]),
  verifierOutput: z.object({
    passed: z.boolean(),
    findings: z.array(z.object({
      severity: z.enum(["error", "warn", "info"]),
      code: z.string(),
      message: z.string(),
    })).default([]),
  }).optional(),
  challengerOutput: z.object({
    questions: z.array(z.object({
      symbol: z.string(),
      question: z.string(),
      priority: z.enum(["High", "Medium", "Low"]),
    })).default([]),
  }).optional(),
  snapshot: portfolioAnalysisSnapshotSchema.optional(),
  error: z.string().optional(),
});
export type RefreshSession = z.infer<typeof refreshSessionSchema>;

export const decisionContractSchema = z.object({
  version: z.string(),
  asOf: z.string().datetime(),
  symbol: z.string(),
  role: z.enum(["CORE", "GROWTH", "ASYMMETRIC", "TACTICAL", "WATCHLIST", "EXIT_CANDIDATE"]),
  action: z.enum(["STRONG_BUY", "BUY", "ACCUMULATE", "HOLD", "REDUCE", "EXIT", "AVOID", "RESEARCH", "REVALIDATE", "INSUFFICIENT_DATA"]),
  declaredConfidence: z.number().min(0).max(100),
  ruinGate: z.object({
    code: z.string(),
    active: z.boolean(),
    description: z.string(),
  }),
  reversibility: z.enum(["HIGH", "MEDIUM", "LOW", "IRREVERSIBLE"]),
  retries: z.number().int().nonnegative(),
  counterfactuals: z.array(z.string()).default([]),
  invalidationConditions: z.array(z.string()).default([]),
});
export type DecisionContract = z.infer<typeof decisionContractSchema>;
