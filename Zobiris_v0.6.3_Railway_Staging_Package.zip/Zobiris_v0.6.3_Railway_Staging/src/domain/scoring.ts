/**
 * Scoring vocabulary.
 *
 * Per docs/SCORING_AND_PORTFOLIO.md:
 *   - Score ≠ Confidence ≠ Target Weight
 *   - Opportunity Rank (raw attractiveness) vs Allocation Rank (capital priority)
 *   - Role vocabulary: Core / Growth / Asymmetric / Tactical / Watch / Exit Candidate
 *   - Action vocabulary: Strong Buy / Buy / Accumulate / Hold / Reduce / Exit / Avoid
 *
 * Hard risk gates (veto / size cap) are NOT part of the raw score; they
 * override the score after the fact.
 */

import { z } from "zod";

export const PORTFOLIO_ROLES = [
  "CORE",
  "GROWTH",
  "ASYMMETRIC",
  "TACTICAL",
  "WATCHLIST",
  "EXIT_CANDIDATE",
] as const;
export type PortfolioRole = (typeof PORTFOLIO_ROLES)[number];

export const ACTION_LABELS = [
  "STRONG_BUY",
  "BUY",
  "ACCUMULATE",
  "HOLD",
  "REDUCE",
  "EXIT",
  "AVOID",
  "RESEARCH",
  "REVALIDATE",
  "INSUFFICIENT_DATA",
] as const;
export type ActionLabel = (typeof ACTION_LABELS)[number];

export const RISK_LEVELS = ["Low", "Moderate", "High", "Unknown"] as const;
export type RiskLevel = (typeof RISK_LEVELS)[number];

export const factorScoreSchema = z.object({
  family: z.enum([
    "marketTechnical",
    "fundamentalTokenomics",
    "liquidityMarketStructure",
    "socialAttention",
    "derivativesLeverage",
    "onchainPositioning",
    "catalystsNarrative",
    "asymmetryConvexity",
  ]),
  raw: z.number().min(0).max(100),             // 0-100 input from specialist
  weight: z.number().min(0).max(1),           // factor weight in this config version
  contribution: z.number(),                   // raw * weight
  evidenceClaimIds: z.array(z.string().uuid()).default([]),
  epistemicState: z.enum(["KNOWN", "INFERRED", "UNCERTAIN", "CONFLICTED", "UNKNOWN", "STALE"]),
});
export type FactorScore = z.infer<typeof factorScoreSchema>;

export const scoringConfigSchema = z.object({
  version: z.string().regex(/^\d+\.\d+\.\d+$/),
  factorWeights: z.object({
    marketTechnical: z.number().min(0).max(1),
    fundamentalTokenomics: z.number().min(0).max(1),
    liquidityMarketStructure: z.number().min(0).max(1),
    socialAttention: z.number().min(0).max(1),
    derivativesLeverage: z.number().min(0).max(1),
    onchainPositioning: z.number().min(0).max(1),
    catalystsNarrative: z.number().min(0).max(1),
    asymmetryConvexity: z.number().min(0).max(1),
  }).refine(w => Math.abs(Object.values(w).reduce((s,v)=>s+v, 0) - 1) < 0.001, "weights must sum to 1"),
  buyThreshold: z.number().min(0).max(100).default(86),
  accumulateThreshold: z.number().min(0).max(100).default(77),
  holdThreshold: z.number().min(0).max(100).default(68),
  minConfidenceForBuy: z.number().min(0).max(100).default(72),
  highRiskScalar: z.number().min(0).max(1).default(0.68),
  moderateRiskScalar: z.number().min(0).max(1).default(0.84),
  evidenceGapPenalty: z.number().min(0).max(100).default(12),
  reservePct: z.number().min(0).max(50).default(10),
});
export type ScoringConfig = z.infer<typeof scoringConfigSchema>;

/** Default factor weights. Per docs/SCORING_AND_PORTFOLIO.md. Versioned, mutable, evaluated. */
export const DEFAULT_SCORING_CONFIG: ScoringConfig = {
  version: "0.4.7",
  factorWeights: {
    marketTechnical: 0.20,
    fundamentalTokenomics: 0.15,
    liquidityMarketStructure: 0.15,
    socialAttention: 0.15,
    derivativesLeverage: 0.10,
    onchainPositioning: 0.10,
    catalystsNarrative: 0.10,
    asymmetryConvexity: 0.05,
  },
  buyThreshold: 86,
  accumulateThreshold: 77,
  holdThreshold: 68,
  minConfidenceForBuy: 72,
  highRiskScalar: 0.68,
  moderateRiskScalar: 0.84,
  evidenceGapPenalty: 12,
  reservePct: 10,
};

/** Clamp a number to [lo, hi]. */
export function clamp(n: number, lo: number, hi: number): number {
  return Math.max(lo, Math.min(hi, n));
}
