/**
 * Evidence model.
 *
 * Evidence claims are the user-facing language of "why Zobiris believes this."
 * They are derived from normalized observations but live in their own object
 * so the UI can render the evidence ledger and the scoring engine can attribute
 * factors to specific evidence.
 *
 * The 6 epistemic states (KNOWN / INFERRED / UNCERTAIN / CONFLICTED / UNKNOWN / STALE)
 * are the contract for what the UI is allowed to display.
 */

import { z } from "zod";
import { EPISTEMIC_STATES, type EpistemicState } from "./events.js";

export type { EpistemicState };

export const CLAIM_ORIGINS = [
  "provider",      // derived from a real provider observation
  "model",         // derived from an LLM/Soofi call (with parent claim IDs)
  "synthetic",     // fixture/test data; cannot drive production scoring
  "rehydrated",    // rehydrated from a prior session; identity may be legacy
] as const;
export type ClaimOrigin = (typeof CLAIM_ORIGINS)[number];

export const evidenceClaimSchema = z.object({
  id: z.string().uuid(),
  /** Source observation id (slice 2). Required for provider claims. */
  observationId: z.string().uuid().optional(),
  symbol: z.string().min(1).max(16),
  factorFamily: z.enum([
    "marketTechnical",
    "fundamentalTokenomics",
    "liquidityMarketStructure",
    "socialAttention",
    "derivativesLeverage",
    "onchainPositioning",
    "catalystsNarrative",
    "asymmetryConvexity",
    "macro",
    "identity",
    "model",
    // v0.4.3 audit fix (P1): unknown event types are quarantined as
    // "unclassified" rather than silently scored as marketTechnical.
    "unclassified",
  ]),
  claim: z.string().min(1).max(2000),
  source: z.string(),                          // provider name + endpoint or paper trail
  observedAt: z.string().datetime(),
  receivedAt: z.string().datetime(),
  freshnessAgeSeconds: z.number().int().nonnegative(),
  epistemicState: z.enum(EPISTEMIC_STATES),
  evidenceConfidence: z.number().min(0).max(1),
  licenseClass: z.string().default("display-only"),
  providerIds: z.array(z.string()).default([]),
  // v0.4.4 audit fix: typed provenance. The audit forbade string-prefix
  // detection (e.g. `claim.startsWith("synthetic:")`). Now we have
  // a typed enum and a `syntheticClaim: boolean` is computed from it
  // (NOT from the claim text).
  claimOrigin: z.enum(CLAIM_ORIGINS).default("provider"),
  // v0.4.4 audit fix (P0 #12): freshness as a typed field (was implicit
  // in freshnessAgeSeconds). One of: live | delayed | stale | unavailable.
  freshness: z.enum(["live", "delayed", "stale", "unavailable"]).default("live"),
  // v0.4.4 audit fix: dataMode. A "fallback" claim MUST be marked so
  // the runtime can apply the no-new-positive-score rule.
  dataMode: z.enum(["live", "snapshot", "fallback"]).default("live"),
  // v0.4.4 audit fix: payload hash for tamper detection / dedup.
  payloadHash: z.string().optional(),
  // v0.4.4 audit fix: transformation version (which normalizer version).
  transformationVersion: z.string().default("0.0.0"),
  // v0.4.4 audit fix: provider endpoint that produced the underlying
  // observation. Required for the click-through proof chain.
  providerEndpoint: z.string().optional(),
  // v0.4.4 audit fix: model info for "model" claims (LLM provenance).
  modelProvider: z.string().optional(),
  modelVersion: z.string().optional(),
  // v0.4.4 audit fix: parent claim IDs for "model" claims.
  // Model claims MUST cite the parent claims they consumed.
  parentClaimIds: z.array(z.string().uuid()).default([]),
  notes: z.string().max(2000).optional(),
});
export type EvidenceClaim = z.infer<typeof evidenceClaimSchema>;

/**
 * v0.4.4 audit fix: synthetic-claim integrity.
 *
 * The previous code checked `claim.startsWith("synthetic:")` to
 * detect synthetic claims. The audit forbade that pattern. Now
 * we use the typed `claimOrigin` field.
 */
export function isSyntheticClaim(claim: EvidenceClaim): boolean {
  return claim.claimOrigin === "synthetic";
}

/** A claim is "displayable" only if it's not UNKNOWN or STALE. */
export function isDisplayable(state: EpistemicState): boolean {
  return state !== "UNKNOWN" && state !== "STALE";
}

/** Weight-class mapping for the UI: higher epistemic weight = stronger claim. */
export function epistemicWeight(state: EpistemicState): number {
  switch (state) {
    case "KNOWN": return 1.0;
    case "INFERRED": return 0.7;
    case "UNCERTAIN": return 0.5;
    case "CONFLICTED": return 0.4;
    case "STALE": return 0.2;
    case "UNKNOWN": return 0.0;
  }
}
