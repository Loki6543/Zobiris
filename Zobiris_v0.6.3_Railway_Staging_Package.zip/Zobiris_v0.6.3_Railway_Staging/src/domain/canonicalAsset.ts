/**
 * Canonical asset identity.
 *
 * Ticker is NEVER the primary key. Tickers collide (UNI = Uniswap OR Unison OR
 * many other tokens). The canonical asset table is the single source of truth
 * for joining provider data.
 *
 * Mapping states:
 *   - verified:    provider id + on-chain contract/chain confirmed
 *   - ambiguous:   ticker matches multiple provider entries; manual review required
 *   - unmapped:    no provider id found yet
 *   - quarantined: known ticker collision; do NOT auto-join provider data
 *
 * Per docs/ARCHITECTURE.md and acceptance_contract.json, ambiguous assets
 * are release-blockers and must not contribute to automated cross-provider
 * joins.
 */

import { z } from "zod";
import { resolveCanonicalIdentity } from "../providers/canonicalResolve.js";

export const MAPPING_STATUSES = ["verified", "ambiguous", "unmapped", "quarantined"] as const;
export type MappingStatus = (typeof MAPPING_STATUSES)[number];

export const chainIdSchema = z.string().min(1).max(64);
export const contractAddressSchema = z.string().regex(/^0x[a-fA-F0-9]{40}$/, "must be 0x-prefixed 20-byte EVM address").or(
  z.string().min(20).max(80)
);
export const providerIdSchema = z.string().min(1).max(64);

export const canonicalAssetSchema = z.object({
  id: z.string().uuid(),
  symbol: z.string().min(1).max(16).toUpperCase(),
  name: z.string().min(1).max(120),
  chainId: chainIdSchema.optional(),
  contractAddress: contractAddressSchema.optional(),
  providerIds: z.record(z.string(), z.string()),  // provider -> provider asset id
  mappingStatus: z.enum(MAPPING_STATUSES),
  mappingConfidence: z.number().min(0).max(1),
  // v0.4.4 audit fix (P0 #5): the identity provenance records the
  // strongest identity known at the time the canonical id was
  // generated. The id itself is an OPAQUE UUIDv4 — it is NEVER
  // derived from a current alias. New identity information is
  // appended to `providerIds` and the identity_provenance column
  // in storage; the id does not change.
  //
  // Optional with default: pre-v0.4.4 fixtures and tests can omit
  // it; the runtime stamps "uuidv4-initial" by default.
  identityProvenance: z.enum([
    "uuidv4-initial",          // opaque UUID generated on first encounter
    "uuidv4-persisted",        // opaque UUID loaded from storage
    "persistence-rehydrated",  // rehydrated from a prior session
    "fallback",                // identity is unknown; asset is quarantined
  ]).optional(),
  updatedAt: z.string().datetime(),
});
export type CanonicalAsset = z.infer<typeof canonicalAssetSchema>;

/** True if this asset is safe to auto-join with provider data. */
export function isAutoJoinable(asset: CanonicalAsset): boolean {
  return asset.mappingStatus === "verified" && asset.mappingConfidence >= 0.8;
}

/**
 * Ticker collision guard.
 *
 * If two CanonicalAssets share the same symbol but have different
 * canonical ids, both are quarantined (returns both). This is the
 * pre-flight check before any provider join.
 */
export function detectTickerCollision(assets: CanonicalAsset[]): Map<string, CanonicalAsset[]> {
  const bySymbol = new Map<string, CanonicalAsset[]>();
  for (const a of assets) {
    const list = bySymbol.get(a.symbol) ?? [];
    list.push(a);
    bySymbol.set(a.symbol, list);
  }
  const collisions = new Map<string, CanonicalAsset[]>();
  for (const [symbol, list] of bySymbol) {
    if (list.length > 1) collisions.set(symbol, list);
  }
  return collisions;
}

/**
 * Build a deterministic canonical id from a chain + contract (or fallback to
 * symbol + chain). v0.4.3 fix: routes through resolveCanonicalIdentity()
 * so the id is always `cn-<hex>`, never `sym:TICKER`. The previous
 * implementation produced `sym:BTC` for any symbol-only path; the v0.4.2
 * audit caught that as a false-positive risk. v0.4.3 uses the same
 * SHA-256-based resolver as the production code path.
 */
export function buildCanonicalId(input: { chainId?: string; contractAddress?: string; symbol: string; cmcId?: string }): string {
  if (input.chainId && input.contractAddress) {
    return resolveCanonicalIdentity({
      provider: "chain",
      providerAssetId: `${input.chainId}:${input.contractAddress}`,
      symbol: input.symbol,
      chainId: input.chainId,
      contractAddress: input.contractAddress,
    }).canonicalAssetId;
  }
  if (input.cmcId) {
    return resolveCanonicalIdentity({
      provider: "cmc",
      providerAssetId: input.cmcId,
      symbol: input.symbol,
    }).canonicalAssetId;
  }
  // Symbol fallback. v0.4.3: the caller should treat this id as
  // `mappingStatus: "ambiguous"` — see lookupCanonicalIdentity().
  return resolveCanonicalIdentity({
    provider: "fallback",
    providerAssetId: "",
    symbol: input.symbol,
  }).canonicalAssetId;
}
