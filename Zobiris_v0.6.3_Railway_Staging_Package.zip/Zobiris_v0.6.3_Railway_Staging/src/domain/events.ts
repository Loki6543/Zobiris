/**
 * Event model.
 *
 * Per docs/ARCHITECTURE.md and CoinGlass/Bitquery blueprint, every observation/event must carry:
 *   - unique event id
 *   - deterministic idempotency key
 *   - provider id
 *   - provider event id (if any)
 *   - event type
 *   - schema version
 *   - canonical asset id OR quarantine state
 *   - source/provider timestamp
 *   - occurred-at timestamp
 *   - received-at timestamp
 *   - retrieval timestamp (where meaningful)
 *   - transformation/normalizer version
 *   - payload
 *   - evidence confidence/quality metadata
 *   - license/display class
 *
 * Upstream delivery is at-least-once and possibly unordered. Zobiris provides
 * idempotent storage and exactly-once observable effects.
 */

import { z } from "zod";

export const FRESHNESS_STATES = ["live", "delayed", "stale", "backfilling", "unavailable"] as const;
export type FreshnessState = (typeof FRESHNESS_STATES)[number];

export const EPISTEMIC_STATES = ["KNOWN", "INFERRED", "UNCERTAIN", "CONFLICTED", "UNKNOWN", "STALE"] as const;
export type EpistemicState = (typeof EPISTEMIC_STATES)[number];

/** Provider-reported raw observation. May have missing or stale fields. */
export const providerHealthSchema = z.object({
  provider: z.string(),
  status: z.enum(["connected", "degraded", "disconnected", "credentials-needed", "adapter-needed", "snapshot"]),
  lastConnectedAt: z.string().datetime().optional(),
  lastMessageAt: z.string().datetime().optional(),
  lastEventAt: z.string().datetime().optional(),
  lastErrorAt: z.string().datetime().optional(),
  lastErrorClass: z.string().optional(),  // e.g. "rate_limit", "schema_mismatch", "auth"
  reconnectAttempt: z.number().int().nonnegative().default(0),
  freshness: z.enum(FRESHNESS_STATES).default("unavailable"),
});
export type ProviderHealth = z.infer<typeof providerHealthSchema>;

/** A single normalized observation emitted by a provider adapter. */
export const normalizedObservationSchema = z.object({
  id: z.string().uuid(),
  idempotencyKey: z.string().min(8),     // deterministic per source event
  provider: z.string(),                  // "kraken" | "cmc" | "lunarcrush" | ...
  providerEventId: z.string().optional(),
  eventType: z.string(),                 // "ticker" | "quote" | "social_snapshot" | "funding" | "liquidation" | ...
  schemaVersion: z.string().regex(/^\d+\.\d+\.\d+$/),
  canonicalAssetId: z.string().nullable(),   // null if quarantined
  quarantineState: z.enum(["verified", "ambiguous", "unmapped", "quarantined"]).default("verified"),
  sourceTimestamp: z.string().datetime().optional(),
  occurredAt: z.string().datetime(),
  receivedAt: z.string().datetime(),
  retrievedAt: z.string().datetime().optional(),
  normalizerVersion: z.string(),
  // v0.4.3 audit fix: how this observation's canonical id was derived.
  // A symbol-only join is recorded as "symbol-only" so the scoring layer
  // and audit trail can refuse to treat it as verified evidence.
  // v0.4.4 audit fix: "persistence-symbol-fallback" is added for
  // observations whose canonical id was resolved at persistence time
  // through a symbol lookup (the integration fallback path). Such
  // observations are recorded as ambiguous.
  identityMatchMethod: z.enum([
    "id", "provider-id", "provider-slug", "contract",
    "chain+symbol", "symbol-only", "fallback",
    "persistence-symbol-fallback",
  ]).nullable().optional(),
  /** Transport/source provenance stamped by the refresh boundary. */
  dataMode: z.enum(["live", "snapshot", "fallback"]).optional(),
  providerEndpoint: z.string().optional(),
  requestedSymbol: z.string().optional(),
  requestedExchange: z.string().optional(),
  providerGeneratedAt: z.string().datetime().optional(),
  fallbackReason: z.string().optional(),
  upstreamFailure: z.object({
    class: z.enum(["network", "auth", "rate_limit", "schema_mismatch", "server_error"]),
    status: z.number().int().optional(),
    message: z.string().optional(),
  }).optional(),
  /** SHA-256 of the provider payload before normalization. */
  payloadHash: z.string().regex(/^[a-f0-9]{64}$/).optional(),
  payload: z.unknown(),
  epistemicState: z.enum(EPISTEMIC_STATES).default("KNOWN"),
  evidenceConfidence: z.number().min(0).max(1).default(1),
  licenseClass: z.string().default("display-only"),
});
export type NormalizedObservation = z.infer<typeof normalizedObservationSchema>;

/** Deterministic idempotency key. Same source event always produces the same key. */
export function makeIdempotencyKey(input: {
  provider: string;
  providerEventId?: string;
  canonicalAssetId: string | null;
  eventType: string;
  sourceTimestamp?: string;
}): string {
  // If provider supplies its own event id, use it; otherwise compose from the
  // dimensions that uniquely identify the event in the upstream feed.
  if (input.providerEventId) {
    return `${input.provider}:${input.eventType}:${input.providerEventId}`;
  }
  const asset = input.canonicalAssetId ?? "quarantined";
  return `${input.provider}:${input.eventType}:${asset}:${input.sourceTimestamp ?? "no-ts"}`;
}
