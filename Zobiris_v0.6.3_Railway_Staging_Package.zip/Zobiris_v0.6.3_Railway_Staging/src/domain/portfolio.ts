/**
 * Portfolio + analysis snapshot.
 *
 * Per docs/PRODUCT_REQUIREMENTS.md: every asset must have a case file with
 * score, confidence, target weight, action, role, conclusion, evidence, etc.
 * Per ACCEPTANCE_TESTS.md: weights + reserve must sum to 100% within rounding.
 */

import { z } from "zod";
import { factorScoreSchema, type ActionLabel, type PortfolioRole, type RiskLevel } from "./scoring.js";
import { EPISTEMIC_STATES } from "./events.js";

export const opportunitySchema = z.object({
  raw: z.number().min(0).max(100),
  adjusted: z.number().min(0).max(100),     // after freshness/confidence/risk gate
  evidenceGapPenalty: z.number().min(0).max(100).default(0),
  factorScores: z.array(factorScoreSchema),
});
export type Opportunity = z.infer<typeof opportunitySchema>;

export const confidenceSchema = z.object({
  pct: z.number().min(0).max(100),
  inputs: z.object({
    sourceReputation: z.number().min(0).max(1),
    coverage: z.number().min(0).max(1),
    freshness: z.number().min(0).max(1),
    crossSourceAgreement: z.number().min(0).max(1),
    identityConfidence: z.number().min(0).max(1),
    unresolvedConflicts: z.number().int().nonnegative(),
  }),
});
export type Confidence = z.infer<typeof confidenceSchema>;

export const riskGateSchema = z.object({
  code: z.string(),
  active: z.boolean(),
  reason: z.string(),
  effect: z.enum(["veto", "size_cap", "confidence_reduction"]),
  cap: z.number().min(0).max(100).optional(),
});
export type RiskGate = z.infer<typeof riskGateSchema>;

export const targetWeightSchema = z.object({
  pct: z.number().min(0).max(100),
  rawEdge: z.number().min(0).max(100),
  scalars: z.object({
    volatility: z.number().min(0).max(1),
    liquidity: z.number().min(0).max(1),
    regime: z.number().min(0).max(1),
    risk: z.number().min(0).max(1),
    diversification: z.number().min(0).max(1),
    correlation: z.number().min(0).max(1),
  }),
  explanation: z.string(),
});
export type TargetWeight = z.infer<typeof targetWeightSchema>;

export const assetAnalysisSnapshotSchema = z.object({
  symbol: z.string().min(1).max(16),
  canonicalAssetId: z.string().nullable(),
  mappingStatus: z.enum(["verified", "ambiguous", "unmapped", "quarantined"]),
  asOf: z.string().datetime(),
  opportunity: opportunitySchema,
  confidence: confidenceSchema,
  riskGates: z.array(riskGateSchema),
  targetWeight: targetWeightSchema,
  role: z.enum(["CORE", "GROWTH", "ASYMMETRIC", "TACTICAL", "WATCHLIST", "EXIT_CANDIDATE"]),
  action: z.enum(["STRONG_BUY", "BUY", "ACCUMULATE", "HOLD", "REDUCE", "EXIT", "AVOID", "RESEARCH", "REVALIDATE", "INSUFFICIENT_DATA"]),
  risk: z.enum(["Low", "Moderate", "High", "Unknown"]),
  evidenceClaimIds: z.array(z.string().uuid()),
  counterEvidenceClaimIds: z.array(z.string().uuid()).default([]),
  evidenceState: z.enum(EPISTEMIC_STATES),
  conclusion: z.string(),
  scenarios: z.object({
    bull: z.string().optional(),
    base: z.string().optional(),
    bear: z.string().optional(),
  }).default({}),
  invalidationConditions: z.array(z.string()).default([]),
  opportunityRank: z.number().int().positive().nullable().default(null),
  allocationRank: z.number().int().positive().nullable().default(null),
  evidenceCoverage: z.number().min(0).max(1),
  criticalUnknowns: z.number().int().nonnegative().default(0),
  /** v0.6.0 Strategy Engine 2.1 decision layer. */
  strategy21: z.unknown().optional(),
});
export type AssetAnalysisSnapshot = z.infer<typeof assetAnalysisSnapshotSchema>;

export const refreshStageSchema = z.object({
  index: z.number().int().positive(),
  name: z.string(),
  status: z.string(),
  notes: z.string().optional(),
  startedAt: z.string().datetime().optional(),
  completedAt: z.string().datetime().optional(),
});
export type RefreshStage = z.infer<typeof refreshStageSchema>;

export const portfolioAnalysisSnapshotSchema = z.object({
  asOf: z.string().datetime(),
  policyVersion: z.string(),
  regime: z.string(),
  regimeConfidence: z.number().min(0).max(100),
  totalAllocatedPct: z.number().min(0).max(100),
  reservePct: z.number().min(0).max(100),
  unallocatedPct: z.number().min(0).max(100),
  conclusion: z.string(),
  rankedAssets: z.array(assetAnalysisSnapshotSchema),
  sectorConcentration: z.record(z.string(), z.number()).default({}),
  narrativeConcentration: z.record(z.string(), z.number()).default({}),
  topRiskGates: z.array(riskGateSchema).default([]),
  changesSinceLastRefresh: z.object({
    rankUps: z.array(z.string()).default([]),
    rankDowns: z.array(z.string()).default([]),
    newTopTen: z.array(z.string()).default([]),
    droppedTopTen: z.array(z.string()).default([]),
    largestTargetWeightChanges: z.array(z.object({ symbol: z.string(), from: z.number(), to: z.number() })).default([]),
  }).default({ rankUps: [], rankDowns: [], newTopTen: [], droppedTopTen: [], largestTargetWeightChanges: [] }),
  /** Slice 2: 19-stage telemetry embedded in the snapshot. */
  stages: z.array(refreshStageSchema).default([]),
  /** v0.6.0 Strategy Engine 2.1 market/capital summary. */
  strategy21: z.unknown().optional(),
});
export type PortfolioAnalysisSnapshot = z.infer<typeof portfolioAnalysisSnapshotSchema>;

/** Re-export so consumers can import everything from one place. */
export type { ActionLabel, PortfolioRole, RiskLevel };
