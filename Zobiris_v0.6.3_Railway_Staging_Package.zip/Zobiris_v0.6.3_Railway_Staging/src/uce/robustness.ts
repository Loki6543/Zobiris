/**
 * Iyaza Addendum — Item F: UCE-style robustness/sensitivity analysis.
 *
 * For material portfolio comparisons: hard constraints first, then perturbed
 * Monte Carlo to estimate winner-flip rate and rank stability. Returns a
 * typed verdict; never uses Monte Carlo to compensate for weak evidence.
 */

export type CriterionDirection = "maximize" | "minimize" | "target";

export interface Criterion {
  id: string;
  direction: CriterionDirection;
  /** Only used when direction === "target" */
  target?: number;
  /** Initial weight. */
  weight: number;
}

export interface Option {
  id: string;
  /** Per-criterion normalized score, 0..1 */
  criteria: Record<string, number>;
  /** Optional hard constraints. If any value is false, the option is excluded. */
  hardConstraints?: Record<string, boolean>;
}

export interface UncertainInput {
  id: string;
  low: number;
  likely: number;
  high: number;
}

export type UceVerdict =
  | "DOMINANT_ROBUST"
  | "DOMINANT_FRAGILE"
  | "NO_CLEAR_DOMINANCE"
  | "CONSTRAINT_BLOCKED"
  | "INSUFFICIENT_EVIDENCE"
  | "STALE_EVIDENCE";

export interface RobustnessResult {
  verdict: UceVerdict;
  /** Fraction of MC iterations where the winner changes vs the base winner. */
  winnerFlipRate: number;
  /** 0..1, 1 = perfectly stable ranking across all iterations. */
  rankStability: number;
  iterations: number;
  baseWinner: string | null;
  confidenceInterval: { option: string; pWin: number }[];
  allOptionWins: Record<string, number>;
}

export interface RobustnessOpts {
  options: Option[];
  criteria: Criterion[];
  uncertainInputs?: UncertainInput[];
  /** Default 1000. */
  iterations?: number;
  /** For determinism; default Math.random (unseeded). */
  seed?: number;
  /** Maximum staleness for any criterion value (ISO datetime). */
  freshnessCutoff?: string;
}

/** Mulberry32 PRNG. Deterministic given a seed. */
function makeRng(seed: number): () => number {
  let a = seed >>> 0;
  return function () {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/** Triangular distribution sample. */
function triangularSample(rng: () => number, low: number, likely: number, high: number): number {
  const u = rng();
  const f = (likely - low) / (high - low);
  if (u < f) {
    return low + Math.sqrt(u * (high - low) * (likely - low));
  } else {
    return high - Math.sqrt((1 - u) * (high - low) * (high - likely));
  }
}

function scoreOption(option: Option, perturbedCriteria: Criterion[]): number {
  let s = 0;
  for (const c of perturbedCriteria) {
    const v = option.criteria[c.id];
    if (v === undefined) continue;
    let normalized = v;
    if (c.direction === "minimize") normalized = 1 - v;
    if (c.direction === "target" && c.target !== undefined) {
      const d = Math.abs(v - c.target);
      normalized = Math.max(0, 1 - d);
    }
    s += normalized * c.weight;
  }
  return s;
}

function passesHardConstraints(option: Option): boolean {
  if (!option.hardConstraints) return true;
  for (const v of Object.values(option.hardConstraints)) {
    if (!v) return false;
  }
  return true;
}

/** Spearman footrule-style rank stability (0..1). */
function rankStability(observedRanks: Map<string, number[]>, options: Option[]): number {
  if (options.length < 2) return 1;
  const n = options.length;
  const ids = options.map((o) => o.id);
  // Average rank of each option across iterations
  const avgRanks: Record<string, number> = {};
  for (const id of ids) {
    const ranks = observedRanks.get(id) ?? [];
    avgRanks[id] = ranks.length > 0 ? ranks.reduce((a, b) => a + b, 0) / ranks.length : 0;
  }
  // Standard deviation of ranks for each option
  let totalVar = 0;
  for (const id of ids) {
    const ranks = observedRanks.get(id) ?? [];
    const mean = avgRanks[id]!;
    const variance = ranks.reduce((a, b) => a + (b - mean) ** 2, 0) / Math.max(ranks.length, 1);
    totalVar += variance;
  }
  // Max possible variance for n options is roughly (n-1)^2 / 4
  const maxVar = (n - 1) ** 2;
  return Math.max(0, 1 - totalVar / (n * maxVar));
}

export function runRobustness(opts: RobustnessOpts): RobustnessResult {
  const iterations = opts.iterations ?? 1000;
  const rng = makeRng(opts.seed ?? Math.floor(Math.random() * 2 ** 31));
  const useRng = opts.seed !== undefined;
  const random = useRng ? rng : Math.random;

  // Stale-evidence check
  if (opts.freshnessCutoff) {
    // We don't have per-criterion timestamps in the input; we just check the freshnessCutoff param.
    // This is a placeholder; the real check requires the caller to supply per-criterion timestamps.
  }

  // Empty options: insufficient evidence
  if (opts.options.length === 0) {
    return {
      verdict: "INSUFFICIENT_EVIDENCE",
      winnerFlipRate: 0,
      rankStability: 0,
      iterations: 0,
      baseWinner: null,
      confidenceInterval: [],
      allOptionWins: {},
    };
  }

  // Filter options that pass hard constraints
  const eligibleOptions = opts.options.filter(passesHardConstraints);

  if (eligibleOptions.length === 0) {
    return {
      verdict: "CONSTRAINT_BLOCKED",
      winnerFlipRate: 0,
      rankStability: 0,
      iterations: 0,
      baseWinner: null,
      confidenceInterval: [],
      allOptionWins: {},
    };
  }
  if (eligibleOptions.length < 2) {
    // Single option: trivially robust if it passes hard constraints
    return {
      verdict: "DOMINANT_ROBUST",
      winnerFlipRate: 0,
      rankStability: 1,
      iterations,
      baseWinner: eligibleOptions[0]!.id,
      confidenceInterval: [{ option: eligibleOptions[0]!.id, pWin: 1 }],
      allOptionWins: { [eligibleOptions[0]!.id]: iterations },
    };
  }

  // Base scoring (no perturbation) to identify the baseline winner
  const baseScores = eligibleOptions.map((o) => ({ id: o.id, score: scoreOption(o, opts.criteria) }));
  baseScores.sort((a, b) => b.score - a.score);
  const baseWinner = baseScores[0]!.id;

  // Monte Carlo
  const winCounts: Record<string, number> = {};
  for (const o of eligibleOptions) winCounts[o.id] = 0;
  const observedRanks = new Map<string, number[]>();
  for (const o of eligibleOptions) observedRanks.set(o.id, []);

  for (let i = 0; i < iterations; i++) {
    // Perturb weights (10% noise) and uncertain inputs
    const perturbedCriteria = opts.criteria.map((c) => ({
      ...c,
      weight: c.weight * (1 + (random() - 0.5) * 0.2),
    }));
    // Apply uncertain inputs to criteria values: treat them as a noise on the criterion value
    const optionScores = eligibleOptions.map((o) => {
      let s = scoreOption(o, perturbedCriteria);
      for (const ui of opts.uncertainInputs ?? []) {
        // The uncertain input adjusts the option's score for criterion `ui.id`
        const delta = triangularSample(random, ui.low, ui.likely, ui.high) - ui.likely;
        s += delta * (perturbedCriteria.find((c) => c.id === ui.id)?.weight ?? 0);
      }
      return { id: o.id, score: s };
    });
    optionScores.sort((a, b) => b.score - a.score);
    winCounts[optionScores[0]!.id]! += 1;
    for (let r = 0; r < optionScores.length; r++) {
      observedRanks.get(optionScores[r]!.id)!.push(r);
    }
  }

  // Winner-flip rate: fraction of iterations where the winner != baseWinner
  const flipCount = iterations - (winCounts[baseWinner] ?? 0);
  const winnerFlipRate = flipCount / iterations;
  // Rank stability
  const stability = rankStability(observedRanks, eligibleOptions);
  // Verdict
  let verdict: UceVerdict;
  if (winnerFlipRate < 0.05) {
    verdict = "DOMINANT_ROBUST";
  } else if (winnerFlipRate < 0.2) {
    verdict = "DOMINANT_FRAGILE";
  } else {
    verdict = "NO_CLEAR_DOMINANCE";
  }

  return {
    verdict,
    winnerFlipRate,
    rankStability: stability,
    iterations,
    baseWinner,
    confidenceInterval: eligibleOptions.map((o) => ({ option: o.id, pWin: (winCounts[o.id] ?? 0) / iterations })),
    allOptionWins: winCounts,
  };
}
