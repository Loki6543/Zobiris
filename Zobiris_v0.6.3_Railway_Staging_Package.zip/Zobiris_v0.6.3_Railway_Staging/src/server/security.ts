/**
 * v0.4.4 audit fix (P0 #4): HTTP security for /api/refresh and the
 * static SPA.
 *
 * Provides:
 *  - Auth: Bearer-token (ZOBIRIS_REFRESH_TOKEN). Anonymous GETs are
 *    allowed; POST /api/refresh requires auth unless the server is in
 *    explicitly opted in with ZOBIRIS_ALLOW_ANONYMOUS_REFRESH=1.
 *  - Rate limit: per-IP sliding window for /api/refresh
 *    (ZOBIRIS_REFRESH_RATE_LIMIT_PER_HOUR, default 12).
 *  - Single-flight: only one refresh at a time. Concurrent calls get
 *    a 202 with the in-flight sessionId.
 *  - CORS: explicit allow-list (ZOBIRIS_CORS_ORIGINS=comma,separated).
 *    Defaults to no Access-Control-Allow-Origin at all (same-origin only).
 *  - Static path-traversal hardening (defense in depth on top of the
 *    existing serveStatic check).
 *
 * The HTTP boundary is currently under-tested relative to its risk.
 * v0.4.4 closes it: see src/tests/refresh-security.test.ts.
 */

import type { IncomingMessage, ServerResponse } from "node:http";
import { timingSafeEqual } from "node:crypto";

// ---------- Config ----------

export interface SecurityConfig {
  /** Bearer token required on POST /api/refresh. Required in production. */
  refreshToken: string | null;
  /** When true, POST /api/refresh accepts anonymous calls. Explicit opt-in only. */
  allowAnonymousRefresh: boolean;
  /** Per-IP requests-per-hour limit for POST /api/refresh. */
  refreshRateLimitPerHour: number;
  /** Comma-separated allowed CORS origins. Empty = same-origin only. */
  corsOrigins: string[];
}

export function loadSecurityConfig(env: NodeJS.ProcessEnv = process.env): SecurityConfig {
  const allowAnonymous = env.ZOBIRIS_ALLOW_ANONYMOUS_REFRESH === "1" && env.NODE_ENV !== "production";
  const origins = (env.ZOBIRIS_CORS_ORIGINS ?? "")
    .split(",")
    .map((s) => s.trim())
    .filter((s) => s.length > 0);
  return {
    refreshToken: env.ZOBIRIS_REFRESH_TOKEN ?? null,
    allowAnonymousRefresh: allowAnonymous,
    refreshRateLimitPerHour: Number(env.ZOBIRIS_REFRESH_RATE_LIMIT_PER_HOUR ?? "12"),
    corsOrigins: origins,
  };
}

// ---------- Single-flight refresh lock ----------

let activeRefreshSessionId: string | null = null;
let activeRefreshStartedAt: number | null = null;

export function isRefreshActive(): boolean {
  return activeRefreshSessionId !== null;
}

export function startRefreshSession(sessionId: string): { ok: true } | { ok: false; activeSessionId: string; startedAt: number } {
  if (activeRefreshSessionId !== null) {
    return {
      ok: false,
      activeSessionId: activeRefreshSessionId,
      startedAt: activeRefreshStartedAt ?? 0,
    };
  }
  activeRefreshSessionId = sessionId;
  activeRefreshStartedAt = Date.now();
  return { ok: true };
}

export function endRefreshSession(sessionId: string): void {
  if (activeRefreshSessionId === sessionId) {
    activeRefreshSessionId = null;
    activeRefreshStartedAt = null;
  }
}

/** Test-only: reset the in-process single-flight lock. */
export function _resetSingleFlightForTests(): void {
  activeRefreshSessionId = null;
  activeRefreshStartedAt = null;
}

// ---------- Rate limit (per-IP, sliding window) ----------

interface RateLimitBucket {
  /** unix-ms timestamps of recent refresh requests, oldest first */
  window: number[];
}

const rateLimitBuckets = new Map<string, RateLimitBucket>();

export function checkRateLimit(ip: string, now: number, limitPerHour: number): { allowed: true } | { allowed: false; retryAfterSec: number } {
  const bucket = rateLimitBuckets.get(ip) ?? { window: [] };
  const oneHourAgo = now - 3_600_000;
  // Drop entries older than 1 hour
  while (bucket.window.length > 0 && bucket.window[0]! < oneHourAgo) {
    bucket.window.shift();
  }
  if (bucket.window.length >= limitPerHour) {
    const oldest = bucket.window[0]!;
    const retryAfterMs = oldest + 3_600_000 - now;
    return { allowed: false, retryAfterSec: Math.max(1, Math.ceil(retryAfterMs / 1000)) };
  }
  bucket.window.push(now);
  rateLimitBuckets.set(ip, bucket);
  return { allowed: true };
}

/** Test-only: clear all rate-limit buckets. */
export function _resetRateLimitForTests(): void {
  rateLimitBuckets.clear();
}

// ---------- Auth ----------

/** Constant-time string comparison to avoid token-timing leaks. */
function safeEqual(a: string, b: string): boolean {
  const ab = Buffer.from(a);
  const bb = Buffer.from(b);
  if (ab.length !== bb.length) {
    // Still do a comparison to keep the timing similar.
    timingSafeEqual(ab, ab);
    return false;
  }
  return timingSafeEqual(ab, bb);
}

/**
 * Returns true if the request carries a valid Authorization: Bearer
 * header. The expected token is `cfg.refreshToken`. If no token is
 * configured, no request can satisfy general auth. The anonymous-refresh
 * development exception is deliberately excluded from this function.
 */
export function isAuthenticated(req: IncomingMessage, cfg: SecurityConfig): boolean {
  if (!cfg.refreshToken) return false;
  const auth = req.headers["authorization"];
  if (!auth || typeof auth !== "string") return false;
  const m = auth.match(/^Bearer\s+(.+)$/i);
  if (!m) return false;
  return safeEqual(m[1]!, cfg.refreshToken);
}

/**
 * Refresh-specific authorization. Anonymous refresh is a development-only
 * exception and can never authorize any other mutation route.
 */
export function isRefreshAuthorized(req: IncomingMessage, cfg: SecurityConfig): boolean {
  return cfg.allowAnonymousRefresh || isAuthenticated(req, cfg);
}

// ---------- CORS ----------

/**
 * Returns the value to send in the Access-Control-Allow-Origin header
 * for this request, or null if the origin is not allowed.
 *
 * If `cfg.corsOrigins` is empty, only same-origin requests are allowed
 * (i.e. no CORS header at all, which makes the browser block
 * cross-origin requests).
 */
export function resolveCorsOrigin(req: IncomingMessage, cfg: SecurityConfig): string | null {
  if (cfg.corsOrigins.length === 0) return null;
  const origin = req.headers["origin"];
  if (typeof origin !== "string") return null;
  if (cfg.corsOrigins.includes(origin)) return origin;
  return null;
}

// ---------- Client IP extraction ----------

/** Extract the best-effort client IP. Trusts X-Forwarded-For when present
 *  (typical for reverse-proxied deployments). */
export function clientIpFrom(req: IncomingMessage): string {
  const xff = req.headers["x-forwarded-for"];
  if (typeof xff === "string" && xff.length > 0) {
    // First entry is the original client
    return xff.split(",")[0]!.trim();
  }
  return req.socket.remoteAddress ?? "unknown";
}

// ---------- Path traversal hardening ----------

/**
 * Belt-and-suspenders path-traversal check. Returns true if the
 * relative path is safe to join with the public directory.
 */
export function isSafeStaticPath(relPath: string): boolean {
  if (relPath.length === 0) return false;
  if (relPath.includes("..")) return false;
  if (relPath.startsWith("/") || relPath.startsWith("\\")) return false;
  // Reject any null bytes
  if (relPath.includes("\0")) return false;
  // No Windows drive letters
  if (/^[a-zA-Z]:[\\/]/.test(relPath)) return false;
  return true;
}

// ---------- Response helpers ----------

export function sendJson(res: ServerResponse, status: number, body: unknown): void {
  const text = JSON.stringify(body);
  res.writeHead(status, {
    "Content-Type": "application/json; charset=utf-8",
    "Content-Length": Buffer.byteLength(text),
    "Cache-Control": "no-store",
  });
  res.end(text);
}

export function send401(res: ServerResponse, message = "unauthorized"): void {
  res.setHeader("WWW-Authenticate", 'Bearer realm="zobiris"');
  sendJson(res, 401, { error: message });
}

export function send429(res: ServerResponse, retryAfterSec: number): void {
  res.setHeader("Retry-After", String(retryAfterSec));
  sendJson(res, 429, { error: "rate_limited", retryAfterSec });
}

export function send503(res: ServerResponse, message: string, retryAfterSec = 0): void {
  if (retryAfterSec > 0) res.setHeader("Retry-After", String(retryAfterSec));
  sendJson(res, 503, { error: message });
}
