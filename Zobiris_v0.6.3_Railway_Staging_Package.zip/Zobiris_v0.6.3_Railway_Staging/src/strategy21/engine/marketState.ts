export const MARKET_STATES = [
  "UNCERTAIN",
  "DELEVERAGED_ACCUMULATION",
  "BROAD_EXPANSION",
  "LEVERAGED_EXPANSION",
  "EUPHORIA",
  "DETERIORATION",
  "CAPITULATION",
  "SYSTEMIC_BREAK",
] as const;

export type MarketStateName = (typeof MARKET_STATES)[number];

export interface MarketAxes {
  btcStructure: number;
  breadth: number;
  spotParticipation: number;
  leverageCrowding: number;
  liquidityStress: number;
  extension: number;
  macroImpulse: number;
}

export interface PreviousMarketState {
  state: MarketStateName;
  enteredAt: string;
  minimumDwellUntil: string;
}

export interface ClassifyMarketStateInput {
  axes: MarketAxes;
  confidence: number;
  asOf: string;
  integrityBreak?: boolean;
  previous?: PreviousMarketState;
}

export interface MarketStateResult extends PreviousMarketState {
  confidence: number;
  axes: MarketAxes;
  deploymentCapPct: number;
  reason: string;
}

const DEPLOYMENT_CAP_PCT: Record<MarketStateName, number> = {
  UNCERTAIN: 0.15,
  DELEVERAGED_ACCUMULATION: 0.55,
  BROAD_EXPANSION: 0.85,
  LEVERAGED_EXPANSION: 0.45,
  EUPHORIA: 0.10,
  DETERIORATION: 0.10,
  CAPITULATION: 0.35,
  SYSTEMIC_BREAK: 0,
};

const MIN_DWELL_HOURS: Record<MarketStateName, number> = {
  UNCERTAIN: 12,
  DELEVERAGED_ACCUMULATION: 24,
  BROAD_EXPANSION: 48,
  LEVERAGED_EXPANSION: 12,
  EUPHORIA: 24,
  DETERIORATION: 24,
  CAPITULATION: 24,
  SYSTEMIC_BREAK: 48,
};

const DOCTRINE_ALIASES: Record<MarketStateName, string> = {
  UNCERTAIN: "Reconnaissance",
  DELEVERAGED_ACCUMULATION: "Ambush / Elastic Defense",
  BROAD_EXPANSION: "Offensive Rotation",
  LEVERAGED_EXPANSION: "Elastic Offense",
  EUPHORIA: "Strategic Retreat",
  DETERIORATION: "Controlled Retreat",
  CAPITULATION: "Valley Forge",
  SYSTEMIC_BREAK: "Regime Break",
};

function clampAxis(value: number): number {
  return Math.max(-1, Math.min(1, value));
}

function normalizedAxes(axes: MarketAxes): MarketAxes {
  return {
    btcStructure: clampAxis(axes.btcStructure),
    breadth: clampAxis(axes.breadth),
    spotParticipation: clampAxis(axes.spotParticipation),
    leverageCrowding: clampAxis(axes.leverageCrowding),
    liquidityStress: clampAxis(axes.liquidityStress),
    extension: clampAxis(axes.extension),
    macroImpulse: clampAxis(axes.macroImpulse),
  };
}

function rawClassify(axes: MarketAxes, confidence: number, integrityBreak: boolean): { state: MarketStateName; reason: string } {
  const { btcStructure: S, breadth: B, spotParticipation: P, leverageCrowding: L, liquidityStress: X, extension: E } = axes;

  if (integrityBreak || (X > 0.9 && S < -0.6)) {
    return { state: "SYSTEMIC_BREAK", reason: "critical integrity or market-liquidity break" };
  }

  if (confidence < 0.65) {
    return { state: "UNCERTAIN", reason: "insufficient market evidence confidence" };
  }

  if (S < -0.65 && E < -0.75 && L < 0 && X < 0.8) {
    return { state: "CAPITULATION", reason: "extreme downside with deleveraging and surviving market infrastructure" };
  }

  if ((S < -0.3 || B < -0.25) && (P < 0 || X > 0.35)) {
    return { state: "DETERIORATION", reason: "structure or breadth deteriorating with weak spot demand or liquidity stress" };
  }

  if (E > 0.8 && L > 0.55 && B > 0.3) {
    return { state: "EUPHORIA", reason: "extension and leverage are both extreme" };
  }

  if (S > 0.1 && L > 0.55) {
    return { state: "LEVERAGED_EXPANSION", reason: "positive structure with dangerous leverage crowding" };
  }

  if (S > 0.25 && B > 0.35 && P > 0.25 && L < 0.55 && X < 0.55) {
    return { state: "BROAD_EXPANSION", reason: "BTC structure, breadth and spot participation confirm broad expansion" };
  }

  if (S > -0.2 && P > 0.2 && L < 0 && E < 0.8 && X < 0.5) {
    return { state: "DELEVERAGED_ACCUMULATION", reason: "spot participation is constructive after leverage has cooled" };
  }

  return { state: "UNCERTAIN", reason: "observable axes do not establish a higher-confidence regime" };
}

function addHours(iso: string, hours: number): string {
  const ms = Date.parse(iso);
  if (!Number.isFinite(ms)) throw new Error(`invalid asOf timestamp: ${iso}`);
  return new Date(ms + hours * 3_600_000).toISOString();
}

function isImmediateRiskReduction(state: MarketStateName): boolean {
  return state === "DETERIORATION" || state === "CAPITULATION" || state === "SYSTEMIC_BREAK" || state === "EUPHORIA";
}

export function classifyMarketState(input: ClassifyMarketStateInput): MarketStateResult {
  const axes = normalizedAxes(input.axes);
  const confidence = Math.max(0, Math.min(1, input.confidence));
  const candidate = rawClassify(axes, confidence, input.integrityBreak ?? false);

  if (
    input.previous &&
    candidate.state !== input.previous.state &&
    Date.parse(input.asOf) < Date.parse(input.previous.minimumDwellUntil) &&
    !isImmediateRiskReduction(candidate.state)
  ) {
    return {
      state: input.previous.state,
      enteredAt: input.previous.enteredAt,
      minimumDwellUntil: input.previous.minimumDwellUntil,
      confidence,
      axes,
      deploymentCapPct: DEPLOYMENT_CAP_PCT[input.previous.state],
      reason: `hysteresis hold: candidate ${candidate.state} suppressed until minimum dwell expires`,
    };
  }

  const enteredAt = input.previous?.state === candidate.state ? input.previous.enteredAt : input.asOf;
  const minimumDwellUntil = input.previous?.state === candidate.state
    ? input.previous.minimumDwellUntil
    : addHours(input.asOf, MIN_DWELL_HOURS[candidate.state]);

  return {
    state: candidate.state,
    enteredAt,
    minimumDwellUntil,
    confidence,
    axes,
    deploymentCapPct: DEPLOYMENT_CAP_PCT[candidate.state],
    reason: candidate.reason,
  };
}

export function deploymentCapForState(state: MarketStateName, fundedCapitalUsd: number): number {
  return Math.round(fundedCapitalUsd * DEPLOYMENT_CAP_PCT[state] * 100) / 100;
}

export function doctrineAlias(state: MarketStateName): string {
  return DOCTRINE_ALIASES[state];
}
