import type { EvidenceItem } from "../domain/evidence.js";
import { classifyAssetState, type AssetStateInput, type AssetStateResult } from "./assetState.js";
import { calculatePositionAuthority, type CapitalLedger, type PortfolioExposureContext, type PositionAuthority, type StrategyAssetClass } from "./capital.js";
import { authorizeExecutionLine, planStagedExecution, type LineAuthorizationInput } from "./executionPlan.js";
import type { FactorResult, OpportunityHeuristicResult } from "./factors.js";
import type { LiquidityEligibilityResult } from "./liquidity.js";
import type { BehavioralPersonalityResult } from "./personality.js";
import { doctrineAlias, type MarketStateResult } from "./marketState.js";

export type ZobirisAction =
  | "QUARANTINE"
  | "AVOID"
  | "WAIT"
  | "PROBE"
  | "HOLD_PROBE"
  | "ACCUMULATE"
  | "HOLD_OR_REINFORCE"
  | "HOLD"
  | "HARVEST"
  | "REDUCE";

export interface DecisionAsset {
  id: string;
  symbol: string;
  name: string;
  assetClass: StrategyAssetClass;
}

export interface FactorBundle {
  fundamental: FactorResult;
  execution: FactorResult;
  flow: FactorResult;
  discovery: FactorResult;
  resilience: FactorResult;
}

export interface ZobirisDecisionInput {
  asset: DecisionAsset;
  asOf: string;
  market: MarketStateResult;
  eligibility: LiquidityEligibilityResult;
  factors: FactorBundle;
  opportunity: OpportunityHeuristicResult;
  assetStateInput: AssetStateInput;
  ledger: CapitalLedger;
  portfolio: PortfolioExposureContext;
  requestedTargetUsd: number;
  evidence: EvidenceItem[];
  personality?: BehavioralPersonalityResult | null;
  lineSignals: Omit<LineAuthorizationInput, "marketState" | "assetState" | "confidence" | "eligibilityActive" | "opportunityPositive">;
}

export interface AuthorizedExecutionLine {
  line: 1 | 2 | 3;
  label: "PROBE" | "ACCUMULATE" | "CONFIRMED_TREND";
  amountUsd: number;
  authorized: boolean;
  reason: string;
}

export interface ZobirisExplanation {
  observations: EvidenceItem[];
  derivedMetrics: EvidenceItem[];
  inferredClaims: EvidenceItem[];
  forecasts: EvidenceItem[];
  narrativeSignals: EvidenceItem[];
  supportingEvidenceIds: string[];
  contradictions: string[];
  flipBullish: string[];
  flipBearish: string[];
  cancelConditions: string[];
}

export interface ZobirisDecision {
  assetId: string;
  symbol: string;
  name: string;
  assetClass: StrategyAssetClass;
  coreAuthority: boolean;
  asOf: string;
  market: MarketStateResult;
  doctrine: string;
  assetState: AssetStateResult;
  eligibility: LiquidityEligibilityResult;
  factors: FactorBundle;
  opportunity: OpportunityHeuristicResult;
  personality: BehavioralPersonalityResult | null;
  authority: PositionAuthority;
  action: ZobirisAction;
  stagedExecution: {
    targetUsd: number;
    lines: AuthorizedExecutionLine[];
  };
  explanation: ZobirisExplanation;
}

function actionForState(state: AssetStateResult["state"]): ZobirisAction {
  switch (state) {
    case "QUARANTINED": return "QUARANTINE";
    case "INELIGIBLE": return "AVOID";
    case "RESEARCH": return "WAIT";
    case "PRE_IGNITION": return "PROBE";
    case "PROBE": return "HOLD_PROBE";
    case "ACCUMULATE": return "ACCUMULATE";
    case "CONFIRMED_TREND": return "HOLD_OR_REINFORCE";
    case "EXTENDED": return "HOLD";
    case "HARVEST": return "HARVEST";
    case "DETERIORATING": return "REDUCE";
  }
}

function buildExplanation(
  input: ZobirisDecisionInput,
  assetState: AssetStateResult,
): ZobirisExplanation {
  const observations = input.evidence.filter((item) => item.type === "OBSERVATION");
  const derivedMetrics = input.evidence.filter((item) => item.type === "DERIVED_METRIC");
  const inferredClaims = input.evidence.filter((item) => item.type === "CAUSAL_HYPOTHESIS");
  const forecasts = input.evidence.filter((item) => item.type === "FORECAST");
  const narrativeSignals = input.evidence.filter((item) => item.type === "NARRATIVE_SIGNAL");
  const contradictions = [...new Set(input.evidence.flatMap((item) => item.contradictions))];

  const flipBullish: string[] = [];
  if (input.eligibility.status !== "ACTIVE_ELIGIBLE") {
    flipBullish.push("restore ACTIVE_ELIGIBLE execution eligibility with fresh Kraken depth and complete critical evidence");
  }
  if (assetState.state === "RESEARCH") {
    flipBullish.push("add non-price discovery confirmation: observable catalyst, contributor-breadth improvement, or spot accumulation");
  }
  if (!input.opportunity.eligibleForRanking) {
    flipBullish.push("raise evidence coverage/confidence enough for ranking without filling missing data with assumptions");
  }
  if (input.market.state === "UNCERTAIN" || input.market.state === "DETERIORATION") {
    flipBullish.push("market state improves with independent spot, breadth, and BTC-structure confirmation");
  }

  const flipBearish = [
    "Kraken execution liquidity fails or stressed exit capacity falls below the intended position",
    "fundamental or distribution thesis deteriorates materially",
    "token-supply, security, custody, or identity risk worsens",
    "market state transitions to DETERIORATION or SYSTEMIC_BREAK",
  ];

  const cancelConditions = [
    "eligibility is no longer ACTIVE_ELIGIBLE",
    "order-book data becomes stale, crossed, or materially thinner than authorization snapshot",
    "realized slippage exceeds the approved estimate by more than 20 bps",
    "asset state becomes DETERIORATING, INELIGIBLE, or QUARANTINED",
    "market state no longer permits the planned execution line",
  ];

  return {
    observations,
    derivedMetrics,
    inferredClaims,
    forecasts,
    narrativeSignals,
    supportingEvidenceIds: input.evidence.filter((item) => item.contradictions.length === 0).map((item) => item.id),
    contradictions,
    flipBullish,
    flipBearish,
    cancelConditions,
  };
}

export function evaluateZobirisDecision(input: ZobirisDecisionInput): ZobirisDecision {
  const assetState = classifyAssetState({
    ...input.assetStateInput,
    eligibility: input.eligibility.status,
    confidence: input.opportunity.confidence,
  });

  const authority = calculatePositionAuthority({
    assetId: input.asset.id,
    assetClass: input.asset.assetClass,
    requestedTargetUsd: input.requestedTargetUsd,
    marketState: input.market.state,
    assetState: assetState.state,
    confidence: input.opportunity.confidence,
    eligibilityMaximumPositionUsd: input.eligibility.maximumPositionUsd,
    eligibilityMaximumOrderUsd: input.eligibility.maximumOrderUsd,
    ledger: input.ledger,
    portfolio: input.portfolio,
  });

  const opportunityPositive = input.opportunity.eligibleForRanking && input.opportunity.score >= 50;
  const basePlan = authority.maxNextOrderUsd > 0
    ? planStagedExecution(Math.min(input.requestedTargetUsd, authority.maxPositionUsd), authority)
    : { targetUsd: 0, lines: [] };

  const lines: AuthorizedExecutionLine[] = basePlan.lines.map((line) => {
    const authorization = authorizeExecutionLine(line.line, {
      marketState: input.market.state,
      assetState: assetState.state,
      confidence: input.opportunity.confidence,
      eligibilityActive: input.eligibility.status === "ACTIVE_ELIGIBLE",
      opportunityPositive,
      ...input.lineSignals,
    });

    // The first child order may never exceed the explicitly calculated next-order authority.
    const amountUsd = line.line === 1 ? Math.min(line.amountUsd, authority.maxNextOrderUsd) : line.amountUsd;
    return { ...line, amountUsd, authorized: authorization.authorized, reason: authorization.reason };
  });

  return {
    assetId: input.asset.id,
    symbol: input.asset.symbol,
    name: input.asset.name,
    assetClass: input.asset.assetClass,
    coreAuthority: input.asset.assetClass !== "MEME",
    asOf: input.asOf,
    market: input.market,
    doctrine: doctrineAlias(input.market.state),
    assetState,
    eligibility: input.eligibility,
    factors: input.factors,
    opportunity: input.opportunity,
    personality: input.personality ?? null,
    authority,
    action: actionForState(assetState.state),
    stagedExecution: { targetUsd: basePlan.targetUsd, lines },
    explanation: buildExplanation(input, assetState),
  };
}
