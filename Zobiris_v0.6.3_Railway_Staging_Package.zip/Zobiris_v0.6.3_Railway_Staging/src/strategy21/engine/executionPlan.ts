import type { AssetStateName } from "./assetState.js";
import type { MarketStateName } from "./marketState.js";

export interface ExecutionLine {
  line: 1 | 2 | 3;
  label: "PROBE" | "ACCUMULATE" | "CONFIRMED_TREND";
  amountUsd: number;
}

export interface StagedExecutionPlan {
  targetUsd: number;
  lines: ExecutionLine[];
}

export function planStagedExecution(
  requestedTargetUsd: number,
  authority: { maxPositionUsd: number; maxNextOrderUsd: number; probeOnly: boolean },
): StagedExecutionPlan {
  const target = Math.max(0, Math.min(requestedTargetUsd, authority.maxPositionUsd));
  if (target === 0) return { targetUsd: 0, lines: [] };
  const amounts = [0.20 * target, 0.30 * target, 0.50 * target];
  const round = (n: number) => Math.round(n * 100) / 100;
  return {
    targetUsd: round(target),
    lines: [
      { line: 1, label: "PROBE", amountUsd: round(amounts[0] ?? 0) },
      { line: 2, label: "ACCUMULATE", amountUsd: round(amounts[1] ?? 0) },
      { line: 3, label: "CONFIRMED_TREND", amountUsd: round(amounts[2] ?? 0) },
    ],
  };
}

export interface LineAuthorizationInput {
  marketState: MarketStateName;
  assetState: AssetStateName;
  confidence: number;
  eligibilityActive: boolean;
  opportunityPositive: boolean;
  nonPriceConfirmation: boolean;
  liquidityStable: boolean;
  supplyRiskStable: boolean;
  spotRelativeStrengthConfirmed: boolean;
  covarianceAcceptable: boolean;
}

export interface LineAuthorizationResult {
  authorized: boolean;
  reason: string;
}

const RISK_ON_MARKETS = new Set<MarketStateName>([
  "UNCERTAIN",
  "DELEVERAGED_ACCUMULATION",
  "BROAD_EXPANSION",
  "LEVERAGED_EXPANSION",
  "CAPITULATION",
]);

export function authorizeExecutionLine(line: 1 | 2 | 3, input: LineAuthorizationInput): LineAuthorizationResult {
  if (!input.eligibilityActive) return { authorized: false, reason: "execution eligibility is not active" };
  if (!input.opportunityPositive) return { authorized: false, reason: "opportunity no longer positive" };
  if (!RISK_ON_MARKETS.has(input.marketState)) return { authorized: false, reason: `market state ${input.marketState} does not permit new risk` };
  if (!input.liquidityStable) return { authorized: false, reason: "liquidity deteriorated" };
  if (!input.supplyRiskStable) return { authorized: false, reason: "token-supply risk deteriorated" };

  if (line === 1) {
    const allowed = input.assetState === "PRE_IGNITION" || input.assetState === "PROBE" || input.assetState === "ACCUMULATE" || input.assetState === "CONFIRMED_TREND";
    return allowed
      ? { authorized: true, reason: "probe conditions satisfied" }
      : { authorized: false, reason: `asset state ${input.assetState} does not permit a probe` };
  }

  if (line === 2) {
    if (input.assetState !== "ACCUMULATE" && input.assetState !== "CONFIRMED_TREND") {
      return { authorized: false, reason: "asset has not advanced to ACCUMULATE" };
    }
    if (!input.nonPriceConfirmation) return { authorized: false, reason: "non-price thesis confirmation is required for line 2" };
    return { authorized: true, reason: "accumulation conditions satisfied" };
  }

  if (input.assetState !== "CONFIRMED_TREND") return { authorized: false, reason: "line 3 requires CONFIRMED_TREND" };
  if (input.confidence < 0.75) return { authorized: false, reason: "line 3 requires confidence >= 0.75" };
  if (!input.spotRelativeStrengthConfirmed) return { authorized: false, reason: "spot-supported relative strength is not confirmed" };
  if (!input.covarianceAcceptable) return { authorized: false, reason: "portfolio covariance/cluster risk is not acceptable" };
  if (input.marketState === "LEVERAGED_EXPANSION") return { authorized: false, reason: "line 3 suppressed during leveraged expansion" };
  return { authorized: true, reason: "confirmed-trend scaling conditions satisfied" };
}
