export const DEPENDENCY_ROOTS = [
  "EXECUTION",
  "SPOT_FLOW",
  "LEVERAGE",
  "PRICE_STRUCTURE",
  "FUNDAMENTALS",
  "TOKEN_SUPPLY",
  "NARRATIVE",
  "MACRO",
] as const;

export type DependencyRoot = (typeof DEPENDENCY_ROOTS)[number];

export class DependencyRegistry {
  private readonly roots = new Map<string, DependencyRoot>();

  register(signal: string, root: DependencyRoot): void {
    const existing = this.roots.get(signal);
    if (existing && existing !== root) {
      throw new Error(`signal ${signal} already registered to primary root ${existing}`);
    }
    this.roots.set(signal, root);
  }

  getRoot(signal: string): DependencyRoot | undefined {
    return this.roots.get(signal);
  }

  requireRoot(signal: string): DependencyRoot {
    const root = this.getRoot(signal);
    if (!root) throw new Error(`signal ${signal} has no declared dependency root`);
    return root;
  }

  hasOverlap(a: string[], b: string[]): boolean {
    const rootsA = new Set(a.map((signal) => this.requireRoot(signal)));
    return b.some((signal) => rootsA.has(this.requireRoot(signal)));
  }
}

export function countIndependentConfirmations(signals: string[], registry: DependencyRegistry): number {
  return new Set(signals.map((signal) => registry.requireRoot(signal))).size;
}
