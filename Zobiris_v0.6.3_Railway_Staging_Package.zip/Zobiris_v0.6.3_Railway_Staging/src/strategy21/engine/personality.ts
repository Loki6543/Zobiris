export type BehavioralPersonality =
  | "BTC_SHADOW"
  | "BREAKOUT_SPRINTER"
  | "MEAN_REVERTER"
  | "DIP_EATER"
  | "MOMENTUM_CASCADE"
  | "NARRATIVE_ROCKET"
  | "LIQUIDITY_TRAP"
  | "INDEPENDENT_LEADER"
  | "SLOW_ACCUMULATOR"
  | "CAPITULATION_REBOUNDER";

export type MatchBand = "HIGH" | "MEDIUM" | "LOW" | "INSUFFICIENT";
export type ElasticStrengthBand = "HIGH" | "MODERATE" | "LOW" | "INSUFFICIENT";

export interface BehavioralProfileInput {
  btcCorrelation?: number;                 // -1..1
  btcBeta?: number;                        // >= 0
  relativeStrengthOnBtcDown?: number;      // 0..1, higher = more resilient vs BTC in down windows
  supportHoldRateOnBtcDown?: number;       // 0..1
  spotPersistenceOnBtcDown?: number;       // 0..1
  fundingCrowding?: number;                // 0..1, higher = more crowded
  oiCrowding?: number;                     // 0..1, higher = more crowded
  breakoutFollowThroughRate?: number;      // 0..1
  falseBreakoutRate?: number;              // 0..1
  dipRecoveryRate?: number;                // 0..1
  medianRecoveryHours?: number;            // hours
  compressionBreakoutRate?: number;        // 0..1
  trendPersistence?: number;               // 0..1
  narrativeSensitivity?: number;           // 0..1
  postPumpLiquidityDecay?: number;          // 0..1
  capitulationBounceRate?: number;          // 0..1
  similarSetupCount?: number;               // historical analog count
}

export interface ElasticStrengthResult {
  score: number; // 0..100
  band: ElasticStrengthBand;
  coverage: number;
  components: {
    btcDownRelativeStrength?: number;
    supportHolding?: number;
    spotPersistence?: number;
    uncrowdedFunding?: number;
    uncrowdedOpenInterest?: number;
  };
}

export interface BehavioralPersonalityResult {
  primary: BehavioralPersonality;
  secondary: BehavioralPersonality[];
  scores: Record<BehavioralPersonality, number>;
  elasticStrength: ElasticStrengthResult;
  confidence: number;
  coverage: number;
  similarSetupCount: number;
  historicalMatch: MatchBand;
  calibratedProbability: null;
  warnings: string[];
  evidenceRoots: Array<"PRICE_STRUCTURE" | "SPOT_FLOW" | "LEVERAGE" | "NARRATIVE" | "EXECUTION">;
  productionAuthority: "DESCRIPTIVE_ONLY";
}

function clamp01(value: number): number {
  return Math.max(0, Math.min(1, value));
}

function unit(value: number | undefined): number | undefined {
  if (value === undefined || !Number.isFinite(value)) return undefined;
  return clamp01(value);
}

function weightedPresent(parts: Array<[number | undefined, number]>): { value: number; coverage: number } {
  const present = parts.filter((p): p is [number, number] => p[0] !== undefined);
  const totalWeight = parts.reduce((sum, [, weight]) => sum + weight, 0);
  const presentWeight = present.reduce((sum, [, weight]) => sum + weight, 0);
  if (!present.length || totalWeight <= 0 || presentWeight <= 0) return { value: 0, coverage: 0 };
  const value = present.reduce((sum, [v, weight]) => sum + v * weight, 0) / presentWeight;
  return { value: clamp01(value), coverage: clamp01(presentWeight / totalWeight) };
}

export function computeElasticStrength(input: BehavioralProfileInput): ElasticStrengthResult {
  const rs = unit(input.relativeStrengthOnBtcDown);
  const support = unit(input.supportHoldRateOnBtcDown);
  const spot = unit(input.spotPersistenceOnBtcDown);
  const funding = unit(input.fundingCrowding);
  const oi = unit(input.oiCrowding);

  const result = weightedPresent([
    [rs, 0.30],
    [support, 0.25],
    [spot, 0.20],
    [funding === undefined ? undefined : 1 - funding, 0.125],
    [oi === undefined ? undefined : 1 - oi, 0.125],
  ]);

  const score = Math.round(result.value * 1000) / 10;
  let band: ElasticStrengthBand = "INSUFFICIENT";
  if (result.coverage >= 0.6) {
    band = score >= 75 ? "HIGH" : score >= 55 ? "MODERATE" : "LOW";
  }

  return {
    score,
    band,
    coverage: result.coverage,
    components: {
      btcDownRelativeStrength: rs,
      supportHolding: support,
      spotPersistence: spot,
      uncrowdedFunding: funding === undefined ? undefined : 1 - funding,
      uncrowdedOpenInterest: oi === undefined ? undefined : 1 - oi,
    },
  };
}

function scoreMap(input: BehavioralProfileInput, elastic: ElasticStrengthResult): Record<BehavioralPersonality, number> {
  const corr = input.btcCorrelation === undefined ? undefined : clamp01((input.btcCorrelation + 1) / 2);
  const beta = input.btcBeta === undefined || !Number.isFinite(input.btcBeta) ? undefined : clamp01(input.btcBeta / 1.5);
  const rs = unit(input.relativeStrengthOnBtcDown);
  const support = unit(input.supportHoldRateOnBtcDown);
  const follow = unit(input.breakoutFollowThroughRate);
  const falseBreak = unit(input.falseBreakoutRate);
  const dip = unit(input.dipRecoveryRate);
  const compression = unit(input.compressionBreakoutRate);
  const trend = unit(input.trendPersistence);
  const narrative = unit(input.narrativeSensitivity);
  const liqDecay = unit(input.postPumpLiquidityDecay);
  const capitulation = unit(input.capitulationBounceRate);
  const recoveryFast = input.medianRecoveryHours === undefined || !Number.isFinite(input.medianRecoveryHours)
    ? undefined
    : clamp01(1 - input.medianRecoveryHours / 96);

  const independent = weightedPresent([
    [rs, 0.35], [support, 0.25], [elastic.score / 100, 0.25],
    [corr === undefined ? undefined : 1 - corr, 0.15],
  ]).value;

  const btcShadow = weightedPresent([
    [corr, 0.45], [beta, 0.35], [rs === undefined ? undefined : 1 - rs, 0.20],
  ]).value;

  const breakout = weightedPresent([
    [follow, 0.45], [compression, 0.30], [falseBreak === undefined ? undefined : 1 - falseBreak, 0.25],
  ]).value;

  const meanReverter = weightedPresent([
    [falseBreak, 0.50], [trend === undefined ? undefined : 1 - trend, 0.30],
    [follow === undefined ? undefined : 1 - follow, 0.20],
  ]).value;

  const dipEater = weightedPresent([[dip, 0.65], [recoveryFast, 0.35]]).value;
  const momentum = weightedPresent([[follow, 0.35], [trend, 0.35], [compression, 0.15], [elastic.score / 100, 0.15]]).value;
  const slowAccumulator = weightedPresent([[support, 0.40], [trend, 0.30], [dip, 0.20], [compression === undefined ? undefined : 1 - compression, 0.10]]).value;
  const liquidityTrap = weightedPresent([[liqDecay, 0.60], [falseBreak, 0.40]]).value;

  return {
    BTC_SHADOW: btcShadow,
    BREAKOUT_SPRINTER: breakout,
    MEAN_REVERTER: meanReverter,
    DIP_EATER: dipEater,
    MOMENTUM_CASCADE: momentum,
    NARRATIVE_ROCKET: narrative ?? 0,
    LIQUIDITY_TRAP: liquidityTrap,
    INDEPENDENT_LEADER: independent,
    SLOW_ACCUMULATOR: slowAccumulator,
    CAPITULATION_REBOUNDER: capitulation ?? 0,
  };
}

function inputCoverage(input: BehavioralProfileInput): number {
  const keys: Array<keyof BehavioralProfileInput> = [
    "btcCorrelation", "btcBeta", "relativeStrengthOnBtcDown", "supportHoldRateOnBtcDown",
    "spotPersistenceOnBtcDown", "fundingCrowding", "oiCrowding", "breakoutFollowThroughRate",
    "falseBreakoutRate", "dipRecoveryRate", "medianRecoveryHours", "compressionBreakoutRate",
    "trendPersistence", "narrativeSensitivity", "postPumpLiquidityDecay", "capitulationBounceRate",
  ];
  const present = keys.filter((key) => {
    const value = input[key];
    return typeof value === "number" && Number.isFinite(value);
  }).length;
  return present / keys.length;
}

export function classifyBehavioralPersonality(input: BehavioralProfileInput): BehavioralPersonalityResult {
  const elasticStrength = computeElasticStrength(input);
  const scores = scoreMap(input, elasticStrength);
  const coverage = inputCoverage(input);
  const similarSetupCount = Math.max(0, Math.floor(input.similarSetupCount ?? 0));
  const warnings: string[] = [];

  // Safety override: strong exit-liquidity decay + false-breakout tendency must not be hidden by momentum labels.
  const trapScore = scores.LIQUIDITY_TRAP;
  let ordered = (Object.entries(scores) as Array<[BehavioralPersonality, number]>)
    .sort((a, b) => b[1] - a[1]);

  // When BTC-down resilience is genuinely strong, prefer the Independent Leader label
  // over a near-tied breakout label. This keeps the classifier focused on the behavior
  // the module was added to detect rather than simply rewarding momentum.
  const independentScore = scores.INDEPENDENT_LEADER;
  const currentTopScore = ordered[0]?.[1] ?? 0;
  if (elasticStrength.band === "HIGH" && independentScore >= 0.72 && currentTopScore - independentScore <= 0.10) {
    ordered = [["INDEPENDENT_LEADER", independentScore], ...ordered.filter(([k]) => k !== "INDEPENDENT_LEADER")];
  }

  if (trapScore >= 0.70) {
    ordered = [["LIQUIDITY_TRAP", trapScore], ...ordered.filter(([k]) => k !== "LIQUIDITY_TRAP")];
    warnings.push("Exit liquidity decays after pumps; apparent momentum may be difficult to exit safely.");
  }

  const primary = ordered[0]?.[0] ?? "BTC_SHADOW";
  const primaryScore = ordered[0]?.[1] ?? 0;
  const secondary = ordered
    .slice(1)
    .filter(([, score]) => score >= 0.62 && primaryScore - score <= 0.20)
    .slice(0, 2)
    .map(([personality]) => personality);

  let historicalMatch: MatchBand = "INSUFFICIENT";
  if (similarSetupCount >= 12 && coverage >= 0.6) {
    historicalMatch = primaryScore >= 0.72 ? "HIGH" : primaryScore >= 0.58 ? "MEDIUM" : "LOW";
  }

  const countConfidence = clamp01(similarSetupCount / 30);
  const confidence = Math.round(clamp01(0.65 * coverage + 0.35 * countConfidence) * 1000) / 1000;

  if (coverage < 0.6) warnings.push("Behavioral coverage is incomplete; personality is descriptive only.");
  if (similarSetupCount < 12) warnings.push("Too few comparable historical setups for a historical-match label.");

  return {
    primary,
    secondary,
    scores,
    elasticStrength,
    confidence,
    coverage,
    similarSetupCount,
    historicalMatch,
    calibratedProbability: null,
    warnings,
    evidenceRoots: ["PRICE_STRUCTURE", "SPOT_FLOW", "LEVERAGE", "NARRATIVE", "EXECUTION"],
    productionAuthority: "DESCRIPTIVE_ONLY",
  };
}
