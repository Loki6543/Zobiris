import type { DependencyRoot } from "./dependencyRegistry.js";
import type { MarketStateName } from "./marketState.js";

export type SensorStatus = "OFF" | "OBSERVING" | "ACTIVE" | "INVALID";

export interface SensorDefinition {
  sensorId: string;
  dependencyGroup: DependencyRoot;
  validRegimes: MarketStateName[];
  likelihoodRatio: number;
  likelihoodRatioLowerBound: number;
  effectiveSampleSize: number;
  minimumEffectiveSampleSize: number;
  fresh: boolean;
  integrityContradiction: boolean;
}

export interface SensorProbabilityResult {
  probability: number;
  applied: boolean;
  requiresTargetConfirmation: boolean;
  status: SensorStatus;
  reason: string;
}

function clampProbability(value: number): number {
  return Math.min(1 - 1e-9, Math.max(1e-9, value));
}

function logit(p: number): number {
  const x = clampProbability(p);
  return Math.log(x / (1 - x));
}

function sigmoid(x: number): number {
  return 1 / (1 + Math.exp(-x));
}

export function activateSensor(sensor: SensorDefinition, marketState: MarketStateName): SensorStatus {
  if (sensor.integrityContradiction) return "INVALID";
  if (!sensor.fresh || !sensor.validRegimes.includes(marketState)) return "OFF";
  if (
    sensor.likelihoodRatio <= 2 ||
    sensor.likelihoodRatioLowerBound <= 1 ||
    sensor.effectiveSampleSize < sensor.minimumEffectiveSampleSize
  ) {
    return "OBSERVING";
  }
  return "ACTIVE";
}

export function applySensorToProbability(input: {
  priorProbability: number;
  sensor: SensorDefinition;
  currentMarketState: MarketStateName;
  targetDependencyGroups: DependencyRoot[];
}): SensorProbabilityResult {
  const status = activateSensor(input.sensor, input.currentMarketState);
  if (status !== "ACTIVE") {
    return {
      probability: input.priorProbability,
      applied: false,
      requiresTargetConfirmation: false,
      status,
      reason: `sensor status ${status}`,
    };
  }

  if (input.targetDependencyGroups.includes(input.sensor.dependencyGroup)) {
    return {
      probability: input.priorProbability,
      applied: false,
      requiresTargetConfirmation: true,
      status,
      reason: "dependency overlap: sensor retained as context only",
    };
  }

  const delta = Math.max(-0.40, Math.min(0.40, Math.log(Math.max(1e-9, input.sensor.likelihoodRatio))));
  return {
    probability: sigmoid(logit(input.priorProbability) + delta),
    applied: true,
    requiresTargetConfirmation: true,
    status,
    reason: "bounded independent sensor update applied",
  };
}
