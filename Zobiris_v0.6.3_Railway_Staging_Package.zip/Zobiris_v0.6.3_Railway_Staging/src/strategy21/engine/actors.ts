export type ActorItemType = "OBSERVED_ACTION" | "INFERRED_INCENTIVE" | "CAPACITY_ESTIMATE" | "CONSTRAINT" | "FORECAST";

export interface ActorItem {
  itemId: string;
  actorId: string;
  itemType: ActorItemType;
  claim: string;
  magnitude: number;
  horizon: "MINUTES" | "HOURS" | "DAYS" | "WEEKS" | "MONTHS";
  confidence: number;
  sourceDependencies: string[];
  contradictions: string[];
}

export interface Actor {
  actorId: string;
  actorType:
    | "GOVERNMENT"
    | "CENTRAL_BANK"
    | "REGULATOR"
    | "EXCHANGE"
    | "ISSUER"
    | "FOUNDATION"
    | "MARKET_MAKER"
    | "WHALE"
    | "DEVELOPER_GROUP"
    | "SOCIAL_NETWORK"
    | "OTHER";
  jurisdiction?: string;
  observedActions: ActorItem[];
  inferredIncentives: ActorItem[];
  estimatedCapacity: number;
  estimatedTimeHorizon: string;
  constraints: string[];
  affectedMarkets: string[];
  evidenceIds: string[];
  confidence: number;
  lastUpdatedAt: string;
  expiresAt: string;
}

export interface ActorInfluenceEdge {
  edgeId: string;
  fromActor: string;
  toMarketOrActor: string;
  transmissionMechanism: string;
  expectedSign: -1 | 0 | 1;
  historicalReliability: number;
  supportingEvidence: string[];
  falsificationCondition: string;
  expiresAt: string;
}

function clamp01(value: number): number {
  return Math.max(0, Math.min(1, value));
}

function clampSigned(value: number): number {
  return Math.max(-1, Math.min(1, value));
}

export function actorImpulse(item: ActorItem, estimatedCapacity: number, edgeReliability: number): number {
  if (item.itemType !== "OBSERVED_ACTION") return 0;
  return clampSigned(item.magnitude) * clamp01(estimatedCapacity) * clamp01(edgeReliability) * clamp01(item.confidence);
}

export function causalChainConfidence(evidenceConfidences: number[], edgeReliabilities: number[]): number {
  if (evidenceConfidences.length === 0) return 0;
  const weakestEvidence = Math.min(...evidenceConfidences.map(clamp01));
  const reliabilityProduct = edgeReliabilities.map(clamp01).reduce((acc, value) => acc * value, 1);
  return weakestEvidence * reliabilityProduct;
}

export function capPoliticalIncentiveConfidence(item: ActorItem): ActorItem {
  if (item.itemType !== "INFERRED_INCENTIVE") return item;
  return { ...item, confidence: Math.min(0.35, item.confidence) };
}
