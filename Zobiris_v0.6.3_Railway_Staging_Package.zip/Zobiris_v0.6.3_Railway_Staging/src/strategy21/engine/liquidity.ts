export interface OrderBookLevel {
  price: number;
  size: number;
}

export interface OrderBookSnapshot {
  pair: string;
  observedAt: string;
  bids: OrderBookLevel[];
  asks: OrderBookLevel[];
  activeMinute: boolean;
  tradeNotional1m: number;
}

export interface LiquidityProfile {
  snapshots: OrderBookSnapshot[];
  invalidBookCount: number;
  dailyCredibleNotionalUsd: number[];
  coverageDays: number;
  medianDailyNotionalUsd: number;
  p10DailyNotionalUsd: number;
  activeMinuteCoverage: number;
  spreadP95Bps: number;
  bidDepth50P10Usd: number;
  askDepth50P10Usd: number;
  bidDepth100P10Usd: number;
  askDepth100P10Usd: number;
}

export type LiquidityEligibilityStatus = "QUARANTINED" | "INELIGIBLE" | "WATCH_ONLY" | "ACTIVE_ELIGIBLE";

export interface LiquidityEligibilityInput {
  pair: string;
  plannedOrderUsd: number;
  intendedFinalPositionUsd: number;
  profile: LiquidityProfile;
  identityVerified: boolean;
  activeKrakenUsdPair: boolean;
  migrationResolved: boolean;
  exploitClear: boolean;
  tokenomicsComplete: boolean;
  bookFresh: boolean;
  /** All-in fee estimate for one side of the round trip. Missing fee evidence fails closed after history is complete. */
  takerFeeBpsPerSide?: number;
  /** Optional expected gross return used to ensure costs consume <=25% of expected edge. */
  estimatedGrossExpectedReturnBps?: number;
}

export interface LiquidityEligibilityResult {
  status: LiquidityEligibilityStatus;
  maximumOrderUsd: number;
  maximumPositionUsd: number;
  spreadP95Bps: number;
  entryImpactP95Bps: number | null;
  exitImpactP95Bps: number | null;
  stressedExitImpactBps: number | null;
  failureReasons: string[];
}

export function isBookStructurallyValid(snapshot: OrderBookSnapshot): boolean {
  const bestBid = snapshot.bids[0]?.price;
  const bestAsk = snapshot.asks[0]?.price;
  if (bestBid === undefined || bestAsk === undefined || bestBid <= 0 || bestAsk <= 0) return false;
  if (bestBid >= bestAsk) return false;
  if (snapshot.bids.some((level) => !Number.isFinite(level.price) || !Number.isFinite(level.size) || level.price <= 0 || level.size < 0)) return false;
  if (snapshot.asks.some((level) => !Number.isFinite(level.price) || !Number.isFinite(level.size) || level.price <= 0 || level.size < 0)) return false;
  return true;
}

function midpoint(snapshot: OrderBookSnapshot): number {
  const bestBid = snapshot.bids[0]?.price;
  const bestAsk = snapshot.asks[0]?.price;
  if (!isBookStructurallyValid(snapshot) || bestBid === undefined || bestAsk === undefined) {
    throw new Error("order book is empty, crossed, or invalid");
  }
  return (bestBid + bestAsk) / 2;
}

export function spreadBps(snapshot: OrderBookSnapshot): number {
  const bestBid = snapshot.bids[0]?.price;
  const bestAsk = snapshot.asks[0]?.price;
  if (bestBid === undefined || bestAsk === undefined) throw new Error("order book is empty");
  const mid = midpoint(snapshot);
  return 10_000 * ((bestAsk - bestBid) / mid);
}

export function dollarDepthWithinBps(snapshot: OrderBookSnapshot, side: "bid" | "ask", deltaBps: number): number {
  const mid = midpoint(snapshot);
  const levels = side === "bid" ? snapshot.bids : snapshot.asks;
  const threshold = side === "bid"
    ? mid * (1 - deltaBps / 10_000)
    : mid * (1 + deltaBps / 10_000);

  return levels.reduce((sum, level) => {
    const inside = side === "bid" ? level.price >= threshold : level.price <= threshold;
    return inside ? sum + level.price * level.size : sum;
  }, 0);
}

function vwapForDollarOrder(snapshot: OrderBookSnapshot, side: "buy" | "sell", orderUsd: number): number | null {
  if (orderUsd <= 0) return midpoint(snapshot);
  const levels = side === "buy" ? snapshot.asks : snapshot.bids;
  let remainingUsd = orderUsd;
  let acquiredBase = 0;
  let spentUsd = 0;

  for (const level of levels) {
    if (remainingUsd <= 1e-9) break;
    const levelUsd = level.price * level.size;
    const takeUsd = Math.min(levelUsd, remainingUsd);
    const base = takeUsd / level.price;
    acquiredBase += base;
    spentUsd += takeUsd;
    remainingUsd -= takeUsd;
  }

  if (remainingUsd > 1e-6 || acquiredBase <= 0) return null;
  return spentUsd / acquiredBase;
}

export function simulateImpactBps(snapshot: OrderBookSnapshot, side: "buy" | "sell", orderUsd: number): number {
  const mid = midpoint(snapshot);
  const vwap = vwapForDollarOrder(snapshot, side, orderUsd);
  if (vwap === null) return Number.POSITIVE_INFINITY;
  return side === "buy"
    ? 10_000 * (vwap / mid - 1)
    : 10_000 * (1 - vwap / mid);
}

/**
 * Nearest-rank quantile used for execution-risk percentiles.
 * For n observations, rank = ceil(p * n), clamped to [1, n].
 * This makes p10 for 14 observations the second-lowest value.
 */
export function quantile(values: number[], p: number): number {
  if (values.length === 0) return Number.NaN;
  const sorted = [...values].sort((a, b) => a - b);
  const clamped = Math.max(0, Math.min(1, p));
  const rank = Math.max(1, Math.min(sorted.length, Math.ceil(clamped * sorted.length)));
  return sorted[rank - 1] ?? Number.NaN;
}

/** Arithmetic median remains distinct from nearest-rank percentiles. */
export function median(values: number[]): number {
  if (values.length === 0) return Number.NaN;
  const sorted = [...values].sort((a, b) => a - b);
  const middle = Math.floor(sorted.length / 2);
  if (sorted.length % 2 === 1) return sorted[middle] ?? Number.NaN;
  const lo = sorted[middle - 1];
  const hi = sorted[middle];
  return lo === undefined || hi === undefined ? Number.NaN : (lo + hi) / 2;
}

function uniqueUtcDays(snapshots: OrderBookSnapshot[]): number {
  return new Set(snapshots.map((s) => s.observedAt.slice(0, 10))).size;
}

export function buildLiquidityProfile(input: {
  snapshots: OrderBookSnapshot[];
  dailyCredibleNotionalUsd: number[];
}): LiquidityProfile {
  const sorted = [...input.snapshots].sort((a, b) => Date.parse(a.observedAt) - Date.parse(b.observedAt));
  const snapshots = sorted.filter(isBookStructurallyValid);
  const invalidBookCount = sorted.length - snapshots.length;
  const validNotional = input.dailyCredibleNotionalUsd.filter((v) => Number.isFinite(v) && v >= 0);
  const latestMs = sorted.length ? Math.max(...sorted.map((s) => Date.parse(s.observedAt)).filter(Number.isFinite)) : Number.NaN;
  const recent = Number.isFinite(latestMs)
    ? sorted.filter((s) => isBookStructurallyValid(s) && Date.parse(s.observedAt) >= latestMs - 24 * 60 * 60 * 1000)
    : [];
  const active = recent.filter((s) => s.activeMinute).length;

  return {
    snapshots,
    invalidBookCount,
    dailyCredibleNotionalUsd: validNotional,
    coverageDays: Math.min(uniqueUtcDays(snapshots), validNotional.length),
    medianDailyNotionalUsd: median(validNotional),
    p10DailyNotionalUsd: quantile(validNotional, 0.1),
    activeMinuteCoverage: recent.length === 0 ? 0 : active / recent.length,
    spreadP95Bps: quantile(snapshots.map(spreadBps), 0.95),
    bidDepth50P10Usd: quantile(snapshots.map((s) => dollarDepthWithinBps(s, "bid", 50)), 0.1),
    askDepth50P10Usd: quantile(snapshots.map((s) => dollarDepthWithinBps(s, "ask", 50)), 0.1),
    bidDepth100P10Usd: quantile(snapshots.map((s) => dollarDepthWithinBps(s, "bid", 100)), 0.1),
    askDepth100P10Usd: quantile(snapshots.map((s) => dollarDepthWithinBps(s, "ask", 100)), 0.1),
  };
}

function stressBook(snapshot: OrderBookSnapshot): OrderBookSnapshot {
  const mid = midpoint(snapshot);
  const minBid = mid * (1 - 25 / 10_000);
  const bids = snapshot.bids
    .filter((level) => level.price < minBid)
    .map((level) => ({ ...level, size: level.size * 0.5 }));
  return { ...snapshot, bids };
}

export function stressedExitCapacity(snapshot: OrderBookSnapshot, maxImpactBps = 250): number {
  const stressed = stressBook(snapshot);
  if (stressed.bids.length === 0) return 0;
  const depth250 = dollarDepthWithinBps(stressed, "bid", maxImpactBps);
  const depthCap = 0.20 * depth250;
  if (depthCap <= 0) return 0;

  let lo = 0;
  let hi = depthCap;
  for (let i = 0; i < 40; i += 1) {
    const midUsd = (lo + hi) / 2;
    const impact = simulateImpactBps(stressed, "sell", midUsd);
    if (impact <= maxImpactBps) lo = midUsd;
    else hi = midUsd;
  }
  return lo;
}

function totalSideUsd(snapshot: OrderBookSnapshot, side: "buy" | "sell"): number {
  const levels = side === "buy" ? snapshot.asks : snapshot.bids;
  return levels.reduce((sum, level) => sum + level.price * level.size, 0);
}

function maxOrderForImpact(snapshots: OrderBookSnapshot[], side: "buy" | "sell", impactLimitBps: number): number {
  if (snapshots.length === 0) return 0;
  const upper = Math.min(...snapshots.map((s) => totalSideUsd(s, side)));
  let lo = 0;
  let hi = upper;
  for (let i = 0; i < 40; i += 1) {
    const q = (lo + hi) / 2;
    const impacts = snapshots.map((s) => simulateImpactBps(s, side, q));
    const p95 = quantile(impacts, 0.95);
    if (p95 <= impactLimitBps) lo = q;
    else hi = q;
  }
  return lo;
}

function p95Impact(snapshots: OrderBookSnapshot[], side: "buy" | "sell", q: number): number | null {
  if (snapshots.length === 0) return null;
  return quantile(snapshots.map((s) => simulateImpactBps(s, side, q)), 0.95);
}

function round2(value: number): number {
  return Math.round(value * 100) / 100;
}

export function evaluateLiquidityEligibility(input: LiquidityEligibilityInput): LiquidityEligibilityResult {
  const failures: string[] = [];
  const latest = input.profile.snapshots.at(-1);
  const staticBroken = !input.identityVerified || !input.activeKrakenUsdPair || !input.migrationResolved || !input.exploitClear || !input.bookFresh;

  if (!input.exploitClear) {
    return {
      status: "QUARANTINED",
      maximumOrderUsd: 0,
      maximumPositionUsd: 0,
      spreadP95Bps: input.profile.spreadP95Bps,
      entryImpactP95Bps: null,
      exitImpactP95Bps: null,
      stressedExitImpactBps: null,
      failureReasons: ["exploit, custody, or integrity quarantine"],
    };
  }

  if (staticBroken || !latest) {
    if (!input.identityVerified) failures.push("identity not verified");
    if (!input.activeKrakenUsdPair) failures.push("active Kraken USD pair not verified");
    if (!input.migrationResolved) failures.push("migration or symbol collision unresolved");
    if (!input.bookFresh) failures.push("Kraken book is stale");
    if (!latest) failures.push("Kraken book is missing");
    return {
      status: "INELIGIBLE",
      maximumOrderUsd: 0,
      maximumPositionUsd: 0,
      spreadP95Bps: input.profile.spreadP95Bps,
      entryImpactP95Bps: null,
      exitImpactP95Bps: null,
      stressedExitImpactBps: null,
      failureReasons: failures,
    };
  }

  const requiredMetrics = [
    input.profile.coverageDays, input.profile.medianDailyNotionalUsd,
    input.profile.p10DailyNotionalUsd, input.profile.activeMinuteCoverage,
    input.profile.spreadP95Bps, input.profile.bidDepth50P10Usd,
    input.profile.askDepth50P10Usd, input.profile.bidDepth100P10Usd,
    input.profile.askDepth100P10Usd,
  ];
  const missingMetric = requiredMetrics.some((value) => !Number.isFinite(value) || value < 0);
  const invalidFee = input.takerFeeBpsPerSide === undefined || !Number.isFinite(input.takerFeeBpsPerSide) || input.takerFeeBpsPerSide < 0;
  if (!input.tokenomicsComplete || input.profile.coverageDays < 14 || invalidFee || input.profile.invalidBookCount > 0 || missingMetric) {
    if (missingMetric) failures.push("required liquidity metric is missing or invalid");
    if (!input.tokenomicsComplete) failures.push("critical tokenomics evidence incomplete");
    if (input.profile.coverageDays < 14) failures.push("14-day Kraken book/notional history incomplete");
    if (invalidFee) failures.push("Kraken execution fee evidence incomplete or invalid");
    if (input.profile.invalidBookCount > 0) failures.push("crossed or invalid order-book snapshots detected");
    return {
      status: "WATCH_ONLY",
      maximumOrderUsd: 0,
      maximumPositionUsd: 0,
      spreadP95Bps: input.profile.spreadP95Bps,
      entryImpactP95Bps: null,
      exitImpactP95Bps: null,
      stressedExitImpactBps: null,
      failureReasons: failures,
    };
  }

  if (input.estimatedGrossExpectedReturnBps === undefined || !Number.isFinite(input.estimatedGrossExpectedReturnBps) || input.estimatedGrossExpectedReturnBps < 0) {
    return {
      status: "WATCH_ONLY",
      maximumOrderUsd: 0,
      maximumPositionUsd: 0,
      spreadP95Bps: input.profile.spreadP95Bps,
      entryImpactP95Bps: null,
      exitImpactP95Bps: null,
      stressedExitImpactBps: null,
      failureReasons: ["expected gross return evidence incomplete"],
    };
  }

  const currentSpread = spreadBps(latest);
  if (currentSpread > 100) failures.push("current book spread exceeds broken-market ceiling");

  const qBuy35 = maxOrderForImpact(input.profile.snapshots, "buy", 35);
  const qSell50 = maxOrderForImpact(input.profile.snapshots, "sell", 50);
  const capacityParts = [
    input.profile.medianDailyNotionalUsd / 500,
    input.profile.p10DailyNotionalUsd / 200,
    input.profile.askDepth50P10Usd / 10,
    input.profile.bidDepth50P10Usd / 10,
    input.profile.askDepth100P10Usd / 25,
    input.profile.bidDepth100P10Usd / 25,
    qBuy35,
    qSell50,
  ].filter((v) => Number.isFinite(v) && v >= 0);
  const maximumOrderUsd = capacityParts.length === 0 ? 0 : Math.min(...capacityParts);
  const stressedCaps = input.profile.snapshots.map((s) => stressedExitCapacity(s, 250));
  const maximumPositionUsd = quantile(stressedCaps, 0.1);

  const entryImpactP95Bps = p95Impact(input.profile.snapshots, "buy", input.plannedOrderUsd);
  const exitImpactP95Bps = p95Impact(input.profile.snapshots, "sell", input.plannedOrderUsd);
  const latestStressed = stressBook(latest);
  const stressedExitImpactBps = simulateImpactBps(latestStressed, "sell", input.intendedFinalPositionUsd);

  if (input.profile.activeMinuteCoverage < 0.90) failures.push("active-minute coverage below 90%");
  if (input.profile.spreadP95Bps > 25) failures.push("95th-percentile spread exceeds 25 bps");
  if ((entryImpactP95Bps ?? Number.POSITIVE_INFINITY) > 35) failures.push("entry impact exceeds 35 bps");
  if ((exitImpactP95Bps ?? Number.POSITIVE_INFINITY) > 50) failures.push("exit impact exceeds 50 bps");
  if (input.profile.bidDepth50P10Usd < 10 * input.plannedOrderUsd) failures.push("50-bps bid depth below 10x order");
  if (input.profile.askDepth50P10Usd < 10 * input.plannedOrderUsd) failures.push("50-bps ask depth below 10x order");
  if (input.profile.bidDepth100P10Usd < 25 * input.plannedOrderUsd) failures.push("100-bps bid depth below 25x order");
  if (input.profile.askDepth100P10Usd < 25 * input.plannedOrderUsd) failures.push("100-bps ask depth below 25x order");
  if (input.plannedOrderUsd > maximumOrderUsd) failures.push("planned order exceeds size-adaptive execution capacity");
  if (input.intendedFinalPositionUsd > maximumPositionUsd) failures.push("intended final position exceeds stressed exit capacity");
  if (stressedExitImpactBps > 250) failures.push("stressed final-position liquidation exceeds 250 bps");

  const feeBps = Math.max(0, input.takerFeeBpsPerSide ?? 0) * 2;
  const roundTripBps = (entryImpactP95Bps ?? Number.POSITIVE_INFINITY) + (exitImpactP95Bps ?? Number.POSITIVE_INFINITY) + feeBps;
  const expectedReturnCostCeiling = Math.max(0, input.estimatedGrossExpectedReturnBps) * 0.25;
  const allInCostCeiling = Math.min(150, expectedReturnCostCeiling);
  if (roundTripBps > allInCostCeiling) failures.push("estimated round-trip execution cost exceeds approved ceiling");

  return {
    status: failures.length === 0 ? "ACTIVE_ELIGIBLE" : "INELIGIBLE",
    maximumOrderUsd: round2(maximumOrderUsd),
    maximumPositionUsd: round2(maximumPositionUsd),
    spreadP95Bps: round2(input.profile.spreadP95Bps),
    entryImpactP95Bps: entryImpactP95Bps === null ? null : round2(entryImpactP95Bps),
    exitImpactP95Bps: exitImpactP95Bps === null ? null : round2(exitImpactP95Bps),
    stressedExitImpactBps: Number.isFinite(stressedExitImpactBps) ? round2(stressedExitImpactBps) : null,
    failureReasons: failures,
  };
}
