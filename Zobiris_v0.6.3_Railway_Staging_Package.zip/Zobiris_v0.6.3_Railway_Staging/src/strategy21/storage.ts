import { randomUUID } from 'node:crypto';
import { openStorage } from '../storage/client.js';
import { buildLiquidityProfile, type OrderBookSnapshot } from './engine/liquidity.js';
import type { PreviousMarketState } from './engine/marketState.js';
import type { StrategyLiquidityInput } from './integration.js';

const STRATEGY_SQL = `
CREATE TABLE IF NOT EXISTS strategy21_book_snapshots (
  id TEXT PRIMARY KEY,
  symbol TEXT NOT NULL,
  pair TEXT NOT NULL,
  observed_at INTEGER NOT NULL,
  bids_json TEXT NOT NULL,
  asks_json TEXT NOT NULL,
  active_minute INTEGER NOT NULL DEFAULT 0,
  trade_notional_1m REAL NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS strategy21_book_symbol_time_idx ON strategy21_book_snapshots(symbol, observed_at);
CREATE TABLE IF NOT EXISTS strategy21_daily_notional (
  symbol TEXT NOT NULL,
  day TEXT NOT NULL,
  notional_usd REAL NOT NULL,
  observed_at INTEGER NOT NULL,
  PRIMARY KEY(symbol, day)
);
CREATE TABLE IF NOT EXISTS strategy21_market_state (
  id TEXT PRIMARY KEY CHECK(id='current'),
  state TEXT NOT NULL,
  entered_at TEXT NOT NULL,
  minimum_dwell_until TEXT NOT NULL,
  updated_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS strategy21_collector_state (
  id TEXT PRIMARY KEY CHECK(id='current'),
  rotation_cursor INTEGER NOT NULL DEFAULT 0,
  updated_at INTEGER NOT NULL
);
`;

export function ensureStrategy21Storage(dbPath?: string): void {
  const storage = openStorage({ path: dbPath });
  try { storage.sqlite.exec(STRATEGY_SQL); } finally { storage.close(); }
}

export function saveStrategyBookSnapshot(dbPath: string | undefined, symbol: string, snapshot: OrderBookSnapshot, dailyNotionalUsd: number): void {
  const storage = openStorage({ path: dbPath });
  try {
    storage.sqlite.exec(STRATEGY_SQL);
    storage.sqlite.prepare(`INSERT INTO strategy21_book_snapshots
      (id,symbol,pair,observed_at,bids_json,asks_json,active_minute,trade_notional_1m)
      VALUES (?,?,?,?,?,?,?,?)`).run(
      randomUUID(), symbol.toUpperCase(), snapshot.pair, Date.parse(snapshot.observedAt), JSON.stringify(snapshot.bids), JSON.stringify(snapshot.asks), snapshot.activeMinute ? 1 : 0, snapshot.tradeNotional1m,
    );
    const day = snapshot.observedAt.slice(0,10);
    storage.sqlite.prepare(`INSERT INTO strategy21_daily_notional(symbol,day,notional_usd,observed_at)
      VALUES (?,?,?,?) ON CONFLICT(symbol,day) DO UPDATE SET notional_usd=excluded.notional_usd, observed_at=excluded.observed_at`).run(
      symbol.toUpperCase(), day, dailyNotionalUsd, Date.parse(snapshot.observedAt),
    );
    const cutoff = Date.now() - 16*24*60*60*1000;
    storage.sqlite.prepare('DELETE FROM strategy21_book_snapshots WHERE observed_at < ?').run(cutoff);
  } finally { storage.close(); }
}

export function loadStrategyLiquidity(dbPath: string | undefined, symbols: string[]): Map<string, StrategyLiquidityInput> {
  const storage = openStorage({ path: dbPath });
  const out = new Map<string, StrategyLiquidityInput>();
  try {
    storage.sqlite.exec(STRATEGY_SQL);
    const cutoff = Date.now() - 15*24*60*60*1000;
    const bookStmt = storage.sqlite.prepare(`SELECT * FROM strategy21_book_snapshots WHERE symbol=? AND observed_at>=? ORDER BY observed_at ASC`);
    const notionalStmt = storage.sqlite.prepare(`SELECT day,notional_usd FROM strategy21_daily_notional WHERE symbol=? ORDER BY day ASC LIMIT 14`);
    for (const rawSymbol of symbols) {
      const symbol = rawSymbol.toUpperCase();
      const rows = bookStmt.all(symbol, cutoff) as Array<Record<string, unknown>>;
      if (!rows.length) continue;
      const snapshots: OrderBookSnapshot[] = rows.map((r) => ({
        pair: String(r.pair), observedAt: new Date(Number(r.observed_at)).toISOString(),
        bids: JSON.parse(String(r.bids_json)), asks: JSON.parse(String(r.asks_json)),
        activeMinute: Number(r.active_minute) === 1, tradeNotional1m: Number(r.trade_notional_1m),
      }));
      const daily = (notionalStmt.all(symbol) as Array<{notional_usd:number}>).map((r) => Number(r.notional_usd));
      const pair = snapshots.at(-1)!.pair;
      out.set(symbol, {
        pair,
        profile: buildLiquidityProfile({ snapshots, dailyCredibleNotionalUsd: daily }),
        takerFeeBpsPerSide: Number(process.env.ZOBIRIS_KRAKEN_FEE_BPS ?? '40'),
      });
    }
    return out;
  } finally { storage.close(); }
}

export function saveStrategyMarketState(dbPath: string | undefined, state: PreviousMarketState): void {
  const storage = openStorage({ path: dbPath });
  try {
    storage.sqlite.exec(STRATEGY_SQL);
    storage.sqlite.prepare(`INSERT INTO strategy21_market_state(id,state,entered_at,minimum_dwell_until,updated_at)
      VALUES ('current',?,?,?,?) ON CONFLICT(id) DO UPDATE SET state=excluded.state,entered_at=excluded.entered_at,minimum_dwell_until=excluded.minimum_dwell_until,updated_at=excluded.updated_at`)
      .run(state.state, state.enteredAt, state.minimumDwellUntil, Date.now());
  } finally { storage.close(); }
}

export function loadStrategyMarketState(dbPath?: string): PreviousMarketState | undefined {
  const storage = openStorage({ path: dbPath });
  try {
    storage.sqlite.exec(STRATEGY_SQL);
    const row = storage.sqlite.prepare('SELECT state,entered_at,minimum_dwell_until FROM strategy21_market_state WHERE id=\'current\'').get() as {state:string;entered_at:string;minimum_dwell_until:string}|undefined;
    if (!row) return undefined;
    return { state: row.state as PreviousMarketState['state'], enteredAt: row.entered_at, minimumDwellUntil: row.minimum_dwell_until };
  } finally { storage.close(); }
}

export function readCollectorCursor(dbPath?: string): number {
  const storage = openStorage({ path: dbPath });
  try {
    storage.sqlite.exec(STRATEGY_SQL);
    const row = storage.sqlite.prepare("SELECT rotation_cursor FROM strategy21_collector_state WHERE id='current'").get() as {rotation_cursor:number}|undefined;
    return Number(row?.rotation_cursor ?? 0);
  } finally { storage.close(); }
}

export function writeCollectorCursor(dbPath: string | undefined, cursor: number): void {
  const storage = openStorage({ path: dbPath });
  try {
    storage.sqlite.exec(STRATEGY_SQL);
    storage.sqlite.prepare(`INSERT INTO strategy21_collector_state(id,rotation_cursor,updated_at) VALUES('current',?,?)
      ON CONFLICT(id) DO UPDATE SET rotation_cursor=excluded.rotation_cursor,updated_at=excluded.updated_at`).run(cursor, Date.now());
  } finally { storage.close(); }
}
