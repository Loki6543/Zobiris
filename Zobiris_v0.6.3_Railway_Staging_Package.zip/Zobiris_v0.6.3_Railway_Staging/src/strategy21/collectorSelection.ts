const PRIORITY = ['BTC','SOL','ONDO','KAS','NEAR','TAO','RENDER','HBAR','SUI','AKT','APT'];

export function selectCollectionSymbols(watchlist: string[], cursor: number, totalSlots = 12, prioritySlots = 9): { symbols:string[]; nextCursor:number } {
  const universe = [...new Set(watchlist.map((s)=>s.toUpperCase()))];
  const priority = PRIORITY.filter((s)=>universe.includes(s)).slice(0, Math.min(prioritySlots,totalSlots));
  const rest = universe.filter((s)=>!priority.includes(s));
  const rotateSlots = Math.max(0,totalSlots-priority.length);
  const rotating: string[] = [];
  for (let i=0;i<Math.min(rotateSlots,rest.length);i++) rotating.push(rest[(cursor+i)%rest.length]!);
  return { symbols:[...priority,...rotating], nextCursor: rest.length ? (cursor+rotating.length)%rest.length : 0 };
}
