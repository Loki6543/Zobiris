import test from "node:test";
import assert from "node:assert/strict";
import {
  computeDiscoveryCatalyst,
  computeExecutionQuality,
  computeFundamentalTrajectory,
  computeLossResilience,
  computeMemeOpportunity,
  computeOpportunityHeuristic,
  computeFlowSetup,
} from "../engine/factors.js";

test("fundamental trajectory requires at least two independent usage/economic families", () => {
  const result = computeFundamentalTrajectory({ usersDelta: 0.4 });
  assert.equal(result.value, null);
  assert.ok(result.coverage < 0.5);
});

test("execution quality rewards tight spreads low impact and ample depth", () => {
  const good = computeExecutionQuality({
    spreadP95Bps: 5,
    impactP95Bps: 8,
    depth50ToOrder: 30,
    depth100ToOrder: 60,
    venueHhi: 0.2,
    activeMinuteCoverage: 0.99,
  });
  const bad = computeExecutionQuality({
    spreadP95Bps: 24,
    impactP95Bps: 34,
    depth50ToOrder: 10,
    depth100ToOrder: 25,
    venueHhi: 0.9,
    activeMinuteCoverage: 0.91,
  });
  assert.ok(good.value !== null && bad.value !== null);
  assert.ok(good.value > bad.value);
});

test("volume residual changes flow/setup without changing execution quality", () => {
  const execution = computeExecutionQuality({
    spreadP95Bps: 5,
    impactP95Bps: 8,
    depth50ToOrder: 30,
    depth100ToOrder: 60,
    venueHhi: 0.2,
    activeMinuteCoverage: 0.99,
  });
  const lowFlow = computeFlowSetup({
    spotCvd: 0.1,
    spotVolumeResidual: -0.5,
    betaNeutralRelativeStrength: 0.1,
    priceStructure: 0.1,
    leverageResilience: 0.1,
  });
  const highFlow = computeFlowSetup({
    spotCvd: 0.1,
    spotVolumeResidual: 0.8,
    betaNeutralRelativeStrength: 0.1,
    priceStructure: 0.1,
    leverageResilience: 0.1,
  });
  assert.ok(highFlow.value !== null && lowFlow.value !== null && execution.value !== null);
  assert.ok(highFlow.value > lowFlow.value);
  assert.ok(execution.value > 0.5);
});

test("loss resilience falls when dilution unlock security and concentration risks rise", () => {
  const safe = computeLossResilience({
    dilutionRisk: 0.1,
    unlockRisk: 0.1,
    securityRisk: 0.1,
    holderConcentration: 0.2,
    regulatoryTail: 0.1,
    venueDependency: 0.1,
  });
  const risky = computeLossResilience({
    dilutionRisk: 0.9,
    unlockRisk: 0.9,
    securityRisk: 0.7,
    holderConcentration: 0.9,
    regulatoryTail: 0.5,
    venueDependency: 0.8,
  });
  assert.ok(safe.value !== null && risky.value !== null);
  assert.ok(safe.value > risky.value);
});

test("heuristic score keeps confidence and coverage separate from attractiveness", () => {
  const f = computeFundamentalTrajectory({ usersDelta: 0.4, feesDelta: 0.3, developerBreadthDelta: 0.2 });
  const x = computeExecutionQuality({ spreadP95Bps: 5, impactP95Bps: 8, depth50ToOrder: 30, depth100ToOrder: 60, venueHhi: 0.2, activeMinuteCoverage: 0.99 });
  const g = computeFlowSetup({ spotCvd: 0.4, spotVolumeResidual: 0.3, betaNeutralRelativeStrength: 0.2, priceStructure: 0.3, leverageResilience: 0.4 });
  const d = computeDiscoveryCatalyst({ contributorBreadth: 0.6, attentionAcceleration: 0.5, catalystObservability: 0.8, sourceDiversity: 0.7, attentionHeadroom: 0.7, crowdingPenalty: 0.1 });
  const r = computeLossResilience({ dilutionRisk: 0.2, unlockRisk: 0.1, securityRisk: 0.1, holderConcentration: 0.2, regulatoryTail: 0.2, venueDependency: 0.2 });
  const score = computeOpportunityHeuristic({ fundamental: f, execution: x, flow: g, discovery: d, resilience: r, evidenceConfidence: 0.72 });
  assert.ok(score.score > 50);
  assert.equal(score.confidence, 0.72);
  assert.ok(score.coverage > 0.8);
});

test("meme model cannot let social excitement erase poor distribution integrity", () => {
  const common = {
    execution: { value: 0.85, coverage: 1 },
    flow: { value: 0.9, coverage: 1 },
    discovery: { value: 0.95, coverage: 1 },
    resilience: { value: 0.6, coverage: 1 },
    evidenceConfidence: 0.9,
  };
  const poor = computeMemeOpportunity({
    ...common,
    distributionIntegrity: 0.15,
  });
  const healthy = computeMemeOpportunity({
    ...common,
    distributionIntegrity: 0.8,
  });
  assert.ok(poor.score < healthy.score);
  assert.ok(poor.score <= 40);
  assert.equal(poor.coreAuthority, false);
});
