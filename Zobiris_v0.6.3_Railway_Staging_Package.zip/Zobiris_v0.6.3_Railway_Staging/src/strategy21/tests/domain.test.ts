import test from "node:test";
import assert from "node:assert/strict";
import {
  createDerivedEvidence,
  validateEvidenceItem,
  type EvidenceItem,
} from "../domain/evidence.js";
import {
  DependencyRegistry,
  countIndependentConfirmations,
} from "../engine/dependencyRegistry.js";

test("evidence validation rejects confidence outside 0..1", () => {
  const bad = {
    id: "e1",
    type: "OBSERVATION",
    claim: "BTC price observed",
    value: 80770,
    confidence: 1.2,
    observedAt: "2026-09-04T07:39:00Z",
    expiresAt: "2026-09-04T07:44:00Z",
    horizon: "MINUTES",
    sourceClass: "exchange",
    dependencies: ["kraken:BTCUSD"],
    contradictions: [],
  } satisfies EvidenceItem;

  const result = validateEvidenceItem(bad);
  assert.equal(result.ok, false);
  assert.match(result.errors.join(" "), /confidence/i);
});

test("derived evidence inherits source dependencies without duplication", () => {
  const a: EvidenceItem = {
    id: "a",
    type: "OBSERVATION",
    claim: "spot flow",
    value: 0.4,
    confidence: 0.9,
    observedAt: "2026-09-04T07:39:00Z",
    expiresAt: "2026-09-04T08:39:00Z",
    horizon: "HOURS",
    sourceClass: "exchange",
    dependencies: ["kraken:trades", "btc:spot"],
    contradictions: [],
  };
  const b: EvidenceItem = {
    ...a,
    id: "b",
    claim: "relative strength",
    dependencies: ["btc:spot", "price:asset"],
  };

  const derived = createDerivedEvidence({
    id: "d",
    claim: "flow setup",
    value: 0.5,
    sources: [a, b],
    confidence: 0.8,
    observedAt: a.observedAt,
    expiresAt: a.expiresAt,
    horizon: "HOURS",
    sourceClass: "engine",
  });

  assert.deepEqual(derived.dependencies.sort(), ["btc:spot", "kraken:trades", "price:asset"].sort());
});

test("dependency registry forbids one signal from having two primary roots", () => {
  const registry = new DependencyRegistry();
  registry.register("spotCvd", "SPOT_FLOW");
  assert.throws(() => registry.register("spotCvd", "PRICE_STRUCTURE"), /already registered/i);
});

test("independent confirmations count dependency roots, not indicator count", () => {
  const registry = new DependencyRegistry();
  registry.register("trend", "PRICE_STRUCTURE");
  registry.register("relativeStrength", "PRICE_STRUCTURE");
  registry.register("spotCvd", "SPOT_FLOW");
  registry.register("funding", "LEVERAGE");

  assert.equal(
    countIndependentConfirmations(["trend", "relativeStrength", "spotCvd", "funding"], registry),
    3,
  );
});
