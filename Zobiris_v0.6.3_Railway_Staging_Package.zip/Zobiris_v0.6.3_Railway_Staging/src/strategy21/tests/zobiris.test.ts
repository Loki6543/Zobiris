import test from "node:test";
import assert from "node:assert/strict";
import type { EvidenceItem } from "../domain/evidence.js";
import type { FactorResult, OpportunityHeuristicResult } from "../engine/factors.js";
import { createCapitalLedger } from "../engine/capital.js";
import { evaluateZobirisDecision, type ZobirisDecisionInput } from "../engine/zobiris.js";
import type { MarketStateResult } from "../engine/marketState.js";
import type { LiquidityEligibilityResult } from "../engine/liquidity.js";

const asOf = "2026-09-04T08:00:00.000Z";

function market(state: MarketStateResult["state"] = "BROAD_EXPANSION"): MarketStateResult {
  return {
    state,
    enteredAt: asOf,
    minimumDwellUntil: "2026-09-06T08:00:00.000Z",
    confidence: 0.82,
    deploymentCapPct: state === "BROAD_EXPANSION" ? 0.85 : 0.15,
    reason: "fixture market",
    axes: {
      btcStructure: 0.5,
      breadth: 0.5,
      spotParticipation: 0.5,
      leverageCrowding: 0.1,
      liquidityStress: 0,
      extension: 0.2,
      macroImpulse: 0,
    },
  };
}

function eligible(status: LiquidityEligibilityResult["status"] = "ACTIVE_ELIGIBLE"): LiquidityEligibilityResult {
  return {
    status,
    maximumOrderUsd: status === "ACTIVE_ELIGIBLE" ? 100 : 0,
    maximumPositionUsd: status === "ACTIVE_ELIGIBLE" ? 250 : 0,
    spreadP95Bps: 5,
    entryImpactP95Bps: 3,
    exitImpactP95Bps: 4,
    stressedExitImpactBps: 80,
    failureReasons: status === "ACTIVE_ELIGIBLE" ? [] : ["fixture failure"],
  };
}

const goodFactor: FactorResult = { value: 0.8, coverage: 1 };
const opportunity: OpportunityHeuristicResult = {
  score: 80,
  confidence: 0.8,
  coverage: 1,
  eligibleForRanking: true,
};

function evidence(type: "OBSERVATION" | "CAUSAL_HYPOTHESIS", id: string): EvidenceItem {
  return {
    id,
    type,
    claim: id,
    value: 1,
    confidence: type === "OBSERVATION" ? 0.95 : 0.3,
    observedAt: asOf,
    expiresAt: "2026-09-05T08:00:00.000Z",
    horizon: "DAYS",
    sourceClass: "fixture",
    dependencies: type === "OBSERVATION" ? ["SPOT_FLOW"] : ["MACRO"],
    contradictions: [],
  };
}

function baseInput(): ZobirisDecisionInput {
  return {
    asset: { id: "ondo", symbol: "ONDO", name: "Ondo", assetClass: "CORE" as const },
    asOf,
    market: market(),
    eligibility: eligible(),
    factors: {
      fundamental: goodFactor,
      execution: goodFactor,
      flow: goodFactor,
      discovery: goodFactor,
      resilience: goodFactor,
    },
    opportunity,
    assetStateInput: {
      eligibility: "ACTIVE_ELIGIBLE" as const,
      confidence: 0.8,
      fundamentalTrajectory: 0.2,
      developerHealth: 0.8,
      minimumDeveloperHealth: 0.5,
      attentionPercentile: 45,
      crowdingThreshold: 60,
      observableCatalyst: true,
      contributorBreadthImproving: false,
      spotAccumulation: true,
      structurallyDeclining: false,
      extended: false,
      deterioration: false,
      existingPositionUsd: 0,
      nonPriceConfirmation: false,
      trendConfirmed: false,
      profitable: false,
      expectedNextDollarBelowHoldHurdle: false,
    },
    ledger: createCapitalLedger(),
    portfolio: { grossExposureUsd: 0, assetExposureUsd: 0, clusterExposureUsd: 0, memeExposureUsd: 0 },
    requestedTargetUsd: 120,
    evidence: [evidence("OBSERVATION", "spot_accumulation"), evidence("CAUSAL_HYPOTHESIS", "macro_story")],
    lineSignals: {
      nonPriceConfirmation: false,
      liquidityStable: true,
      supplyRiskStable: true,
      spotRelativeStrengthConfirmed: false,
      covarianceAcceptable: true,
    },
  };
}

test("active pre-ignition core asset becomes a bounded PROBE with explainability", () => {
  const decision = evaluateZobirisDecision(baseInput());
  assert.equal(decision.assetState.state, "PRE_IGNITION");
  assert.equal(decision.action, "PROBE");
  assert.equal(decision.authority.probeOnly, true);
  assert.equal(decision.authority.maxNextOrderUsd, 37.5);
  assert.equal(decision.stagedExecution.lines[0]?.line, 1);
  assert.equal(decision.stagedExecution.lines[0]?.authorized, true);
  assert.ok(decision.explanation.flipBearish.length > 0);
  assert.ok(decision.explanation.cancelConditions.length > 0);
});

test("quarantined asset cannot receive an order", () => {
  const input = baseInput();
  input.eligibility = eligible("QUARANTINED");
  input.assetStateInput.eligibility = "QUARANTINED";
  const decision = evaluateZobirisDecision(input);
  assert.equal(decision.assetState.state, "QUARANTINED");
  assert.equal(decision.action, "QUARANTINE");
  assert.equal(decision.authority.maxNextOrderUsd, 0);
  assert.equal(decision.stagedExecution.lines.length, 0);
});

test("explanation separates measured evidence from causal hypotheses", () => {
  const decision = evaluateZobirisDecision(baseInput());
  assert.deepEqual(decision.explanation.observations.map((x) => x.id), ["spot_accumulation"]);
  assert.deepEqual(decision.explanation.inferredClaims.map((x) => x.id), ["macro_story"]);
});

test("meme asset cannot receive CORE authority and respects current funded meme caps", () => {
  const input = baseInput();
  input.asset = { id: "bonk", symbol: "BONK", name: "Bonk", assetClass: "MEME" };
  input.requestedTargetUsd = 95;
  input.portfolio.memeExposureUsd = 0;
  input.opportunity = { ...opportunity, score: 85 };
  const decision = evaluateZobirisDecision(input);
  assert.equal(decision.assetClass, "MEME");
  assert.equal(decision.authority.maxPositionUsd, 45);
  assert.equal(decision.authority.maxNextOrderUsd, 37.5);
  assert.equal(decision.coreAuthority, false);
});

test("WATCH_ONLY asset returns WAIT and says what is missing", () => {
  const input = baseInput();
  input.eligibility = eligible("WATCH_ONLY");
  input.assetStateInput.eligibility = "WATCH_ONLY";
  const decision = evaluateZobirisDecision(input);
  assert.equal(decision.action, "WAIT");
  assert.equal(decision.authority.maxNextOrderUsd, 0);
  assert.ok(decision.explanation.flipBullish.some((x) => x.includes("eligibility")));
});

test("behavioral personality is first-class explainability but cannot authorize or resize an order", async () => {
  const { classifyBehavioralPersonality } = await import("../engine/personality.js");
  const input = baseInput();
  const before = evaluateZobirisDecision(input);
  const enrichedInput = {
    ...input,
    personality: classifyBehavioralPersonality({
      btcCorrelation: 0.42,
      btcBeta: 0.8,
      relativeStrengthOnBtcDown: 0.84,
      supportHoldRateOnBtcDown: 0.82,
      spotPersistenceOnBtcDown: 0.78,
      fundingCrowding: 0.2,
      oiCrowding: 0.2,
      breakoutFollowThroughRate: 0.76,
      falseBreakoutRate: 0.16,
      dipRecoveryRate: 0.7,
      medianRecoveryHours: 30,
      compressionBreakoutRate: 0.7,
      trendPersistence: 0.74,
      narrativeSensitivity: 0.3,
      postPumpLiquidityDecay: 0.12,
      capitulationBounceRate: 0.5,
      similarSetupCount: 20,
    }),
  };
  const after = evaluateZobirisDecision(enrichedInput);
  assert.equal(after.personality?.primary, "INDEPENDENT_LEADER");
  assert.equal(after.personality?.productionAuthority, "DESCRIPTIVE_ONLY");
  assert.equal(after.authority.maxNextOrderUsd, before.authority.maxNextOrderUsd);
  assert.equal(after.action, before.action);
});
