import test from 'node:test';
import assert from 'node:assert/strict';
import { selectCollectionSymbols } from '../collectorSelection.js';

test('collector keeps nine priority assets and rotates three wider-watchlist slots', () => {
  const watch = ['BTC','SOL','ONDO','KAS','NEAR','TAO','RENDER','HBAR','SUI','AKT','APT','DOT','AVAX','POL','ICP','ATOM'];
  const first = selectCollectionSymbols(watch, 0, 12, 9);
  assert.equal(first.symbols.length, 12);
  assert.deepEqual(first.symbols.slice(0,9), ['BTC','SOL','ONDO','KAS','NEAR','TAO','RENDER','HBAR','SUI']);
  const second = selectCollectionSymbols(watch, first.nextCursor, 12, 9);
  assert.ok(second.symbols.some((s) => !first.symbols.includes(s)));
});
