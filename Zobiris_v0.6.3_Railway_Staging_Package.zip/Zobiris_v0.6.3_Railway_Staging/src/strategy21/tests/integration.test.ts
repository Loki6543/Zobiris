import test from 'node:test';
import assert from 'node:assert/strict';
import { integrateStrategy21 } from '../integration.js';
import { buildLiquidityProfile, type OrderBookSnapshot } from '../engine/liquidity.js';

function legacyAsset(symbol: string, score: number, confidence = 80) {
  return {
    symbol,
    canonicalAssetId: `${symbol}-id`,
    mappingStatus: 'verified',
    asOf: '2026-09-04T12:00:00.000Z',
    opportunity: { adjusted: score, raw: score, evidenceGapPenalty: 0, factorScores: [
      { family: 'marketTechnical', raw: score, adjusted: score, evidenceClaimIds: [] },
      { family: 'fundamentalTokenomics', raw: 65, adjusted: 65, evidenceClaimIds: [] },
      { family: 'liquidityMarketStructure', raw: 70, adjusted: 70, evidenceClaimIds: [] },
      { family: 'socialAttention', raw: 55, adjusted: 55, evidenceClaimIds: [] },
      { family: 'derivativesLeverage', raw: 70, adjusted: 70, evidenceClaimIds: [] },
      { family: 'catalystsNarrative', raw: 60, adjusted: 60, evidenceClaimIds: [] },
    ]},
    confidence: { pct: confidence },
    riskGates: [],
    targetWeight: { pct: 0 },
    action: score >= 60 ? 'ACCUMULATE' : 'HOLD',
    risk: 'Moderate',
    evidenceCoverage: 0.8,
  };
}

function snapshots14(): OrderBookSnapshot[] {
  const end = Date.parse('2026-09-04T12:00:00.000Z');
  return Array.from({ length: 14 }, (_, i) => ({
    pair: 'ONDOUSD', observedAt: new Date(end - (13-i)*24*60*60*1000).toISOString(), activeMinute: true, tradeNotional1m: 1000,
    bids: [{ price: 99.95, size: 1000 }, { price: 99.5, size: 1000 }, { price: 98, size: 1000 }],
    asks: [{ price: 100.05, size: 1000 }, { price: 100.5, size: 1000 }, { price: 102, size: 1000 }],
  }));
}

test('strategy integration adds separate research and next-dollar ranks without using legacy target weight', () => {
  const snapshot = {
    asOf: '2026-09-04T12:00:00.000Z', policyVersion: '0.4.13', regime: 'legacy', regimeConfidence: 80,
    rankedAssets: [legacyAsset('BTC', 70), legacyAsset('ONDO', 78), legacyAsset('BONK', 72)],
  };
  const profile = buildLiquidityProfile({ snapshots: snapshots14(), dailyCredibleNotionalUsd: Array(14).fill(5_000_000) });
  const result = integrateStrategy21({
    snapshot,
    canonicalAssets: new Map([
      ['BTC', { id:'BTC-id', symbol:'BTC', name:'Bitcoin', mappingStatus:'verified' }],
      ['ONDO', { id:'ONDO-id', symbol:'ONDO', name:'Ondo', mappingStatus:'verified' }],
      ['BONK', { id:'BONK-id', symbol:'BONK', name:'Bonk', mappingStatus:'verified' }],
    ]),
    evidenceClaims: [],
    liquidityBySymbol: new Map([['ONDO', { pair:'ONDOUSD', profile, takerFeeBpsPerSide:10, estimatedGrossExpectedReturnBps:1000 }]]),
  });
  const ondo = result.rankedAssets.find(a => a.symbol === 'ONDO')!;
  assert.ok(ondo.strategy21);
  assert.ok(ondo.strategy21.researchRank > 0);
  assert.ok(ondo.strategy21.nextDollarRank !== null);
  assert.ok(ondo.strategy21.positionAuthority.maxNextOrderUsd > 0);
  assert.equal(ondo.targetWeight?.pct, 0);
});

test('asset without 14-day execution history remains research-ranked but has no next-dollar rank', () => {
  const snapshot = {
    asOf: '2026-09-04T12:00:00.000Z', policyVersion: '0.4.13', regime: 'legacy', regimeConfidence: 80,
    rankedAssets: [legacyAsset('BTC', 70), legacyAsset('NEAR', 74)],
  };
  const result = integrateStrategy21({
    snapshot,
    canonicalAssets: new Map([
      ['BTC', { id:'BTC-id', symbol:'BTC', name:'Bitcoin', mappingStatus:'verified' }],
      ['NEAR', { id:'NEAR-id', symbol:'NEAR', name:'Near', mappingStatus:'verified' }],
    ]),
    evidenceClaims: [],
    liquidityBySymbol: new Map(),
  });
  const near = result.rankedAssets.find(a => a.symbol === 'NEAR')!;
  assert.ok(near.strategy21.researchRank > 0);
  assert.equal(near.strategy21.nextDollarRank, null);
  assert.equal(near.strategy21.eligibility.status, 'WATCH_ONLY');
});

test('behavioral personality is surfaced when supplied but does not alter executable next-dollar score', () => {
  const snapshot = {
    asOf: '2026-09-04T12:00:00.000Z', policyVersion: '0.4.13', regime: 'legacy', regimeConfidence: 80,
    rankedAssets: [legacyAsset('BTC', 70), legacyAsset('ONDO', 78)],
  };
  const liquidity = buildLiquidityProfile({ snapshots: snapshots14(), dailyCredibleNotionalUsd: Array(14).fill(5_000_000) });
  const common = {
    snapshot,
    canonicalAssets: new Map([
      ['BTC', { id:'BTC-id', symbol:'BTC', name:'Bitcoin', mappingStatus:'verified' }],
      ['ONDO', { id:'ONDO-id', symbol:'ONDO', name:'Ondo', mappingStatus:'verified' }],
    ]),
    evidenceClaims: [],
    liquidityBySymbol: new Map([['ONDO', { pair:'ONDOUSD', profile: liquidity, takerFeeBpsPerSide:10 }]]),
  };
  const baseline = integrateStrategy21(common);
  const enriched = integrateStrategy21({
    ...common,
    personalityBySymbol: new Map([['ONDO', {
      btcCorrelation: 0.4,
      btcBeta: 0.8,
      relativeStrengthOnBtcDown: 0.85,
      supportHoldRateOnBtcDown: 0.82,
      spotPersistenceOnBtcDown: 0.78,
      fundingCrowding: 0.2,
      oiCrowding: 0.2,
      breakoutFollowThroughRate: 0.75,
      falseBreakoutRate: 0.15,
      dipRecoveryRate: 0.7,
      medianRecoveryHours: 32,
      compressionBreakoutRate: 0.7,
      trendPersistence: 0.72,
      narrativeSensitivity: 0.35,
      postPumpLiquidityDecay: 0.1,
      capitulationBounceRate: 0.5,
      similarSetupCount: 20,
    }]]),
  });
  const before = baseline.rankedAssets.find(a => a.symbol === 'ONDO')!.strategy21;
  const after = enriched.rankedAssets.find(a => a.symbol === 'ONDO')!.strategy21;
  assert.equal(after.personality?.primary, 'INDEPENDENT_LEADER');
  assert.equal(after.personality?.productionAuthority, 'DESCRIPTIVE_ONLY');
  assert.equal(after.nextDollarScore, before.nextDollarScore);
});


test("strategy metadata declares descriptive research, heuristic ranking, and risk-cap-only sizing authorities", () => {
  const snapshot = {
    asOf: '2026-09-04T12:00:00.000Z', policyVersion: '0.4.13', regime: 'legacy', regimeConfidence: 80,
    rankedAssets: [legacyAsset('BTC', 70), legacyAsset('ONDO', 78)],
  };
  const profile = buildLiquidityProfile({ snapshots: snapshots14(), dailyCredibleNotionalUsd: Array(14).fill(5_000_000) });
  const result = integrateStrategy21({
    snapshot,
    canonicalAssets: new Map([
      ['BTC', { id:'BTC-id', symbol:'BTC', name:'Bitcoin', mappingStatus:'verified' }],
      ['ONDO', { id:'ONDO-id', symbol:'ONDO', name:'Ondo', mappingStatus:'verified' }],
    ]),
    evidenceClaims: [],
    liquidityBySymbol: new Map([['ONDO', { pair:'ONDOUSD', profile, takerFeeBpsPerSide:10, estimatedGrossExpectedReturnBps:1000 }]]),
  });
  assert.equal(result.strategy21.researchAuthority, 'DESCRIPTIVE_ONLY');
  assert.equal(result.strategy21.rankingAuthority, 'OPPORTUNITY_HEURISTIC_V1');
  assert.equal(result.strategy21.positionSizingAuthority, 'RISK_CAPS_ONLY');
  assert.equal(result.strategy21.maneuverCapitalUsd, 1500);
  assert.equal(result.strategy21.deploymentAuthorityUsd, 1275);
});
