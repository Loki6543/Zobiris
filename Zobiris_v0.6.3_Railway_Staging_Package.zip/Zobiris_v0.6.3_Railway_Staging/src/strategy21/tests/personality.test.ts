import test from "node:test";
import assert from "node:assert/strict";
import {
  classifyBehavioralPersonality,
  computeElasticStrength,
  type BehavioralProfileInput,
} from "../engine/personality.js";

function profile(overrides: Partial<BehavioralProfileInput> = {}): BehavioralProfileInput {
  return {
    btcCorrelation: 0.45,
    btcBeta: 0.8,
    relativeStrengthOnBtcDown: 0.82,
    supportHoldRateOnBtcDown: 0.84,
    spotPersistenceOnBtcDown: 0.78,
    fundingCrowding: 0.20,
    oiCrowding: 0.25,
    breakoutFollowThroughRate: 0.76,
    falseBreakoutRate: 0.18,
    dipRecoveryRate: 0.68,
    medianRecoveryHours: 36,
    compressionBreakoutRate: 0.72,
    trendPersistence: 0.74,
    narrativeSensitivity: 0.35,
    postPumpLiquidityDecay: 0.15,
    capitulationBounceRate: 0.48,
    similarSetupCount: 24,
    ...overrides,
  };
}

test("Elastic Strength rewards BTC-down resilience without leveraged crowding", () => {
  const result = computeElasticStrength(profile());
  assert.ok(result.score >= 75);
  assert.equal(result.band, "HIGH");
  assert.ok(result.coverage >= 0.8);
});

test("Independent Leader plus Breakout Sprinter is selected for resilient follow-through", () => {
  const result = classifyBehavioralPersonality(profile());
  assert.equal(result.primary, "INDEPENDENT_LEADER");
  assert.ok(result.secondary.includes("BREAKOUT_SPRINTER"));
  assert.equal(result.historicalMatch, "HIGH");
  assert.equal(result.calibratedProbability, null);
});

test("BTC Shadow is detected when correlation and beta dominate independent strength", () => {
  const result = classifyBehavioralPersonality(profile({
    btcCorrelation: 0.90,
    btcBeta: 1.35,
    relativeStrengthOnBtcDown: 0.20,
    supportHoldRateOnBtcDown: 0.35,
    breakoutFollowThroughRate: 0.42,
    compressionBreakoutRate: 0.35,
    trendPersistence: 0.45,
  }));
  assert.equal(result.primary, "BTC_SHADOW");
});

test("Liquidity Trap can override a seductive momentum label", () => {
  const result = classifyBehavioralPersonality(profile({
    postPumpLiquidityDecay: 0.86,
    falseBreakoutRate: 0.70,
    trendPersistence: 0.82,
    breakoutFollowThroughRate: 0.72,
  }));
  assert.equal(result.primary, "LIQUIDITY_TRAP");
  assert.ok(result.warnings.some((x) => /exit liquidity/i.test(x)));
});

test("personality remains descriptive and uncalibrated with thin history", () => {
  const result = classifyBehavioralPersonality(profile({ similarSetupCount: 5 }));
  assert.equal(result.historicalMatch, "INSUFFICIENT");
  assert.equal(result.calibratedProbability, null);
  assert.ok(result.confidence < 0.75);
});
