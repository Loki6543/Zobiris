import test from "node:test";
import assert from "node:assert/strict";
import { classifyAssetState, type AssetStateInput } from "../engine/assetState.js";

const base: AssetStateInput = {
  eligibility: "ACTIVE_ELIGIBLE",
  confidence: 0.82,
  fundamentalTrajectory: 0.15,
  developerHealth: 0.70,
  minimumDeveloperHealth: 0.50,
  attentionPercentile: 45,
  crowdingThreshold: 60,
  observableCatalyst: true,
  contributorBreadthImproving: false,
  spotAccumulation: false,
  structurallyDeclining: false,
  extended: false,
  deterioration: false,
  existingPositionUsd: 0,
  nonPriceConfirmation: false,
  trendConfirmed: false,
  profitable: false,
  expectedNextDollarBelowHoldHurdle: false,
};

test("quarantine overrides every positive setup input", () => {
  const result = classifyAssetState({ ...base, eligibility: "QUARANTINED", trendConfirmed: true });
  assert.equal(result.state, "QUARANTINED");
});

test("cheap and ignored is not enough for pre-ignition without a discovery mechanism", () => {
  const result = classifyAssetState({
    ...base,
    observableCatalyst: false,
    contributorBreadthImproving: false,
    spotAccumulation: false,
  });
  assert.equal(result.state, "RESEARCH");
});

test("pre-ignition requires stable fundamentals healthy developers eligibility and discovery evidence", () => {
  const result = classifyAssetState(base);
  assert.equal(result.state, "PRE_IGNITION");
});

test("a probe can advance to accumulate only with non-price confirmation", () => {
  const result = classifyAssetState({ ...base, existingPositionUsd: 30, nonPriceConfirmation: true });
  assert.equal(result.state, "ACCUMULATE");
});

test("spot-supported trend confirmation advances to confirmed trend", () => {
  const result = classifyAssetState({ ...base, existingPositionUsd: 100, nonPriceConfirmation: true, trendConfirmed: true });
  assert.equal(result.state, "CONFIRMED_TREND");
});

test("deterioration cancels a bullish lifecycle", () => {
  const result = classifyAssetState({ ...base, existingPositionUsd: 100, trendConfirmed: true, deterioration: true });
  assert.equal(result.state, "DETERIORATING");
});

test("extended profitable position with weak next-dollar value enters harvest", () => {
  const result = classifyAssetState({
    ...base,
    existingPositionUsd: 100,
    extended: true,
    profitable: true,
    expectedNextDollarBelowHoldHurdle: true,
  });
  assert.equal(result.state, "HARVEST");
});
