import test from "node:test";
import assert from "node:assert/strict";
import { actorImpulse, causalChainConfidence, type ActorItem } from "../engine/actors.js";
import { activateSensor, applySensorToProbability, type SensorDefinition } from "../engine/sensors.js";

test("inferred political incentives have zero direct actor impulse", () => {
  const item: ActorItem = {
    itemId: "whitehouse-oil",
    actorId: "us-government",
    itemType: "INFERRED_INCENTIVE",
    claim: "lower gasoline prices are politically useful before midterms",
    magnitude: 0.9,
    horizon: "WEEKS",
    confidence: 0.35,
    sourceDependencies: ["macro:oil", "politics:midterms"],
    contradictions: [],
  };
  assert.equal(actorImpulse(item, 0.8, 0.7), 0);
});

test("observed actor action is scaled by capacity edge reliability and confidence", () => {
  const item: ActorItem = {
    itemId: "etf-flow",
    actorId: "blackrock-etf",
    itemType: "OBSERVED_ACTION",
    claim: "net BTC ETF creation observed",
    magnitude: 0.8,
    horizon: "DAYS",
    confidence: 0.9,
    sourceDependencies: ["etf:flow"],
    contradictions: [],
  };
  assert.ok(Math.abs(actorImpulse(item, 0.75, 0.8) - 0.432) < 1e-9);
});

test("causal chain confidence is capped by weakest evidence and edge reliability", () => {
  const confidence = causalChainConfidence([0.9, 0.7, 0.8], [0.8, 0.75]);
  assert.ok(Math.abs(confidence - 0.42) < 1e-9);
});

const sensor: SensorDefinition = {
  sensorId: "bonk-meme-appetite",
  dependencyGroup: "PRICE_STRUCTURE",
  validRegimes: ["BROAD_EXPANSION", "LEVERAGED_EXPANSION"],
  likelihoodRatio: 3,
  likelihoodRatioLowerBound: 1.4,
  effectiveSampleSize: 35,
  minimumEffectiveSampleSize: 20,
  fresh: true,
  integrityContradiction: false,
};

test("sensor activates only with out-of-sample evidence and a valid regime", () => {
  assert.equal(activateSensor(sensor, "BROAD_EXPANSION"), "ACTIVE");
  assert.equal(activateSensor({ ...sensor, likelihoodRatioLowerBound: 0.9 }, "BROAD_EXPANSION"), "OBSERVING");
  assert.equal(activateSensor(sensor, "DETERIORATION"), "OFF");
});

test("active sensor can modestly update probability but cannot exceed the bounded log-odds move", () => {
  const result = applySensorToProbability({
    priorProbability: 0.5,
    sensor: { ...sensor, likelihoodRatio: 10 },
    currentMarketState: "BROAD_EXPANSION",
    targetDependencyGroups: ["FUNDAMENTALS"],
  });
  assert.ok(result.probability > 0.5);
  assert.ok(result.probability < 0.61);
  assert.equal(result.requiresTargetConfirmation, true);
});

test("sensor sharing the target dependency root adds context but no confidence update", () => {
  const result = applySensorToProbability({
    priorProbability: 0.55,
    sensor,
    currentMarketState: "BROAD_EXPANSION",
    targetDependencyGroups: ["PRICE_STRUCTURE", "SPOT_FLOW"],
  });
  assert.equal(result.probability, 0.55);
  assert.equal(result.applied, false);
  assert.match(result.reason, /overlap/i);
});
