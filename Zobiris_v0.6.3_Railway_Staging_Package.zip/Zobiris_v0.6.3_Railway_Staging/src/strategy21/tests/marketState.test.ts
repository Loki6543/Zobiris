import test from "node:test";
import assert from "node:assert/strict";
import {
  classifyMarketState,
  deploymentCapForState,
  doctrineAlias,
  type MarketAxes,
  type PreviousMarketState,
} from "../engine/marketState.js";

const broad: MarketAxes = {
  btcStructure: 0.55,
  breadth: 0.50,
  spotParticipation: 0.45,
  leverageCrowding: 0.20,
  liquidityStress: -0.20,
  extension: 0.35,
  macroImpulse: 0.15,
};

test("systemic break has precedence over otherwise bullish axes", () => {
  const result = classifyMarketState({
    axes: broad,
    confidence: 0.95,
    integrityBreak: true,
    asOf: "2026-09-04T08:00:00Z",
  });
  assert.equal(result.state, "SYSTEMIC_BREAK");
  assert.equal(result.deploymentCapPct, 0);
});

test("broad expansion requires structure breadth and spot participation", () => {
  const result = classifyMarketState({
    axes: broad,
    confidence: 0.9,
    asOf: "2026-09-04T08:00:00Z",
  });
  assert.equal(result.state, "BROAD_EXPANSION");
  assert.equal(doctrineAlias(result.state), "Offensive Rotation");
});

test("high leverage changes a bullish board into leveraged expansion", () => {
  const result = classifyMarketState({
    axes: { ...broad, leverageCrowding: 0.72 },
    confidence: 0.9,
    asOf: "2026-09-04T08:00:00Z",
  });
  assert.equal(result.state, "LEVERAGED_EXPANSION");
});

test("euphoria outranks leveraged expansion when extension is extreme", () => {
  const result = classifyMarketState({
    axes: { ...broad, leverageCrowding: 0.75, extension: 0.92, breadth: 0.70 },
    confidence: 0.9,
    asOf: "2026-09-04T08:00:00Z",
  });
  assert.equal(result.state, "EUPHORIA");
});

test("hysteresis holds a prior state during its dwell window for risk-on upgrades", () => {
  const previous: PreviousMarketState = {
    state: "DELEVERAGED_ACCUMULATION",
    enteredAt: "2026-09-04T00:00:00Z",
    minimumDwellUntil: "2026-09-05T00:00:00Z",
  };
  const result = classifyMarketState({
    axes: broad,
    confidence: 0.9,
    asOf: "2026-09-04T08:00:00Z",
    previous,
  });
  assert.equal(result.state, "DELEVERAGED_ACCUMULATION");
  assert.match(result.reason, /hysteresis/i);
});

test("risk deterioration bypasses an upgrade dwell lock", () => {
  const previous: PreviousMarketState = {
    state: "BROAD_EXPANSION",
    enteredAt: "2026-09-04T00:00:00Z",
    minimumDwellUntil: "2026-09-06T00:00:00Z",
  };
  const result = classifyMarketState({
    axes: {
      btcStructure: -0.5,
      breadth: -0.4,
      spotParticipation: -0.5,
      leverageCrowding: 0.1,
      liquidityStress: 0.5,
      extension: -0.4,
      macroImpulse: -0.4,
    },
    confidence: 0.9,
    asOf: "2026-09-04T08:00:00Z",
    previous,
  });
  assert.equal(result.state, "DETERIORATION");
});

test("deployment cap maps to the currently funded maneuver base", () => {
  assert.equal(deploymentCapForState("BROAD_EXPANSION", 1200), 1020);
  assert.equal(deploymentCapForState("UNCERTAIN", 1200), 180);
  assert.equal(deploymentCapForState("SYSTEMIC_BREAK", 1200), 0);
});
