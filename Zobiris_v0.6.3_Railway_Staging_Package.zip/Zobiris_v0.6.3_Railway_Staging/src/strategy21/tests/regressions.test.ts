import test from 'node:test';
import assert from 'node:assert/strict';
import { actorImpulse } from '../engine/actors.js';
import { buildLiquidityProfile, evaluateLiquidityEligibility, type OrderBookSnapshot } from '../engine/liquidity.js';

function book(day: number, active = true): OrderBookSnapshot {
  const d = String(day).padStart(2, '0');
  return {
    pair: 'TESTUSD', observedAt: `2026-08-${d}T12:00:00.000Z`, activeMinute: active, tradeNotional1m: active ? 1000 : 0,
    bids: [{ price: 99.95, size: 1000 }, { price: 99.5, size: 1000 }, { price: 98, size: 1000 }],
    asks: [{ price: 100.05, size: 1000 }, { price: 100.5, size: 1000 }, { price: 102, size: 1000 }],
  };
}

test('bearish observed actor action produces negative impulse', () => {
  const impulse = actorImpulse({
    itemId: 'fed-tighten', actorId: 'fed', itemType: 'OBSERVED_ACTION', claim: 'tightening', magnitude: -0.8,
    horizon: 'DAYS', confidence: 0.9, sourceDependencies: ['MACRO'], contradictions: [],
  }, 0.9, 0.8);
  assert.ok(impulse < 0);
});

test('crossed current book fails closed instead of improving liquidity', () => {
  const snapshots = Array.from({ length: 14 }, (_, i) => book(10 + i));
  snapshots[snapshots.length - 1] = { ...snapshots.at(-1)!, bids: [{ price: 101, size: 1000 }], asks: [{ price: 100, size: 1000 }] };
  const profile = buildLiquidityProfile({ snapshots, dailyCredibleNotionalUsd: Array(14).fill(5_000_000) });
  const result = evaluateLiquidityEligibility({
    pair: 'TESTUSD', plannedOrderUsd: 30, intendedFinalPositionUsd: 100, profile,
    identityVerified: true, activeKrakenUsdPair: true, migrationResolved: true, exploitClear: true,
    tokenomicsComplete: true, bookFresh: true, takerFeeBpsPerSide: 20, estimatedGrossExpectedReturnBps: 1000,
  });
  assert.notEqual(result.status, 'ACTIVE_ELIGIBLE');
  assert.ok(result.failureReasons.some(r => /crossed|invalid/i.test(r)));
});

test('round-trip fees count against the all-in execution cost ceiling', () => {
  const snapshots = Array.from({ length: 14 }, (_, i) => book(10 + i));
  const profile = buildLiquidityProfile({ snapshots, dailyCredibleNotionalUsd: Array(14).fill(5_000_000) });
  const result = evaluateLiquidityEligibility({
    pair: 'TESTUSD', plannedOrderUsd: 30, intendedFinalPositionUsd: 100, profile,
    identityVerified: true, activeKrakenUsdPair: true, migrationResolved: true, exploitClear: true,
    tokenomicsComplete: true, bookFresh: true, takerFeeBpsPerSide: 80, estimatedGrossExpectedReturnBps: 1000,
  });
  assert.equal(result.status, 'INELIGIBLE');
  assert.ok(result.failureReasons.some(r => /round-trip execution cost/i.test(r)));
});
