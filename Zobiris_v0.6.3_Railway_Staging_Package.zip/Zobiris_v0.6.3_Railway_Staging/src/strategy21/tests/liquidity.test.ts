import test from "node:test";
import assert from "node:assert/strict";
import {
  buildLiquidityProfile,
  dollarDepthWithinBps,
  evaluateLiquidityEligibility,
  median,
  quantile,
  simulateImpactBps,
  spreadBps,
  stressedExitCapacity,
  type OrderBookSnapshot,
} from "../engine/liquidity.js";

function book(day: number, scale = 1): OrderBookSnapshot {
  const size = (usd: number, price: number) => (usd / price) * scale;
  return {
    pair: "TESTUSD",
    observedAt: `2026-08-${String(20 + day).padStart(2, "0")}T12:00:00Z`,
    bids: [
      { price: 99.99, size: size(8000, 99.99) },
      { price: 99.70, size: size(7000, 99.70) },
      { price: 99.50, size: size(7000, 99.50) },
      { price: 99.00, size: size(7000, 99.00) },
      { price: 97.60, size: size(7000, 97.60) },
    ],
    asks: [
      { price: 100.01, size: size(8000, 100.01) },
      { price: 100.30, size: size(7000, 100.30) },
      { price: 100.50, size: size(7000, 100.50) },
      { price: 101.00, size: size(7000, 101.00) },
      { price: 102.40, size: size(7000, 102.40) },
    ],
    activeMinute: true,
    tradeNotional1m: 5000,
  };
}

test("spread is calculated in basis points from best bid and ask", () => {
  assert.ok(Math.abs(spreadBps(book(1)) - 2) < 0.01);
});

test("depth within 50 bps is computed separately on both sides", () => {
  const snapshot = book(1);
  const bid = dollarDepthWithinBps(snapshot, "bid", 50);
  const ask = dollarDepthWithinBps(snapshot, "ask", 50);
  assert.ok(bid > 14000);
  assert.ok(ask > 14000);
});

test("simulated impact uses VWAP rather than displayed top-of-book only", () => {
  const snapshot = book(1);
  const tiny = simulateImpactBps(snapshot, "buy", 100);
  const larger = simulateImpactBps(snapshot, "buy", 12000);
  assert.ok(tiny < 5);
  assert.ok(larger > tiny);
});

test("stressed exit capacity removes near bids and haircuts remaining book", () => {
  const capacity = stressedExitCapacity(book(1), 250);
  assert.ok(capacity > 1000);
  assert.ok(capacity < 30000);
});

test("size-adaptive liquidity approves a small order when 14-day history and stressed exits pass", () => {
  const snapshots = Array.from({ length: 14 }, (_, i) => book(i + 1, 0.95 + i * 0.005));
  const profile = buildLiquidityProfile({
    snapshots,
    dailyCredibleNotionalUsd: Array.from({ length: 14 }, (_, i) => 100000 + i * 1000),
  });
  const result = evaluateLiquidityEligibility({
    pair: "TESTUSD",
    plannedOrderUsd: 100,
    intendedFinalPositionUsd: 500,
    profile,
    identityVerified: true,
    activeKrakenUsdPair: true,
    migrationResolved: true,
    exploitClear: true,
    tokenomicsComplete: true,
    bookFresh: true,
    takerFeeBpsPerSide: 10,
    estimatedGrossExpectedReturnBps: 1000,
  });
  assert.equal(result.status, "ACTIVE_ELIGIBLE");
  assert.ok(result.maximumOrderUsd >= 100);
  assert.ok(result.maximumPositionUsd >= 500);
});

test("missing 14-day book history fails closed to watch-only", () => {
  const profile = buildLiquidityProfile({
    snapshots: [book(1), book(2)],
    dailyCredibleNotionalUsd: [100000, 100000],
  });
  const result = evaluateLiquidityEligibility({
    pair: "TESTUSD",
    plannedOrderUsd: 25,
    intendedFinalPositionUsd: 50,
    profile,
    identityVerified: true,
    activeKrakenUsdPair: true,
    migrationResolved: true,
    exploitClear: true,
    tokenomicsComplete: true,
    bookFresh: true,
    takerFeeBpsPerSide: 10,
    estimatedGrossExpectedReturnBps: 1000,
  });
  assert.equal(result.status, "WATCH_ONLY");
  assert.match(result.failureReasons.join(" "), /14-day/i);
});

test("an oversized requested order is rejected even when the asset is liquid at smaller size", () => {
  const snapshots = Array.from({ length: 14 }, (_, i) => book(i + 1));
  const profile = buildLiquidityProfile({
    snapshots,
    dailyCredibleNotionalUsd: Array.from({ length: 14 }, () => 100000),
  });
  const result = evaluateLiquidityEligibility({
    pair: "TESTUSD",
    plannedOrderUsd: 5000,
    intendedFinalPositionUsd: 12000,
    profile,
    identityVerified: true,
    activeKrakenUsdPair: true,
    migrationResolved: true,
    exploitClear: true,
    tokenomicsComplete: true,
    bookFresh: true,
    takerFeeBpsPerSide: 10,
    estimatedGrossExpectedReturnBps: 1000,
  });
  assert.equal(result.status, "INELIGIBLE");
  assert.ok(result.maximumOrderUsd < 5000);
});

import { parseKrakenDepthResponse } from "../providers/kraken.js";

test("missing or invalid required liquidity metrics never become certified capacity", () => {
  const profile = buildLiquidityProfile({
    snapshots: Array.from({ length: 14 }, (_, i) => ({ ...book(1), observedAt: new Date(Date.UTC(2026, 7, 1 + i, 12)).toISOString() })),
    dailyCredibleNotionalUsd: Array(14).fill(100000),
  });
  for (const metric of ["coverageDays", "p10DailyNotionalUsd", "medianDailyNotionalUsd", "bidDepth50P10Usd", "askDepth50P10Usd", "bidDepth100P10Usd", "askDepth100P10Usd", "spreadP95Bps", "activeMinuteCoverage"] as const) {
    for (const bad of [NaN, Infinity, -1]) {
      const result = evaluateLiquidityEligibility({
        pair: "TESTUSD", plannedOrderUsd: 30, intendedFinalPositionUsd: 50,
        profile: { ...profile, [metric]: bad },
        identityVerified: true, activeKrakenUsdPair: true, migrationResolved: true,
        exploitClear: true, tokenomicsComplete: true, bookFresh: true,
        takerFeeBpsPerSide: 10, estimatedGrossExpectedReturnBps: 1000,
      });
      assert.equal(result.status, "WATCH_ONLY", `${metric}: ${bad}`);
      assert.equal(result.maximumOrderUsd, 0);
      assert.equal(result.maximumPositionUsd, 0);
    }
  }
});

test("malformed fee or expected return evidence cannot bypass cost checks", () => {
  const profile = buildLiquidityProfile({
    snapshots: Array.from({ length: 14 }, (_, i) => ({ ...book(1), observedAt: new Date(Date.UTC(2026, 7, 1 + i, 12)).toISOString() })),
    dailyCredibleNotionalUsd: Array(14).fill(100000),
  });
  for (const field of ["takerFeeBpsPerSide", "estimatedGrossExpectedReturnBps"] as const) {
    for (const bad of [NaN, Infinity, -1]) {
      const result = evaluateLiquidityEligibility({
        pair: "TESTUSD", plannedOrderUsd: 30, intendedFinalPositionUsd: 50, profile,
        identityVerified: true, activeKrakenUsdPair: true, migrationResolved: true,
        exploitClear: true, tokenomicsComplete: true, bookFresh: true,
        takerFeeBpsPerSide: 10, estimatedGrossExpectedReturnBps: 1000, [field]: bad,
      });
      assert.equal(result.status, "WATCH_ONLY", `${field}: ${bad}`);
      assert.equal(result.maximumOrderUsd, 0);
    }
  }
});

test("Kraken depth parser resolves the returned pair key instead of assuming ticker spelling", () => {
  const snapshot = parseKrakenDepthResponse("BTCUSD", {
    error: [],
    result: {
      XXBTZUSD: {
        bids: [["80750.0", "0.25", "0"]],
        asks: [["80760.0", "0.30", "0"]],
      },
    },
  }, "2026-09-04T08:00:00Z");
  assert.equal(snapshot.pair, "BTCUSD");
  assert.equal(snapshot.bids[0]?.price, 80750);
  assert.equal(snapshot.asks[0]?.size, 0.3);
});


test("nearest-rank p10 uses the second-lowest observation for 14 values", () => {
  const values = [99082, 70783, 29493, 53612, 22270, 14616, 37152, 17655, 35932, 10021, 39480, 40449, 7401, 31924];
  assert.equal(quantile(values, 0.10), 10021);
});

test("nearest-rank p95 uses the ceiling rank without interpolation", () => {
  const values = Array.from({ length: 14 }, (_, i) => i + 1);
  assert.equal(quantile(values, 0.95), 14);
});

test("median remains the arithmetic median for an even sample", () => {
  assert.equal(median([1, 2, 10, 20]), 6);
});

test("DYDX 14-day turnover fixture reproduces the audited capacity", () => {
  const values = [
    99082.351, 70783.214, 29493.118, 53612.442, 22270.125, 14616.004, 37152.441,
    17655.087, 35932.153, 10020.581623472979, 39480.116, 40449.229, 7401.337, 31923.979,
  ];
  const med = median(values);
  const p10 = quantile(values, 0.10);
  const capacity = Math.min(med / 500, p10 / 200);
  assert.ok(Math.abs(p10 - 10020.581623472979) < 1e-9);
  assert.ok(Math.abs(capacity - 50.1029081173649) < 0.01);
});

test("missing expected gross return evidence fails closed after history is complete", () => {
  const snapshots = Array.from({ length: 14 }, (_, i) => book(i + 1));
  const profile = buildLiquidityProfile({
    snapshots,
    dailyCredibleNotionalUsd: Array.from({ length: 14 }, () => 100000),
  });
  const result = evaluateLiquidityEligibility({
    pair: "TESTUSD",
    plannedOrderUsd: 30,
    intendedFinalPositionUsd: 120,
    profile,
    identityVerified: true,
    activeKrakenUsdPair: true,
    migrationResolved: true,
    exploitClear: true,
    tokenomicsComplete: true,
    bookFresh: true,
    takerFeeBpsPerSide: 10,
  });
  assert.equal(result.status, "WATCH_ONLY");
  assert.match(result.failureReasons.join(" "), /expected gross return evidence incomplete/i);
});
