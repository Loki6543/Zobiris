import type { OrderBookSnapshot } from "../engine/liquidity.js";

interface KrakenDepthPayload {
  error?: unknown[];
  result?: Record<string, { bids?: unknown[][]; asks?: unknown[][] }>;
}

function parseLevels(rows: unknown[] | undefined): { price: number; size: number }[] {
  if (!rows) return [];
  return rows.flatMap((row) => {
    if (!Array.isArray(row) || row.length < 2) return [];
    const price = Number(row[0]);
    const size = Number(row[1]);
    if (!Number.isFinite(price) || !Number.isFinite(size) || price <= 0 || size < 0) return [];
    return [{ price, size }];
  });
}

export function parseKrakenDepthResponse(pair: string, payload: KrakenDepthPayload, observedAt = new Date().toISOString()): OrderBookSnapshot {
  const errors = Array.isArray(payload.error) ? payload.error.filter(Boolean) : [];
  if (errors.length > 0) throw new Error(`Kraken depth error: ${errors.join(", ")}`);
  const result = payload.result ?? {};
  const key = Object.keys(result)[0];
  if (!key) throw new Error(`Kraken returned no order book for ${pair}`);
  const book = result[key];
  if (!book) throw new Error(`Kraken returned malformed order book for ${pair}`);
  const bids = parseLevels(book.bids).sort((a, b) => b.price - a.price);
  const asks = parseLevels(book.asks).sort((a, b) => a.price - b.price);
  if (bids.length === 0 || asks.length === 0) throw new Error(`Kraken returned empty order book for ${pair}`);
  return {
    pair,
    observedAt,
    bids,
    asks,
    activeMinute: true,
    tradeNotional1m: 0,
  };
}

export async function fetchKrakenOrderBook(pair: string, count = 500): Promise<OrderBookSnapshot> {
  const url = `https://api.kraken.com/0/public/Depth?pair=${encodeURIComponent(pair)}&count=${Math.max(1, Math.min(500, count))}`;
  const response = await fetch(url, { headers: { accept: "application/json" } });
  if (!response.ok) throw new Error(`Kraken HTTP ${response.status}`);
  const payload = await response.json() as KrakenDepthPayload;
  return parseKrakenDepthResponse(pair, payload, new Date().toISOString());
}

interface KrakenTickerResult {
  error?: unknown[];
  result?: Record<string, { c?: string[]; v?: string[]; p?: string[] }>;
}

export interface KrakenTickerSnapshot {
  pair: string;
  observedAt: string;
  last: number;
  volume24hBase: number;
  vwap24h: number;
  notional24hUsd: number;
}

export async function fetchKrakenTicker(pair: string): Promise<KrakenTickerSnapshot> {
  const response = await fetch(`https://api.kraken.com/0/public/Ticker?pair=${encodeURIComponent(pair)}`, {
    headers: { accept: "application/json" },
  });
  if (!response.ok) throw new Error(`Kraken HTTP ${response.status}`);
  const payload = await response.json() as KrakenTickerResult;
  const errors = Array.isArray(payload.error) ? payload.error.filter(Boolean) : [];
  if (errors.length > 0) throw new Error(`Kraken ticker error: ${errors.join(", ")}`);
  const key = Object.keys(payload.result ?? {})[0];
  const ticker = key ? payload.result?.[key] : undefined;
  if (!ticker) throw new Error(`Kraken returned no ticker for ${pair}`);
  const last = Number(ticker.c?.[0]);
  const volume24hBase = Number(ticker.v?.[1]);
  const vwap24h = Number(ticker.p?.[1]);
  if (![last, volume24hBase, vwap24h].every(Number.isFinite)) throw new Error(`Kraken ticker malformed for ${pair}`);
  return {
    pair,
    observedAt: new Date().toISOString(),
    last,
    volume24hBase,
    vwap24h,
    notional24hUsd: volume24hBase * vwap24h,
  };
}
