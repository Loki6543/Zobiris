export const EVIDENCE_TYPES = [
  "OBSERVATION",
  "DERIVED_METRIC",
  "CAUSAL_HYPOTHESIS",
  "FORECAST",
  "NARRATIVE_SIGNAL",
] as const;
export type EvidenceType = (typeof EVIDENCE_TYPES)[number];

export const HORIZONS = ["MINUTES", "HOURS", "DAYS", "WEEKS", "MONTHS"] as const;
export type EvidenceHorizon = (typeof HORIZONS)[number];

export interface EvidenceItem {
  id: string;
  type: EvidenceType;
  claim: string;
  value?: number | string | Record<string, unknown>;
  confidence: number;
  observedAt: string;
  expiresAt: string;
  horizon: EvidenceHorizon;
  sourceClass: string;
  dependencies: string[];
  contradictions: string[];
}

export interface ValidationResult {
  ok: boolean;
  errors: string[];
}

function isIsoDate(value: string): boolean {
  const parsed = Date.parse(value);
  return Number.isFinite(parsed);
}

export function validateEvidenceItem(item: EvidenceItem): ValidationResult {
  const errors: string[] = [];
  if (!item.id.trim()) errors.push("id is required");
  if (!EVIDENCE_TYPES.includes(item.type)) errors.push("invalid evidence type");
  if (!item.claim.trim()) errors.push("claim is required");
  if (item.confidence < 0 || item.confidence > 1 || !Number.isFinite(item.confidence)) {
    errors.push("confidence must be between 0 and 1");
  }
  if (!isIsoDate(item.observedAt)) errors.push("observedAt must be an ISO timestamp");
  if (!isIsoDate(item.expiresAt)) errors.push("expiresAt must be an ISO timestamp");
  if (isIsoDate(item.observedAt) && isIsoDate(item.expiresAt) && Date.parse(item.expiresAt) < Date.parse(item.observedAt)) {
    errors.push("expiresAt must be at or after observedAt");
  }
  if (!HORIZONS.includes(item.horizon)) errors.push("invalid horizon");
  if (!item.sourceClass.trim()) errors.push("sourceClass is required");
  if (!Array.isArray(item.dependencies)) errors.push("dependencies must be an array");
  if (!Array.isArray(item.contradictions)) errors.push("contradictions must be an array");
  if (item.type === "CAUSAL_HYPOTHESIS" && item.dependencies.length === 0) {
    errors.push("causal hypotheses require dependencies");
  }
  return { ok: errors.length === 0, errors };
}

export interface CreateDerivedEvidenceInput {
  id: string;
  claim: string;
  value?: number | string | Record<string, unknown>;
  sources: EvidenceItem[];
  confidence: number;
  observedAt: string;
  expiresAt: string;
  horizon: EvidenceHorizon;
  sourceClass: string;
  contradictions?: string[];
}

export function createDerivedEvidence(input: CreateDerivedEvidenceInput): EvidenceItem {
  const dependencies = [...new Set(input.sources.flatMap((source) => source.dependencies))];
  const inheritedContradictions = input.sources.flatMap((source) => source.contradictions);
  const item: EvidenceItem = {
    id: input.id,
    type: "DERIVED_METRIC",
    claim: input.claim,
    ...(input.value !== undefined ? { value: input.value } : {}),
    confidence: Math.min(input.confidence, ...input.sources.map((source) => source.confidence)),
    observedAt: input.observedAt,
    expiresAt: input.expiresAt,
    horizon: input.horizon,
    sourceClass: input.sourceClass,
    dependencies,
    contradictions: [...new Set([...(input.contradictions ?? []), ...inheritedContradictions])],
  };
  return item;
}

export function effectiveConfidence(
  sourceReliability: number,
  freshness: number,
  identityConfidence: number,
  measurementConfidence: number,
): number {
  return [sourceReliability, freshness, identityConfidence, measurementConfidence]
    .map((v) => Math.min(1, Math.max(0, v)))
    .reduce((acc, value) => acc * value, 1);
}

export function exponentialFreshness(ageMs: number, halfLifeMs: number): number {
  if (halfLifeMs <= 0) return 0;
  return Math.exp(-Math.max(0, ageMs) / halfLifeMs);
}
