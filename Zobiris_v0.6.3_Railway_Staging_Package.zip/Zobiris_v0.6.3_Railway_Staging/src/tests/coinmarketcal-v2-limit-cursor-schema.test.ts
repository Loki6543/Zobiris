/**
 * v0.4.3 audit regression test (required #7)
 * Test: coinmarketcal-v2-limit-cursor-schema
 *
 * Per the v0.4.3 audit (P0-4): "The request now uses /v2/events and
 * x-api-key, which is progress. But the source still calls:
 *   /v2/events?max=100
 * Current v2 uses `limit`, not `max`, and cursor pagination."
 *
 * v0.4.3 fix: live URL uses `limit=100&page=1` (cursor pagination
 * instead of the v1 `max` parameter).
 */

import { describe, it, expect, vi, afterEach } from "vitest";
import { CoinMarketCalAdapter } from "../providers/coinmarketcal.js";

afterEach(() => { vi.unstubAllGlobals(); });

describe("v0.4.3 P0-4: CoinMarketCal v2 uses limit + page (not max)", () => {
  it("live URL uses limit=100&page=1 (not max=100)", async () => {
    const fetchMock = vi.fn(async () => new Response(
      JSON.stringify({ data: [] }),
      { status: 200, headers: { "content-type": "application/json" } },
    ));
    vi.stubGlobal("fetch", fetchMock);
    const adapter = new CoinMarketCalAdapter();
    adapter.configure({
      baseUrl: "https://api.coinmarketcal.com",
      liveConfig: { apiKey: "test-key" },
    });
    await adapter.fetch({ canonicalAssets: new Map() });
    const [calledUrl] = fetchMock.mock.calls[0]! as unknown as [string, RequestInit];
    // v0.4.4 audit fix (P0-4): v2 uses cursor pagination via
    // meta.cursor. The first request has no page param; the cursor
    // is read from the response and used for subsequent pages.
    expect(calledUrl).toContain("limit=100");
    expect(calledUrl).not.toContain("max=");
    expect(calledUrl).not.toContain("page=");  // first-page has no page param
  });

  it("live URL does not include ?key= in the query string (v1 legacy)", async () => {
    const fetchMock = vi.fn(async () => new Response(
      JSON.stringify({ data: [] }),
      { status: 200, headers: { "content-type": "application/json" } },
    ));
    vi.stubGlobal("fetch", fetchMock);
    const adapter = new CoinMarketCalAdapter();
    adapter.configure({
      baseUrl: "https://api.coinmarketcal.com",
      liveConfig: { apiKey: "test-key" },
    });
    await adapter.fetch({ canonicalAssets: new Map() });
    const [calledUrl] = fetchMock.mock.calls[0]! as unknown as [string, RequestInit];
    expect(calledUrl).not.toMatch(/[?&]key=/);
  });

  it("x-api-key header is set (v2 auth contract)", async () => {
    const fetchMock = vi.fn(async () => new Response(
      JSON.stringify({ data: [] }),
      { status: 200, headers: { "content-type": "application/json" } },
    ));
    vi.stubGlobal("fetch", fetchMock);
    const adapter = new CoinMarketCalAdapter();
    adapter.configure({
      baseUrl: "https://api.coinmarketcal.com",
      liveConfig: { apiKey: "test-key-12345" },
    });
    await adapter.fetch({ canonicalAssets: new Map() });
    const [, calledInit] = fetchMock.mock.calls[0]! as unknown as [string, RequestInit];
    const headers = calledInit.headers as Record<string, string>;
    expect(headers["x-api-key"]).toBe("test-key-12345");
  });

  it("normalizer accepts v2 response fields (date, displayedDate, isEstimated, categories)", () => {
    const adapter = new CoinMarketCalAdapter();
    const obs = adapter.normalize(
      {
        data: [
          {
            id: 1,
            title: "Bitcoin halving",
            coins: [{ symbol: "BTC" }],
            date: "2026-04-15T00:00:00Z",
            dateEnd: "2026-04-15T23:59:59Z",
            dateType: "estimated",
            displayedDate: "Q2 2026",
            isEstimated: true,
            categories: ["tokenomics", "macro"],
            sourceUrl: "https://bitcoin.org/halving",
            snapshotUrl: "https://api.coinmarketcal.com/snapshots/1",
            lastVerifiedAt: "2026-08-01T00:00:00Z",
          },
        ],
      },
      { canonicalAssets: new Map(), endpoint: "events", receivedAt: new Date().toISOString(), rawSchemaVersion: "1.0.0" },
    );
    expect(obs).toHaveLength(1);
    const p = obs[0]!.payload as Record<string, any>;
    // v0.4.3 fix: both v1 (snake_case) and v2 (camelCase) field
    // names are accepted.
    expect(p.displayDate).toBe("Q2 2026");
    expect(p.isEstimated).toBe(true);
    expect(p.categories).toEqual(["tokenomics", "macro"]);
    expect(p.sourceUrl).toBe("https://bitcoin.org/halving");
    expect(p.snapshotUrl).toBe("https://api.coinmarketcal.com/snapshots/1");
  });

  it("normalizer still accepts v1 response fields (snake_case backward compat)", () => {
    const adapter = new CoinMarketCalAdapter();
    const obs = adapter.normalize(
      {
        data: [
          {
            id: 2,
            title: "Ethereum upgrade",
            coins: [{ symbol: "ETH" }],
            date_event: "2026-01-01T00:00:00Z",
            display_date: "Q1 2026",
            is_estimated: false,
            category: "protocol",
            proof: "https://ethereum.org",
            source: "Ethereum Foundation",
          },
        ],
      },
      { canonicalAssets: new Map(), endpoint: "events", receivedAt: new Date().toISOString(), rawSchemaVersion: "1.0.0" },
    );
    expect(obs).toHaveLength(1);
    const p = obs[0]!.payload as Record<string, any>;
    expect(p.displayDate).toBe("Q1 2026");
    expect(p.isEstimated).toBe(false);
    expect(p.category).toBe("protocol");
  });
});
