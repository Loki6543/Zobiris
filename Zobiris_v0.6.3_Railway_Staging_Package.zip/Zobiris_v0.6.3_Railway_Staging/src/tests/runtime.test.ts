/**
 * Runtime tests: backoff, freshness, epistemic.
 */
import { describe, it, expect } from "vitest";
import { computeFreshness } from "../runtime/freshness.js";
import { classifyEpistemicState, displayability } from "../runtime/epistemic.js";
import { nextBackoffDelay, shouldRetry, DEFAULT_BACKOFF } from "../runtime/backoff.js";

describe("nextBackoffDelay", () => {
  it("is 0 for negative attempts", () => {
    expect(nextBackoffDelay(-1)).toBe(0);
  });
  it("scales exponentially but caps at policy maxMs", () => {
    const rng = () => 1.0;  // worst-case jitter
    expect(nextBackoffDelay(0, DEFAULT_BACKOFF, rng)).toBeLessThanOrEqual(DEFAULT_BACKOFF.baseMs);
    expect(nextBackoffDelay(3, DEFAULT_BACKOFF, rng)).toBeLessThanOrEqual(DEFAULT_BACKOFF.maxMs);
    expect(nextBackoffDelay(20, DEFAULT_BACKOFF, rng)).toBeLessThanOrEqual(DEFAULT_BACKOFF.maxMs);
  });
  it("is bounded — never exceeds policy maxMs * 1.0 (jitter factor 0-1)", () => {
    for (let attempt = 0; attempt < 30; attempt++) {
      const d = nextBackoffDelay(attempt);
      expect(d).toBeLessThanOrEqual(DEFAULT_BACKOFF.maxMs);
    }
  });
});

describe("shouldRetry", () => {
  it("returns true below max attempts", () => {
    expect(shouldRetry(0)).toBe(true);
    expect(shouldRetry(DEFAULT_BACKOFF.maxAttempts - 1)).toBe(true);
  });
  it("returns false at or above max attempts", () => {
    expect(shouldRetry(DEFAULT_BACKOFF.maxAttempts)).toBe(false);
    expect(shouldRetry(DEFAULT_BACKOFF.maxAttempts + 1)).toBe(false);
  });
});

describe("computeFreshness", () => {
  const budget = 900;  // 15 min
  it("returns live for very recent events", () => {
    const now = new Date().toISOString();
    expect(computeFreshness({ lastEventAt: now, liveBudgetSeconds: budget })).toBe("live");
  });
  it("returns delayed within 2x budget", () => {
    const t = new Date(Date.now() - (budget + 60) * 1000).toISOString();
    expect(computeFreshness({ lastEventAt: t, liveBudgetSeconds: budget })).toBe("delayed");
  });
  it("returns stale beyond 2x budget", () => {
    const t = new Date(Date.now() - (budget * 3) * 1000).toISOString();
    expect(computeFreshness({ lastEventAt: t, liveBudgetSeconds: budget })).toBe("stale");
  });
  it("returns unavailable when no lastEventAt", () => {
    expect(computeFreshness({ liveBudgetSeconds: budget })).toBe("unavailable");
  });
  it("returns backfilling when backfilling flag is set", () => {
    expect(computeFreshness({ lastEventAt: undefined, liveBudgetSeconds: budget, backfilling: true })).toBe("backfilling");
  });
  it("returns unavailable for malformed or materially future timestamps", () => {
    expect(computeFreshness({ lastEventAt: "not-a-date", liveBudgetSeconds: budget })).toBe("unavailable");
    const future = new Date(Date.now() + 5 * 60 * 1000).toISOString();
    expect(computeFreshness({ lastEventAt: future, liveBudgetSeconds: budget })).toBe("unavailable");
  });
  it("allows only bounded provider clock skew", () => {
    const slightFuture = new Date(Date.now() + 20 * 1000).toISOString();
    expect(computeFreshness({ lastEventAt: slightFuture, liveBudgetSeconds: budget })).toBe("live");
    expect(computeFreshness({ lastEventAt: slightFuture, liveBudgetSeconds: budget, maxFutureSkewSeconds: 0 })).toBe("unavailable");
  });
});

describe("classifyEpistemicState", () => {
  it("returns UNKNOWN when no source", () => {
    expect(classifyEpistemicState({ hasSource: false, hasTimestamp: true, ageSeconds: 0, freshBudgetSeconds: 900 })).toBe("UNKNOWN");
  });
  it("returns CONFLICTED when conflicting sources", () => {
    expect(classifyEpistemicState({ hasSource: true, hasTimestamp: true, ageSeconds: 0, freshBudgetSeconds: 900, conflictingSources: true })).toBe("CONFLICTED");
  });
  it("returns INFERRED when no timestamp", () => {
    expect(classifyEpistemicState({ hasSource: true, hasTimestamp: false, ageSeconds: 0, freshBudgetSeconds: 900 })).toBe("INFERRED");
  });
  it("returns STALE for very old", () => {
    expect(classifyEpistemicState({ hasSource: true, hasTimestamp: true, ageSeconds: 10000, freshBudgetSeconds: 900 })).toBe("STALE");
  });
  it("returns UNCERTAIN for half-fresh", () => {
    expect(classifyEpistemicState({ hasSource: true, hasTimestamp: true, ageSeconds: 500, freshBudgetSeconds: 900 })).toBe("UNCERTAIN");
  });
  it("returns KNOWN for fresh and sourced", () => {
    expect(classifyEpistemicState({ hasSource: true, hasTimestamp: true, ageSeconds: 100, freshBudgetSeconds: 900 })).toBe("KNOWN");
  });
});

describe("displayability", () => {
  it("ranks KNOWN highest, UNKNOWN lowest", () => {
    expect(displayability("KNOWN")).toBe(1.0);
    expect(displayability("UNKNOWN")).toBe(0.0);
    expect(displayability("STALE")).toBe(0.2);
  });
});
