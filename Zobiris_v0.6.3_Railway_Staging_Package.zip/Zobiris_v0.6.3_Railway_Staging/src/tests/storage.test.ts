/**
 * Storage layer tests.
 *
 * Covers the release-blocker "transactional_outbox" + idempotent_ingest +
 * provider_circuit_breaker + replay/audit.
 */
import { describe, it, expect, beforeEach, afterEach } from "vitest";
import { openStorage, type DB } from "../storage/client.js";
import {
  ingestObservation,
  insertEvidenceClaim,
  openSession,
  appendSessionStage,
  closeSession,
  insertSnapshot,
  upsertProviderHealth,
  shouldAttemptProvider,
  listPendingOutbox,
  markOutboxPublished,
  markOutboxFailed,
  enqueueOutbox,
  emitAudit,
  listAuditEvents,
  upsertCanonicalAsset,
  syncWatchlist,
  getCanonicalBySymbol,
  replaySession,
  getLatestSnapshot,
  getRecentSnapshots,
  insertForecast,
  listForecasts,
  recordForecastActual,
  insertCalibrationRun,
  listCalibrationRuns,
  insertMemory,
  listMemoryByKind,
} from "../storage/repository.js";
import { providerHealth, outboxEvents, watchlist } from "../storage/schema.js";
import { randomUUID } from "node:crypto";

let storage: ReturnType<typeof openStorage>;
let db: DB;

beforeEach(() => {
  storage = openStorage({ path: ":memory:" });
  db = storage.db;
});

afterEach(() => {
  storage.close();
});

describe("Idempotent ingest", () => {
  it("inserts once; second ingest of same key is a no-op", () => {
    const key = `kraken:ticker:${randomUUID()}`;
    const a = ingestObservation(db, {
      idempotencyKey: key,
      provider: "kraken",
      eventType: "ticker",
      schemaVersion: "1.0.0",
      occurredAt: Date.now(),
      payload: { price: 100 },
      epistemicState: "KNOWN",
      evidenceConfidence: 1,
      normalizerVersion: "0.1.0",
    });
    const b = ingestObservation(db, {
      idempotencyKey: key,
      provider: "kraken",
      eventType: "ticker",
      schemaVersion: "1.0.0",
      occurredAt: Date.now(),
      payload: { price: 100 },
      epistemicState: "KNOWN",
      evidenceConfidence: 1,
      normalizerVersion: "0.1.0",
    });
    expect(a.id).toBe(b.id);
    expect(a.inserted).toBe(true);
    expect(b.inserted).toBe(false);
  });
});

describe("Watchlist sync", () => {
  it("syncs entries and dedupes by symbol", () => {
    const n1 = syncWatchlist(db, [
      { symbol: "BTC", name: "Bitcoin", rank: 1 },
      { symbol: "ETH", name: "Ethereum", rank: 2 },
    ]);
    const n2 = syncWatchlist(db, [
      { symbol: "BTC", name: "Bitcoin", rank: 1 },
      { symbol: "SOL", name: "Solana", rank: 3 },
    ]);
    expect(n1.synced).toBe(2);
    expect(n2.synced).toBe(2);
    expect(n2.added).toEqual(["SOL"]);
    expect(n2.removed).toEqual(["ETH"]);
    const all = db.select().from(watchlist).all();
    // After n2, ETH should be marked removed (soft) so still in table but inactive.
    expect(all.length).toBe(3);
  });
});

describe("Canonical asset upsert", () => {
  it("updates by symbol, never ticker-primary-key", () => {
    const id1 = upsertCanonicalAsset(db, {
      symbol: "BTC",
      name: "Bitcoin",
      mappingStatus: "verified",
      mappingConfidence: 0.9,
      providerIds: { kraken: "XBT" },
    });
    const id2 = upsertCanonicalAsset(db, {
      symbol: "BTC",
      name: "Bitcoin (updated)",
      mappingStatus: "verified",
      mappingConfidence: 0.95,
      providerIds: { kraken: "XBT", cmc: "1" },
    });
    expect(id1).toBe(id2);
    const row = getCanonicalBySymbol(db, "BTC");
    expect(row?.name).toBe("Bitcoin (updated)");
    expect(JSON.parse(row!.providerIds).cmc).toBe("1");
  });
});

describe("Provider circuit breaker", () => {
  it("opens after N consecutive failures", () => {
    for (let i = 0; i < 3; i++) {
      upsertProviderHealth(db, { provider: "kraken", status: "disconnected", freshness: "unavailable", onSuccess: false });
    }
    const health = db.select().from(providerHealth).all();
    expect(health[0]?.circuitState).toBe("open");
    expect(shouldAttemptProvider(db, "kraken")).toBe(false);
  });

  it("resets on success and stays closed", () => {
    upsertProviderHealth(db, { provider: "kraken", status: "connected", freshness: "live", onSuccess: true });
    upsertProviderHealth(db, { provider: "kraken", status: "disconnected", freshness: "unavailable", onSuccess: false });
    upsertProviderHealth(db, { provider: "kraken", status: "connected", freshness: "live", onSuccess: true });
    const health = db.select().from(providerHealth).all();
    expect(health[0]?.circuitState).toBe("closed");
    expect(health[0]?.consecutiveFailures).toBe(0);
    expect(shouldAttemptProvider(db, "kraken")).toBe(true);
  });

  it("half-opens after reset window expires", () => {
    // Open the circuit
    for (let i = 0; i < 3; i++) {
      upsertProviderHealth(db, { provider: "kraken", status: "disconnected", freshness: "unavailable", onSuccess: false });
    }
    // Manually set nextRetryAt to 1ms ago
    db.update(providerHealth)
      .set({ circuitNextRetryAt: Date.now() - 1 })
      .run();
    expect(shouldAttemptProvider(db, "kraken")).toBe(true);
  });
});

describe("Transactional outbox", () => {
  it("enqueues and marks published", () => {
    const id = enqueueOutbox(db, {
      aggregateType: "snapshot",
      aggregateId: "snap-1",
      eventType: "snapshot.published",
      payload: { regime: "UNKNOWN" },
    });
    const pending = listPendingOutbox(db);
    expect(pending.length).toBe(1);
    markOutboxPublished(db, id);
    const after = listPendingOutbox(db);
    expect(after.length).toBe(0);
  });

  it("retries on failure up to 5 attempts before marking failed", () => {
    const id = enqueueOutbox(db, {
      aggregateType: "observation",
      aggregateId: "obs-1",
      eventType: "observation.published",
      payload: { x: 1 },
    });
    for (let i = 0; i < 5; i++) {
      
      markOutboxFailed(db, id, `error ${i}`);
    }
    const row = db.select().from(outboxEvents).all();
    expect(row[0]?.status).toBe("failed");
  });
});

describe("Audit (allowlisted)", () => {
  it("emits and queries allowlisted event types", () => {
    emitAudit(db, { eventType: "refresh.start", sessionId: "s1" });
    emitAudit(db, { eventType: "snapshot.publish", sessionId: "s1" });
    const all = listAuditEvents(db);
    expect(all.length).toBe(2);
    expect(all[0]?.eventType).toMatch(/^(refresh\.start|snapshot\.publish)$/);
  });

  it("filter by event type", () => {
    emitAudit(db, { eventType: "refresh.start", sessionId: "s1" });
    emitAudit(db, { eventType: "snapshot.publish", sessionId: "s1" });
    const only = listAuditEvents(db, { eventType: "snapshot.publish" });
    expect(only.length).toBe(1);
    expect(only[0]?.eventType).toBe("snapshot.publish");
  });
});

describe("Session + snapshot lifecycle", () => {
  it("opens, records stages, persists snapshot, closes", () => {
    const sessionId = `sess-${Date.now()}`;
    openSession(db, { id: sessionId, mode: "deep", policyVersion: "0.1.0", specialistRoster: ["verifier"] });
    
    appendSessionStage(db, sessionId, { index: 1, name: "open", status: "succeeded" });
    const snapId = insertSnapshot(db, {
      sessionId,
      asOf: Date.now(),
      policyVersion: "0.1.0",
      regime: "STRESSED",
      regimeConfidence: 0.6,
      totalAllocatedPct: 80,
      reservePct: 10,
      unallocatedPct: 10,
      rankedAssets: [],
      sectorConcentration: {},
      narrativeConcentration: {},
      topRiskGates: [],
      changesSinceLastRefresh: { rankUps: [], rankDowns: [], newTopTen: [], droppedTopTen: [], largestTargetWeightChanges: [] },
      conclusion: "Test",
    });
    closeSession(db, sessionId, {
      status: "complete",
      observationCount: 0,
      evidenceClaimCount: 0,
      conclusion: "Test",
    });
    expect(snapId).toBeDefined();
    const snap = getLatestSnapshot(db);
    expect(snap?.id).toBe(snapId);
    const recent = getRecentSnapshots(db);
    expect(recent.length).toBe(1);
  });
});

describe("Replay", () => {
  it("replays a session with all artifacts", () => {
    const sessionId = `sess-replay-${Date.now()}`;
    openSession(db, { id: sessionId, mode: "deep", policyVersion: "0.1.0", specialistRoster: [] });
    const obs = ingestObservation(db, {
      idempotencyKey: `replay-obs-${randomUUID()}`,
      provider: "kraken",
      eventType: "ticker",
      schemaVersion: "1.0.0",
      occurredAt: Date.now(),
      payload: { price: 100 },
      epistemicState: "KNOWN",
      evidenceConfidence: 1,
      normalizerVersion: "0.1.0",
      sessionId,
    });
    insertEvidenceClaim(db, {
      observationId: obs.id,
      symbol: "BTC",
      factorFamily: "marketTechnical",
      claim: "Price above 100",
      source: "kraken",
      observedAt: Date.now(),
      freshnessAgeSeconds: 60,
      epistemicState: "KNOWN",
      evidenceConfidence: 0.9,
      providerIds: ["kraken"],
    });
    insertSnapshot(db, {
      sessionId,
      asOf: Date.now(),
      policyVersion: "0.1.0",
      regime: "UNKNOWN",
      regimeConfidence: 0,
      totalAllocatedPct: 0,
      reservePct: 10,
      unallocatedPct: 90,
      rankedAssets: [],
      sectorConcentration: {},
      narrativeConcentration: {},
      topRiskGates: [],
      changesSinceLastRefresh: { rankUps: [], rankDowns: [], newTopTen: [], droppedTopTen: [], largestTargetWeightChanges: [] },
      conclusion: "",
    });
    closeSession(db, sessionId, {
      status: "complete",
      observationCount: 1,
      evidenceClaimCount: 1,
      conclusion: "",
    });
    emitAudit(db, { eventType: "refresh.start", sessionId });
    emitAudit(db, { eventType: "refresh.complete", sessionId });
    const replay = replaySession(db, sessionId);
    expect(replay.session?.id).toBe(sessionId);
    expect(replay.observations.length).toBe(1);
    expect(replay.evidenceClaims.length).toBe(1);
    expect(replay.auditEvents.length).toBe(2);
  });
});

describe("Memory records (slice 7 prep)", () => {
  it("inserts and lists by kind", () => {
    insertMemory(db, {
      kind: "episodic",
      symbol: "BTC",
      subject: "2026-08-22: BTC 7% intraday",
      body: "BTC rallied 7.41% on Kraken snapshot.",
      provenance: { sessionId: "s1" },
      confidence: 0.9,
      tags: ["btc", "rally"],
    });
    insertMemory(db, {
      kind: "regime",
      subject: "Regime memory test",
      body: "STRESSED, IG credit 77 bps, hyperscaler capex 93%",
      provenance: { asOf: Date.now() },
      confidence: 0.7,
    });
    const episodic = listMemoryByKind(db, "episodic");
    const regime = listMemoryByKind(db, "regime");
    expect(episodic.length).toBe(1);
    expect(regime.length).toBe(1);
    expect(episodic[0]?.symbol).toBe("BTC");
  });
});

describe("Forecasts + calibration (slice 11 prep)", () => {
  it("inserts, lists, resolves with Brier score", () => {
    const fId = insertForecast(db, {
      sessionId: "s1",
      snapshotId: "snap1",
      symbol: "BTC",
      horizonDays: 30,
      forecast: { prob: 0.7, expectedDirection: "up", range: [80000, 100000] },
      hidden: false,
    });
    const list = listForecasts(db);
    expect(list.length).toBe(1);
    expect(list[0]?.brier).toBe(null);
    recordForecastActual(db, fId, { price: 95000, direction: "up" }, 0.09);
    const after = listForecasts(db);
    expect(after[0]?.brier).toBe(0.09);
    expect(after[0]?.actual).toBeDefined();
  });

  it("calibration runs persist with metrics", () => {
    const id = insertCalibrationRun(db, {
      policyVersion: "0.1.0",
      scope: "all",
      sampleSize: 50,
      metrics: { brier: 0.18, logLoss: 0.55, accuracy: 0.62, edgeByBucket: {} },
      hiddenHoldout: true,
      promotion: "neutral",
      notes: "Slice 1 baseline",
    });
    const runs = listCalibrationRuns(db);
    expect(runs.length).toBe(1);
    expect(runs[0]?.id).toBe(id);
  });
});
