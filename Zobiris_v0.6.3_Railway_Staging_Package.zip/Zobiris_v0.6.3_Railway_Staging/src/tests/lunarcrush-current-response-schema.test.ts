/**
 * v0.4.3 audit regression test (required #6)
 * Test: lunarcrush-current-response-schema
 *
 * Per the v0.4.3 audit (P0-3): the v4 list endpoint returns a nested
 * object `{ config, data: { coins: [{ id, name, symbol, metrics: {...} }] } }`
 * with metrics nested under a `metrics` key. The previous normalizer
 * assumed the v3 flat-array shape. v0.4.3 accepts both shapes for
 * backward compat but the normalizer is tested against the v4 nested
 * shape end-to-end.
 */

import { describe, it, expect } from "vitest";
import { LunarCrushAdapter } from "../providers/lunarcrush.js";
import { type CanonicalAsset } from "../domain/index.js";

function makeAsset(symbol: string, lunarcrushId?: string): CanonicalAsset {
  return {
    id: `cn-${symbol.toLowerCase()}-test`,
    symbol,
    name: symbol,
    providerIds: lunarcrushId ? { lunarcrushId } : {},
    mappingStatus: lunarcrushId ? "verified" : "unmapped",
    mappingConfidence: lunarcrushId ? 0.9 : 0,
    updatedAt: new Date().toISOString(),
  };
}

function assetMap(...assets: CanonicalAsset[]): Map<string, CanonicalAsset> {
  return new Map(assets.map(a => [a.symbol, a]));
}

describe("v0.4.3 P0-3: LunarCrush normalizer parses the documented v4 response shape", () => {
  it("parses the v4 list-endpoint nested shape (data.coins[].metrics)", () => {
    const adapter = new LunarCrushAdapter();
    const obs = adapter.normalize(
      {
        // v4 list-endpoint shape:
        //   { data: { coins: [{ id, name, symbol, metrics: {...} }] } }
        data: {
          coins: [
            {
              id: 1,
              name: "Bitcoin",
              symbol: "BTC",
              time: 1700000000,
              metrics: {
                galaxy_score: 78.2,
                alt_rank: 1,
                social_volume: 245000,
                sentiment: 72.3,
                social_dominance: 28.4,
                price: 78408.5,
                price_change_24h: 7.41,
                market_cap: 1_540_000_000_000,
              },
            },
          ],
        },
      },
      {
        canonicalAssets: assetMap(makeAsset("BTC", "1")),
        endpoint: "list",
        receivedAt: new Date().toISOString(),
        rawSchemaVersion: "1.0.0",
      },
    );
    expect(obs).toHaveLength(1);
    expect(obs[0]!.provider).toBe("lunarcrush");
    expect(obs[0]!.eventType).toBe("social_snapshot");
    // v0.4.3 fix: the v4 metrics are unwrapped into the payload.
    const p = obs[0]!.payload as Record<string, any>;
    expect(p.symbol).toBe("BTC");
    expect(p.galaxyScore).toBe(78.2);
    expect(p.altRank).toBe(1);
    expect(p.priceUsd).toBe(78408.5);
    expect(p.change24hPct).toBe(7.41);
  });

  it("parses the legacy v3 flat-array shape (backward compat)", () => {
    const adapter = new LunarCrushAdapter();
    const obs = adapter.normalize(
      {
        data: [
          {
            id: 1,
            name: "Bitcoin",
            symbol: "BTC",
            galaxy_score: 78.2,
            alt_rank: 1,
            social_volume: 245000,
            sentiment: 72.3,
            social_dominance: 28.4,
            price: 78408.5,
            percent_change_24h: 7.41,
            time: 1700000000,
          },
        ],
      },
      {
        canonicalAssets: assetMap(makeAsset("BTC", "1")),
        endpoint: "v4/coins",
        receivedAt: new Date().toISOString(),
        rawSchemaVersion: "1.0.0",
      },
    );
    expect(obs).toHaveLength(1);
    const p = obs[0]!.payload as Record<string, any>;
    expect(p.galaxyScore).toBe(78.2);
    expect(p.priceUsd).toBe(78408.5);
  });

  it("an empty response yields zero observations (no errors)", () => {
    const adapter = new LunarCrushAdapter();
    const obs = adapter.normalize(
      { data: { coins: [] } },
      {
        canonicalAssets: assetMap(),
        endpoint: "list",
        receivedAt: new Date().toISOString(),
        rawSchemaVersion: "1.0.0",
      },
    );
    expect(obs).toEqual([]);
  });
});
