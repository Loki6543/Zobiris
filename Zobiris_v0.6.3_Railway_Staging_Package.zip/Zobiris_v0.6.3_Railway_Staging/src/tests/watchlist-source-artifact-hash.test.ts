/**
 * v0.4.3 audit regression test (required #12)
 * Test: watchlist-source-artifact-hash
 *
 * Per the v0.4.3 audit (P0-6): "It also contains only a URL and
 * claimed retrieval timestamp, not a raw-source hash or reproducible
 * import artifact." v0.4.3 fix: the source-snapshot includes a SHA-256
 * of the ordered membership so a fresh fetch can be verified.
 */

import { describe, it, expect } from "vitest";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { createHash } from "node:crypto";

const SOURCE_SNAPSHOT = JSON.parse(
  readFileSync(resolve(process.cwd(), "src/fixtures/watchlist-source-snapshot.json"), "utf8"),
) as {
  source: string;
  retrievedAt: string;
  importMethod: string;
  rawHashAlgorithm: string;
  rawHash: string;
  orderedMembership: string[];
};

const WATCHLIST = JSON.parse(
  readFileSync(resolve(process.cwd(), "src/fixtures/watchlist.json"), "utf8"),
) as { symbol: string; name: string }[];

describe("v0.4.3 P0-6: watchlist source-artifact is auditable", () => {
  it("source snapshot has a source URL", () => {
    expect(SOURCE_SNAPSHOT.source).toMatch(/^https?:\/\//);
  });

  it("source snapshot has a retrieval timestamp", () => {
    expect(typeof SOURCE_SNAPSHOT.retrievedAt).toBe("string");
    expect(new Date(SOURCE_SNAPSHOT.retrievedAt).getTime()).toBeGreaterThan(0);
  });

  it("source snapshot has an import method", () => {
    expect(typeof SOURCE_SNAPSHOT.importMethod).toBe("string");
    expect(SOURCE_SNAPSHOT.importMethod.length).toBeGreaterThan(0);
  });

  it("source snapshot has a raw hash algorithm and value", () => {
    expect(SOURCE_SNAPSHOT.rawHashAlgorithm).toBe("sha256");
    expect(SOURCE_SNAPSHOT.rawHash).toMatch(/^[a-f0-9]{64}$/);
  });

  it("the raw hash matches the SHA-256 of the ordered membership", () => {
    const expected = createHash("sha256")
      .update(SOURCE_SNAPSHOT.orderedMembership.join("\n"))
      .digest("hex");
    expect(SOURCE_SNAPSHOT.rawHash).toBe(expected);
  });

  it("the local watchlist file matches the source snapshot membership (in order)", () => {
    expect(WATCHLIST.map(w => w.symbol)).toEqual(SOURCE_SNAPSHOT.orderedMembership);
  });

  it("the raw hash also matches the SHA-256 of the local watchlist", () => {
    const local = WATCHLIST.map(w => w.symbol);
    const expected = createHash("sha256").update(local.join("\n")).digest("hex");
    expect(SOURCE_SNAPSHOT.rawHash).toBe(expected);
  });
});
