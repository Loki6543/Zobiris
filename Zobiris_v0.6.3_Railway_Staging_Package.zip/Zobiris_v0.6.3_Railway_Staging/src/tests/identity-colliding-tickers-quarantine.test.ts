/**
 * v0.4.3 audit regression test (required #2)
 * Test: identity-colliding-tickers-quarantine
 *
 * Per the v0.4.3 audit: "Add tests using colliding tickers and an
 * unmapped asset." Two assets that share a symbol (e.g. native BTC and
 * WBTC) must BOTH be quarantined; neither is verified until the
 * provider offers a chain or contract that disambiguates.
 */

import { describe, it, expect } from "vitest";
import { lookupCanonicalIdentity } from "../providers/canonicalResolve.js";
import { detectTickerCollision as detectTickerCollisionDomain } from "../domain/canonicalAsset.js";
import type { ProviderIds } from "../providers/canonicalResolve.js";

describe("v0.4.3 P0-1: colliding tickers must be quarantined, not auto-joined", () => {
  const nativeBtc: { id: string; providerIds: ProviderIds; symbol: string; chainId?: string; contractAddress?: string } = {
    id: "cn-btc-native",
    symbol: "BTC",
    providerIds: { cmcNumericId: "1", cmcSlug: "bitcoin" },
  };
  const wbtc: { id: string; providerIds: ProviderIds; symbol: string; chainId?: string; contractAddress?: string } = {
    id: "cn-wbtc-eth",
    symbol: "BTC", // COLLISION: same ticker
    providerIds: {},
    chainId: "1",
    contractAddress: "0x2260fac5e5542a773aa44fbcfedf7c193bc2c599",
  };

  it("detectTickerCollision (domain) flags the BTC/WBTC collision", () => {
    const collisions = detectTickerCollisionDomain([
      { ...nativeBtc, name: "Bitcoin", mappingStatus: "verified", mappingConfidence: 0.99, updatedAt: new Date().toISOString() },
      { ...wbtc, name: "WBTC", mappingStatus: "verified", mappingConfidence: 0.99, updatedAt: new Date().toISOString() },
    ] as any);
    expect(collisions.has("BTC")).toBe(true);
    expect(collisions.get("BTC")).toHaveLength(2);
  });

  it("symbol-only lookup against two colliding assets is ambiguous", () => {
    const result = lookupCanonicalIdentity(
      { provider: "coinglass", providerAssetId: "BTC", symbol: "BTC" },
      [nativeBtc, wbtc],
    );
    expect(result).not.toBeNull();
    expect(result!.mappingStatus).toBe("ambiguous");
    expect(result!.mappingConfidence).toBeLessThanOrEqual(0.7);
  });

  it("chain+contract lookup disambiguates the collision", () => {
    const result = lookupCanonicalIdentity(
      {
        provider: "kraken",
        providerAssetId: "WBTC",
        symbol: "BTC",
        chainId: "1",
        contractAddress: "0x2260fac5e5542a773aa44fbcfedf7c193bc2c599",
      },
      [nativeBtc, wbtc],
    );
    expect(result).not.toBeNull();
    expect(result!.canonicalAssetId).toBe("cn-wbtc-eth");
    expect(result!.matchMethod).toBe("contract");
    expect(result!.mappingStatus).toBe("verified");
  });

  it("an unmapped asset (no providerIds, no contract) is quarantined", () => {
    const unmappedAsset: { id: string; providerIds: ProviderIds; symbol: string } = {
      id: "cn-foo-unmapped",
      symbol: "FOO",
      providerIds: {},
    };
    const result = lookupCanonicalIdentity(
      { provider: "kraken", providerAssetId: "FOO", symbol: "FOO" },
      [unmappedAsset],
    );
    expect(result).not.toBeNull();
    expect(result!.mappingStatus).toBe("ambiguous");
    expect(result!.matchMethod).toBe("symbol-only");
  });

  it("lookupCanonicalIdentity returns null for an unknown symbol with no entries", () => {
    const result = lookupCanonicalIdentity(
      { provider: "kraken", providerAssetId: "ZZZZ", symbol: "ZZZZ" },
      [nativeBtc],
    );
    expect(result).toBeNull();
  });
});
