/**
 * v0.4.3 audit regression test (required #10)
 * Test: coinglass-current-v4-liquidation-endpoint
 *
 * Per the v0.4.3 audit (P0-5): CoinGlass v4 liquidation endpoints are
 *   /api/futures/liquidation/order
 *   /api/futures/liquidation/coin-list
 *   /api/futures/liquidation/history
 *   /api/futures/liquidation/aggregated-history
 * The v2 `/api/futures/liquidation/info` endpoint is removed.
 */

import { describe, it, expect, vi, afterEach } from "vitest";
import { CoinGlassAdapter } from "../providers/coinglass.js";

afterEach(() => { vi.unstubAllGlobals(); });

describe("v0.4.3 P0-5: CoinGlass v4 liquidation endpoint", () => {
  it("live URL uses /api/futures/liquidation/aggregated-history (not /liquidation/info)", async () => {
    const fetchMock = vi.fn(async () => new Response("[]", { status: 200 }));
    vi.stubGlobal("fetch", fetchMock);
    const adapter = new CoinGlassAdapter();
    adapter.configure({
      baseUrl: "https://open-api-v4.coinglass.com",
      liveConfig: { apiKey: "test-key" },
    });
    await adapter.fetch({ canonicalAssets: new Map() });
    // Find the second fetch call (liquidation is the 2nd request)
    const liquidationCall = fetchMock.mock.calls.find(
      (call: unknown[]) => typeof call[0] === "string" && (call[0] as string).includes("liquidation"),
    );
    expect(liquidationCall).toBeDefined();
    const [calledUrl] = liquidationCall! as unknown as [string, RequestInit];
    expect(calledUrl).toContain("/api/futures/liquidation/aggregated-history");
    expect(calledUrl).not.toContain("/liquidation/info");
  });

  it("normalizer accepts v4 liquidation response fields (longVolumeUsd, shortVolumeUsd, createTime)", () => {
    const adapter = new CoinGlassAdapter();
    const obs = adapter.normalize(
      { code: "0", msg: "ok", data: [
        {
          // v4 aggregated-history shape
          createTime: 1700000000,
          exchangeName: "Binance",
          symbol: "BTC",
          longVolumeUsd: 1234567,
          shortVolumeUsd: 7654321,
        },
      ] },
      { canonicalAssets: new Map(), endpoint: "liquidations", receivedAt: new Date().toISOString(), rawSchemaVersion: "1.0.0" },
    );
    expect(obs).toHaveLength(1);
    const p = obs[0]!.payload as Record<string, any>;
    // v0.4.3 fix: long+short volumes are summed to a single volumeUsd
    expect(p.volumeUsd).toBe(1234567 + 7654321);
    // v0.4.3 fix: side is inferred from which leg is larger
    expect(p.side).toBe("short");
    expect(p.exchange).toBe("Binance");
  });
});
