/**
 * Tests for the Iyaza Addendum capability registry.
 */
import { describe, it, expect } from "vitest";
import { CapabilityRegistry, buildDefaultRegistry, upgradeHealth, CAPABILITY_IDS } from "../capabilities/registry.js";

describe("capability-registry", () => {
  it("exposes all 20 capability IDs in the catalogue", () => {
    expect(CAPABILITY_IDS.length).toBe(20);
    expect(CAPABILITY_IDS).toContain("market.quotes");
    expect(CAPABILITY_IDS).toContain("derivs.liquidations");
    expect(CAPABILITY_IDS).toContain("social.attention");
    expect(CAPABILITY_IDS).toContain("onchain.flows");
    expect(CAPABILITY_IDS).toContain("eval.replay");
  });

  it("buildDefaultRegistry() registers all 20 capabilities", () => {
    const reg = buildDefaultRegistry();
    expect(reg.size()).toBe(20);
    expect(reg.get("market.quotes")).not.toBeNull();
    expect(reg.get("eval.replay")).not.toBeNull();
  });

  it("forProvider('kraken') returns market capabilities", () => {
    const reg = buildDefaultRegistry();
    const krakenCaps = reg.forProvider("kraken");
    expect(krakenCaps.length).toBeGreaterThan(0);
    const ids = krakenCaps.map((c) => c.capabilityId);
    expect(ids).toContain("market.quotes");
    expect(ids).toContain("market.candles");
    expect(ids).toContain("market.orderbook");
  });

  it("getHealth returns the initial state (unconfigured) by default", () => {
    const reg = buildDefaultRegistry();
    expect(reg.getHealth("market.quotes")).toBe("unconfigured");
  });

  it("markHealth updates the provider's state, which affects capabilities", () => {
    const reg = buildDefaultRegistry();
    // market.candles is only advertised by kraken, so a single markHealth flips it.
    reg.markHealth("kraken", "healthy");
    expect(reg.getHealth("market.candles")).toBe("healthy");
  });

  it("get returns null for an unregistered capability", () => {
    const reg = new CapabilityRegistry();
    expect(reg.get("market.quotes")).toBeNull();
  });

  it("markHealth on an unregistered capability still works (provider-level)", () => {
    const reg = new CapabilityRegistry();
    reg.markHealth("kraken", "healthy");
    // No capability registered, so health is unconfigured (default).
    expect(reg.getHealth("market.quotes")).toBe("unconfigured");
  });

  it("duplicate registration throws", () => {
    const reg = new CapabilityRegistry();
    reg.register({
      capabilityId: "market.quotes",
      version: "1.0.0",
      inputSchemaVersion: "1.0.0",
      outputSchemaVersion: "1.0.0",
      providers: ["kraken"],
      requiredPermissions: [],
      sideEffectClass: "network",
      allowedHosts: ["api.kraken.com"],
      timeoutMs: 10_000,
      retryPolicy: "no-retry",
      idempotencyPolicy: "by ts",
      healthState: "unconfigured",
      evidenceObligations: [],
      degradationPolicy: "fixture",
    });
    expect(() =>
      reg.register({
        capabilityId: "market.quotes",
        version: "1.0.0",
        inputSchemaVersion: "1.0.0",
        outputSchemaVersion: "1.0.0",
        providers: ["cmc"],
        requiredPermissions: [],
        sideEffectClass: "network",
        allowedHosts: [],
        timeoutMs: 10_000,
        retryPolicy: "no-retry",
        idempotencyPolicy: "by ts",
        healthState: "unconfigured",
        evidenceObligations: [],
        degradationPolicy: "fixture",
      }),
    ).toThrow();
  });

  it("default timeouts are in the allowed range [1000, 60000] ms", () => {
    const reg = buildDefaultRegistry();
    for (const cap of reg.list()) {
      expect(cap.timeoutMs).toBeGreaterThanOrEqual(1000);
      expect(cap.timeoutMs).toBeLessThanOrEqual(60_000);
    }
  });

  it("registered descriptors are frozen (immutable)", () => {
    const reg = buildDefaultRegistry();
    const cap = reg.get("market.quotes")!;
    expect(Object.isFrozen(cap)).toBe(true);
  });

  it("upgradeHealth maps legacy 4-state to new 9-state", () => {
    expect(upgradeHealth("snapshot")).toBe("configured");
    expect(upgradeHealth("connected")).toBe("healthy");
    expect(upgradeHealth("degraded")).toBe("degraded");
    expect(upgradeHealth("credentials-needed")).toBe("unconfigured");
    // Pass-through for already-extended states
    expect(upgradeHealth("rate_limited")).toBe("rate_limited");
    expect(upgradeHealth("auth_failed")).toBe("auth_failed");
    // Unknown defaults to unavailable
    expect(upgradeHealth("unknown_thing")).toBe("unavailable");
  });

  it("worst-case health across multiple providers is the least-healthy one", () => {
    const reg = buildDefaultRegistry();
    reg.markHealth("kraken", "healthy");
    reg.markHealth("cmc", "auth_failed");
    // market.quotes has both providers -> worst is auth_failed
    expect(reg.getHealth("market.quotes")).toBe("auth_failed");
  });
});
