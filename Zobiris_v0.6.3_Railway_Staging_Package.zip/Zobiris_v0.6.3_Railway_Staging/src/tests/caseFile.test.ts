/**
 * Case file tests — slice 5+ v0.4.0.
 */

import { describe, it, expect } from "vitest";
import { randomUUID } from "node:crypto";
import {
  type CanonicalAsset,
  type NormalizedObservation,
  type AssetAnalysisSnapshot,
} from "../domain/index.js";
import { buildCaseFile } from "../portfolio/caseFile.js";
import { orchestrate } from "../specialists/orchestrator.js";

function makeCanonical(
  symbol: string,
  mappingStatus:
    "verified" | "ambiguous" | "unmapped" | "quarantined" = "verified",
): CanonicalAsset {
  return {
    id: randomUUID(),
    symbol,
    name: symbol,
    providerIds: {},
    mappingStatus,
    mappingConfidence: mappingStatus === "verified" ? 1.0 : 0.5,
    updatedAt: new Date().toISOString(),
  };
}

function makeAssetAnalysis(
  symbol: string,
  score: number,
  action: string = "HOLD",
): AssetAnalysisSnapshot {
  return {
    symbol,
    canonicalAssetId: randomUUID(),
    mappingStatus: "verified",
    asOf: new Date().toISOString(),
    opportunity: {
      raw: score,
      evidenceGapPenalty: 0,
      adjusted: score,
      factorScores: [],
    },
    confidence: {
      pct: 60,
      inputs: {
        freshness: 0.8,
        sourceReputation: 0.7,
        coverage: 0.7,
        crossSourceAgreement: 0.6,
        identityConfidence: 1.0,
        unresolvedConflicts: 0,
      },
    },
    riskGates: [],
    targetWeight: {
      pct: score / 10,
      rawEdge: 0.1,
      scalars: {
        volatility: 0.1,
        liquidity: 0.1,
        regime: 0.1,
        risk: 0.1,
        diversification: 0.1,
        correlation: 0.1,
      },
      explanation: "test",
    },
    role: "WATCHLIST",
    action: action as any,
    risk: "Moderate" as const,
    evidenceClaimIds: [],
    counterEvidenceClaimIds: [],
    evidenceState: "KNOWN",
    conclusion: "test",
    scenarios: { bull: "bull case", base: "base case", bear: "bear case" },
    invalidationConditions: ["price < $50k"],
    opportunityRank: 1,
    allocationRank: 2,
    evidenceCoverage: 0.7,
    criticalUnknowns: 0,
  };
}

function makeQuoteObs(
  assetId: string,
  changePct24h: number,
  priceUsd: number = 60000,
): NormalizedObservation {
  return {
    id: randomUUID(),
    idempotencyKey: `${assetId}:quote:${Date.now()}`,
    provider: "kraken",
    providerEventId: `${assetId}:${Date.now()}`,
    eventType: "quote",
    schemaVersion: "1.0.0",
    canonicalAssetId: assetId,
    quarantineState: "verified",
    occurredAt: new Date().toISOString(),
    receivedAt: new Date().toISOString(),
    retrievedAt: new Date().toISOString(),
    normalizerVersion: "0.1.0",
    payload: {
      priceUsd,
      changePct24h,
      volumeUsd24h: 1_000_000_000,
      marketCapUsd: 1_200_000_000_000,
    },
    epistemicState: "KNOWN",
    evidenceConfidence: 0.95,
    licenseClass: "display-only",
  };
}

describe("buildCaseFile", () => {
  it("builds a basic case file from snapshot, canonical, observations", () => {
    const canonical = makeCanonical("BTC");
    const assetAnalysis = makeAssetAnalysis("BTC", 80, "BUY");
    const obs = [makeQuoteObs(canonical.id, 5.0)];
    const cf = buildCaseFile({
      symbol: "BTC",
      assetAnalysis,
      canonical,
      observations: obs,
      specialistResult: null,
    });
    expect(cf.symbol).toBe("BTC");
    expect(cf.identity.status).toBe("verified");
    expect(cf.score.opportunity).toBe(80);
    expect(cf.scenarios.bull).toBe("bull case");
    expect(cf.evidence.length).toBe(1);
    expect(cf.specialist).toBeNull();
  });

  it("emits caveats for unmapped / unobserved assets", () => {
    const cf = buildCaseFile({
      symbol: "UNKNOWN",
      assetAnalysis: null,
      canonical: null,
      observations: [],
      specialistResult: null,
    });
    expect(cf.caveats.length).toBeGreaterThan(0);
    expect(cf.caveats.some((c) => c.includes("unmapped"))).toBe(true);
    expect(cf.caveats.some((c) => c.includes("No observations"))).toBe(true);
  });

  it("includes specialist reconciliation when supplied", async () => {
    const canonical = makeCanonical("BTC");
    const obs = [makeQuoteObs(canonical.id, 5.0)];
    const result = await orchestrate({
      canonicalAsset: canonical,
      observations: obs,
      seed: 1,
    });
    const cf = buildCaseFile({
      symbol: "BTC",
      assetAnalysis: null,
      canonical,
      observations: obs,
      specialistResult: result,
    });
    expect(cf.specialist).not.toBeNull();
    expect(cf.specialist!.reconciledDirection).toBeDefined();
    expect(cf.specialist!.specialistOpinions.length).toBeGreaterThan(0);
  });

  it("surfaces open challenges", async () => {
    const canonical = makeCanonical("X", "quarantined");
    const obs = [makeQuoteObs(canonical.id, 5.0)];
    const result = await orchestrate({
      canonicalAsset: canonical,
      observations: obs,
      seed: 1,
    });
    const cf = buildCaseFile({
      symbol: "X",
      assetAnalysis: null,
      canonical,
      observations: obs,
      specialistResult: result,
    });
    expect(cf.specialist?.vetoed).toBe(true);
  });

  it("builds recent history from prior snapshots", () => {
    const canonical = makeCanonical("BTC");
    const cf = buildCaseFile({
      symbol: "BTC",
      assetAnalysis: null,
      canonical,
      observations: [],
      specialistResult: null,
      recentHistory: [
        {
          asOf: new Date().toISOString(),
          rankedAssets: [
            {
              symbol: "BTC",
              opportunity: { adjusted: 75 },
              confidence: { pct: 60 },
              action: "BUY",
            },
            {
              symbol: "ETH",
              opportunity: { adjusted: 70 },
              confidence: { pct: 55 },
              action: "HOLD",
            },
          ],
        },
        {
          asOf: new Date().toISOString(),
          rankedAssets: [
            {
              symbol: "BTC",
              opportunity: { adjusted: 70 },
              confidence: { pct: 55 },
              action: "HOLD",
            },
          ],
        },
      ],
    });
    expect(cf.recentHistory.length).toBe(2);
    expect(cf.recentHistory[0]?.opportunity).toBe(75);
  });

  it("exposes provenance and keeps fallback evidence display-only", () => {
    const canonical = makeCanonical("BTC");
    const observation = {
      ...makeQuoteObs(canonical.id, 2),
      dataMode: "fallback" as const,
      providerEndpoint: "fixture://kraken/quote",
      requestedSymbol: "BTC/USD",
      requestedExchange: "kraken",
      payloadHash: "a".repeat(64),
    };
    const cf = buildCaseFile({
      symbol: "BTC",
      assetAnalysis: makeAssetAnalysis("BTC", 80),
      canonical,
      observations: [observation],
      specialistResult: null,
    });
    expect(cf.evidence[0]).toMatchObject({
      dataMode: "fallback",
      providerEndpoint: "fixture://kraken/quote",
      payloadHash: "a".repeat(64),
      requestedMarket: "kraken:BTC/USD",
      eligibility: "display_only_ambiguous",
    });
    expect(
      cf.unknowns.some((item) => item.code === "DISPLAY_ONLY_EVIDENCE"),
    ).toBe(true);
  });

  it("reports exact contradictory claims and deltas from the previous snapshot", () => {
    const canonical = makeCanonical("BTC");
    const assetAnalysis = makeAssetAnalysis("BTC", 80, "BUY");
    assetAnalysis.confidence.pct = 64;
    assetAnalysis.counterEvidenceClaimIds = [
      "3f8aaac9-7654-4a74-aecc-1c33fe62aa0b",
    ];
    const cf = buildCaseFile({
      symbol: "BTC",
      assetAnalysis,
      canonical,
      observations: [makeQuoteObs(canonical.id, 5)],
      evidenceClaims: [
        {
          id: "3f8aaac9-7654-4a74-aecc-1c33fe62aa0b",
          claim: "Exchange flows conflict with the bullish price signal.",
          source: "onchain-provider",
          factorFamily: "onchainPositioning",
          epistemicState: "CONFLICTED",
          freshness: "live",
          dataMode: "live",
        },
      ],
      specialistResult: null,
      recentHistory: [
        {
          asOf: "2026-08-24T12:00:00.000Z",
          rankedAssets: [
            {
              symbol: "BTC",
              opportunity: { adjusted: 75 },
              confidence: { pct: 60 },
              action: "HOLD",
            },
          ],
        },
      ],
    });
    expect(cf.contradictions).toEqual([
      expect.objectContaining({
        code: "CONFLICTED_CLAIM",
        claimId: "3f8aaac9-7654-4a74-aecc-1c33fe62aa0b",
      }),
    ]);
    expect(cf.changeSincePrevious).toEqual({
      previousAsOf: "2026-08-24T12:00:00.000Z",
      opportunityDelta: 5,
      confidenceDelta: 4,
      actionChanged: true,
      previousAction: "HOLD",
    });
  });
});
