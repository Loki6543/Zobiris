/**
 * v0.4.3 audit regression test (required #17)
 * Test: cmc-no-key-state-truthful
 *
 * Per the v0.4.3 audit (P1): "`buildAdapters()` sets the CMC fixture
 * path to an empty string in live mode, then if `CMC_API_KEY` is
 * absent logs: 'using fixture mode' without restoring the fixture.
 * The PDF correctly lists this as deferred. Fix the behavior or
 * report `credentials-needed`; do not claim fixture fallback when no
 * fixture is configured."
 *
 * v0.4.3 fix: when --live and no CMC_API_KEY is set, the adapter
 * surfaces as `credentials-needed` (via health()), NOT as
 * 'connected' or 'snapshot'. The console message is honest.
 */

import { describe, it, expect, beforeEach, afterEach } from "vitest";
import { buildAdapters } from "../scripts/_adapters.js";
import { CMCAdapter } from "../providers/cmc.js";

describe("v0.4.3 P1: CMC no-key state is truthful (credentials-needed, not silent fixture)", () => {
  let originalKey: string | undefined;
  beforeEach(() => {
    originalKey = process.env.CMC_API_KEY;
  });
  afterEach(() => {
    if (originalKey === undefined) delete process.env.CMC_API_KEY;
    else process.env.CMC_API_KEY = originalKey;
  });

  it("with --live and no CMC_API_KEY: health() reports credentials-needed (not connected)", () => {
    delete process.env.CMC_API_KEY;
    const adapters = buildAdapters({ live: true, staleSeconds: 60 });
    const cmc = (adapters as any).cmc as CMCAdapter;
    const h = cmc.health();
    expect(h.status).toBe("credentials-needed");
  });

  it("with --live and no CMC_API_KEY: fetch() returns no rows (no fake data)", async () => {
    delete process.env.CMC_API_KEY;
    const adapters = buildAdapters({ live: true, staleSeconds: 60 });
    const cmc = (adapters as any).cmc as CMCAdapter;
    const result = await cmc.fetch({ canonicalAssets: new Map() });
    // No fixture, no live key: should return an empty/null result.
    expect(result).toBeDefined();
    expect(result.length).toBeLessThanOrEqual(1);
    // The single result (if any) has data=null, which the
    // normalizer handles as a no-op.
    if (result[0]) {
      expect(result[0].data).toBeNull();
    }
  });

  it("with --live AND CMC_API_KEY set: health() reports connected", () => {
    process.env.CMC_API_KEY = "test-key-12345";
    const adapters = buildAdapters({ live: true, staleSeconds: 60 });
    const cmc = (adapters as any).cmc as CMCAdapter;
    const h = cmc.health();
    expect(h.status).toBe("connected");
  });

  it("without --live: fixture path is set, health() reports snapshot", () => {
    delete process.env.CMC_API_KEY;
    const adapters = buildAdapters({ live: false, staleSeconds: 60 });
    const cmc = (adapters as any).cmc as CMCAdapter;
    const h = cmc.health();
    expect(h.status).toBe("snapshot");
  });
});
