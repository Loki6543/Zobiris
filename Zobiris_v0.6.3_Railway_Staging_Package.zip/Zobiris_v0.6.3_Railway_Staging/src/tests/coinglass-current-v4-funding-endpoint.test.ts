/**
 * v0.4.3 audit regression test (required #9)
 * Test: coinglass-current-v4-funding-endpoint
 *
 * Per the v0.4.3 audit (P0-5): "The CG-API-KEY header and v4 host are
 * correct. The source still calls old paths:
 *   /api/futures/fundingRate/v2
 *   /api/futures/liquidation/info
 * Current v4 documentation exposes endpoint families such as:
 *   /api/futures/funding-rate/history
 *   /api/futures/funding-rate/vol-weight-history
 *   /api/futures/liquidation/order
 *   /api/futures/liquidation/coin-list
 *   /api/futures/liquidation/history
 *   /api/futures/liquidation/aggregated-history"
 */

import { describe, it, expect, vi, afterEach } from "vitest";
import { CoinGlassAdapter } from "../providers/coinglass.js";

afterEach(() => { vi.unstubAllGlobals(); });

describe("v0.4.3 P0-5: CoinGlass v4 funding endpoint", () => {
  it("live URL uses /api/futures/funding-rate/history (not /fundingRate/v2)", async () => {
    const fetchMock = vi.fn(async () => new Response("[]", { status: 200 }));
    vi.stubGlobal("fetch", fetchMock);
    const adapter = new CoinGlassAdapter();
    adapter.configure({
      baseUrl: "https://open-api-v4.coinglass.com",
      liveConfig: { apiKey: "test-key" },
    });
    await adapter.fetch({ canonicalAssets: new Map() });
    expect(fetchMock).toHaveBeenCalled();
    const [calledUrl] = fetchMock.mock.calls[0]! as unknown as [string, RequestInit];
    expect(calledUrl).toContain("/api/futures/funding-rate/history");
    expect(calledUrl).not.toContain("/fundingRate/v2");
  });

  it("live URL includes exchange, symbol, interval query params (v4 contract)", async () => {
    const fetchMock = vi.fn(async () => new Response("[]", { status: 200 }));
    vi.stubGlobal("fetch", fetchMock);
    const adapter = new CoinGlassAdapter();
    adapter.configure({
      baseUrl: "https://open-api-v4.coinglass.com",
      liveConfig: { apiKey: "test-key", symbols: ["BTC"] },
    });
    await adapter.fetch({ canonicalAssets: new Map() });
    const [calledUrl] = fetchMock.mock.calls[0]! as unknown as [string, RequestInit];
    expect(calledUrl).toMatch(/[?&]exchange=/);
    expect(calledUrl).toMatch(/[?&]symbol=/);
    expect(calledUrl).toMatch(/[?&]interval=/);
  });

  it("CG-API-KEY header is set (v4 auth contract)", async () => {
    const fetchMock = vi.fn(async () => new Response("[]", { status: 200 }));
    vi.stubGlobal("fetch", fetchMock);
    const adapter = new CoinGlassAdapter();
    adapter.configure({
      baseUrl: "https://open-api-v4.coinglass.com",
      liveConfig: { apiKey: "test-key-abc" },
    });
    await adapter.fetch({ canonicalAssets: new Map() });
    const [, calledInit] = fetchMock.mock.calls[0]! as unknown as [string, RequestInit];
    const headers = calledInit.headers as Record<string, string>;
    expect(headers["CG-API-KEY"]).toBe("test-key-abc");
    // v0.4.3 fix: no legacy `coinglassSecret` header.
    expect(headers["coinglassSecret"]).toBeUndefined();
  });

  it("normalizer accepts v4 funding response fields (createTime, fundingRate, exchangeName)", () => {
    const adapter = new CoinGlassAdapter();
    const obs = adapter.normalize(
      { code: "0", msg: "ok", data: [
        {
          // v4 shape
          createTime: 1700000000,
          fundingRate: 0.0001,
          exchangeName: "Binance",
          symbol: "BTC",
        },
      ] },
      { canonicalAssets: new Map(), endpoint: "funding", receivedAt: new Date().toISOString(), rawSchemaVersion: "1.0.0" },
    );
    expect(obs).toHaveLength(1);
    const p = obs[0]!.payload as Record<string, any>;
    expect(p.rate).toBe(0.0001);
    expect(p.exchange).toBe("Binance");
  });
});
