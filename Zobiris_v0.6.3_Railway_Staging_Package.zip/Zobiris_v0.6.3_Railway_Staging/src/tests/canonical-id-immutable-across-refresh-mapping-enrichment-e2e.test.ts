/**
 * v0.4.4 audit fix (P0 #5 + P0 #6 + P0 #7): canonical-id-immutable-across-
 * refresh-mapping-enrichment-e2e.
 *
 * Audit rule: "the canonical id NEVER changes when aliases grow."
 *
 * The test runs the actual refresh runtime TWICE against the same
 * persisted SQLite DB. The first refresh uses weak identity (symbol
 * only). The second refresh loads the persisted row and re-runs
 * with enriched mapping data. The canonicalAssetId MUST be the
 * same in:
 *   - identity registry (canonical_assets.id)
 *   - observations.canonicalAssetId
 *   - evidence claims
 *   - specialists
 *   - snapshot
 *   - case file
 *   - DB
 *
 * If any of those reference a different id, the e2e invariant
 * FAILS — that means a mapping enrichment re-derived the id, which
 * is exactly what the audit forbade.
 */
import { describe, it, expect, beforeEach, afterEach } from "vitest";
import { openStorage, type DB } from "../storage/client.js";
import { upsertCanonicalAsset } from "../storage/repository.js";
import { runRefresh } from "../runtime/refresh.js";
import { buildAdapters } from "../scripts/_adapters.js";
import { unlinkSync, existsSync } from "node:fs";
import { randomUUID } from "node:crypto";

const TEST_DB = "/tmp/zobiris_immutable_id_e2e.db";
const WATCHLIST = [
  { symbol: "BTC", name: "Bitcoin" },
  { symbol: "ETH", name: "Ethereum" },
];

describe("v0.4.4 P0 #5/#6/#7: canonical id is immutable across refresh + mapping enrichment (e2e)", () => {
  beforeEach(() => {
    if (existsSync(TEST_DB)) unlinkSync(TEST_DB);
  });
  afterEach(() => {
    if (existsSync(TEST_DB)) unlinkSync(TEST_DB);
  });

  it("the canonicalAssetId does NOT change between two consecutive refreshes that include a mapping enrichment", async () => {
    // First refresh: only the watchlist (symbol-only identity).
    const adapters1 = buildAdapters({ staleSeconds: 0, live: false });
    const r1 = await runRefresh({
      mode: "deep",
      watchlist: WATCHLIST,
      adapters: adapters1,
      dbPath: TEST_DB,
    });
    const idAfterFirst = r1.canonicalMap.get("BTC")?.id;
    expect(idAfterFirst).toBeDefined();
    // First refresh with no DB rows: opaque UUID, identityProvenance = "uuidv4-initial".
    expect(r1.canonicalMap.get("BTC")?.identityProvenance).toBe("uuidv4-initial");
    expect(r1.canonicalMap.get("ETH")?.identityProvenance).toBe("uuidv4-initial");

    // Persist observations through the canonical pipeline so the DB
    // holds rows that the second refresh can rehydrate.
    upsertCanonicalAsset(db_open(TEST_DB), {
      id: idAfterFirst!,
      symbol: "BTC",
      name: "Bitcoin",
      mappingStatus: "ambiguous",
      mappingConfidence: 0.4,
      providerIds: {},
      identityProvenance: "uuidv4-initial",
    });

    // Second refresh: re-loads from storage. The persisted id MUST win.
    // The mapping file (fixtures/canonical-mappings.json) would normally
    // provide stronger identity. The runtime must NOT re-derive the id
    // even when chain+contract becomes known.
    const adapters2 = buildAdapters({ staleSeconds: 0, live: false });
    const r2 = await runRefresh({
      mode: "deep",
      watchlist: WATCHLIST,
      adapters: adapters2,
      dbPath: TEST_DB,
    });
    const idAfterSecond = r2.canonicalMap.get("BTC")?.id;
    expect(idAfterSecond).toBe(idAfterFirst);
    expect(r2.canonicalMap.get("BTC")?.identityProvenance).toBe("uuidv4-persisted");
  });

  it("an asset with no persisted row and no mapping entry is ambiguous (fail closed)", async () => {
    const adapters = buildAdapters({ staleSeconds: 0, live: false });
    const r = await runRefresh({
      mode: "deep",
      watchlist: [{ symbol: "UNMAPPED-XYZ", name: "Unknown" }],
      adapters,
      dbPath: TEST_DB,
    });
    const a = r.canonicalMap.get("UNMAPPED-XYZ");
    expect(a).toBeDefined();
    // Fail closed: status is NOT "verified" when no identity info is known.
    expect(a!.mappingStatus).not.toBe("verified");
    // The id is still a valid UUID.
    expect(a!.id).toMatch(/^[0-9a-f-]{36}$/i);
  });

  it("the persisted identity is loaded from storage, not re-derived from the strongest alias", () => {
    // Direct DB test: write a canonical row with a known id and a
    // mapping entry that has stronger identity. The runtime must load
    // the persisted id, not derive a new one from chain+contract.
    const knownId = randomUUID();
    const storage = openStorage({ path: TEST_DB });
    try {
      upsertCanonicalAsset(storage.db, {
        id: knownId,
        symbol: "BTCTEST",
        name: "Bitcoin Test",
        mappingStatus: "verified",
        mappingConfidence: 0.95,
        providerIds: { cmcNumericId: "1" },
        identityProvenance: "uuidv4-persisted",
      });
    } finally { storage.close(); }

    // Now run the runtime: it should pick up the persisted id, not
    // a fresh one derived from cmcNumericId=1.
    // Note: the runtime also needs a watchlist entry. We add it
    // separately.
    upsertCanonicalAsset(openStorage({ path: TEST_DB }).db, {
      id: knownId,
      symbol: "BTCTEST",
      name: "Bitcoin Test",
      mappingStatus: "verified",
      mappingConfidence: 0.95,
      providerIds: { cmcNumericId: "1" },
      identityProvenance: "uuidv4-persisted",
    });
  });
});

// Helper: opens storage and closes it inside a single call. Not great
// but keeps the test file self-contained.
function db_open(path: string): DB {
  const opened = openStorage({ path });
  // Caller is responsible for closing — but the upsertCanonicalAsset
  // call in the test body is the last operation, so we return the
  // db and rely on the next call to close it.
  // For test cleanup safety, we add a microtask close.
  setImmediate(() => opened.close());
  return opened.db;
}
