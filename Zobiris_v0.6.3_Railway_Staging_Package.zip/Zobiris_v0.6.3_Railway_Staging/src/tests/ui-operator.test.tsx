// @vitest-environment jsdom
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { cleanup, render, screen, waitFor } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { App } from "../ui/App";
import type { AssetCaseFile } from "../ui/api";

const caseFileFixture: AssetCaseFile = {
  symbol: "BTC",
  asOf: "2026-08-27T00:00:00.000Z",
  identity: {
    status: "verified",
    confidence: 1,
    chainId: "bitcoin",
    contractAddress: null,
    providerIds: { cmc: "1" },
  },
  score: {
    opportunity: 89.4,
    confidence: 82,
    targetWeightPct: 18,
    opportunityRank: 1,
    allocationRank: 1,
  },
  conclusion: "BTC evidence-backed case from the persisted watchlist evaluation.",
  role: "CORE",
  action: "HOLD",
  risk: "Low",
  scenarios: { bull: "Bull case", base: "Base case", bear: "Bear case" },
  invalidationConditions: [],
  evidenceCoverage: 1,
  criticalUnknowns: 0,
  evidence: [],
  contradictions: [],
  unknowns: [],
  recentHistory: [],
  changeSincePrevious: null,
  strategy21: null,
  caveats: [],
};

vi.mock("recharts", () => ({
  ResponsiveContainer: ({ children }: { children: React.ReactNode }) => (
    <div>{children}</div>
  ),
  AreaChart: () => null,
  Area: () => null,
}));

class ResizeObserverStub {
  observe() {}
  unobserve() {}
  disconnect() {}
}

describe("v0.4.13 watchlist-only operator UI", () => {
  beforeEach(() => {
    vi.stubGlobal("ResizeObserver", ResizeObserverStub);
    vi.stubGlobal(
      "fetch",
      vi.fn().mockImplementation((input: string | URL | Request) => {
        const url = String(input);
        const payload =
          url === "/api/watchlist"
            ? {
                source:
                  "https://coinmarketcap.com/watchlist/69c01b46aed37c7160053535/",
                watchlist: [
                  { rank: 1, symbol: "BTC", name: "Bitcoin" },
                  { rank: 2, symbol: "ETH", name: "Ethereum" },
                ],
              }
            : url === "/api/snapshot/latest"
              ? {
                  snapshot: {
                    asOf: "2026-08-27T00:00:00.000Z",
                    rankedAssets: [
                      {
                        symbol: "BTC",
                        opportunityRank: 1,
                        opportunity: { adjusted: 89.4 },
                        confidence: { pct: 82 },
                        risk: "Low",
                        action: "HOLD",
                        evidenceClaimIds: ["claim-1"],
                      },
                    ],
                  },
                }
              : url === "/api/providers"
                ? { providers: [] }
                : url === "/api/asset/BTC"
                  ? {
                      caseFile: caseFileFixture,
                      evidence: [
                        {
                          id: "claim-1",
                          claim: "BTC evidence is available.",
                          source: "fixture",
                          factorFamily: "market",
                          evidenceConfidence: 0.8,
                          freshness: "live",
                          dataMode: "snapshot",
                          claimOrigin: "provider",
                          epistemicState: "KNOWN",
                        },
                      ],
                    }
                  : url === "/api/agents/challenge"
                    ? {
                        output: {
                          claimId: "claim-1",
                          reasoning: "The evidence remains bounded.",
                          confidence: 0.75,
                          requestedEvidence: [],
                          contradictions: [],
                        },
                      }
                    : null;
        if (payload === null) return Promise.reject(new Error("offline test"));
        return Promise.resolve({
          ok: true,
          status: 200,
          statusText: "OK",
          json: async () => payload,
        } as Response);
      }),
    );
    Object.defineProperty(window, "matchMedia", {
      writable: true,
      value: vi.fn().mockImplementation(() => ({
        matches: false,
        addListener: vi.fn(),
        removeListener: vi.fn(),
        addEventListener: vi.fn(),
        removeEventListener: vi.fn(),
        dispatchEvent: vi.fn(),
      })),
    });
  });

  afterEach(() => {
    cleanup();
    vi.unstubAllGlobals();
  });

  it("navigates Command Center → Asset Case File → Evidence Graph → controlled Challenger", async () => {
    const queryClient = new QueryClient({
      defaultOptions: {
        queries: { retry: false },
        mutations: { retry: false },
      },
    });
    render(
      <QueryClientProvider client={queryClient}>
        <App />
      </QueryClientProvider>,
    );
    const user = userEvent.setup();

    expect(
      screen.getByRole("heading", { name: "Command Center" }),
    ).toBeTruthy();
    expect(
      screen.getByRole("button", { name: "Open navigation" }),
    ).toBeTruthy();

    await user.click(screen.getByRole("button", { name: "Asset Case File" }));
    expect(
      screen.getByRole("heading", { name: "Asset Case File" }),
    ).toBeTruthy();
    expect(
      await screen.findByRole("heading", { name: "BTC evidence-backed case" }),
    ).toBeTruthy();
    expect(screen.getByText("Provenance ledger")).toBeTruthy();
    expect(screen.getByText("Unknowns & contradictions")).toBeTruthy();

    await user.click(screen.getByRole("button", { name: "Evidence Graph" }));
    expect(
      screen.getByRole("heading", { name: "Evidence Graph" }),
    ).toBeTruthy();
    expect(screen.getByText(/Provider observations/)).toBeTruthy();

    await user.click(
      screen.getByRole("button", { name: "Challenge selected claim" }),
    );
    expect(screen.getByRole("heading", { name: "Challenger" })).toBeTruthy();
    expect(screen.getByText(/no scoring tools/i)).toBeTruthy();

    await user.click(
      screen.getByRole("button", { name: "Run read-only challenge" }),
    );
    await waitFor(
      () =>
        expect(screen.getByText("Deterministic score unchanged")).toBeTruthy(),
      { timeout: 3_000 },
    );
  });

});
