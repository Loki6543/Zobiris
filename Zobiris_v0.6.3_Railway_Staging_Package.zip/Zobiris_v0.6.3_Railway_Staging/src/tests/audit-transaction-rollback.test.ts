/**
 * P0 #3 regression tests — persistRefresh must be atomic.
 *
 * Per the v0.4.1 audit: "Wrap the durable refresh mutation in one real DB
 * transaction. Add failure-injection integration tests:
 *   - throw after observations -> nothing from refresh committed
 *   - throw after snapshot but before outbox -> snapshot rolled back
 *   - successful transaction -> snapshot + outbox both visible
 *   - replay after crash -> internally consistent"
 */

import { describe, it, expect, beforeEach, afterEach } from "vitest";
import { openStorage } from "../storage/client.js";
import { persistRefresh, type PersistedRefreshInput } from "../storage/integration.js";
import { refreshSessions, snapshots, outboxEvents, observations, evidenceClaims } from "../storage/schema.js";
import { type PortfolioAnalysisSnapshot } from "../domain/index.js";

const POLICY = "0.4.1";

function makeSnapshot(): PortfolioAnalysisSnapshot {
  return {
    asOf: new Date().toISOString(),
    policyVersion: POLICY,
    regime: "test_regime",
    regimeConfidence: 0.5,
    totalAllocatedPct: 0,
    reservePct: 10,
    unallocatedPct: 100,
    rankedAssets: [],
    sectorConcentration: {},
    narrativeConcentration: {},
    topRiskGates: [],
    changesSinceLastRefresh: { rankUps: [], rankDowns: [], newTopTen: [], droppedTopTen: [], largestTargetWeightChanges: [] },
    stages: [],
    conclusion: "audit test",
  };
}

function makeInput(overrides: Partial<PersistedRefreshInput> = {}): PersistedRefreshInput {
  return {
    db: undefined as any,
    watchlist: [{ symbol: "BTC", name: "Bitcoin" }],
    observations: [],
    evidenceClaims: [],
    snapshot: makeSnapshot(),
    canonicalMap: new Map(),
    ...overrides,
  };
}

describe("P0 #3: persistRefresh is atomic", () => {
  let storage: ReturnType<typeof openStorage>;
  beforeEach(() => {
    storage = openStorage({ path: ":memory:" });
  });
  afterEach(() => {
    storage.close();
  });

  it("throws on failure but does not commit any refresh state", () => {
    const input = makeInput({ db: storage.db, options: { failAfter: "outbox" } });
    expect(() => persistRefresh(input)).toThrow();
    // After failure, no session / no snapshot / no outbox rows.
    expect(storage.db.select().from(refreshSessions).all().length).toBe(0);
    expect(storage.db.select().from(snapshots).all().length).toBe(0);
    expect(storage.db.select().from(outboxEvents).all().length).toBe(0);
  });

  it("successful transaction commits session + snapshot + outbox atomically", () => {
    const input = makeInput({ db: storage.db });
    const r = persistRefresh(input);
    expect(r.snapshotId).toBeDefined();
    expect(r.outboxIds.length).toBe(1);
    expect(storage.db.select().from(refreshSessions).all().length).toBe(1);
    expect(storage.db.select().from(snapshots).all().length).toBe(1);
    expect(storage.db.select().from(outboxEvents).all().length).toBe(1);
  });

  it("rollback when failAfter === 'snapshot' leaves no snapshot row", () => {
    const input = makeInput({ db: storage.db, options: { failAfter: "snapshot" } });
    expect(() => persistRefresh(input)).toThrow();
    // Session was opened BEFORE the snapshot insert, so it must be rolled back too.
    expect(storage.db.select().from(refreshSessions).all().length).toBe(0);
    expect(storage.db.select().from(snapshots).all().length).toBe(0);
  });

  it("rollback when failAfter === 'evidence' leaves no observation/evidence rows", () => {
    const input = makeInput({
      db: storage.db,
      evidenceClaims: [
        {
          id: "c1",
          observationId: "obs-missing", // orphan claim
          symbol: "BTC",
          factorFamily: "marketTechnical",
          claim: "test claim",
          // v0.4.4 audit fix: typed provenance on every claim.
          claimOrigin: "provider" as const,
          freshness: "live" as const,
          dataMode: "live" as const,
          transformationVersion: "0.0.0",
          parentClaimIds: [],
          source: "kraken",
          observedAt: new Date().toISOString(),
          receivedAt: new Date().toISOString(),
          freshnessAgeSeconds: 0,
          epistemicState: "KNOWN",
          evidenceConfidence: 0.9,
          licenseClass: "display-only",
          providerIds: ["kraken"],
        },
      ],
      options: { failAfter: "evidence" },
    });
    expect(() => persistRefresh(input)).toThrow();
    expect(storage.db.select().from(observations).all().length).toBe(0);
    expect(storage.db.select().from(evidenceClaims).all().length).toBe(0);
  });

  it("atomic: snapshot + outbox are visible together or not at all", () => {
    // Success: both visible
    const ok = persistRefresh(makeInput({ db: storage.db }));
    expect(ok.snapshotId).toBeDefined();
    expect(ok.outboxIds.length).toBe(1);

    // Failure between snapshot and outbox: BOTH must be absent.
    const fail = makeInput({ db: storage.db, options: { failAfter: "outbox" } });
    expect(() => persistRefresh(fail)).toThrow();
    // After the failed attempt, the only rows should be from the first successful run.
    const sessions = storage.db.select().from(refreshSessions).all();
    expect(sessions.length).toBe(1); // only the first (successful) session
    const snapshotsRows = storage.db.select().from(snapshots).all();
    expect(snapshotsRows.length).toBe(1); // only the first snapshot
    const outboxRows = storage.db.select().from(outboxEvents).all();
    expect(outboxRows.length).toBe(1); // only the first outbox event
  });

  it("replay after crash leaves the database in a consistent state", () => {
    // Crash mid-flight.
    expect(() => persistRefresh(makeInput({ db: storage.db, options: { failAfter: "observations" } }))).toThrow();
    // A subsequent successful run after the "crash" must produce a fully committed set.
    const r2 = persistRefresh(makeInput({ db: storage.db }));
    expect(r2.snapshotId).toBeDefined();
    // The replay's snapshot should have an outbox event paired with it.
    const outbox = storage.db.select().from(outboxEvents).all();
    expect(outbox.length).toBe(1);
    const outboxRow = outbox[0]!;
    expect(outboxRow.aggregateId).toBe(r2.snapshotId);
  });
});
