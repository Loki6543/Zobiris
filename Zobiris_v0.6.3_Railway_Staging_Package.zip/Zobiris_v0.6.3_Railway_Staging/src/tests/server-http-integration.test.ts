import { afterAll, beforeAll, describe, expect, it, vi } from "vitest";
import { mkdtempSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import type { AddressInfo } from "node:net";
import type { Server } from "node:http";

type JsonRecord = Record<string, any>;

describe("v0.4.13 watchlist-only HTTP boundary", () => {
  let server: Server;
  let baseUrl: string;
  let workDir: string;
  const originalEnv = {
    NODE_ENV: process.env.NODE_ENV,
    ZOBIRIS_REFRESH_TOKEN: process.env.ZOBIRIS_REFRESH_TOKEN,
    ZOBIRIS_DB_PATH: process.env.ZOBIRIS_DB_PATH,
    ZOBIRIS_ALLOW_ANONYMOUS_REFRESH:
      process.env.ZOBIRIS_ALLOW_ANONYMOUS_REFRESH,
    ZOBIRIS_ALLOW_LIVE_PROVIDERS: process.env.ZOBIRIS_ALLOW_LIVE_PROVIDERS,
    OPENAI_API_KEY: process.env.OPENAI_API_KEY,
  };

  beforeAll(async () => {
    workDir = mkdtempSync(join(tmpdir(), "zobiris-http-"));
    process.env.NODE_ENV = "development";
    process.env.ZOBIRIS_REFRESH_TOKEN = "http-integration-only";
    process.env.ZOBIRIS_DB_PATH = join(workDir, "integration.db");
    process.env.ZOBIRIS_ALLOW_ANONYMOUS_REFRESH = "1";
    process.env.ZOBIRIS_ALLOW_LIVE_PROVIDERS = "0";
    process.env.OPENAI_API_KEY = "";
    vi.resetModules();
    const { createZobirisServer } = await import("../server/server.js");
    server = createZobirisServer();
    await new Promise<void>((resolve, reject) => {
      server.once("error", reject);
      server.listen(0, "127.0.0.1", resolve);
    });
    const address = server.address() as AddressInfo;
    baseUrl = `http://127.0.0.1:${address.port}`;
  });

  afterAll(async () => {
    server.closeAllConnections();
    await new Promise<void>((resolve) => server.close(() => resolve()));
    rmSync(workDir, { recursive: true, force: true });
    for (const [key, value] of Object.entries(originalEnv)) {
      if (value === undefined) delete process.env[key];
      else process.env[key] = value;
    }
  });

  it("serves the built operator console and health endpoint", async () => {
    const health = await fetch(`${baseUrl}/api/health`);
    expect(health.status).toBe(200);
    expect(await health.json()).toMatchObject({ status: "ok" });

    const index = await fetch(`${baseUrl}/`);
    expect(index.status).toBe(200);
    expect(await index.text()).toContain("Zobiris Intelligence Engine");
  });

  it("refreshes, atomically persists, and rehydrates an evidence-rich case file", async () => {
    const firstResponse = await fetch(`${baseUrl}/api/refresh`, {
      method: "POST",
    });
    expect(firstResponse.status).toBe(200);
    const first = (await firstResponse.json()) as JsonRecord;
    expect(first).toMatchObject({
      observationCount: 18,
      evidenceClaimCount: 18,
      live: false,
    });
    expect(first.outboxIds).toHaveLength(1);

    const latestResponse = await fetch(`${baseUrl}/api/snapshot/latest`);
    expect(latestResponse.status).toBe(200);
    const latest = (await latestResponse.json()) as JsonRecord;
    expect(latest.snapshot.id).toBe(first.snapshotId);
    expect(latest.snapshot.sessionId).toBe(first.sessionId);
    expect(latest.session.id).toBe(first.sessionId);
    const stages = JSON.parse(latest.session.stages) as Array<{
      index: number;
      status: string;
    }>;
    expect(stages.find((stage) => stage.index === 18)?.status).toBe(
      "succeeded",
    );

    const secondResponse = await fetch(`${baseUrl}/api/refresh`, {
      method: "POST",
    });
    expect(secondResponse.status).toBe(200);

    const assetResponse = await fetch(`${baseUrl}/api/asset/BTC`);
    expect(assetResponse.status).toBe(200);
    const asset = (await assetResponse.json()) as JsonRecord;
    expect(asset.caseFile.symbol).toBe("BTC");
    expect(asset.caseFile.recentHistory).toHaveLength(1);
    expect(asset.caseFile.changeSincePrevious).not.toBeNull();
    expect(asset.caseFile.evidence.length).toBeGreaterThan(0);
    expect(
      asset.caseFile.evidence.every(
        (item: JsonRecord) => typeof item.dataMode === "string",
      ),
    ).toBe(true);
    expect(
      asset.caseFile.evidence.every(
        (item: JsonRecord) => typeof item.eligibility === "string",
      ),
    ).toBe(true);
    expect(
      asset.evidence.every(
        (claim: JsonRecord) => typeof claim.payloadHash === "string",
      ),
    ).toBe(true);
  }, 20_000);

  it("fails truthfully when the optional OpenAI Challenger is not configured", async () => {
    const response = await fetch(`${baseUrl}/api/agents/challenge`, {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: "Bearer http-integration-only" },
      body: JSON.stringify({}),
    });
    expect(response.status).toBe(503);
    expect(await response.json()).toEqual({
      error: "OpenAI challenger is not configured",
    });
  });

  it("blocks anonymous Challenger requests before evaluating configuration", async () => {
    for (const authorization of [undefined, "Bearer incorrect"]) {
      const response = await fetch(`${baseUrl}/api/agents/challenge`, {
        method: "POST",
        headers: authorization ? { Authorization: authorization } : {},
      });
      expect(response.status).toBe(401);
    }
  });

  it("exposes only the canonical watchlist as the asset universe", async () => {
    const watchlistResponse = await fetch(`${baseUrl}/api/watchlist`);
    expect(watchlistResponse.status).toBe(200);
    const watchlist = (await watchlistResponse.json()) as JsonRecord;
    expect(watchlist.source).toBe(
      "https://coinmarketcap.com/watchlist/69c01b46aed37c7160053535/",
    );
    expect(watchlist.watchlist.length).toBeGreaterThan(0);
    expect(watchlist.watchlist[0]).toMatchObject({
      rank: 1,
      symbol: "BTC",
      name: "Bitcoin",
    });

    const outsideUniverse = await fetch(`${baseUrl}/api/asset/NOTINLIST`);
    expect(outsideUniverse.status).toBe(404);
    expect(await outsideUniverse.json()).toEqual({
      error: "NOTINLIST is not in the active watchlist",
    });
  });

  it("returns a typed 404 for unknown API routes", async () => {
    const response = await fetch(`${baseUrl}/api/not-a-route`);
    expect(response.status).toBe(404);
    expect(await response.json()).toMatchObject({
      error: "no route for GET /api/not-a-route",
    });
  });
});
