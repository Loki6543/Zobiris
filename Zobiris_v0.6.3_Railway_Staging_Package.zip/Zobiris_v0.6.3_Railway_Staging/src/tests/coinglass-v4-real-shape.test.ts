/**
 * v0.4.4 audit fix (P0-3): CoinGlass v4 contract.
 *
 * The audit caught that the v0.4.3 code:
 *   - Used `createTime`, `fundingRate`, `exchangeName` (old v2 fields)
 *     instead of the v4 OHLC fields `time, open, high, low, close`.
 *   - Did not include the per-row `symbol` because the v4 funding
 *     endpoint does not return it; the symbol is part of the query
 *     string (e.g. symbol=BTCUSDT).
 *   - Multiplied the timestamp by 1000 even when the API already
 *     returned milliseconds.
 *   - Did not identify the FetchResult's endpoint (funding vs
 *     liquidations).
 *
 * v0.4.4 fixes all of these. These tests pin the behavior.
 */
import { describe, it, expect } from "vitest";
import { CoinGlassAdapter } from "../providers/coinglass.js";
import { type CanonicalAsset } from "../domain/index.js";

function makeAsset(symbol: string): CanonicalAsset {
  return {
    id: `cn-${symbol.toLowerCase()}-test`,
    symbol,
    name: symbol,
    // The asset must have its symbol so the symbol-only fallback
    // in the typed resolver can attach observations. The
    // canonical asset id is the first argument (cn-...).
    providerIds: {},
    mappingStatus: "verified",
    mappingConfidence: 0.9,
    updatedAt: new Date().toISOString(),
  };
}

function mapWith(...symbols: string[]): Map<string, CanonicalAsset> {
  // Map keyed by symbol so the runtime can look up by ticker.
  return new Map(symbols.map((s) => [s, makeAsset(s)] as [string, CanonicalAsset]));
}

describe("v0.4.4 P0-3: CoinGlass v4 funding-rate/history OHLC", () => {
  it("parses v4 OHLC shape (time, open, high, low, close) and uses close as the rate", () => {
    const adapter = new CoinGlassAdapter();
    const obs = adapter.normalize(
      {
        code: "0",
        data: [
          {
            time: 1700000000000,  // ms (v4)
            open: 0.0001,
            high: 0.0002,
            low: 0.00009,
            close: 0.00015,  // <-- this is the funding rate bar close
            exchangeName: "Binance",
          },
        ],
      },
      {
        canonicalAssets: mapWith("BTC"),
        endpoint: "funding",
        receivedAt: new Date().toISOString(),
        rawSchemaVersion: "4.0.0",
        // v0.4.4: query symbol is BTCUSDT; the normalizer strips
        // USDT to get the underlying ticker.
        requestedSymbol: "BTCUSDT",
      } as any,
    );
    expect(obs).toHaveLength(1);
    // canonicalAssetId is the asset's id (cn-btc-test), NOT the
    // ticker. The ticker is in the payload.
    expect(obs[0]?.canonicalAssetId).toBe("cn-btc-test");
    const p = obs[0]!.payload as Record<string, any>;
    expect(p.rate).toBe(0.00015);  // close → rate
    expect(p.exchange).toBe("Binance");
  });

  it("does NOT multiply the timestamp by 1000 when the API returns ms", () => {
    const adapter = new CoinGlassAdapter();
    const msTimestamp = 1700000000000;
    const obs = adapter.normalize(
      {
        code: "0",
        data: [{ time: msTimestamp, close: 0.001, exchangeName: "Binance" }],
      },
      {
        canonicalAssets: mapWith("BTC"),
        endpoint: "funding",
        receivedAt: new Date().toISOString(),
        rawSchemaVersion: "4.0.0",
        requestedSymbol: "BTCUSDT",
      } as any,
    );
    expect(obs).toHaveLength(1);
    // sourceTimestamp must reflect the API timestamp, NOT
    // msTimestamp * 1000. If we multiplied we'd be in the year
    // 56000+; the correct date is November 2023.
    const ts = obs[0]?.sourceTimestamp;
    expect(ts).toBeDefined();
    const date = new Date(ts!);
    expect(date.getUTCFullYear()).toBe(2023);
  });

  it("the FetchResult preserves the endpoint tag (funding vs liquidations)", async () => {
    const adapter = new CoinGlassAdapter();
    adapter.configure({
      baseUrl: "https://open-api.coinglass.com",
      forceFixtures: false,
      liveConfig: { apiKey: "test-key" },
    });
    (globalThis as any).fetch = (async () => ({
      ok: true, status: 200, json: async () => ({
        code: "0", data: [{ time: 1700000000000, close: 0.001, exchangeName: "Binance" }],
      }),
    })) as any;
    // A single fetch() returns BOTH the funding and liquidations
    // results. The audit fix wires `endpoint` so the runtime can
    // route the right normalizer.
    const results = await adapter.fetch({ canonicalAssets: mapWith("BTC") });
    expect(results).toHaveLength(2);
    const endpoints = results.map(r => r.endpoint).sort();
    expect(endpoints).toEqual(["funding", "liquidations"]);
  });

  it("funding URL uses BTCUSDT (per-pair), not just BTC", async () => {
    const adapter = new CoinGlassAdapter();
    adapter.configure({
      baseUrl: "https://open-api.coinglass.com",
      forceFixtures: false,
      liveConfig: { apiKey: "test-key" },
    });
    let capturedUrl = "";
    (globalThis as any).fetch = (async (url: string) => {
      capturedUrl = url;
      return {
        ok: true, status: 200, json: async () => ({ code: "0", data: [] }),
      };
    }) as any;
    await adapter.fetch({ canonicalAssets: mapWith("BTC") });
    expect(capturedUrl).toContain("symbol=BTCUSDT");
  });
});

describe("v0.4.4 P0-3: CoinGlass v4 liquidations aggregated-history", () => {
  it("parses v4 aggregated_long_liquidation_usd and aggregated_short_liquidation_usd", () => {
    const adapter = new CoinGlassAdapter();
    const obs = adapter.normalize(
      {
        code: "0",
        data: [
          {
            time: 1700000000000,
            aggregated_long_liquidation_usd: 5_000_000,
            aggregated_short_liquidation_usd: 3_000_000,
            exchangeName: "Binance",
          },
        ],
      },
      {
        canonicalAssets: mapWith("BTC"),
        endpoint: "liquidations",
        receivedAt: new Date().toISOString(),
        rawSchemaVersion: "4.0.0",
        requestedSymbol: "BTCUSDT",
      } as any,
    );
    expect(obs).toHaveLength(1);
    const p = obs[0]!.payload as Record<string, any>;
    // volumeUsd = long + short = 8M
    expect(p.volumeUsd).toBe(8_000_000);
    // side is "long" because longs > shorts
    expect(p.side).toBe("long");
  });
});
