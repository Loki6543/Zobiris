/**
 * v0.4.6 regression: public/app.js must register BTC and SOL deep-dive
 * routes, and the AssetCaseView must be wrapped in a try/catch that
 * shows a diagnose panel on render failure (instead of leaving the
 * user staring at a "Loading..." spinner).
 */

import { describe, it, expect } from "vitest";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";

const APP_JS = readFileSync(resolve(process.cwd(), "public/app.js"), "utf8");
const INDEX_HTML = readFileSync(resolve(process.cwd(), "public/index.html"), "utf8");

describe("v0.4.6 SPA: case file bug fix + BTC/SOL deep-dive routes", () => {
  it("AssetCaseView is wrapped in try/catch with diagnose output", () => {
    // The try/catch must wrap the actual render of the case file.
    expect(APP_JS).toMatch(/AssetCaseView[\s\S]{0,400}try\s*\{/);
    expect(APP_JS).toMatch(/Render failed/);
    // The catch should print a meaningful diagnostic.
    expect(APP_JS).toMatch(/assetAnalysis keys/);
  });

  it("BTC and SOL deep-dive views are defined", () => {
    expect(APP_JS).toMatch(/BtcDeepDive\s*=/);
    expect(APP_JS).toMatch(/SolDeepDive\s*=/);
    // The factory must include the maximum-analysis content
    expect(APP_JS).toMatch(/Score Anatomy/);
    expect(APP_JS).toMatch(/Per-Factor Contribution/);
    expect(APP_JS).toMatch(/Confidence Breakdown/);
    expect(APP_JS).toMatch(/Specialist Opinions/);
    expect(APP_JS).toMatch(/Evidence Ledger/);
    expect(APP_JS).toMatch(/Provider Coverage/);
    expect(APP_JS).toMatch(/Scenarios/);
    expect(APP_JS).toMatch(/Invalidation Conditions|Invalidation/i);
    expect(APP_JS).toMatch(/Cross-checks/);
  });

  it("routes table includes btc and sol", () => {
    expect(APP_JS).toMatch(/"btc":\s*\{/);
    expect(APP_JS).toMatch(/"sol":\s*\{/);
  });

  it("nav menu links to #/btc and #/sol", () => {
    expect(INDEX_HTML).toMatch(/href="#\/btc"[^>]*data-route="btc"/);
    expect(INDEX_HTML).toMatch(/href="#\/sol"[^>]*data-route="sol"/);
  });

  it("v0.4.7: null scenarios don't crash the deep-dive render", () => {
    // The engine can return { scenarios: { bull: null, base: null, bear: null } }
    // in fixture mode when there's no live evidence to support a scenario.
    // The SPA must handle this without throwing on null.probability.
    // Look for the explicit guard before the .probability access.
    expect(APP_JS).toMatch(/if\s*\(\s*!sc\s*\)/);
    // And the explicit insufficient-live-evidence text the user sees
    expect(APP_JS).toMatch(/insufficient live evidence/);
  });
});
