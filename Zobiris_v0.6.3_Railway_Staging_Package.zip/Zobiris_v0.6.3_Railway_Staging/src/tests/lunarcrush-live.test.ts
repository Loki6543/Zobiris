/**
 * LunarCrush live-mode tests.
 *
 * Mirrors the Kraken live-mode pattern: AbortController + 10s timeout,
 * network error → fall through to fixture, HTTP 401 → AdapterNormalizationError.
 *
 * All network calls are mocked via `vi.stubGlobal('fetch', mockFn)` — the
 * real LunarCrush API is never contacted.
 */

import { describe, it, expect, beforeEach, afterEach, vi } from "vitest";
import { LunarCrushAdapter } from "../providers/lunarcrush.js";
import { AdapterContractError, AdapterNormalizationError } from "../providers/types.js";
import type { CanonicalAsset } from "../domain/canonicalAsset.js";
import { resolve } from "node:path";
import { readFile } from "node:fs/promises";

const FIXTURE_DIR = resolve(process.cwd(), "src/providers/fixtures");
const FIXTURE_PATH = `${FIXTURE_DIR}/lunarcrush-coin.valid.json`;

/** Build a minimal CanonicalAsset for symbol lookups in normalize(). */
function mkCanonical(symbol: string): CanonicalAsset {
  return {
    id: `id-${symbol}`,
    symbol,
    name: symbol,
    providerIds: { lunarcrush: symbol },
    mappingStatus: "verified",
    mappingConfidence: 0.9,
    updatedAt: new Date().toISOString(),
  };
}

/** Live-shape response payload (uses `price_change_24h`, not the fixture's `percent_change_24h`). */
function livePayload() {
  return {
    data: [
      {
        id: 1,
        name: "Bitcoin",
        symbol: "BTC",
        galaxy_score: 78.2,
        alt_rank: 1,
        social_volume: 245000,
        sentiment: 72.3,
        social_dominance: 28.4,
        price: 78408.5,
        price_change_24h: 7.41,
        market_cap: 1_540_000_000_000,
        time: 1700000000,
      },
      {
        id: 1027,
        name: "Ethereum",
        symbol: "ETH",
        galaxy_score: 75.8,
        alt_rank: 3,
        social_volume: 178000,
        sentiment: 68.7,
        social_dominance: 16.8,
        price: 2950.1,
        price_change_24h: 5.2,
        market_cap: 355_000_000_000,
        time: 1700000000,
      },
      {
        id: 5426,
        name: "Solana",
        symbol: "SOL",
        galaxy_score: 84.1,
        alt_rank: 2,
        social_volume: 312000,
        sentiment: 81.0,
        social_dominance: 8.4,
        price: 94.28,
        price_change_24h: 7.58,
        market_cap: 44_000_000_000,
        time: 1700000000,
      },
    ],
  };
}

let fetchMock: ReturnType<typeof vi.fn>;

beforeEach(() => {
  fetchMock = vi.fn();
  vi.stubGlobal("fetch", fetchMock);
});

afterEach(() => {
  vi.unstubAllGlobals();
  vi.useRealTimers();
});

describe("LunarCrushAdapter live mode (v0.4.2 contract fix)", () => {
  it("uses the v4 base URL and Authorization: Bearer auth (not ?key= query string)", async () => {
    const payload = livePayload();
    fetchMock.mockResolvedValueOnce(
      new Response(JSON.stringify(payload), { status: 200, headers: { "content-type": "application/json" } }),
    );
    const adapter = new LunarCrushAdapter();
    adapter.configure({
      baseUrl: "https://lunarcrush.com/api4",
      liveConfig: { apiKey: "test-key-abc" },
    });

    const results = await adapter.fetch({ canonicalAssets: new Map() });
    expect(results).toHaveLength(1);
    const first = results[0]!;
    expect(first.data).toEqual(payload);
    expect(first.networkError).toBeUndefined();
    expect(adapter.lastNetworkError).toBeUndefined();

    // v0.4.3 audit fix (P0-3): LunarCrush v4 documented endpoint is
    //   GET /public/coins/list/v1
    // The key is sent as `Authorization: Bearer <key>`, never in the URL.
    expect(fetchMock).toHaveBeenCalledTimes(1);
    const [calledUrl, calledInit] = fetchMock.mock.calls[0]! as [string, RequestInit];
    expect(calledUrl).toContain("https://lunarcrush.com/api4/public/coins/list/v1");
    expect(calledUrl).not.toContain("key=test-key-abc");
    expect(calledUrl).not.toMatch(/[?&]key=/);
    expect(calledUrl).not.toMatch(/[?&]symbol=/);
    expect(calledInit.method).toBe("GET");
    expect(calledInit.signal).toBeDefined();
    const headers = calledInit.headers as Record<string, string>;
    expect(headers["Authorization"]).toBe("Bearer test-key-abc");
    expect(adapter.capabilities.supported).toBe("live");
  });

  it("normalizes the live response (with price_change_24h) into a verified social_snapshot per symbol", async () => {
    fetchMock.mockResolvedValueOnce(
      new Response(JSON.stringify(livePayload()), { status: 200, headers: { "content-type": "application/json" } }),
    );
    const adapter = new LunarCrushAdapter();
    adapter.configure({
      baseUrl: "https://api.lunarcrush.com",
      liveConfig: { apiKey: "test-key-abc" },
    });

    const [result] = await adapter.fetch({ canonicalAssets: new Map() });
    const map = new Map<string, CanonicalAsset>([
      ["BTC", mkCanonical("BTC")], ["ETH", mkCanonical("ETH")], ["SOL", mkCanonical("SOL")],
    ]);
    const obs = adapter.normalize(result!.data, {
      canonicalAssets: map,
      endpoint: "v4/coins",
      receivedAt: "2026-08-22T01:00:00.000Z",
      rawSchemaVersion: "1.0.0",
    });
    expect(obs).toHaveLength(3);
    const sol = obs.find(o => (o.payload as { symbol: string }).symbol === "SOL");
    expect(sol).toBeDefined();
    const p = sol!.payload as Record<string, unknown>;
    expect(p.galaxyScore).toBe(84.1);
    expect(p.altRank).toBe(2);
    expect(p.priceUsd).toBe(94.28);
    // The live field `price_change_24h` should populate `change24hPct`.
    expect(p.change24hPct).toBe(7.58);
    expect(sol!.epistemicState).toBe("KNOWN");
  });

  it("throws AdapterNormalizationError on HTTP 401 (does NOT fall through to fixture)", async () => {
    fetchMock.mockResolvedValueOnce(new Response("Unauthorized", { status: 401 }));
    const adapter = new LunarCrushAdapter();
    adapter.configure({
      baseUrl: "https://api.lunarcrush.com",
      liveConfig: { apiKey: "bad-key" },
    });

    await expect(adapter.fetch({ canonicalAssets: new Map() })).rejects.toBeInstanceOf(AdapterNormalizationError);
    // fetch was attempted exactly once — no fixture fallback on 401.
    expect(fetchMock).toHaveBeenCalledTimes(1);
  });

  it("falls through to the fixture on network failure (fetch throws) and records lastNetworkError", async () => {
    fetchMock.mockRejectedValueOnce(new TypeError("network down"));
    const adapter = new LunarCrushAdapter();
    adapter.configure({
      baseUrl: "https://api.lunarcrush.com",
      fixturePath: FIXTURE_PATH,
      liveConfig: { apiKey: "test-key-abc" },
    });

    const results = await adapter.fetch({ canonicalAssets: new Map() });
    expect(results).toHaveLength(1);
    const [result] = results;
    expect(result!.networkError).toBe("network down");
    // Fall-through surfaces as a networkError result, not as raw fixture data.
    expect(result!.data).toBeNull();
    expect(adapter.lastNetworkError).toBe("network down");
    expect(adapter.health().status).toBe("degraded");
    expect(adapter.health().lastErrorClass).toBe("network");
  });

  it("falls through to the fixture on non-401 HTTP errors (e.g. 500) and records lastNetworkError", async () => {
    fetchMock.mockResolvedValueOnce(new Response("boom", { status: 500 }));
    const adapter = new LunarCrushAdapter();
    adapter.configure({
      baseUrl: "https://api.lunarcrush.com",
      fixturePath: FIXTURE_PATH,
      liveConfig: { apiKey: "test-key-abc" },
    });

    const results = await adapter.fetch({ canonicalAssets: new Map() });
    expect(results).toHaveLength(1);
    const [result] = results;
    expect(result!.data).toBeNull();
    expect(result!.networkError).toContain("lunarcrush http 500");
    expect(adapter.lastNetworkError).toContain("lunarcrush http 500");
  });

  it("falls through to the fixture when AbortController fires (timeout)", async () => {
    // Mock fetch to throw an AbortError when its signal aborts.
    fetchMock.mockImplementationOnce((_url: string, init?: RequestInit) =>
      new Promise((_resolve, reject) => {
        init?.signal?.addEventListener("abort", () => {
          const e = new Error("aborted");
          e.name = "AbortError";
          reject(e);
        });
      }),
    );
    // Use fake timers so we can drive the 10s timeout deterministically.
    vi.useFakeTimers();
    const adapter = new LunarCrushAdapter();
    adapter.configure({
      baseUrl: "https://api.lunarcrush.com",
      fixturePath: FIXTURE_PATH,
      liveConfig: { apiKey: "test-key-abc", timeoutMs: 100 },
    });

    const fetchPromise = adapter.fetch({ canonicalAssets: new Map() });
    // Advance past the 100ms timeout so the AbortController fires.
    await vi.advanceTimersByTimeAsync(150);
    const results = await fetchPromise;
    expect(results).toHaveLength(1);
    const [result] = results;
    expect(result!.data).toBeNull();
    expect(result!.networkError).toBeDefined();
    expect(adapter.lastNetworkError).toBeDefined();
  });

  it("validateRaw accepts the live shape (price_change_24h) without throwing", () => {
    const adapter = new LunarCrushAdapter();
    // Throws AdapterContractError on schema mismatch.
    const parsed = adapter.validateRaw(livePayload(), { endpoint: "v4/coins" });
    expect(parsed).toBeDefined();
    const data = (parsed as { data?: unknown[] }).data;
    expect(Array.isArray(data)).toBe(true);
    expect((data as unknown[]).length).toBe(3);
  });

  it("validateRaw still accepts the legacy fixture shape (percent_change_24h)", async () => {
    const adapter = new LunarCrushAdapter();
    const raw = JSON.parse(await readFile(FIXTURE_PATH, "utf8"));
    // The fixture should still validate without throwing.
    expect(() => adapter.validateRaw(raw, { endpoint: "v4/coins" })).not.toThrow();
  });

  it("validateRaw rejects a payload missing required fields with AdapterContractError", () => {
    const adapter = new LunarCrushAdapter();
    // `name` and `symbol` are required — payload is missing them.
    const bad = { data: [{ galaxy_score: 1 }] };
    expect(() => adapter.validateRaw(bad, { endpoint: "v4/coins" })).toThrow(AdapterContractError);
  });

  it("setLiveMode(apiKey) flips capabilities.supported to 'live' without needing configure()", async () => {
    fetchMock.mockResolvedValueOnce(
      new Response(JSON.stringify(livePayload()), { status: 200, headers: { "content-type": "application/json" } }),
    );
    const adapter = new LunarCrushAdapter();
    expect(adapter.capabilities.supported).toBe("fixture-only");
    adapter.setLiveMode("test-key-abc");
    expect(adapter.capabilities.supported).toBe("live");
    // Should now actually use the live path.
    const results = await adapter.fetch({ canonicalAssets: new Map() });
    expect(results[0]!.data).toEqual(livePayload());
  });
});
