import { describe, expect, it } from "vitest";
import { mergeWatchlist, type WatchlistApi } from "../ui/api.js";
import type { AssetRow } from "../ui/data.js";

describe("watchlist-only UI universe", () => {
  it("keeps every watchlist member, excludes off-list snapshots, and marks pending assets", () => {
    const watchlist: WatchlistApi = {
      source: "https://coinmarketcap.com/watchlist/69c01b46aed37c7160053535/",
      watchlist: [
        { rank: 1, symbol: "BTC", name: "Bitcoin" },
        { rank: 2, symbol: "ETH", name: "Ethereum" },
        { rank: 3, symbol: "SOL", name: "Solana" },
      ],
    };
    const evaluated: AssetRow[] = [
      {
        rank: 99,
        symbol: "BTC",
        name: "BTC",
        score: 80,
        confidence: 70,
        risk: "Low",
        action: "HOLD",
        change: 0,
        trend: [],
        evidenceCount: 4,
        evaluated: true,
      },
      {
        rank: 1,
        symbol: "DOGE",
        name: "Dogecoin",
        score: 99,
        confidence: 99,
        risk: "Low",
        action: "BUY",
        change: 0,
        trend: [],
        evidenceCount: 99,
        evaluated: true,
      },
    ];

    const merged = mergeWatchlist(watchlist, evaluated);

    expect(merged.map((asset) => asset.symbol)).toEqual(["BTC", "ETH", "SOL"]);
    expect(merged[0]).toMatchObject({ name: "Bitcoin", rank: 1, evaluated: true });
    expect(merged[1]).toMatchObject({ risk: "Unknown", action: "Awaiting evaluation", evaluated: false });
    expect(merged[2]).toMatchObject({ evaluated: false });
  });
});
