/**
 * v0.4.3 audit regression test (required #14)
 * Test: stage-outcome-missing-is-integrity-error
 *
 * Per the v0.4.3 audit (P0-7B): "`composeStages()` silently creates
 * missing stages as `not_configured`. That makes an omitted
 * implementation look like an explicit runtime decision. Missing
 * stage outcome should be an integrity error, not silently
 * synthesized."
 *
 * v0.4.3 fix: composeStages() now throws StageSetIntegrityError when
 * any of the 19 stages is missing an explicit outcome.
 */

import { describe, it, expect } from "vitest";
import { composeStages, STAGE_NAMES, StageSetIntegrityError, verifyStageSet } from "../runtime/stages.js";

describe("v0.4.3 P0-7B: missing stage outcome is an integrity error", () => {
  it("composeStages throws StageSetIntegrityError when any of the 19 stages is missing", () => {
    const outcomes = STAGE_NAMES.map((name) => ({
      name,
      status: "succeeded" as const,
    })).filter(o => o.name !== "snapshot");  // Omit snapshot on purpose.
    expect(() => composeStages(outcomes)).toThrow(StageSetIntegrityError);
  });

  it("StageSetIntegrityError lists the missing stage names", () => {
    const outcomes = STAGE_NAMES.map((name) => ({
      name,
      status: "succeeded" as const,
    })).filter(o => o.name !== "snapshot" && o.name !== "telemetry");
    try {
      composeStages(outcomes);
      expect.fail("expected StageSetIntegrityError");
    } catch (e) {
      expect(e).toBeInstanceOf(StageSetIntegrityError);
      const err = e as StageSetIntegrityError;
      expect(err.missing).toContain("snapshot");
      expect(err.missing).toContain("telemetry");
    }
  });

  it("composeStages succeeds when all 19 stages are present", () => {
    const outcomes = STAGE_NAMES.map((name) => ({
      name,
      status: "succeeded" as const,
    }));
    const result = composeStages(outcomes);
    expect(result).toHaveLength(19);
    expect(result.map(r => r.name)).toEqual([...STAGE_NAMES]);
  });

  it("verifyStageSet rejects pending/running as terminal states", () => {
    const records = STAGE_NAMES.map((name, i) => ({
      index: i + 1,
      name,
      status: "pending" as const,
    }));
    const v = verifyStageSet(records);
    expect(v.ok).toBe(false);
    expect(v.wrongStatus.length).toBe(19);
  });
});
