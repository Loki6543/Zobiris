import { describe, expect, it } from "vitest";
import { applyRiskGates, evaluateRiskGates } from "../scoring/riskGates.js";

describe("hard risk-gate contracts", () => {
  it("veto always forces zero regardless of the proposed weight", () => {
    const gates = evaluateRiskGates({
      symbol: "COLLISION",
      mappingStatus: "ambiguous",
      hasMarketData: true,
    });
    expect(gates.some(gate => gate.effect === "veto")).toBe(true);
    expect(applyRiskGates(99, gates)).toBe(0);
  });

  it("suspicious volume creates a strict 1% cap", () => {
    const gates = evaluateRiskGates({
      symbol: "WASH",
      mappingStatus: "verified",
      hasMarketData: true,
      volumeToMcRatio: 5.01,
    });
    expect(gates).toContainEqual(expect.objectContaining({
      code: "SUSPICIOUS_VOLUME",
      effect: "size_cap",
      cap: 1,
    }));
    expect(applyRiskGates(25, gates)).toBe(1);
  });

  it("the strictest of multiple simultaneous caps wins", () => {
    const gates = evaluateRiskGates({
      symbol: "MULTI",
      mappingStatus: "verified",
      hasMarketData: false,
      holderConcentration: 0.9,
      volumeToMcRatio: 8,
    });
    expect(gates.filter(gate => gate.effect === "size_cap").length).toBeGreaterThan(1);
    expect(applyRiskGates(25, gates)).toBe(0.5);
  });

  it("confidence-reduction gates do not silently change size", () => {
    const gates = evaluateRiskGates({
      symbol: "STALE",
      mappingStatus: "verified",
      hasMarketData: true,
      criticalEvidenceStale: true,
    });
    expect(gates).toContainEqual(expect.objectContaining({
      code: "STALE_CRITICAL_EVIDENCE",
      effect: "confidence_reduction",
    }));
    expect(applyRiskGates(3.5, gates)).toBe(3.5);
  });
});
