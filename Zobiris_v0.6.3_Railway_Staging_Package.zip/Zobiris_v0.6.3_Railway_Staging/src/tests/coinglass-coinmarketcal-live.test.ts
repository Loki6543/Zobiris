/**
 * Live provider tests for CoinGlass + CoinMarketCal — slice 5+ v0.4.0.
 * Uses a mocked fetch to exercise the network code path without hitting the
 * real APIs (which require credentials).
 */

import { describe, it, expect, vi, afterEach } from "vitest";
import { CoinGlassAdapter } from "../providers/coinglass.js";
import { CoinMarketCalAdapter } from "../providers/coinmarketcal.js";
import { AdapterNormalizationError } from "../providers/types.js";
import { fileURLToPath } from "node:url";
import { dirname, join } from "node:path";

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
const FIXTURES = join(__dirname, "..", "..", "src", "providers", "fixtures");

afterEach(() => {
  vi.unstubAllGlobals();
});

describe("CoinGlassAdapter live path", () => {
  it("throws AdapterNormalizationError on 401", async () => {
    const adapter = new CoinGlassAdapter();
    adapter.configure({
      baseUrl: "https://open-api.coinglass.com",
      liveConfig: { apiKey: "invalid", timeoutMs: 1000 },
      forceFixtures: false,
    });
    vi.stubGlobal("fetch", vi.fn(async () => new Response("unauthorized", { status: 401 })));
    await expect(adapter.fetch({ canonicalAssets: new Map() })).rejects.toThrow(AdapterNormalizationError);
  });

  it("falls back to fixture when 5xx and lastNetworkError recorded", async () => {
    const adapter = new CoinGlassAdapter();
    adapter.configure({
      baseUrl: "https://open-api.coinglass.com",
      liveConfig: { apiKey: "valid-key", timeoutMs: 1000 },
      fundingFixturePath: join(FIXTURES, "coinglass-funding.valid.json"),
      liquidationsFixturePath: join(FIXTURES, "coinglass-liquidations.valid.json"),
      forceFixtures: false,
    });
    vi.stubGlobal("fetch", vi.fn(async () => new Response("server error", { status: 503 })));
    const results = await adapter.fetch({ canonicalAssets: new Map() });
    expect(adapter.lastNetworkError).toBeDefined();
    expect(results.length).toBeGreaterThan(0);
    // Should have fallen through to fixture
    const fundingResult = results.find(r => (r.raw as any)?.data?.some((e: any) => e.symbol !== undefined));
    expect(fundingResult).toBeDefined();
  });

  it("records network error on timeout (AbortController)", async () => {
    const adapter = new CoinGlassAdapter();
    adapter.configure({
      baseUrl: "https://open-api.coinglass.com",
      liveConfig: { apiKey: "valid-key", timeoutMs: 50 },
      forceFixtures: false,
    });
    vi.stubGlobal("fetch", vi.fn(async (_url: any, opts: any) => {
      // Simulate a slow response that aborts
      return new Promise((_resolve, reject) => {
        opts.signal.addEventListener("abort", () => reject(new Error("aborted")));
      });
    }));
    const results = await adapter.fetch({ canonicalAssets: new Map() });
    expect(adapter.lastNetworkError).toBeDefined();
    // No fixture configured, so we get an empty result with networkError
    const r0 = results[0];
    expect(r0?.networkError).toBeDefined();
  });

  it("returns live data on 200 response and parses correctly", async () => {
    const adapter = new CoinGlassAdapter();
    adapter.configure({
      baseUrl: "https://open-api.coinglass.com",
      liveConfig: { apiKey: "valid-key", timeoutMs: 1000 },
      forceFixtures: false,
    });
    const liveBody = {
      code: "0",
      msg: "success",
      data: [
        { symbol: "BTC", exchange: "Binance", rate: 0.0001, nextFundingTime: Math.floor(Date.now() / 1000) + 3600, time: Math.floor(Date.now() / 1000) },
      ],
    };
    let callCount = 0;
    vi.stubGlobal("fetch", vi.fn(async () => {
      callCount++;
      // First call: funding, second call: liquidations
      if (callCount === 1) return new Response(JSON.stringify(liveBody), { status: 200 });
      return new Response(JSON.stringify({ code: "0", data: [] }), { status: 200 });
    }));
    const results = await adapter.fetch({ canonicalAssets: new Map() });
    expect(adapter.lastNetworkError).toBeUndefined();
    expect(results.length).toBeGreaterThan(0);
  });

  it("health() returns connected when live key configured", () => {
    const adapter = new CoinGlassAdapter();
    adapter.configure({
      baseUrl: "https://open-api.coinglass.com",
      liveConfig: { apiKey: "valid-key" },
    });
    const h = adapter.health();
    expect(h.status).toBe("connected");
    expect(h.freshness).toBe("live");
  });

  it("health() returns degraded after network error", async () => {
    const adapter = new CoinGlassAdapter();
    adapter.configure({
      baseUrl: "https://open-api.coinglass.com",
      liveConfig: { apiKey: "valid-key", timeoutMs: 100 },
      forceFixtures: false,
    });
    vi.stubGlobal("fetch", vi.fn(async () => new Response("server error", { status: 503 })));
    await adapter.fetch({ canonicalAssets: new Map() });
    const h = adapter.health();
    expect(h.status).toBe("degraded");
    expect(h.freshness).toBe("delayed");
  });

  it("uses fixture-only when forceFixtures is true", async () => {
    const adapter = new CoinGlassAdapter();
    adapter.configure({
      baseUrl: "https://open-api.coinglass.com",
      liveConfig: { apiKey: "valid-key" },
      fundingFixturePath: join(FIXTURES, "coinglass-funding.valid.json"),
      forceFixtures: true,
    });
    const fetchSpy = vi.fn();
    vi.stubGlobal("fetch", fetchSpy);
    const results = await adapter.fetch({ canonicalAssets: new Map() });
    expect(fetchSpy).not.toHaveBeenCalled();
    expect(results.length).toBeGreaterThan(0);
  });
});

describe("CoinMarketCalAdapter live path", () => {
  it("throws AdapterNormalizationError on 401", async () => {
    const adapter = new CoinMarketCalAdapter();
    adapter.configure({
      baseUrl: "https://api.coinmarketcal.com",
      liveConfig: { apiKey: "invalid" },
      forceFixtures: false,
    });
    vi.stubGlobal("fetch", vi.fn(async () => new Response("unauthorized", { status: 401 })));
    await expect(adapter.fetch({ canonicalAssets: new Map() })).rejects.toThrow(AdapterNormalizationError);
  });

  it("falls back to fixture on 5xx with lastNetworkError recorded", async () => {
    const adapter = new CoinMarketCalAdapter();
    adapter.configure({
      baseUrl: "https://api.coinmarketcal.com",
      liveConfig: { apiKey: "valid-key", timeoutMs: 1000 },
      fixturePath: join(FIXTURES, "coinmarketcal.valid.json"),
      forceFixtures: false,
    });
    vi.stubGlobal("fetch", vi.fn(async () => new Response("server error", { status: 500 })));
    const results = await adapter.fetch({ canonicalAssets: new Map() });
    expect(adapter.lastNetworkError).toBeDefined();
    expect(results.length).toBe(1);
    // Should be fixture
    const raw = results[0]?.raw as { data?: Array<{ title?: string }> } | undefined;
    expect(raw?.data?.[0]?.title).toBeDefined();
  });

  it("returns live data on 200", async () => {
    const adapter = new CoinMarketCalAdapter();
    adapter.configure({
      baseUrl: "https://api.coinmarketcal.com",
      liveConfig: { apiKey: "valid-key", timeoutMs: 1000 },
      forceFixtures: false,
    });
    const liveBody = {
      data: [
        {
          id: 1,
          title: "ETH upgrade",
          coins: [{ symbol: "eth", name: "Ethereum" }],
          date_event: "2026-09-01T00:00:00Z",
          display_date: "Q3 2026",
          is_estimated: true,
          category: "upgrade",
        },
      ],
    };
    vi.stubGlobal("fetch", vi.fn(async () => new Response(JSON.stringify(liveBody), { status: 200 })));
    const results = await adapter.fetch({ canonicalAssets: new Map() });
    expect(results.length).toBe(1);
    expect(adapter.lastNetworkError).toBeUndefined();
  });

  it("health() returns connected when live key configured", () => {
    const adapter = new CoinMarketCalAdapter();
    adapter.configure({ baseUrl: "https://x", liveConfig: { apiKey: "valid-key" } });
    expect(adapter.health().status).toBe("connected");
    expect(adapter.freshness()).toBe("live");
  });

  it("health() returns degraded after network error", async () => {
    const adapter = new CoinMarketCalAdapter();
    adapter.configure({
      baseUrl: "https://x",
      liveConfig: { apiKey: "valid-key", timeoutMs: 100 },
      forceFixtures: false,
    });
    vi.stubGlobal("fetch", vi.fn(async () => new Response("server error", { status: 500 })));
    await adapter.fetch({ canonicalAssets: new Map() });
    expect(adapter.health().status).toBe("degraded");
  });

  it("forceFixtures bypasses network", async () => {
    const adapter = new CoinMarketCalAdapter();
    adapter.configure({
      baseUrl: "https://x",
      liveConfig: { apiKey: "valid-key" },
      fixturePath: join(FIXTURES, "coinmarketcal.valid.json"),
      forceFixtures: true,
    });
    const fetchSpy = vi.fn();
    vi.stubGlobal("fetch", fetchSpy);
    const results = await adapter.fetch({ canonicalAssets: new Map() });
    expect(fetchSpy).not.toHaveBeenCalled();
    expect(results.length).toBe(1);
  });
});

describe("v0.4.2 audit: live-mode auth headers match current public docs", () => {
  it("CoinGlass live path uses CG-API-KEY header (not coinglassSecret)", async () => {
    const adapter = new CoinGlassAdapter();
    let capturedUrl: string | undefined;
    let capturedHeaders: Record<string, string> = {};
    vi.stubGlobal(
      "fetch",
      vi.fn(async (url: any, init: any) => {
        capturedUrl = String(url);
        capturedHeaders = (init?.headers ?? {}) as Record<string, string>;
        return new Response("[]", { status: 200 });
      }),
    );
    adapter.configure({
      baseUrl: "https://open-api-v4.coinglass.com",
      liveConfig: { apiKey: "CGKEY-1", timeoutMs: 1000 },
      fundingFixturePath: join(FIXTURES, "coinglass-funding.valid.json"),
      liquidationsFixturePath: join(FIXTURES, "coinglass-liquidations.valid.json"),
      forceFixtures: false,
    });
    await adapter.fetch({ canonicalAssets: new Map() });
    expect(capturedUrl).toContain("open-api-v4.coinglass.com");
    expect(capturedHeaders["CG-API-KEY"]).toBe("CGKEY-1");
    expect(capturedHeaders["coinglassSecret"]).toBeUndefined();
  });

  it("CoinMarketCal live path uses x-api-key header on /v2/events (not ?key=)", async () => {
    const adapter = new CoinMarketCalAdapter();
    let capturedUrl: string | undefined;
    let capturedHeaders: Record<string, string> = {};
    vi.stubGlobal(
      "fetch",
      vi.fn(async (url: any, init: any) => {
        capturedUrl = String(url);
        capturedHeaders = (init?.headers ?? {}) as Record<string, string>;
        return new Response(JSON.stringify({ events: [] }), { status: 200 });
      }),
    );
    adapter.configure({
      baseUrl: "https://api.coinmarketcal.com",
      liveConfig: { apiKey: "cmc-key" },
    });
    await adapter.fetch({ canonicalAssets: new Map() });
    expect(capturedUrl).toContain("/v2/events");
    expect(capturedUrl).not.toMatch(/[?&]key=/);
    expect(capturedHeaders["x-api-key"]).toBe("cmc-key");
  });
});
