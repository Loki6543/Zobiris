/**
 * Secrets redaction tests.
 *
 * Per SECURITY_GOVERNANCE.md: never write credentials into logs, metrics,
 * event payloads, error responses, screenshots, or test fixtures. Redact
 * query strings/headers for providers that authenticate via URL.
 */
import { describe, it, expect } from "vitest";
import { redact, redactObject } from "../runtime/secrets.js";

describe("redact", () => {
  it("redacts api_key query params", () => {
    expect(redact("https://api.example.com?api_key=secret123&other=ok"))
      .toContain("REDACTED");
    expect(redact("https://api.example.com?api_key=secret123&other=ok"))
      .not.toContain("secret123");
  });

  it("redacts Authorization Bearer tokens", () => {
    expect(redact("Authorization: Bearer abc.def.ghi")).toContain("REDACTED");
    expect(redact("Authorization: Bearer abc.def.ghi")).not.toContain("abc.def.ghi");
  });

  it("redacts sk- keys", () => {
    const fakeKey = ["sk", "proj", "abc123def456ghi789jkl012mno345pqr678stu901vwx234"].join("-");
    expect(redact(fakeKey))
      .toContain("REDACTED");
  });

  it("redacts UUIDs", () => {
    expect(redact("session=11111111-2222-4333-8444-555555555555"))
      .toContain("REDACTED");
  });

  it("does not redact ordinary text", () => {
    expect(redact("BTC up 7.41% on Kraken snapshot")).toBe("BTC up 7.41% on Kraken snapshot");
  });

  it("is idempotent on already-redacted text", () => {
    const a = redact("api_key=secret123");
    const b = redact(a);
    expect(a).toBe(b);
  });
});

describe("redactObject", () => {
  it("recursively redacts strings inside an object", () => {
    const input = {
      url: "https://api.example.com?api_key=secret",
      nested: { token: "Bearer abc.def.ghi" },
      array: ["https://x.com?key=foo", "BTC normal"],
    };
    const out = redactObject(input);
    expect(JSON.stringify(out)).toContain("REDACTED");
    expect(JSON.stringify(out)).not.toContain("secret");
    expect(JSON.stringify(out)).not.toContain("abc.def.ghi");
    expect(JSON.stringify(out)).toContain("BTC normal");
  });

  it("preserves non-string values", () => {
    const input = { count: 42, flag: true, arr: [1, 2, 3] };
    expect(redactObject(input)).toEqual(input);
  });
});
