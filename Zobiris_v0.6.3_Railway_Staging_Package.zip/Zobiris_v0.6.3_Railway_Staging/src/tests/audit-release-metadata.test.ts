/**
 * P2 #13 regression test — package.json and lockfile versions must agree.
 *
 * Per the v0.4.1 audit: "package and lockfile versions disagree."
 */

import { describe, it, expect } from "vitest";
import { readFileSync, existsSync } from "node:fs";
import { resolve } from "node:path";

describe("P2 #13: package.json and lockfile versions match", () => {
  it("package.json version is non-empty semver", () => {
    const pkg = JSON.parse(readFileSync(resolve(process.cwd(), "package.json"), "utf8"));
    expect(pkg.version).toMatch(/^\d+\.\d+\.\d+/);
  });

  it("package-lock.json version matches package.json", () => {
    const pkg = JSON.parse(readFileSync(resolve(process.cwd(), "package.json"), "utf8"));
    const lockPath = resolve(process.cwd(), "package-lock.json");
    if (!existsSync(lockPath)) {
      // No lockfile; skip
      return;
    }
    const lock = JSON.parse(readFileSync(lockPath, "utf8"));
    expect(lock.version, "lockfile version must match package.json version").toBe(pkg.version);
  });
});
