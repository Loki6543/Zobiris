import { describe, expect, it } from "vitest";
import { randomUUID } from "node:crypto";
import { runRefresh } from "../runtime/refresh.js";
import { buildAdapters } from "../scripts/_adapters.js";
import { isObservationEligibleForAnalysis } from "../providers/eligibility.js";
import { challengerResultSchema } from "../agents/contracts.js";
import { evaluateChallengerOutput } from "../agents/eval.js";
import type { NormalizedObservation } from "../domain/index.js";

function observation(overrides: Partial<NormalizedObservation> = {}): NormalizedObservation {
  return {
    id: randomUUID(),
    idempotencyKey: `test:${randomUUID()}`,
    provider: "cmc",
    eventType: "quote",
    schemaVersion: "1.0.0",
    canonicalAssetId: randomUUID(),
    quarantineState: "verified",
    identityMatchMethod: "provider-id",
    occurredAt: new Date().toISOString(),
    receivedAt: new Date().toISOString(),
    normalizerVersion: "0.4.8",
    payload: { symbol: "BTC" },
    epistemicState: "KNOWN",
    evidenceConfidence: 0.9,
    licenseClass: "display-only",
    ...overrides,
  };
}

describe("v0.4.8 trust contracts", () => {
  it("keeps fallback evidence display-only even with a verified identity", () => {
    expect(isObservationEligibleForAnalysis(observation({ dataMode: "fallback" })))
      .toBe("display_only_ambiguous");
  });

  it("stamps provider provenance and links factor scores to exact claims before scoring", async () => {
    const result = await runRefresh({
      mode: "deep",
      watchlist: [
        { symbol: "BTC", name: "Bitcoin" },
        { symbol: "SOL", name: "Solana" },
      ],
      adapters: buildAdapters({ live: false, staleSeconds: 0 }),
    });
    expect(result.observations.length).toBeGreaterThan(0);
    for (const item of result.observations) {
      expect(item.dataMode).toBe("snapshot");
      expect(item.providerEndpoint).toBeTruthy();
      expect(item.payloadHash).toMatch(/^[a-f0-9]{64}$/);
    }
    const btc = result.snapshot.rankedAssets.find((asset) => asset.symbol === "BTC");
    expect(btc?.evidenceClaimIds.length).toBeGreaterThan(0);
    const tracedFactorIds = btc?.opportunity.factorScores.flatMap((factor) => factor.evidenceClaimIds) ?? [];
    expect(tracedFactorIds.length).toBeGreaterThan(0);
    expect(tracedFactorIds.every((id) => btc?.evidenceClaimIds.includes(id))).toBe(true);
  });

  it("rejects an agent output that attempts to add scoring authority", () => {
    const output = {
      claimId: randomUUID(),
      reasoning: "The evidence is too stale to establish the claim with high confidence.",
      confidence: 0.4,
      requestedEvidence: ["A fresh independent market quote"],
      contradictions: [],
      scoreDelta: 12,
    };
    expect(challengerResultSchema.safeParse(output).success).toBe(false);
  });

  it("runs the deterministic challenger contract eval", () => {
    const targetClaimId = randomUUID();
    const contradictionId = randomUUID();
    const result = evaluateChallengerOutput({
      name: "cites contradiction",
      targetClaimId,
      expectedContradictionIds: [contradictionId],
      output: {
        claimId: targetClaimId,
        reasoning: "An independent claim reports a directly conflicting provider observation.",
        confidence: 0.77,
        requestedEvidence: [],
        contradictions: [{ claimId: contradictionId, reason: "Opposite direction", severity: "high" }],
      },
    });
    expect(result.passed).toBe(true);
  });
});
