/**
 * Scoring engine tests.
 *
 * Verifies: factor weights sum to 1, raw score monotonically non-decreasing
 * in raw factor inputs, adjusted score decreases with evidence gap,
 * confidence is monotonically non-decreasing in coverage.
 */
import { describe, it, expect } from "vitest";
import { computeRawScore } from "../scoring/score.js";
import { computeConfidence } from "../scoring/confidence.js";
import { DEFAULT_SCORING_CONFIG } from "../domain/scoring.js";

describe("computeRawScore", () => {
  it("default factor weights sum to 1", () => {
    const w = Object.values(DEFAULT_SCORING_CONFIG.factorWeights);
    const sum = w.reduce((s, v) => s + v, 0);
    expect(Math.abs(sum - 1)).toBeLessThan(0.001);
  });

  it("all-zeros factors → raw=0, adjusted=0, no penalty if coverage=1", () => {
    const r = computeRawScore({
      factors: Object.keys(DEFAULT_SCORING_CONFIG.factorWeights).map(family => ({
        family: family as keyof typeof DEFAULT_SCORING_CONFIG.factorWeights,
        raw: 0,
        epistemicState: "KNOWN",
      })),
      evidenceCoverage: 1.0,
    });
    expect(r.raw).toBe(0);
    expect(r.adjusted).toBe(0);
    expect(r.evidenceGapPenalty).toBe(0);
  });

  it("all-100 factors → raw≈100, adjusted≈100-1.2=98.8 (with 99% coverage)", () => {
    const r = computeRawScore({
      factors: Object.keys(DEFAULT_SCORING_CONFIG.factorWeights).map(family => ({
        family: family as keyof typeof DEFAULT_SCORING_CONFIG.factorWeights,
        raw: 100,
        epistemicState: "KNOWN",
      })),
      evidenceCoverage: 0.99,
    });
    expect(r.raw).toBeGreaterThanOrEqual(99);
    expect(r.raw).toBeLessThanOrEqual(100);
    // coverage 0.99 → penalty = 12 * 0.01 = 0.12
    expect(r.adjusted).toBeGreaterThanOrEqual(98.5);
  });

  it("lower coverage increases penalty and lowers adjusted score", () => {
    const base = computeRawScore({
      factors: Object.keys(DEFAULT_SCORING_CONFIG.factorWeights).map(family => ({
        family: family as keyof typeof DEFAULT_SCORING_CONFIG.factorWeights,
        raw: 100,
        epistemicState: "KNOWN",
      })),
      evidenceCoverage: 1.0,
    });
    const low = computeRawScore({
      factors: Object.keys(DEFAULT_SCORING_CONFIG.factorWeights).map(family => ({
        family: family as keyof typeof DEFAULT_SCORING_CONFIG.factorWeights,
        raw: 100,
        epistemicState: "KNOWN",
      })),
      evidenceCoverage: 0.3,
    });
    expect(low.adjusted).toBeLessThan(base.adjusted);
    expect(low.evidenceGapPenalty).toBeGreaterThan(base.evidenceGapPenalty);
  });

  it("epistemic state downgrades factor contribution", () => {
    const known = computeRawScore({
      factors: [{ family: "marketTechnical", raw: 100, epistemicState: "KNOWN" }],
      evidenceCoverage: 1.0,
    });
    const unknown = computeRawScore({
      factors: [{ family: "marketTechnical", raw: 100, epistemicState: "UNKNOWN" }],
      evidenceCoverage: 1.0,
    });
    expect(unknown.factorScores[0]?.contribution).toBe(0);
    expect(known.factorScores[0]?.contribution).toBeGreaterThan(0);
  });

  it("returns factorScores with all 8 families", () => {
    const r = computeRawScore({
      factors: Object.keys(DEFAULT_SCORING_CONFIG.factorWeights).map(family => ({
        family: family as keyof typeof DEFAULT_SCORING_CONFIG.factorWeights,
        raw: 50,
        epistemicState: "KNOWN",
      })),
      evidenceCoverage: 1.0,
    });
    expect(r.factorScores.length).toBe(8);
  });
});

describe("computeConfidence", () => {
  it("perfect inputs → confidence 100%", () => {
    const c = computeConfidence({
      sourceReputation: 1, coverage: 1, freshness: 1,
      crossSourceAgreement: 1, identityConfidence: 1, unresolvedConflicts: 0,
    });
    expect(c.pct).toBe(100);
  });
  it("zero inputs → confidence 0%", () => {
    const c = computeConfidence({
      sourceReputation: 0, coverage: 0, freshness: 0,
      crossSourceAgreement: 0, identityConfidence: 0, unresolvedConflicts: 0,
    });
    expect(c.pct).toBe(0);
  });
  it("more conflicts lower confidence", () => {
    const c0 = computeConfidence({
      sourceReputation: 0.8, coverage: 0.8, freshness: 0.8,
      crossSourceAgreement: 0.8, identityConfidence: 0.8, unresolvedConflicts: 0,
    });
    const c3 = computeConfidence({
      sourceReputation: 0.8, coverage: 0.8, freshness: 0.8,
      crossSourceAgreement: 0.8, identityConfidence: 0.8, unresolvedConflicts: 3,
    });
    expect(c3.pct).toBeLessThan(c0.pct);
  });
});
