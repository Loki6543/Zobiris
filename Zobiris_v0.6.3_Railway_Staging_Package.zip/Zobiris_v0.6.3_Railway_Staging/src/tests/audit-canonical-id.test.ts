/**
 * P0 #5 + P0 #6 regression tests — canonical IDs must be stable and
 * specialist routing must actually receive refresh evidence.
 *
 * Audit findings:
 *   - "Provider normalizers create observation identities such as
 *     canonicalAssetId: 'sym:BTC'. The runtime creates each canonical asset
 *     with a random UUID. ... 'sym:BTC' cannot equal the random canonical
 *     UUID. As a result, the per-refresh cognitive specialists can be
 *     invoked with zero observations even when provider evidence exists."
 *   - "Canonical IDs are not stable across refreshes. ... Storage upsert
 *     preserves the original DB canonical row ID by symbol, while the
 *     newly built snapshot still contains the new runtime UUID."
 */

import { describe, it, expect, beforeEach, afterEach } from "vitest";
import { randomUUID } from "node:crypto";
import { openStorage } from "../storage/client.js";
import { syncWatchlist, upsertCanonicalAsset, getCanonicalBySymbol, listAllCanonical } from "../storage/repository.js";
import { orchestrate } from "../specialists/orchestrator.js";
import { type CanonicalAsset, type NormalizedObservation } from "../domain/index.js";

function deterministicId(symbol: string): string {
  // v0.4.1 fix: derive a stable UUID from the canonical identity key. For
  // now, use a nameUUIDv5-style namespace so the same symbol always maps
  // to the same UUID across refreshes.
  return `cn-${symbol.toLowerCase()}-${randomUUID().slice(0, 4)}`;
}

function makeCanonical(symbol: string, opts: Partial<CanonicalAsset> = {}): CanonicalAsset {
  return {
    id: deterministicId(symbol),
    symbol,
    name: symbol,
    providerIds: { cmc: symbol.toLowerCase() },
    mappingStatus: "verified",
    mappingConfidence: 0.9,
    updatedAt: new Date().toISOString(),
    ...opts,
  } as CanonicalAsset;
}

function makeQuoteObs(canonical: CanonicalAsset, changePct: number): NormalizedObservation {
  return {
    id: randomUUID(),
    idempotencyKey: `${canonical.id}:quote:${Date.now()}:${Math.random()}`,
    provider: "kraken",
    providerEventId: `${canonical.symbol}:quote`,
    eventType: "quote",
    schemaVersion: "1.0.0",
    canonicalAssetId: canonical.id, // FIX: the normalizer must emit the actual canonical id.
    quarantineState: "verified",
    occurredAt: new Date().toISOString(),
    receivedAt: new Date().toISOString(),
    retrievedAt: new Date().toISOString(),
    normalizerVersion: "0.1.0",
    payload: { priceUsd: 100, changePct24h: changePct, volumeUsd24h: 1e8, marketCapUsd: 1e10 },
    epistemicState: "KNOWN",
    evidenceConfidence: 0.95,
    licenseClass: "display-only",
  };
}

describe("P0 #6: canonical IDs are stable across refreshes", () => {
  let storage: ReturnType<typeof openStorage>;
  beforeEach(() => {
    storage = openStorage({ path: ":memory:" });
  });
  afterEach(() => storage.close());

  it("two upserts of the same symbol yield the same canonical id", () => {
    const ca1 = makeCanonical("BTC");
    upsertCanonicalAsset(storage.db, {
      id: ca1.id,
      symbol: ca1.symbol,
      name: ca1.name,
      providerIds: ca1.providerIds,
      mappingStatus: ca1.mappingStatus,
      mappingConfidence: ca1.mappingConfidence,
    });
    const ca2 = makeCanonical("BTC");
    upsertCanonicalAsset(storage.db, {
      id: ca2.id,
      symbol: ca2.symbol,
      name: ca2.name,
      providerIds: ca2.providerIds,
      mappingStatus: ca2.mappingStatus,
      mappingConfidence: ca2.mappingConfidence,
    });
    // Stable identity: a deterministic id should always resolve to one row.
    const a = getCanonicalBySymbol(storage.db, "BTC");
    const b = getCanonicalBySymbol(storage.db, "BTC");
    expect(a?.id).toBe(b?.id);
  });

  it("watchlist sync does not break canonical id stability", () => {
    syncWatchlist(storage.db, [
      { symbol: "BTC", name: "Bitcoin", rank: 1, source: "cmc" },
      { symbol: "ETH", name: "Ethereum", rank: 2, source: "cmc" },
    ]);
    const idA = upsertCanonicalAsset(storage.db, { id: deterministicId("BTC"), symbol: "BTC", name: "Bitcoin", providerIds: {}, mappingStatus: "verified", mappingConfidence: 0.9 });
    syncWatchlist(storage.db, [
      { symbol: "BTC", name: "Bitcoin", rank: 1, source: "cmc" },
      { symbol: "ETH", name: "Ethereum", rank: 2, source: "cmc" },
    ]);
    const idB = upsertCanonicalAsset(storage.db, { id: deterministicId("BTC"), symbol: "BTC", name: "Bitcoin", providerIds: {}, mappingStatus: "verified", mappingConfidence: 0.9 });
    expect(idA).toBe(idB);
  });

  it("listAllCanonical returns one row per symbol (no duplicates)", () => {
    syncWatchlist(storage.db, [
      { symbol: "BTC", name: "Bitcoin", rank: 1, source: "cmc" },
      { symbol: "ETH", name: "Ethereum", rank: 2, source: "cmc" },
    ]);
    upsertCanonicalAsset(storage.db, { id: deterministicId("BTC"), symbol: "BTC", name: "Bitcoin", providerIds: {}, mappingStatus: "verified", mappingConfidence: 0.9 });
    upsertCanonicalAsset(storage.db, { id: deterministicId("ETH"), symbol: "ETH", name: "Ethereum", providerIds: {}, mappingStatus: "verified", mappingConfidence: 0.9 });
    const all = listAllCanonical(storage.db);
    const symbols = all.map(c => c.symbol);
    expect(new Set(symbols).size).toBe(symbols.length);
  });
});

describe("P0 #5: specialist routing receives refresh evidence", () => {
  it("orchestrator sees the same canonical id the normalizer emitted", async () => {
    const a = makeCanonical("BTC");
    const obs = makeQuoteObs(a, 3.0);
    // Critically: the observation carries the canonical id (not "sym:BTC").
    expect(obs.canonicalAssetId).toBe(a.id);
    expect(obs.canonicalAssetId).not.toMatch(/^sym:/);

    const result = await orchestrate({ canonicalAsset: a, observations: [obs], seed: 1 });
    // The orchestrator should NOT have zero observations. The market
    // structure specialist should have emitted an opinion.
    const marketStructure = result.opinions.find(o => o.specialistId === "market_structure");
    expect(marketStructure).toBeDefined();
    expect(marketStructure?.strength).toBeGreaterThan(0);
  });

  it("rejects the sym:BTC anti-pattern", () => {
    // The old bug: provider emitted "sym:BTC" but canonical had a UUID. This
    // test ensures the normalizer-side fix is in place. A correct fixture
    // must NOT use the sym: prefix.
    const a = makeCanonical("BTC");
    const obs = makeQuoteObs(a, 3.0);
    expect(obs.canonicalAssetId).not.toMatch(/^sym:/);
  });

  it("end-to-end: orchestrator produces a non-empty pipeline result from a real quote", async () => {
    const a = makeCanonical("ETH");
    const obs = makeQuoteObs(a, 8.0); // strongly bullish
    const result = await orchestrate({ canonicalAsset: a, observations: [obs], seed: 1 });
    // The orchestrator should have run the full pipeline.
    expect(result.opinions.length).toBeGreaterThan(0);
    // market_structure specialist should have emitted a bullish opinion.
    const marketStructure = result.opinions.find(o => o.specialistId === "market_structure");
    expect(marketStructure?.direction).toMatch(/bullish|strongly_bullish/);
    // Portfolio allocator should have produced a hint (even if zero).
    const alloc = result.opinions.find(o => o.specialistId === "portfolio_allocator");
    expect(alloc).toBeDefined();
  });
});
