/**
 * End-to-end refresh test.
 *
 * Runs the full 19-stage refresh contract on a small watchlist with all
 * fixtures, then asserts: invariants hold, snapshot is well-formed,
 * verifier emits reasonable findings, and no fake live data sneaks in.
 */
import { describe, it, expect } from "vitest";
import { resolve } from "node:path";
import { KrakenAdapter } from "../providers/kraken.js";
import { CMCAdapter } from "../providers/cmc.js";
import { LunarCrushAdapter } from "../providers/lunarcrush.js";
import { CoinGlassAdapter } from "../providers/coinglass.js";
import { CoinMarketCalAdapter } from "../providers/coinmarketcal.js";
import { runRefresh, type RefreshAdapters } from "../runtime/refresh.js";
import { DEFAULT_SCORING_CONFIG } from "../domain/scoring.js";

const FIXTURE_DIR = resolve(process.cwd(), "src/providers/fixtures");

function buildAdapters(): RefreshAdapters {
  const kraken = new KrakenAdapter();
  kraken.configure({
    baseUrl: "x", pairMap: { BTC: "XBTUSD", SOL: "SOLUSD" },
    forceFixtures: true,
    fixturePaths: {
      BTC: `${FIXTURE_DIR}/kraken-btc-ticker.valid.json`,
      SOL: `${FIXTURE_DIR}/kraken-sol-ticker.valid.json`,
    },
  });
  const cmc = new CMCAdapter();
  cmc.configure({ baseUrl: "x", fixturePath: `${FIXTURE_DIR}/cmc-quote.valid.json` });
  const lunarcrush = new LunarCrushAdapter();
  lunarcrush.configure({ baseUrl: "x", fixturePath: `${FIXTURE_DIR}/lunarcrush-coin.valid.json` });
  const coinglass = new CoinGlassAdapter();
  coinglass.configure({
    baseUrl: "x",
    fundingFixturePath: `${FIXTURE_DIR}/coinglass-funding.valid.json`,
    liquidationsFixturePath: `${FIXTURE_DIR}/coinglass-liquidations.valid.json`,
  });
  const coinmarketcal = new CoinMarketCalAdapter();
  coinmarketcal.configure({ baseUrl: "x", fixturePath: `${FIXTURE_DIR}/coinmarketcal.valid.json` });
  return { kraken, cmc, lunarcrush, coinglass, coinmarketcal };
}

const SMALL_WATCHLIST = [
  { symbol: "BTC", name: "Bitcoin" },
  { symbol: "ETH", name: "Ethereum" },
  { symbol: "SOL", name: "Solana" },
  { symbol: "AVAX", name: "Avalanche" },
  { symbol: "LINK", name: "Chainlink" },
];

describe("end-to-end refresh", () => {
  it("completes all 19 stages on a 5-asset watchlist", async () => {
    const result = await runRefresh({
      mode: "deep",
      watchlist: SMALL_WATCHLIST,
      policy: DEFAULT_SCORING_CONFIG,
      adapters: buildAdapters(),
    });
    // The 19 stages are 1, 2, 3, 9, 13, 15, 16, 17. We assert the key ones ran.
    const stageNames = result.session.stages.map(s => s.name);
    expect(stageNames).toContain("open-session");
    expect(stageNames).toContain("provider-health");
    expect(stageNames).toContain("watchlist-sync");
    expect(stageNames).toContain("score");
    expect(stageNames).toContain("allocate");
    expect(stageNames).toContain("verify-challenge");
    expect(stageNames).toContain("publish");
    expect(stageNames).toContain("normalize-dedup");
  });

  it("produces a snapshot with all 5 watchlist assets", async () => {
    const result = await runRefresh({
      mode: "deep",
      watchlist: SMALL_WATCHLIST,
      policy: DEFAULT_SCORING_CONFIG,
      adapters: buildAdapters(),
    });
    expect(result.snapshot.rankedAssets.length).toBe(5);
    for (const sym of SMALL_WATCHLIST.map(w => w.symbol)) {
      expect(result.snapshot.rankedAssets.find(a => a.symbol === sym)).toBeDefined();
    }
  });

  it("emits verifiable verifier findings (no fatal errors on the 5-asset case)", async () => {
    const result = await runRefresh({
      mode: "deep",
      watchlist: SMALL_WATCHLIST,
      policy: DEFAULT_SCORING_CONFIG,
      adapters: buildAdapters(),
    });
    // For a 5-asset watchlist with only BTC and SOL verified, the 3 unverified ones will
    // get unmapped status, which should NOT be a fatal verifier error (only WARN).
    const errors = result.findings.filter(f => f.severity === "error");
    // No fatal errors expected for the small case.
    expect(errors.length).toBe(0);
  });

  it("produces observations with provider attribution for every event", async () => {
    const result = await runRefresh({
      mode: "deep",
      watchlist: SMALL_WATCHLIST,
      policy: DEFAULT_SCORING_CONFIG,
      adapters: buildAdapters(),
    });
    // Every observation must have a provider id and an idempotency key.
    for (const o of result.observations) {
      expect(o.provider).toBeTruthy();
      expect(o.idempotencyKey.length).toBeGreaterThan(8);
    }
  });

  it("dedupes identical observations (idempotency)", async () => {
    const result = await runRefresh({
      mode: "deep",
      watchlist: SMALL_WATCHLIST,
      policy: DEFAULT_SCORING_CONFIG,
      adapters: buildAdapters(),
    });
    const keys = result.observations.map(o => o.idempotencyKey);
    const unique = new Set(keys);
    expect(unique.size).toBe(keys.length);
  });

  it("every asset has a conclusion (case file completeness)", async () => {
    const result = await runRefresh({
      mode: "deep",
      watchlist: SMALL_WATCHLIST,
      policy: DEFAULT_SCORING_CONFIG,
      adapters: buildAdapters(),
    });
    for (const a of result.snapshot.rankedAssets) {
      expect(a.conclusion.length).toBeGreaterThan(10);
    }
  });

  it("allocated + reserve + unallocated = 100% within tolerance", async () => {
    const result = await runRefresh({
      mode: "deep",
      watchlist: SMALL_WATCHLIST,
      policy: DEFAULT_SCORING_CONFIG,
      adapters: buildAdapters(),
    });
    // Invariant: allocated + reserve + unallocated = 100
    const sum = result.snapshot.totalAllocatedPct + result.snapshot.reservePct + result.snapshot.unallocatedPct;
    expect(Math.abs(sum - 100)).toBeLessThanOrEqual(0.1);
  });

  it("opportunity rank and allocation rank are populated when applicable", async () => {
    const result = await runRefresh({
      mode: "deep",
      watchlist: SMALL_WATCHLIST,
      policy: DEFAULT_SCORING_CONFIG,
      adapters: buildAdapters(),
    });
    const eligible = result.snapshot.rankedAssets.filter(a => a.opportunityRank != null);
    expect(eligible.length).toBeGreaterThan(0);
    // Allocation rank only assigned when targetWeight > 0.
    const allocated = result.snapshot.rankedAssets.filter(a => a.allocationRank != null);
    for (const a of allocated) {
      expect(a.targetWeight.pct).toBeGreaterThan(0);
    }
  });
});
