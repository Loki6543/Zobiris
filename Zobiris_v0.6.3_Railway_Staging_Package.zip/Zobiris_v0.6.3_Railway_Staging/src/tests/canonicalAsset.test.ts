/**
 * Canonical identity tests.
 * Verifies: ticker collision quarantine, mapping state machine, isAutoJoinable.
 */
import { describe, it, expect } from "vitest";
import {
  type CanonicalAsset,
  isAutoJoinable,
  detectTickerCollision,
  buildCanonicalId,
  MAPPING_STATUSES,
} from "../domain/canonicalAsset.js";

function mkAsset(over: Partial<CanonicalAsset>): CanonicalAsset {
  return {
    id: over.id ?? "11111111-1111-4111-8111-111111111111",
    symbol: over.symbol ?? "BTC",
    name: over.name ?? "Bitcoin",
    chainId: over.chainId,
    contractAddress: over.contractAddress,
    providerIds: over.providerIds ?? {},
    mappingStatus: over.mappingStatus ?? "verified",
    mappingConfidence: over.mappingConfidence ?? 0.9,
    updatedAt: over.updatedAt ?? new Date().toISOString(),
  };
}

describe("CanonicalAsset", () => {
  describe("isAutoJoinable", () => {
    it("returns true for verified with confidence >= 0.8", () => {
      const a = mkAsset({ mappingStatus: "verified", mappingConfidence: 0.9 });
      expect(isAutoJoinable(a)).toBe(true);
    });
    it("returns false for verified with confidence < 0.8", () => {
      const a = mkAsset({ mappingStatus: "verified", mappingConfidence: 0.5 });
      expect(isAutoJoinable(a)).toBe(false);
    });
    it("returns false for ambiguous", () => {
      const a = mkAsset({ mappingStatus: "ambiguous" });
      expect(isAutoJoinable(a)).toBe(false);
    });
    it("returns false for unmapped", () => {
      const a = mkAsset({ mappingStatus: "unmapped" });
      expect(isAutoJoinable(a)).toBe(false);
    });
    it("returns false for quarantined", () => {
      const a = mkAsset({ mappingStatus: "quarantined" });
      expect(isAutoJoinable(a)).toBe(false);
    });
  });

  describe("detectTickerCollision", () => {
    it("returns empty when no two assets share a symbol", () => {
      const a = mkAsset({ id: "11111111-1111-4111-8111-111111111111", symbol: "BTC" });
      const b = mkAsset({ id: "22222222-2222-4222-8222-222222222222", symbol: "ETH" });
      const collisions = detectTickerCollision([a, b]);
      expect(collisions.size).toBe(0);
    });
    it("returns the colliding pair when two assets share a symbol", () => {
      const a = mkAsset({ id: "11111111-1111-4111-8111-111111111111", symbol: "UNI" });
      const b = mkAsset({ id: "22222222-2222-4222-8222-222222222222", symbol: "UNI" });
      const collisions = detectTickerCollision([a, b]);
      expect(collisions.size).toBe(1);
      expect(collisions.get("UNI")?.length).toBe(2);
    });
    it("detects UNI on a 50-asset watchlist with a deliberate dup", () => {
      const assets: CanonicalAsset[] = [];
      for (let i = 0; i < 50; i++) {
        const sym = i === 7 ? "UNI" : `SYM${i}`;
        assets.push(mkAsset({ id: `id-${i}`, symbol: sym }));
      }
      assets.push(mkAsset({ id: "id-dup", symbol: "UNI" }));
      const collisions = detectTickerCollision(assets);
      expect(collisions.has("UNI")).toBe(true);
      expect(collisions.get("UNI")?.length).toBe(2);
    });
  });

  describe("buildCanonicalId", () => {
    // v0.4.3 audit fix: buildCanonicalId now returns the canonical
    // resolver's id (cn-...) so all ids are stable SHA-256 ids, not the
    // legacy sym:/cmc:/chain: prefixed strings. The legacy form is gone.
    it("returns a cn-... id for chain+contract", () => {
      const id = buildCanonicalId({ chainId: "ethereum", contractAddress: "0xAbCdEf0123456789AbCdEf0123456789AbCdEf01", symbol: "UNI" });
      expect(id).toMatch(/^cn-[a-f0-9]+$/);
    });
    it("returns a cn-... id for cmc id", () => {
      const id = buildCanonicalId({ cmcId: "1", symbol: "BTC" });
      expect(id).toMatch(/^cn-[a-f0-9]+$/);
    });
    it("returns a cn-... id for symbol-only (ambiguous but stable)", () => {
      const id = buildCanonicalId({ symbol: "btc" });
      expect(id).toMatch(/^cn-[a-f0-9]+$/);
    });
    it("same inputs produce the same id (deterministic)", () => {
      const a = buildCanonicalId({ chainId: "1", contractAddress: "0xabc", symbol: "USDC" });
      const b = buildCanonicalId({ chainId: "1", contractAddress: "0xabc", symbol: "USDC" });
      expect(a).toBe(b);
    });
  });

  describe("MAPPING_STATUSES", () => {
    it("is a closed set of 4 values", () => {
      expect(MAPPING_STATUSES).toEqual(["verified", "ambiguous", "unmapped", "quarantined"]);
    });
  });
});
