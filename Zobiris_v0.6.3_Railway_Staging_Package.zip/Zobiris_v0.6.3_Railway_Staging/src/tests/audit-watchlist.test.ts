/**
 * P0 #1 regression tests — watchlist sync must:
 *   - include every current CMC watchlist symbol
 *   - mark missing symbols as removed (audit P0 #1)
 *   - validate membership and order, not a permanently hard-coded count
 */

import { describe, it, expect, beforeEach, afterEach } from "vitest";
import { readFileSync, existsSync } from "node:fs";
import { resolve } from "node:path";
import { openStorage } from "../storage/client.js";
import { syncWatchlist, listActiveWatchlist } from "../storage/repository.js";

interface MappingEntry {
  symbol: string;
  mappingStatus: "verified" | "ambiguous" | "unmapped" | "quarantined";
  [k: string]: unknown;
}

const WATCHLIST = JSON.parse(
  readFileSync(resolve(process.cwd(), "src/fixtures/watchlist.json"), "utf8"),
) as { symbol: string; name: string }[];
const MAPPINGS = JSON.parse(
  readFileSync(resolve(process.cwd(), "src/fixtures/canonical-mappings.json"), "utf8"),
) as MappingEntry[];
// v0.4.2 audit fix (P0 BLOCKER 5): the source-snapshot file records
// what an independent fetch of the CMC watchlist contained at a given
// timestamp. The local fixture must be compared against that independent
// snapshot, not against hand-written subsets of stale/fresh symbols.
const SOURCE_SNAPSHOT_PATH = resolve(process.cwd(), "src/fixtures/watchlist-source-snapshot.json");
const SOURCE_SNAPSHOT = existsSync(SOURCE_SNAPSHOT_PATH)
  ? JSON.parse(readFileSync(SOURCE_SNAPSHOT_PATH, "utf8")) as {
      source: string;
      retrievedAt: string;
      orderedMembership: string[];
    }
  : null;

describe("P0 #1: watchlist matches the agreed/current Zobiris universe", () => {
  it("has at least one watchlist entry", () => {
    expect(WATCHLIST.length).toBeGreaterThan(0);
  });

  it("every watchlist symbol is unique", () => {
    const symbols = WATCHLIST.map(w => w.symbol);
    expect(new Set(symbols).size).toBe(symbols.length);
  });

  it("uses the captured CoinMarketCap membership instead of a second hard-coded universe", () => {
    if (!SOURCE_SNAPSHOT) return;
    expect(WATCHLIST.map((item) => item.symbol)).toEqual(SOURCE_SNAPSHOT.orderedMembership);
  });
});

describe("P0 #1: source-snapshot comparison (P0 BLOCKER 5 fix)", () => {
  it("watchlist-source-snapshot.json exists and is non-empty", () => {
    if (!SOURCE_SNAPSHOT) {
      throw new Error("watchlist-source-snapshot.json is missing — see P0 BLOCKER 5");
    }
    expect(SOURCE_SNAPSHOT.orderedMembership.length).toBeGreaterThan(0);
    expect(SOURCE_SNAPSHOT.source).toMatch(/^https?:\/\//);
    expect(typeof SOURCE_SNAPSHOT.retrievedAt).toBe("string");
  });

  it("local watchlist is exactly the source-snapshot ordered membership (set-wise)", () => {
    if (!SOURCE_SNAPSHOT) return; // skip when snapshot missing
    const watchlistSymbols = new Set(WATCHLIST.map(w => w.symbol));
    const snapshotSymbols = new Set(SOURCE_SNAPSHOT.orderedMembership);
    // Membership must match the captured source snapshot exactly.
    for (const s of snapshotSymbols) {
      expect(watchlistSymbols.has(s), `local watchlist missing source-snapshot member ${s}`).toBe(true);
    }
    for (const s of watchlistSymbols) {
      expect(snapshotSymbols.has(s), `local watchlist has symbol ${s} that source-snapshot does not`).toBe(true);
    }
  });

  it("local watchlist preserves the source-snapshot order", () => {
    if (!SOURCE_SNAPSHOT) return;
    const order = SOURCE_SNAPSHOT.orderedMembership;
    for (let i = 0; i < order.length; i++) {
      const expected = order[i];
      expect(WATCHLIST[i]?.symbol, `position ${i} should be ${expected}`).toBe(expected);
    }
  });
});

describe("P0 #1: canonical-mappings coverage", () => {
  it("every watchlist symbol has a canonical mapping entry", () => {
    const watchlistSymbols = new Set(WATCHLIST.map(w => w.symbol));
    const mappingSymbols = new Set(MAPPINGS.map(m => m.symbol));
    for (const s of watchlistSymbols) {
      expect(mappingSymbols.has(s), `missing mapping for ${s}`).toBe(true);
    }
  });

  it("does not include off-watchlist mapping entries (release-blocker)", () => {
    const watchlistSymbols = new Set(WATCHLIST.map(m => m.symbol));
    const mappingSymbols = new Set(MAPPINGS.map(m => m.symbol));
    for (const symbol of mappingSymbols) {
      expect(watchlistSymbols.has(symbol), `off-watchlist mapping for ${symbol}`).toBe(true);
    }
  });

  it("keeps watchlist and mappings in lockstep at any source-defined size", () => {
    expect(MAPPINGS.length).toBe(WATCHLIST.length);
    const watchlistSymbols = new Set(WATCHLIST.map(w => w.symbol));
    const mappingSymbols = new Set(MAPPINGS.map(m => m.symbol));
    expect(watchlistSymbols).toEqual(mappingSymbols);
  });
});

describe("P0 #1: syncWatchlist handles removals", () => {
  let storage: ReturnType<typeof openStorage>;
  beforeEach(() => {
    storage = openStorage({ path: ":memory:" });
  });
  afterEach(() => {
    storage.close();
  });

  it("marks assets absent from the new source as removed", () => {
    syncWatchlist(storage.db, [
      { symbol: "BTC", name: "Bitcoin", rank: 1, source: "cmc" },
      { symbol: "ETH", name: "Ethereum", rank: 2, source: "cmc" },
      { symbol: "OLD_TOKEN", name: "Removed Token", rank: 3, source: "cmc" },
    ]);
    // Re-sync with OLD_TOKEN absent (simulating it being dropped from the watchlist).
    const r = syncWatchlist(storage.db, [
      { symbol: "BTC", name: "Bitcoin", rank: 1, source: "cmc" },
      { symbol: "ETH", name: "Ethereum", rank: 2, source: "cmc" },
    ]);
    expect(r.removed).toContain("OLD_TOKEN");
    const active = listActiveWatchlist(storage.db);
    expect(active.length).toBe(2);
    expect(active.map(a => a.symbol).sort()).toEqual(["BTC", "ETH"]);
  });

  it("reactivates symbols that re-appear in a later sync", () => {
    syncWatchlist(storage.db, [
      { symbol: "BTC", name: "Bitcoin", rank: 1, source: "cmc" },
    ]);
    // Drop BTC
    syncWatchlist(storage.db, []);
    // Re-add BTC
    const r = syncWatchlist(storage.db, [
      { symbol: "BTC", name: "Bitcoin", rank: 1, source: "cmc" },
    ]);
    expect(r.reactivated).toContain("BTC");
    const active = listActiveWatchlist(storage.db);
    expect(active.length).toBe(1);
  });

  it("does not silently preserve stale entries as active", () => {
    // First sync includes STALE
    syncWatchlist(storage.db, [
      { symbol: "BTC", name: "Bitcoin", rank: 1, source: "cmc" },
      { symbol: "STALE", name: "Stale", rank: 2, source: "cmc" },
    ]);
    // Second sync omits STALE — it MUST be marked removed
    syncWatchlist(storage.db, [
      { symbol: "BTC", name: "Bitcoin", rank: 1, source: "cmc" },
    ]);
    const active = listActiveWatchlist(storage.db);
    expect(active.find(a => a.symbol === "STALE")).toBeUndefined();
  });
});
