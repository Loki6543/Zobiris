/**
 * P0 #4 regression test — buildAdapters must actually wire live mode for
 * CoinGlass, CoinMarketCal, LunarCrush when env keys are set.
 *
 * Per the v0.4.1 audit: "the runtime's mocked 'live adapter' tests do not
 * prove the application runtime can activate them. ... Even though
 * CoinGlassAdapter and CoinMarketCalAdapter accept liveConfig,
 * src/scripts/_adapters.ts never reads COINGLASS_API_KEY or
 * COINMARKETCAL_API_KEY and never passes a live configuration."
 */

import { describe, it, expect, afterEach } from "vitest";
import { buildAdapters } from "../scripts/_adapters.js";

afterEach(() => {
  delete process.env["COINGLASS_API_KEY"];
  delete process.env["COINMARKETCAL_API_KEY"];
  delete process.env["LUNARCRUSH_API_KEY"];
  delete process.env["CMC_API_KEY"];
});

describe("P0 #4: buildAdapters wires live mode from env keys", () => {
  it("CoinGlass is in fixture mode when --live is false (no env keys consulted)", () => {
    process.env["COINGLASS_API_KEY"] = "test-key";
    const adapters = buildAdapters({ staleSeconds: 0, live: false });
    const h = adapters.coinglass.health();
    expect(["snapshot", "credentials-needed"]).toContain(h.status);
  });

  it("CoinGlass is in live mode when --live is true and COINGLASS_API_KEY is set", () => {
    process.env["COINGLASS_API_KEY"] = "test-key";
    const adapters = buildAdapters({ staleSeconds: 0, live: true });
    const h = adapters.coinglass.health();
    expect(h.status).toBe("connected");
  });

  it("CoinGlass falls back to fixture mode when --live is true but no key is set", () => {
    delete process.env["COINGLASS_API_KEY"];
    const adapters = buildAdapters({ staleSeconds: 0, live: true });
    const h = adapters.coinglass.health();
    expect(["snapshot", "credentials-needed"]).toContain(h.status);
  });

  it("CoinMarketCal is in live mode when --live is true and COINMARKETCAL_API_KEY is set", () => {
    process.env["COINMARKETCAL_API_KEY"] = "test-key";
    const adapters = buildAdapters({ staleSeconds: 0, live: true });
    const h = adapters.coinmarketcal.health();
    expect(h.status).toBe("connected");
  });

  it("CoinMarketCal falls back to fixture mode when no key is set", () => {
    delete process.env["COINMARKETCAL_API_KEY"];
    const adapters = buildAdapters({ staleSeconds: 0, live: true });
    const h = adapters.coinmarketcal.health();
    expect(["snapshot", "credentials-needed"]).toContain(h.status);
  });

  it("LunarCrush is in live mode when --live and LUNARCRUSH_API_KEY are set", () => {
    process.env["LUNARCRUSH_API_KEY"] = "test-key";
    const adapters = buildAdapters({ staleSeconds: 0, live: true });
    const h = adapters.lunarcrush.health();
    expect(h.status).toBe("connected");
  });

  it("CMC is in live mode when --live and CMC_API_KEY are set", () => {
    process.env["CMC_API_KEY"] = "test-key";
    const adapters = buildAdapters({ staleSeconds: 0, live: true });
    const h = adapters.cmc.health();
    expect(h.status).toBe("connected");
  });

  it("Empty live-key string is treated as no key", () => {
    process.env["COINGLASS_API_KEY"] = "";
    const adapters = buildAdapters({ staleSeconds: 0, live: true });
    const h = adapters.coinglass.health();
    expect(["snapshot", "credentials-needed"]).toContain(h.status);
  });
});
