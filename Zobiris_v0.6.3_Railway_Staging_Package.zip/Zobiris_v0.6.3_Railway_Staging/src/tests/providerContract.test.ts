/**
 * Provider contract tests.
 */
import { describe, it, expect } from "vitest";
import { KrakenAdapter } from "../providers/kraken.js";
import { CMCAdapter } from "../providers/cmc.js";
import { LunarCrushAdapter } from "../providers/lunarcrush.js";
import { CoinGlassAdapter } from "../providers/coinglass.js";
import { CoinMarketCalAdapter } from "../providers/coinmarketcal.js";
import { AdapterContractError } from "../providers/types.js";
import { loadFixture } from "../providers/identity.js";
import type { CanonicalAsset } from "../domain/canonicalAsset.js";
import { resolve } from "node:path";

const FIXTURE_DIR = resolve(process.cwd(), "src/providers/fixtures");
function fixture(name: string): string {
  return `${FIXTURE_DIR}/${name}`;
}

function mkCanonical(symbol: string, over: Partial<CanonicalAsset> = {}): CanonicalAsset {
  return {
    id: `id-${symbol}`,
    symbol,
    name: symbol,
    providerIds: { kraken: symbol === "BTC" ? "XBT" : symbol },
    mappingStatus: "verified",
    mappingConfidence: 0.9,
    updatedAt: new Date().toISOString(),
    ...over,
  };
}

describe("KrakenAdapter contract", () => {
  it("validates a well-formed ticker", async () => {
    const raw = await loadFixture(fixture("kraken-btc-ticker.valid.json"));
    const adapter = new KrakenAdapter();
    adapter.configure({ baseUrl: "x", pairMap: { BTC: "XXBTZUSD" } });
    const map = new Map<string, CanonicalAsset>([["BTC", mkCanonical("BTC")]]);
    const obs = adapter.normalize(raw, {
      canonicalAssets: map,
      endpoint: "ticker",
      receivedAt: "2026-08-22T01:00:00.000Z",
      rawSchemaVersion: "1.0.0",
    });
    expect(obs.length).toBe(1);
    expect(obs[0]?.eventType).toBe("ticker");
    // v0.4.2 audit fix: canonical id is now stable + deterministic, not sym:TICKER.
    expect(obs[0]?.canonicalAssetId).toMatch(/^cn-[a-f0-9]+$/);
    const p = obs[0]?.payload as Record<string, unknown>;
    expect(p?.priceUsd).toBe(78408.50);
    expect(p?.open24hUsd).toBe(73023.40);
  });

  it("rejects a malformed ticker with AdapterContractError", async () => {
    const raw = await loadFixture(fixture("kraken-btc-ticker.malformed.json"));
    const adapter = new KrakenAdapter();
    adapter.configure({ baseUrl: "x", pairMap: { BTC: "XXBTZUSD" } });
    const map = new Map<string, CanonicalAsset>([["BTC", mkCanonical("BTC")]]);
    expect(() =>
      adapter.normalize(raw, {
        canonicalAssets: map,
        endpoint: "ticker",
        receivedAt: "2026-08-22T01:00:00.000Z",
        rawSchemaVersion: "1.0.0",
      })
    ).toThrow(AdapterContractError);
  });

  it("emits observation with stable idempotency key for same source event", async () => {
    const raw = await loadFixture(fixture("kraken-btc-ticker.valid.json"));
    const adapter = new KrakenAdapter();
    adapter.configure({ baseUrl: "x", pairMap: { BTC: "XXBTZUSD" } });
    const map = new Map<string, CanonicalAsset>([["BTC", mkCanonical("BTC")]]);
    const a = adapter.normalize(raw, {
      canonicalAssets: map, endpoint: "ticker",
      receivedAt: "2026-08-22T01:00:00.000Z", rawSchemaVersion: "1.0.0",
    });
    const b = adapter.normalize(raw, {
      canonicalAssets: map, endpoint: "ticker",
      receivedAt: "2026-08-22T01:00:00.000Z", rawSchemaVersion: "1.0.0",
    });
    expect(a[0]?.idempotencyKey).toBe(b[0]?.idempotencyKey);
  });

  it("freshness reflects staleSeconds config", () => {
    const adapter = new KrakenAdapter();
    adapter.configure({
      baseUrl: "x", pairMap: { BTC: "XXBTZUSD" },
      forceFixtures: true, staleSeconds: 3600,
    });
    expect(adapter.freshness()).toBe("stale");
    adapter.configure({
      baseUrl: "x", pairMap: { BTC: "XXBTZUSD" },
      forceFixtures: true, staleSeconds: 600,
    });
    expect(adapter.freshness()).toBe("delayed");
    adapter.configure({
      baseUrl: "x", pairMap: { BTC: "XXBTZUSD" },
      forceFixtures: true, staleSeconds: 0,
    });
    expect(adapter.freshness()).toBe("live");
  });
});

describe("CMCAdapter contract", () => {
  it("validates a well-formed quote and emits per-symbol observations", async () => {
    const raw = await loadFixture(fixture("cmc-quote.valid.json"));
    const adapter = new CMCAdapter();
    const map = new Map<string, CanonicalAsset>([
      ["BTC", mkCanonical("BTC", { providerIds: { cmc: "1" } })],
      ["ETH", mkCanonical("ETH", { providerIds: { cmc: "1027" } })],
      ["SOL", mkCanonical("SOL", { providerIds: { cmc: "5426" } })],
    ]);
    const obs = adapter.normalize(raw, {
      canonicalAssets: map, endpoint: "quotes/latest",
      receivedAt: "2026-08-22T01:00:00.000Z", rawSchemaVersion: "1.0.0",
    });
    expect(obs.length).toBe(3);
    expect(obs.map(o => (o.payload as { symbol: string }).symbol).sort()).toEqual(["BTC", "ETH", "SOL"]);
  });

  it("rejects error_code != 0 in status", () => {
    const bad = { status: { error_code: 401, error_message: "Invalid API key" }, data: {} };
    const adapter = new CMCAdapter();
    expect(() =>
      adapter.normalize(bad, {
        canonicalAssets: new Map(), endpoint: "quotes/latest",
        receivedAt: "2026-08-22T01:00:00.000Z", rawSchemaVersion: "1.0.0",
      })
    ).toThrow(AdapterContractError);
  });
});

describe("LunarCrushAdapter contract", () => {
  it("validates a well-formed social snapshot", async () => {
    const raw = await loadFixture(fixture("lunarcrush-coin.valid.json"));
    const adapter = new LunarCrushAdapter();
    const map = new Map<string, CanonicalAsset>([
      ["BTC", mkCanonical("BTC")], ["ETH", mkCanonical("ETH")], ["SOL", mkCanonical("SOL")],
    ]);
    const obs = adapter.normalize(raw, {
      canonicalAssets: map, endpoint: "v4/coins",
      receivedAt: "2026-08-22T01:00:00.000Z", rawSchemaVersion: "1.0.0",
    });
    expect(obs.length).toBe(3);
    const sol = obs.find(o => (o.payload as { symbol: string }).symbol === "SOL");
    expect((sol?.payload as { galaxyScore: number }).galaxyScore).toBe(84.1);
  });
});

describe("CoinGlassAdapter contract", () => {
  it("validates funding rates", async () => {
    const raw = await loadFixture(fixture("coinglass-funding.valid.json"));
    const adapter = new CoinGlassAdapter();
    const obs = adapter.normalize(raw, {
      canonicalAssets: new Map(), endpoint: "funding",
      receivedAt: "2026-08-22T01:00:00.000Z", rawSchemaVersion: "1.0.0",
    });
    expect(obs.length).toBe(3);
  });
  it("validates liquidations", async () => {
    const raw = await loadFixture(fixture("coinglass-liquidations.valid.json"));
    const adapter = new CoinGlassAdapter();
    const obs = adapter.normalize(raw, {
      canonicalAssets: new Map(), endpoint: "liquidations",
      receivedAt: "2026-08-22T01:00:00.000Z", rawSchemaVersion: "1.0.0",
    });
    expect(obs.length).toBe(4);
  });
});

describe("CoinMarketCalAdapter contract", () => {
  it("preserves is_estimated as INFERRED epistemic state", async () => {
    const raw = await loadFixture(fixture("coinmarketcal.valid.json"));
    const adapter = new CoinMarketCalAdapter();
    const obs = adapter.normalize(raw, {
      canonicalAssets: new Map(), endpoint: "events",
      receivedAt: "2026-08-22T01:00:00.000Z", rawSchemaVersion: "1.0.0",
    });
    expect(obs.length).toBe(3);
    for (const o of obs) {
      expect(o.epistemicState).toBe("INFERRED");
      const p = o.payload as Record<string, unknown>;
      expect(p.isEstimated).toBe(true);
    }
  });
});
