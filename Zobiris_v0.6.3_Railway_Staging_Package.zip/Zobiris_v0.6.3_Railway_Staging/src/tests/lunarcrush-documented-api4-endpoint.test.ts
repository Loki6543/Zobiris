/**
 * v0.4.3 audit regression test (required #5)
 * Test: lunarcrush-documented-api4-endpoint
 *
 * Per the v0.4.3 audit (P0-3): "Auth was fixed to Bearer, but the
 * source calls:
 *   https://lunarcrush.com/api4/v4/coins?symbol=BTC,ETH,SOL
 * Current public LunarCrush API4 documentation uses endpoint families
 * such as:
 *   GET https://lunarcrush.com/api4/public/coins/list/v1
 *   GET https://lunarcrush.com/api4/public/coins/:coin/v1
 *   GET https://lunarcrush.com/api4/public/coins/:coin/time-series/v2
 * The v0.4.2 test explicitly asserts the undocumented /api4/v4/coins
 * path, so the test certifies the wrong contract."
 */

import { describe, it, expect, vi, afterEach } from "vitest";
import { LunarCrushAdapter } from "../providers/lunarcrush.js";

afterEach(() => { vi.unstubAllGlobals(); });

describe("v0.4.3 P0-3: LunarCrush live path uses the documented /public/coins/list/v1 endpoint", () => {
  it("calls /public/coins/list/v1 (not /v4/coins)", async () => {
    const fetchMock = vi.fn(async () => new Response(
      JSON.stringify({ data: { coins: [] } }),
      { status: 200, headers: { "content-type": "application/json" } },
    ));
    vi.stubGlobal("fetch", fetchMock);
    const adapter = new LunarCrushAdapter();
    adapter.configure({
      baseUrl: "https://lunarcrush.com/api4",
      liveConfig: { apiKey: "test-key" },
    });
    await adapter.fetch({ canonicalAssets: new Map() });
    const [calledUrl] = fetchMock.mock.calls[0]! as unknown as [string, RequestInit];
    expect(calledUrl).toContain("/public/coins/list/v1");
    expect(calledUrl).not.toContain("/v4/coins");
  });

  it("uses Authorization: Bearer <key> (not ?key= in the query string)", async () => {
    const fetchMock = vi.fn(async () => new Response(
      JSON.stringify({ data: { coins: [] } }),
      { status: 200, headers: { "content-type": "application/json" } },
    ));
    vi.stubGlobal("fetch", fetchMock);
    const adapter = new LunarCrushAdapter();
    adapter.configure({
      baseUrl: "https://lunarcrush.com/api4",
      liveConfig: { apiKey: "test-key-12345" },
    });
    await adapter.fetch({ canonicalAssets: new Map() });
    const [, calledInit] = fetchMock.mock.calls[0]! as unknown as [string, RequestInit];
    const headers = calledInit.headers as Record<string, string>;
    expect(headers["Authorization"]).toBe("Bearer test-key-12345");
  });

  it("does NOT include symbol= or key= in the URL", async () => {
    const fetchMock = vi.fn(async () => new Response(
      JSON.stringify({ data: { coins: [] } }),
      { status: 200, headers: { "content-type": "application/json" } },
    ));
    vi.stubGlobal("fetch", fetchMock);
    const adapter = new LunarCrushAdapter();
    adapter.configure({
      baseUrl: "https://lunarcrush.com/api4",
      liveConfig: { apiKey: "test-key" },
    });
    await adapter.fetch({ canonicalAssets: new Map() });
    const [calledUrl] = fetchMock.mock.calls[0]! as unknown as [string, RequestInit];
    expect(calledUrl).not.toMatch(/[?&]symbol=/);
    expect(calledUrl).not.toMatch(/[?&]key=/);
  });

  it("returns 401 as AdapterNormalizationError (credential failure, not silent fallback)", async () => {
    const fetchMock = vi.fn(async () => new Response("unauthorized", { status: 401 }));
    vi.stubGlobal("fetch", fetchMock);
    const adapter = new LunarCrushAdapter();
    adapter.configure({
      baseUrl: "https://lunarcrush.com/api4",
      liveConfig: { apiKey: "bad-key" },
    });
    await expect(adapter.fetch({ canonicalAssets: new Map() })).rejects.toThrow(/401/);
  });
});
