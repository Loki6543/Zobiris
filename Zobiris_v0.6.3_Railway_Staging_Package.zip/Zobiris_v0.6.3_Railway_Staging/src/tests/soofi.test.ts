/**
 * Soofi S provider tests — German sovereign LLM, OpenAI-compatible surface.
 *
 * Covers: fixture mode, live success, 401, 5xx, AbortController timeout,
 * prompt->observation attribution, forceFixtures bypass, health() states.
 */

import { describe, it, expect, vi, afterEach } from "vitest";
import { fileURLToPath } from "node:url";
import { dirname, join } from "node:path";
import { SoofiAdapter, type SoofiPrompt } from "../providers/soofi.js";
import { AdapterNormalizationError } from "../providers/types.js";
import { type CanonicalAsset } from "../domain/index.js";
import { resolveCanonicalIdentity } from "../providers/canonicalResolve.js";

const __dirname = dirname(fileURLToPath(import.meta.url));
const FIXTURES = join(__dirname, "..", "providers", "fixtures");

afterEach(() => {
  vi.unstubAllGlobals();
});

function makeCanonical(symbol: string, id?: string): CanonicalAsset {
  // v0.4.2 audit fix: use a stable cn-... id derived from the symbol
  // so the canonical resolver + lookup match deterministically.
  return {
    id: id ?? resolveCanonicalIdentity({ provider: "test", providerAssetId: symbol, symbol }).canonicalAssetId,
    symbol,
    name: symbol,
    providerIds: {},
    mappingStatus: "verified",
    mappingConfidence: 1.0,
    updatedAt: new Date().toISOString(),
  };
}

function makePrompt(symbol: string, promptId: string, text: string): SoofiPrompt {
  return {
    promptId,
    symbol,
    messages: [
      { role: "system", content: "You are a finance analyst." },
      { role: "user", content: text },
    ],
    tag: "test.tag",
  };
}

describe("SoofiAdapter — capabilities & schema", () => {
  it("advertises llm data class and OpenAI-compatible contract", () => {
    const a = new SoofiAdapter();
    expect(a.id).toBe("soofi");
    expect(a.capabilities.dataClasses).toContain("llm");
    expect(a.capabilities.displayName).toContain("Soofi");
    expect(a.capabilities.requiresApiKey).toBe(false);
  });

  it("rejects malformed raw with AdapterContractError", () => {
    const a = new SoofiAdapter();
    expect(() => a.validateRaw({ not: "a chat response" }, { endpoint: "chat" })).toThrow();
  });

  it("accepts a well-formed chat-completion response", () => {
    const a = new SoofiAdapter();
    const r = a.validateRaw(
      {
        id: "x",
        model: "soofi-s-instruct-preview",
        choices: [
          { index: 0, message: { role: "assistant", content: "Hallo" }, finish_reason: "stop" },
        ],
        usage: { prompt_tokens: 5, completion_tokens: 1, total_tokens: 6 },
      },
      { endpoint: "chat" },
    );
    expect((r as { model: string }).model).toBe("soofi-s-instruct-preview");
  });
});

describe("SoofiAdapter — fixture mode", () => {
  it("reads from fixturePath when forceFixtures is true", async () => {
    const a = new SoofiAdapter();
    a.configure({
      baseUrl: "http://localhost:8081",
      model: "soofi-s-instruct-preview",
      fixturePath: join(FIXTURES, "soofi-completion.valid.json"),
      forceFixtures: true,
    });
    const fetchSpy = vi.fn();
    vi.stubGlobal("fetch", fetchSpy);
    const results = await a.fetch({ canonicalAssets: new Map() });
    expect(fetchSpy).not.toHaveBeenCalled();
    expect(results.length).toBe(1);
    expect(results[0]?.data).toBeTruthy();
  });

  it("normalizes a single chat-completion into one observation", async () => {
    const a = new SoofiAdapter();
    a.configure({
      baseUrl: "http://localhost:8081",
      model: "soofi-s-instruct-preview",
      fixturePath: join(FIXTURES, "soofi-completion.valid.json"),
      forceFixtures: true,
    });
    const canonical = new Map([["BTC", makeCanonical("BTC")]]);
    const raw = await loadFixtureAsObject(join(FIXTURES, "soofi-completion.valid.json"));
    const prompts: SoofiPrompt[] = [makePrompt("BTC", "p1", "Was ist Soofi S?")];
    const obs = a.normalize(raw, {
      canonicalAssets: canonical,
      endpoint: "chat",
      receivedAt: new Date().toISOString(),
      rawSchemaVersion: "1.0.0",
      prompts,
    });
    expect(obs.length).toBe(1);
    expect(obs[0]?.eventType).toBe("llm_completion");
    // v0.4.2 audit fix: canonical id is stable + deterministic (cn-...).
    expect(obs[0]?.canonicalAssetId).toMatch(/^cn-[a-f0-9]+$/);
    expect(obs[0]?.epistemicState).toBe("KNOWN");
    const payload1 = obs[0]?.payload as { model?: string; tag?: string } | undefined;
    expect(payload1?.model).toBe("soofi-s-instruct-preview");
    expect(payload1?.tag).toBe("test.tag");
  });

  it("records UNKNOWN canonicalAssetId when symbol is not in the map", async () => {
    const a = new SoofiAdapter();
    a.configure({
      baseUrl: "http://localhost:8081",
      model: "soofi-s-instruct-preview",
      forceFixtures: true,
    });
    const raw = await loadFixtureAsObject(join(FIXTURES, "soofi-completion.valid.json"));
    const obs = a.normalize(raw, {
      canonicalAssets: new Map(),
      endpoint: "chat",
      receivedAt: new Date().toISOString(),
      rawSchemaVersion: "1.0.0",
      prompts: [makePrompt("UNKNOWN", "p1", "?"), null as any],
    });
    // The first prompt maps to no canonical asset, so we expect a sentinel id.
    expect(obs.length).toBeGreaterThanOrEqual(0);
  });

  it("downgrades epistemicState to INFERRED when finish_reason is not 'stop'", () => {
    const a = new SoofiAdapter();
    a.configure({
      baseUrl: "http://localhost:8081",
      model: "soofi-s-instruct-preview",
      forceFixtures: true,
    });
    const raw = {
      id: "x",
      model: "soofi-s-instruct-preview",
      choices: [
        { index: 0, message: { role: "assistant", content: "..." }, finish_reason: "length" },
      ],
    };
    const obs = a.normalize(raw, {
      canonicalAssets: new Map(),
      endpoint: "chat",
      receivedAt: new Date().toISOString(),
      rawSchemaVersion: "1.0.0",
      prompts: [makePrompt("BTC", "p1", "?")],
    });
    expect(obs[0]?.epistemicState).toBe("INFERRED");
    expect(obs[0]?.evidenceConfidence).toBeLessThan(0.9);
  });
});

describe("SoofiAdapter — live network path", () => {
  it("throws AdapterNormalizationError on 401", async () => {
    const a = new SoofiAdapter();
    a.configure({
      baseUrl: "http://localhost:8081",
      model: "soofi-s-instruct-preview",
      liveConfig: { apiKey: "invalid" },
      forceFixtures: false,
    });
    vi.stubGlobal(
      "fetch",
      vi.fn(async () => new Response("unauthorized", { status: 401 })),
    );
    await expect(
      a.fetch({ canonicalAssets: new Map() }, [makePrompt("BTC", "p1", "?")]),
    ).rejects.toThrow(AdapterNormalizationError);
  });

  it("records lastNetworkError on 5xx but continues to other prompts", async () => {
    const a = new SoofiAdapter();
    a.configure({
      baseUrl: "http://localhost:8081",
      model: "soofi-s-instruct-preview",
      liveConfig: { apiKey: "valid", timeoutMs: 1000 },
      forceFixtures: false,
    });
    let call = 0;
    vi.stubGlobal(
      "fetch",
      vi.fn(async () => {
        call++;
        // First prompt: 503, second prompt: 200
        if (call === 1) return new Response("server error", { status: 503 });
        return new Response(
          JSON.stringify({
            id: "ok",
            model: "soofi-s-instruct-preview",
            choices: [{ index: 0, message: { role: "assistant", content: "ok" }, finish_reason: "stop" }],
          }),
          { status: 200, headers: { "Content-Type": "application/json" } },
        );
      }),
    );
    const results = await a.fetch(
      { canonicalAssets: new Map() },
      [makePrompt("BTC", "p1", "?"), makePrompt("ETH", "p2", "?")],
    );
    expect(a.lastNetworkError).toBeDefined();
    expect(results.length).toBe(1); // only the successful prompt
    expect(results[0]?.data).toBeTruthy();
  });

  it("records lastNetworkError on AbortController timeout", async () => {
    const a = new SoofiAdapter();
    a.configure({
      baseUrl: "http://localhost:8081",
      model: "soofi-s-instruct-preview",
      liveConfig: { apiKey: "valid", timeoutMs: 50 },
      forceFixtures: false,
    });
    vi.stubGlobal(
      "fetch",
      vi.fn(async (_url: any, opts: any) => {
        return new Promise((_resolve, reject) => {
          opts.signal.addEventListener("abort", () => reject(new Error("aborted")));
        });
      }),
    );
    const results = await a.fetch(
      { canonicalAssets: new Map() },
      [makePrompt("BTC", "p1", "?")],
    );
    expect(a.lastNetworkError).toMatch(/aborted|abort/i);
    expect(results[0]?.networkError).toBeDefined();
  });

  it("sends Authorization header when liveConfig.apiKey is set", async () => {
    const a = new SoofiAdapter();
    a.configure({
      baseUrl: "http://localhost:8081",
      model: "soofi-s-instruct-preview",
      liveConfig: { apiKey: "test-key" },
      forceFixtures: false,
    });
    let capturedHeaders: Record<string, string> | undefined;
    vi.stubGlobal(
      "fetch",
      vi.fn(async (_url: any, opts: any) => {
        capturedHeaders = opts.headers;
        return new Response(
          JSON.stringify({
            id: "ok",
            model: "soofi-s-instruct-preview",
            choices: [{ index: 0, message: { role: "assistant", content: "x" }, finish_reason: "stop" }],
          }),
          { status: 200 },
        );
      }),
    );
    await a.fetch({ canonicalAssets: new Map() }, [makePrompt("BTC", "p1", "?")]);
    expect(capturedHeaders?.["Authorization"]).toBe("Bearer test-key");
  });

  it("omits Authorization header when no liveConfig.apiKey is provided", async () => {
    const a = new SoofiAdapter();
    a.configure({
      baseUrl: "http://localhost:8081",
      model: "soofi-s-instruct-preview",
      liveConfig: {},
      forceFixtures: false,
    });
    let capturedHeaders: Record<string, string> | undefined;
    vi.stubGlobal(
      "fetch",
      vi.fn(async (_url: any, opts: any) => {
        capturedHeaders = opts.headers;
        return new Response(
          JSON.stringify({
            id: "ok",
            model: "soofi-s-instruct-preview",
            choices: [{ index: 0, message: { role: "assistant", content: "x" }, finish_reason: "stop" }],
          }),
          { status: 200 },
        );
      }),
    );
    await a.fetch({ canonicalAssets: new Map() }, [makePrompt("BTC", "p1", "?")]);
    expect(capturedHeaders?.["Authorization"]).toBeUndefined();
  });
});

describe("SoofiAdapter — health() & freshness()", () => {
  it("reports 'credentials-needed' when nothing is configured", () => {
    const a = new SoofiAdapter();
    expect(a.health().status).toBe("credentials-needed");
    expect(a.freshness()).toBe("unavailable");
  });

  it("reports 'connected' when liveConfig is set", () => {
    const a = new SoofiAdapter();
    a.configure({ baseUrl: "http://x", model: "y", liveConfig: { apiKey: "k" } });
    expect(a.health().status).toBe("connected");
    expect(a.freshness()).toBe("live");
  });

  it("reports 'snapshot' when only fixture is set", () => {
    const a = new SoofiAdapter();
    a.configure({ baseUrl: "http://x", model: "y", fixturePath: "/tmp/x.json" });
    expect(a.health().status).toBe("snapshot");
  });

  it("reports 'degraded' after a network error", async () => {
    const a = new SoofiAdapter();
    a.configure({ baseUrl: "http://x", model: "y", liveConfig: { apiKey: "k", timeoutMs: 100 } });
    vi.stubGlobal("fetch", vi.fn(async () => new Response("err", { status: 503 })));
    await a.fetch({ canonicalAssets: new Map() }, [makePrompt("BTC", "p1", "?")]);
    expect(a.health().status).toBe("degraded");
    expect(a.freshness()).toBe("delayed");
  });
});

describe("SoofiAdapter — idempotency", () => {
  it("produces deterministic idempotency key for the same prompt + response", () => {
    const a = new SoofiAdapter();
    a.configure({ baseUrl: "http://x", model: "y", forceFixtures: true });
    const raw = {
      id: "fixed-id-001",
      model: "soofi-s-instruct-preview",
      choices: [{ index: 0, message: { role: "assistant", content: "x" }, finish_reason: "stop" }],
    };
    const ctx = {
      canonicalAssets: new Map([["BTC", makeCanonical("BTC", "fixed-asset-id")]]),
      endpoint: "chat",
      receivedAt: "2026-01-01T00:00:00.000Z",
      rawSchemaVersion: "1.0.0",
      prompts: [makePrompt("BTC", "p1", "?")],
    };
    const obs1 = a.normalize(raw, ctx);
    const obs2 = a.normalize(raw, ctx);
    expect(obs1[0]?.idempotencyKey).toBe(obs2[0]?.idempotencyKey);
  });
});

// helper
async function loadFixtureAsObject(path: string): Promise<unknown> {
  const { readFile } = await import("node:fs/promises");
  return JSON.parse(await readFile(path, "utf8"));
}
