/**
 * v0.4.4 audit fix (P0-7): canonicalAssetId is IMMUTABLE.
 *
 * The audit caught: "IDs are derived from the strongest identity
 * information currently known. Today: only symbol/provider mapping
 * known → canonical ID A. Later: we research chain + contract →
 * stronger identity key → canonical ID B. The identity has now
 * changed merely because our knowledge improved."
 *
 * v0.4.4 rule: the canonical id never changes. New identity
 * information is appended to `canonical_asset_aliases` and
 * recorded in `identity_merge_history`.
 *
 * This test asserts the v0.4.4 invariant.
 */
import { describe, it, expect, beforeEach, afterEach } from "vitest";
import { openStorage, type DB } from "../storage/client.js";
import {
  upsertCanonicalAsset,
  appendCanonicalAlias,
  getCanonicalByAlias,
  getCanonicalById,
} from "../storage/repository.js";
import { canonicalAssetAliases, identityMergeHistory } from "../storage/schema.js";
import { eq } from "drizzle-orm";

describe("v0.4.4 P0-7: canonical id is immutable", () => {
  let db: DB;
  let sqlite: { close: () => void };

  beforeEach(() => {
    const opened = openStorage({ path: ":memory:" });
    db = opened.db;
    sqlite = opened.sqlite;
  });

  afterEach(() => {
    sqlite?.close();
  });

  it("upserting the same symbol with stronger identity does NOT change the canonical id", () => {
    // First creation: only symbol+symbol-only mapping known.
    const id1 = upsertCanonicalAsset(db, {
      symbol: "TEST",
      name: "Test Token",
      mappingStatus: "ambiguous",
      mappingConfidence: 0.4,
      providerIds: {},
      identityProvenance: "symbol-only",
    });
    expect(id1).toMatch(/^[0-9a-f-]{36}$/i);  // UUID v4

    // Second upsert (e.g. operator learns chain+contract later):
    // same symbol, stronger identity. The id must NOT change.
    const id2 = upsertCanonicalAsset(db, {
      symbol: "TEST",
      name: "Test Token (better mapping)",
      mappingStatus: "verified",
      mappingConfidence: 0.95,
      providerIds: {
        cmcNumericId: "9999",
        coingeckoId: "test-token",
        contract: "0xTEST",
        chainId: "ethereum",
      },
      identityProvenance: "chain+contract",
    });
    expect(id2).toBe(id1);  // IMMUTABLE

    // The row's mapping confidence can change (knowledge grew),
    // but the id stays.
    const row = getCanonicalById(db, id1);
    expect(row?.mappingStatus).toBe("verified");
    expect(row?.mappingConfidence).toBe(0.95);
    expect(row?.identityProvenance).toBe("chain+contract");
  });

  it("appendCanonicalAlias records a new alias without changing the id", () => {
    const id = upsertCanonicalAsset(db, {
      symbol: "ALIAS",
      name: "Alias Token",
      mappingStatus: "verified",
      mappingConfidence: 0.9,
      providerIds: { cmcNumericId: "1000" },
      identityProvenance: "provider-id",
    });
    appendCanonicalAlias(db, id, "krakenPair", "ALIASUSD", 0.9, "research");

    // Lookup by the new alias returns the original id.
    const found = getCanonicalByAlias(db, "krakenPair", "ALIASUSD");
    expect(found?.canonicalAssetId).toBe(id);

    // The id is still the original.
    const row = getCanonicalById(db, id);
    expect(row?.id).toBe(id);
  });

  it("alias collision is recorded in identity_merge_history but the id is preserved", () => {
    // Two different assets (different symbols) attempt to claim
    // the same provider alias. The second one is logged as a
    // collision; the second asset's id is NOT changed.
    const idA = upsertCanonicalAsset(db, {
      symbol: "AA",
      name: "AA",
      mappingStatus: "verified",
      mappingConfidence: 0.9,
      providerIds: { cmcNumericId: "1" },
      identityProvenance: "provider-id",
    });
    const idB = upsertCanonicalAsset(db, {
      symbol: "BB",
      name: "BB",
      mappingStatus: "verified",
      mappingConfidence: 0.9,
      providerIds: { cmcNumericId: "2" },
      identityProvenance: "provider-id",
    });
    // Force a collision: try to add cmcNumericId=1 to asset B.
    appendCanonicalAlias(db, idB, "cmcNumericId", "1", 0.9, "test");

    // Asset B's id is unchanged; the alias was NOT added.
    const rowB = getCanonicalById(db, idB);
    expect(rowB?.id).toBe(idB);
    // Asset A still owns the alias.
    const lookupA = getCanonicalByAlias(db, "cmcNumericId", "1");
    expect(lookupA?.canonicalAssetId).toBe(idA);

    // The merge history records the collision.
    const collisions = db.select().from(identityMergeHistory)
      .where(eq(identityMergeHistory.survivorCanonicalAssetId, idB))
      .all();
    expect(collisions.length).toBeGreaterThanOrEqual(1);
    expect(collisions[0]?.action).toBe("id_collided");
  });

  it("superseded aliases do not resolve", () => {
    const id = upsertCanonicalAsset(db, {
      symbol: "SUPER",
      name: "Super",
      mappingStatus: "verified",
      mappingConfidence: 0.9,
      providerIds: { cmcNumericId: "5" },
      identityProvenance: "provider-id",
    });
    // Mark the alias as superseded.
    db.update(canonicalAssetAliases)
      .set({ superseded: 1, supersededAt: Date.now() })
      .where(eq(canonicalAssetAliases.canonicalAssetId, id))
      .run();
    const found = getCanonicalByAlias(db, "cmcNumericId", "5");
    expect(found).toBeUndefined();
    // The id itself is still valid.
    const row = getCanonicalById(db, id);
    expect(row?.id).toBe(id);
  });
});
