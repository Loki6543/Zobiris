/**
 * Tests for the Iyaza Addendum memory promotion lifecycle.
 */
import { describe, it, expect } from "vitest";
import { CandidateLifecycle, IllegalCandidateTransitionError } from "../learning/lifecycle.js";
import { evaluatePromotionGates, PROMOTION_GATE_NAMES, type CandidateForGates } from "../learning/promotion.js";

describe("CandidateLifecycle", () => {
  it("supports the happy path PROPOSED -> ... -> PROMOTED", () => {
    const c = new CandidateLifecycle("c-1");
    expect(c.currentState()).toBe("PROPOSED");
    c.record("IMPLEMENTED_IN_SANDBOX");
    c.record("UNIT_TESTED");
    c.record("POINT_IN_TIME_REPLAYED");
    c.record("COUNTERFACTUAL_OR_PAIRED_TESTED");
    c.record("HOLDOUT_EVALUATED");
    c.record("SHADOW_OBSERVED");
    c.record("CROSS_SESSION_RECURRING");
    c.record("INDEPENDENTLY_VERIFIED");
    c.record("HUMAN_APPROVED");
    c.record("PROMOTED");
    c.record("MONITORED");
    expect(c.currentState()).toBe("MONITORED");
    expect(c.isPromotable()).toBe(true);
    expect(c.isTerminal()).toBe(false);
  });

  it("rejects skipping states (PROPOSED -> HUMAN_APPROVED)", () => {
    const c = new CandidateLifecycle("c-1");
    expect(() => c.record("HUMAN_APPROVED")).toThrow(IllegalCandidateTransitionError);
  });

  it("rejects unknown state", () => {
    const c = new CandidateLifecycle("c-1");
    expect(() => c.record("BOGUS_STATE" as any)).toThrow(IllegalCandidateTransitionError);
  });

  it("rollback returns to the previous state and marks ROLLED_BACK in history", () => {
    const c = new CandidateLifecycle("c-1");
    c.record("IMPLEMENTED_IN_SANDBOX");
    c.record("UNIT_TESTED");
    c.record("POINT_IN_TIME_REPLAYED");
    const before = c.currentState();
    const returned = c.rollback();
    expect(returned).toBe("UNIT_TESTED");
    const h = c.history();
    const last = h[h.length - 1]!;
    expect(last.to).toBe("ROLLED_BACK");
    expect(last.from).toBe(before);
  });

  it("history records all transitions with timestamps", () => {
    const c = new CandidateLifecycle("c-1");
    c.record("IMPLEMENTED_IN_SANDBOX");
    c.record("UNIT_TESTED");
    const h = c.history();
    expect(h.length).toBe(3); // initial + 2 transitions
    for (const e of h) {
      expect(typeof e.at).toBe("string");
    }
  });

  it("rejects transitions out of a terminal state", () => {
    const c = new CandidateLifecycle("c-1");
    c.record("IMPLEMENTED_IN_SANDBOX");
    c.record("UNIT_TESTED");
    c.record("POINT_IN_TIME_REPLAYED");
    c.record("COUNTERFACTUAL_OR_PAIRED_TESTED");
    c.record("HOLDOUT_EVALUATED");
    c.record("SHADOW_OBSERVED");
    c.record("CROSS_SESSION_RECURRING");
    c.record("INDEPENDENTLY_VERIFIED");
    c.record("HUMAN_APPROVED");
    c.record("PROMOTED");
    c.record("MONITORED");
    c.record("RETAINED");
    expect(c.isTerminal()).toBe(true);
    expect(() => c.record("PROMOTED")).toThrow(IllegalCandidateTransitionError);
  });
});

describe("evaluatePromotionGates", () => {
  const allGatesPass: CandidateForGates = {
    recurrenceCount: 5,
    distinctSessionCount: 3,
    sourceSessionIds: ["sess-1", "sess-2", "sess-3"],
    sourceDiversity: "multi_source",
    generalizesAcrossAssetsAndRegimes: true,
    hasPointInTimeReplay: true,
    hasHiddenHoldoutEvaluation: true,
    hasIndependentVerifier: true,
    challengerObjectionsAddressed: true,
    hasUnresolvedConflict: false,
    measurableImprovementVsBaseline: 0.15,
    hasUnacceptableRegression: false,
    hasShadowCanaryObservation: true,
    hasHumanApproval: true,
    hasRollbackPath: true,
  };

  it("all gates pass -> pass=true, missing=[]", () => {
    const r = evaluatePromotionGates(allGatesPass);
    expect(r.pass).toBe(true);
    expect(r.missing).toEqual([]);
    expect(r.viaOverride).toBe(false);
    expect(r.overrideRecorded).toBe(false);
  });

  it("fresh candidate with no recurrence fails the recurrence gate", () => {
    const c: CandidateForGates = { ...allGatesPass, recurrenceCount: 1 };
    const r = evaluatePromotionGates(c);
    expect(r.pass).toBe(false);
    expect(r.missing).toContain("recurrence_at_least_3");
  });

  it("missing human approval fails", () => {
    const c: CandidateForGates = { ...allGatesPass, hasHumanApproval: false };
    const r = evaluatePromotionGates(c);
    expect(r.pass).toBe(false);
    expect(r.missing).toContain("human_approval");
  });

  it("missing rollback path fails", () => {
    const c: CandidateForGates = { ...allGatesPass, hasRollbackPath: false };
    const r = evaluatePromotionGates(c);
    expect(r.pass).toBe(false);
    expect(r.missing).toContain("rollback_path");
  });

  it("unacceptable regression fails", () => {
    const c: CandidateForGates = { ...allGatesPass, hasUnacceptableRegression: true };
    const r = evaluatePromotionGates(c);
    expect(r.pass).toBe(false);
    expect(r.missing).toContain("no_unacceptable_regression");
  });

  it("unresolved conflict fails", () => {
    const c: CandidateForGates = { ...allGatesPass, hasUnresolvedConflict: true };
    const r = evaluatePromotionGates(c);
    expect(r.pass).toBe(false);
    expect(r.missing).toContain("no_unresolved_conflict");
  });

  it("critical safety override is recorded but cannot bypass promotion gates", () => {
    const c: CandidateForGates = {
      ...allGatesPass,
      recurrenceCount: 1, // missing
      hasHumanApproval: false, // missing
      criticalSafetyOverride: {
        reason: "live exploit discovered; immediate protective regression needed",
        approvedBy: "kevin@zobiris",
        at: "2026-08-22T03:00:00.000Z",
      },
    };
    const r = evaluatePromotionGates(c);
    expect(r.pass).toBe(false);
    expect(r.viaOverride).toBe(false);
    expect(r.overrideRecorded).toBe(true);
    expect(r.missing.length).toBeGreaterThan(0);
  });

  it("PROMOTION_GATE_NAMES has 15 entries", () => {
    expect(PROMOTION_GATE_NAMES.length).toBe(15);
  });
});
