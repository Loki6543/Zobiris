/**
 * v0.4.4 audit fix (P0-2): CMC v3 contract.
 *
 * The audit caught that v0.4.3 used the symbol-driven
 *   /v1/cryptocurrency/quotes/latest?symbol=BTC,ETH,SOL
 * path and treated the response map key as the CMC numeric id.
 *
 * v0.4.4 wires the current production endpoint:
 *   /v3/cryptocurrency/quotes/latest?id=1,1027,5426
 * and uses the `entry.id` field on each returned record, NOT
 * the response map key.
 */
import { describe, it, expect, beforeEach, afterEach, vi } from "vitest";
import { CMCAdapter } from "../providers/cmc.js";
import { type CanonicalAsset } from "../domain/index.js";

function makeAsset(symbol: string, cmcNumericId?: string): CanonicalAsset {
  return {
    id: `cn-${symbol.toLowerCase()}-test`,
    symbol,
    name: symbol,
    providerIds: cmcNumericId ? { cmcNumericId } : {},
    mappingStatus: cmcNumericId ? "verified" : "unmapped",
    mappingConfidence: cmcNumericId ? 0.9 : 0,
    updatedAt: new Date().toISOString(),
  };
}

const mockFetch = vi.fn();
const realFetch = globalThis.fetch;
beforeEach(() => { (globalThis as any).fetch = mockFetch; });
afterEach(() => { (globalThis as any).fetch = realFetch; mockFetch.mockReset(); });

function mockCmcV3Response(assets: Array<{ id: number; symbol: string; name: string; price: number }>) {
  return {
    status: { error_code: 0, error_message: null, elapsed: 1, credit_count: 1 },
    data: Object.fromEntries(assets.map((a) => [String(a.id), {
      id: a.id,
      name: a.name,
      symbol: a.symbol,
      slug: a.symbol.toLowerCase(),
      quote: {
        USD: {
          price: a.price,
          volume_24h: 1000000,
          market_cap: 1000000000,
          percent_change_24h: 1.23,
          last_updated: new Date().toISOString(),
        },
      },
    }])),
  };
}

describe("v0.4.4 P0-2: CMC current v3 contract", () => {
  it("uses /v3/ and id= query parameter (not symbol=) when canonical assets are supplied", async () => {
    mockFetch.mockResolvedValueOnce({
      ok: true,
      status: 200,
      json: async () => mockCmcV3Response([
        { id: 1, symbol: "BTC", name: "Bitcoin", price: 60000 },
        { id: 1027, symbol: "ETH", name: "Ethereum", price: 3000 },
      ]),
    });
    const adapter = new CMCAdapter();
    adapter.configure({
      baseUrl: "https://pro-api.coinmarketcap.com",
      fixturePath: undefined,
      forceFixtures: false,
      liveConfig: { apiKey: "test-key" },
    });
    const btc = makeAsset("BTC", "1");
    const eth = makeAsset("ETH", "1027");
    const map = new Map([
      [btc.id, btc],
      [eth.id, eth],
    ]);
    await adapter.fetch({ canonicalAssets: map });
    const [urlArg] = mockFetch.mock.calls[0] as [string, RequestInit];
    // v0.4.4: current production endpoint is /v3/.
    expect(urlArg).toContain("/v3/cryptocurrency/quotes/latest");
    // v0.4.4: query by numeric id, not symbol.
    expect(urlArg).toContain("id=");
    expect(urlArg).not.toContain("symbol=");
    // Both CMC numeric ids present.
    expect(urlArg).toMatch(/id=1[,&]/);
    expect(urlArg).toMatch(/(?:,|&)?id=1/);
    // 1027 should also appear in the id list (order may vary).
    expect(urlArg).toMatch(/id=[0-9,]+/);
    // Extract the id= portion and verify it has both numbers.
    const idMatch = urlArg.match(/id=([0-9,]+)/);
    const idList = idMatch?.[1]?.split(",") ?? [];
    expect(idList).toContain("1");
    expect(idList).toContain("1027");
  });

  it("the symbol=BTC fallback is only used when no canonical assets are supplied", async () => {
    mockFetch.mockResolvedValueOnce({
      ok: true,
      status: 200,
      json: async () => mockCmcV3Response([
        { id: 1, symbol: "BTC", name: "Bitcoin", price: 60000 },
      ]),
    });
    const adapter = new CMCAdapter();
    adapter.configure({
      baseUrl: "https://pro-api.coinmarketcap.com",
      fixturePath: undefined,
      forceFixtures: false,
      liveConfig: { apiKey: "test-key" },
    });
    await adapter.fetch({ canonicalAssets: new Map() });
    const [urlArg] = mockFetch.mock.calls[0] as [string, RequestInit];
    expect(urlArg).toContain("/v3/cryptocurrency/quotes/latest");
    // No canonical assets → symbol=BTC,ETH,SOL fallback.
    expect(urlArg).toMatch(/symbol=/);
  });

  it("normalize uses entry.id (not response map key) as the CMC numeric id", () => {
    const adapter = new CMCAdapter();
    adapter.configure({
      baseUrl: "https://pro-api.coinmarketcap.com",
      fixturePath: undefined,
      forceFixtures: false,
      liveConfig: { apiKey: "test-key" },
    });
    const btc = makeAsset("BTC", "1");
    const map = new Map([[btc.id, btc]]);
    const obs = adapter.normalize(
      // The v3 response wraps each coin in a string-keyed object;
      // the key is the CMC id, but v0.4.4 prefers the inner entry.id.
      { data: { "1": { id: 1, name: "Bitcoin", symbol: "BTC", quote: { USD: { price: 60000, last_updated: new Date().toISOString() } } } } },
      {
        canonicalAssets: map,
        endpoint: "quotes/latest",
        receivedAt: new Date().toISOString(),
        rawSchemaVersion: "3.0.0",
      },
    );
    expect(obs).toHaveLength(1);
    // The observation is attached to the canonical asset whose
    // cmcNumericId matched entry.id (1), NOT to whatever the
    // response-map key was. The makeAsset() helper sets the id
    // to cn-btc-test.
    expect(obs[0]?.canonicalAssetId).toBe("cn-btc-test");
    expect(obs[0]?.providerEventId).toBe("1");
    // Critical: even though the response-map key happens to be
    // "1" in this fixture, the normalization is driven by
    // entry.id, not the map key.
    expect(obs[0]?.providerEventId).toBe("1");
  });

  it("cmc-fallback-is-degraded: when live HTTP fails, the adapter's lastNetworkError reflects the failure", async () => {
    mockFetch.mockResolvedValueOnce({
      ok: false,
      status: 500,
      text: async () => "internal error",
    });
    const adapter = new CMCAdapter();
    adapter.configure({
      baseUrl: "https://pro-api.coinmarketcap.com",
      fixturePath: undefined,  // no fixture
      forceFixtures: false,
      liveConfig: { apiKey: "test-key" },
    });
    const result = await adapter.fetch({ canonicalAssets: new Map() });
    // No fixture → return null data with the failure recorded on
    // the adapter so the runtime can mark the stage degraded.
    expect(result).toHaveLength(1);
    expect(result[0]?.data).toBeNull();
    expect(adapter.lastNetworkError).toMatch(/500/);
    // The adapter's health should reflect the failure.
    expect(adapter.health().status).toBe("degraded");
  });

  it("cmc-no-fixture-with-credentials-needed: when no live key, the FetchResult reflects the credentials-needed state", async () => {
    const adapter = new CMCAdapter();
    adapter.configure({
      baseUrl: "https://pro-api.coinmarketcap.com",
      fixturePath: undefined,
      forceFixtures: false,
      // No liveConfig → credentials-needed
    });
    const result = await adapter.fetch({ canonicalAssets: new Map() });
    expect(result).toHaveLength(1);
    expect(result[0]?.data).toBeNull();
    expect(adapter.health().status).toBe("credentials-needed");
  });
});
