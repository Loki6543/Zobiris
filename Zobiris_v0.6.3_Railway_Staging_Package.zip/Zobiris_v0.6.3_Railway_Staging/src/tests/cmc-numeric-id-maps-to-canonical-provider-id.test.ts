/**
 * v0.4.3 audit regression test (required #3)
 * Test: cmc-numeric-id-maps-to-canonical-provider-id
 *
 * Per the v0.4.3 audit: "CMC normalizer receives numeric provider IDs
 * from the quotes payload (1, 1027, 5426, ...), but the canonical
 * mapping file stores CMC values as slugs (bitcoin, ethereum, solana,
 * ...). Therefore the provider-ID lookup does not match and CMC falls
 * through to the symbol-only fallback."
 *
 * v0.4.3 fix: the typed providerIds object has separate `cmcNumericId`
 * and `cmcSlug` fields. The CMC normalizer passes the numeric id from
 * the quotes payload as `providerAssetId`; the resolver looks up by
 * the `cmcNumericId` field first. This test asserts the lookup path.
 */

import { describe, it, expect } from "vitest";
import { lookupCanonicalIdentity } from "../providers/canonicalResolve.js";
import type { ProviderIds } from "../providers/canonicalResolve.js";

describe("v0.4.3 P0-1: CMC numeric id maps to canonical provider-id", () => {
  const btcAsset: { id: string; providerIds: ProviderIds; symbol: string } = {
    id: "cn-btc-0001",
    symbol: "BTC",
    providerIds: {
      cmcNumericId: "1",
      cmcSlug: "bitcoin",
    },
  };
  const ethAsset: { id: string; providerIds: ProviderIds; symbol: string } = {
    id: "cn-eth-1027",
    symbol: "ETH",
    providerIds: {
      cmcNumericId: "1027",
      cmcSlug: "ethereum",
    },
  };
  const assets = [btcAsset, ethAsset];

  it("CMC numeric id 1 (BTC) matches cmcNumericId", () => {
    const result = lookupCanonicalIdentity(
      { provider: "cmc", providerAssetId: "1", symbol: "BTC" },
      assets,
    );
    expect(result).not.toBeNull();
    expect(result!.canonicalAssetId).toBe("cn-btc-0001");
    expect(result!.matchMethod).toBe("provider-id");
    expect(result!.mappingStatus).toBe("verified");
    expect(result!.mappingConfidence).toBe(1.0);
  });

  it("CMC numeric id 1027 (ETH) matches cmcNumericId", () => {
    const result = lookupCanonicalIdentity(
      { provider: "cmc", providerAssetId: "1027", symbol: "ETH" },
      assets,
    );
    expect(result).not.toBeNull();
    expect(result!.canonicalAssetId).toBe("cn-eth-1027");
    expect(result!.matchMethod).toBe("provider-id");
  });

  it("CMC slug 'bitcoin' matches cmcSlug (when no numeric id provided)", () => {
    const result = lookupCanonicalIdentity(
      { provider: "cmc", providerAssetId: "bitcoin", symbol: "BTC" },
      assets,
    );
    expect(result).not.toBeNull();
    expect(result!.canonicalAssetId).toBe("cn-btc-0001");
    expect(result!.matchMethod).toBe("provider-slug");
    expect(result!.mappingStatus).toBe("verified");
  });

  it("an unknown CMC numeric id falls through to symbol-only (ambiguous)", () => {
    const result = lookupCanonicalIdentity(
      { provider: "cmc", providerAssetId: "999999", symbol: "BTC" },
      assets,
    );
    expect(result).not.toBeNull();
    expect(result!.mappingStatus).toBe("ambiguous");
    expect(result!.matchMethod).toBe("symbol-only");
  });
});
