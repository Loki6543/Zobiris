import { afterAll, beforeAll, describe, expect, it, vi } from "vitest";
import { mkdtempSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import type { AddressInfo } from "node:net";
import type { Server } from "node:http";

describe("production mutation authorization on the real server", () => {
  let server: Server | undefined;
  let directory: string;
  let baseUrl: string;

  beforeAll(async () => {
    directory = mkdtempSync(join(tmpdir(), "zobiris-production-auth-"));
    vi.stubEnv("NODE_ENV", "production");
    vi.stubEnv("ZOBIRIS_DB_PATH", join(directory, "test.db"));
    vi.stubEnv("ZOBIRIS_REFRESH_TOKEN", "production-test-only");
    vi.stubEnv("ZOBIRIS_ALLOW_ANONYMOUS_REFRESH", "1");
    vi.stubEnv("ZOBIRIS_ALLOW_LIVE_PROVIDERS", "0");
    vi.stubEnv("OPENAI_API_KEY", "");
    vi.resetModules();
    const { createZobirisServer } = await import("../server/server.js");
    server = createZobirisServer();
    await new Promise<void>((resolve, reject) => {
      server!.once("error", reject);
      server!.listen(0, "127.0.0.1", resolve);
    });
    baseUrl = `http://127.0.0.1:${(server.address() as AddressInfo).port}`;
  });

  afterAll(async () => {
    server?.closeAllConnections();
    if (server?.listening) await new Promise<void>((resolve) => server!.close(() => resolve()));
    if (directory) rmSync(directory, { recursive: true, force: true });
    vi.unstubAllEnvs();
  });

  it.each(["/api/refresh", "/api/strategy21/collect", "/api/agents/challenge"])(
    "%s rejects anonymous and incorrect credentials even with anonymous-refresh opt-in",
    async (path) => {
      for (const authorization of [undefined, "Bearer incorrect"]) {
        const response = await fetch(`${baseUrl}${path}`, {
          method: "POST",
          headers: authorization ? { Authorization: authorization } : {},
        });
        expect(response.status).toBe(401);
        expect(response.headers.get("content-type")).toContain("application/json");
      }
    },
  );

  it("valid credentials reach the protected handler", async () => {
    const response = await fetch(`${baseUrl}/api/agents/challenge`, {
      method: "POST", headers: { Authorization: "Bearer production-test-only" },
    });
    expect(response.status).toBe(503);
    expect(await response.json()).toEqual({ error: "OpenAI challenger is not configured" });
  });
});
