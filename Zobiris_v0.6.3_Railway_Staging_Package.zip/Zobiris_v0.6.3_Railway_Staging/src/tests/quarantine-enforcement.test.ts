/**
 * v0.4.4 audit fix (P0-1): quarantine enforcement.
 *
 * The audit caught that v0.4.3 correctly LABELS an ambiguous match
 * with `quarantineState: "ambiguous"`, but downstream paths (the
 * specialist orchestrator, the evidence summaries, the scoring
 * pass) do not actually CHECK the status. An ambiguous observation
 * could still affect factor state, increase coverage, and
 * contribute to a score.
 *
 * v0.4.4 adds a hard invariant: ambiguous/quarantined evidence can
 * be DISPLAYED (for investigation in the case file) but it cannot
 * affect scoring, factor confidence, specialists, ranks, or
 * target weights.
 *
 * This test pins the v0.4.4 invariant end-to-end.
 */
import { describe, it, expect, beforeEach, afterEach } from "vitest";
import { openStorage } from "../storage/client.js";
import { isObservationEligibleForAnalysis, partitionObservationsByEligibility, eligibleObservations } from "../providers/eligibility.js";
import type { NormalizedObservation } from "../domain/index.js";

function makeObs(overrides: Partial<NormalizedObservation>): NormalizedObservation {
  return {
    id: "obs-" + Math.random().toString(36).slice(2),
    idempotencyKey: "ik-" + Math.random().toString(36).slice(2),
    provider: "cmc",
    providerEventId: "1",
    eventType: "quote",
    schemaVersion: "1.0.0",
    canonicalAssetId: "cn-btc",
    quarantineState: "verified",
    identityMatchMethod: "provider-id",
    occurredAt: new Date().toISOString(),
    receivedAt: new Date().toISOString(),
    retrievedAt: new Date().toISOString(),
    normalizerVersion: "1.0.0",
    payload: {},
    ...overrides,
  } as NormalizedObservation;
}

describe("v0.4.4 P0-1: quarantine enforcement", () => {
  let sqlite: { close: () => void };

  beforeEach(() => {
    const opened = openStorage({ path: ":memory:" });
    void opened.db;
    sqlite = opened.sqlite;
  });
  afterEach(() => sqlite?.close());

  it("ambiguous observations are NOT eligible for analysis", () => {
    const verified = makeObs({ quarantineState: "verified", identityMatchMethod: "provider-id" });
    const ambiguous = makeObs({ quarantineState: "ambiguous" });
    const unmapped = makeObs({ quarantineState: "unmapped" });
    const quarantined = makeObs({ quarantineState: "quarantined" });
    expect(isObservationEligibleForAnalysis(verified)).toBe("eligible");
    expect(isObservationEligibleForAnalysis(ambiguous)).toBe("display_only_ambiguous");
    expect(isObservationEligibleForAnalysis(unmapped)).toBe("display_only_ambiguous");
    expect(isObservationEligibleForAnalysis(quarantined)).toBe("quarantined");
  });

  it("partitionObservationsByEligibility sorts into the four buckets", () => {
    const obs = [
      makeObs({ id: "a", quarantineState: "verified", identityMatchMethod: "provider-id" }),
      makeObs({ id: "b", quarantineState: "ambiguous" }),
      makeObs({ id: "c", quarantineState: "unmapped" }),
      makeObs({ id: "d", quarantineState: "quarantined" }),
    ];
    const parts = partitionObservationsByEligibility(obs);
    expect(parts.eligible.map(o => o.id).sort()).toEqual(["a"]);
    expect(parts.displayOnlyAmbiguous.map(o => o.id).sort()).toEqual(["b", "c"]);
    expect(parts.quarantined.map(o => o.id).sort()).toEqual(["d"]);
    expect(parts.rejected).toEqual([]);
  });

  it("eligibleObservations() filters out all non-eligible observations", () => {
    // The audit's smoking gun: ambiguous observations were
    // passed to specialists, which means they influenced the
    // case file. v0.4.4 partitions before specialists run and
    // records what was excluded.
    const obs = [
      makeObs({ id: "verified-1", quarantineState: "verified", identityMatchMethod: "provider-id", canonicalAssetId: "cn-btc" }),
      makeObs({ id: "ambiguous-1", quarantineState: "ambiguous", canonicalAssetId: "cn-btc" }),
      makeObs({ id: "unmapped-1", quarantineState: "unmapped", canonicalAssetId: "cn-btc" }),
      makeObs({ id: "symbol-only-1", quarantineState: "verified", identityMatchMethod: "symbol-only", canonicalAssetId: "cn-btc" }),
    ];
    const eligible = eligibleObservations(obs);
    expect(eligible.map(o => o.id)).toEqual(["verified-1"]);
    // The symbol-only match is excluded even though
    // quarantineState was "verified" — that's the v0.4.4 invariant.
    expect(eligible.length).toBe(1);
  });
});
