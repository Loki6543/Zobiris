/**
 * P0 #2 regression test — the release ZIP must include the actual UI source.
 *
 * Per the audit: "A full source release must include the actual current UI
 * source. ... Release ZIP must be sufficient to reproduce the deployed site."
 */

import { describe, it, expect } from "vitest";
import { readFileSync, existsSync } from "node:fs";
import { resolve } from "node:path";

describe("P0 #2: release ZIP includes the UI source", () => {
  const publicDir = resolve(process.cwd(), "public");
  it("public/ exists in the repo", () => {
    expect(existsSync(publicDir)).toBe(true);
  });

  it("public/index.html, public/app.js, public/style.css all exist", () => {
    for (const f of ["public/index.html", "public/app.js", "public/style.css"]) {
      expect(existsSync(resolve(process.cwd(), f)), `${f} must exist`).toBe(true);
    }
  });

  it("build_manifest.mjs no longer excludes public/", () => {
    const m = readFileSync(resolve(process.cwd(), "scripts/build_manifest.mjs"), "utf8");
    // The previous bug: line  `"public", // legacy static demo (deployed separately)`.
    // After the v0.4.1 fix, public/ is NOT in the EXCLUDE set.
    expect(m).not.toMatch(/^\s*"public",/m);
  });

  it("public/app.js includes navigation entries for the deployed routes", () => {
    const app = readFileSync(resolve(process.cwd(), "public/app.js"), "utf8");
    // The deployed SPA should at least expose Dashboard, Assets, Specialists, Providers, Audit.
    for (const route of ["dashboard", "assets", "specialists", "providers", "audit"]) {
      expect(app.includes(`"${route}"`), `route ${route} missing in app.js`).toBe(true);
    }
  });
});
