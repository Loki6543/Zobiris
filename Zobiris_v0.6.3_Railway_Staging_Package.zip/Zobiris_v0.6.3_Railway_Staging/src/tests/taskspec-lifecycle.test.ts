/**
 * Tests for the Iyaza Addendum TaskSpec + lifecycle.
 */
import { describe, it, expect } from "vitest";
import {
  compileRefreshTaskSpec,
  taskSpecSchema,
} from "../tasks/spec.js";
import {
  TaskLifecycleTracker,
  TaskLifecycleStore,
  IllegalTransitionError,
} from "../tasks/lifecycle.js";

describe("TaskSpec", () => {
  it("compileRefreshTaskSpec returns a valid spec with all required fields", () => {
    const spec = compileRefreshTaskSpec({
      effortMode: "daily",
      pointInTimeCutoff: "2026-08-22T03:00:00.000Z",
    });
    expect(spec.taskId).toMatch(/^task-/);
    expect(spec.taskType).toBe("refresh.daily");
    expect(spec.effortMode).toBe("daily");
    expect(spec.riskClass).toBe("write_candidate");
    expect(spec.explicitConstraints.length).toBeGreaterThan(0);
    expect(spec.acceptanceCriteria.length).toBeGreaterThan(0);
    expect(spec.requiredCapabilities.length).toBeGreaterThan(0);
    expect(spec.requestedArtifacts.length).toBeGreaterThan(0);
    expect(spec.stopConditions.length).toBeGreaterThan(0);
    expect(spec.verificationRequirements.length).toBeGreaterThan(0);
  });

  it("Zod schema rejects missing required fields", () => {
    const r = taskSpecSchema.safeParse({});
    expect(r.success).toBe(false);
  });

  it("Zod schema accepts a fully populated spec", () => {
    const spec = compileRefreshTaskSpec({ effortMode: "deep", pointInTimeCutoff: "2026-08-22T03:00:00.000Z" });
    const r = taskSpecSchema.safeParse(spec);
    expect(r.success).toBe(true);
  });
});

describe("TaskLifecycleTracker", () => {
  it("starts at NEW", () => {
    const t = new TaskLifecycleTracker("task-1");
    expect(t.currentState()).toBe("NEW");
    expect(t.isTerminal()).toBe(false);
  });

  it("rejects illegal transition NEW -> IN_PROGRESS", () => {
    const t = new TaskLifecycleTracker("task-1");
    expect(() => t.transition("IN_PROGRESS")).toThrow(IllegalTransitionError);
  });

  it("supports happy path NEW -> ACK -> DISPATCHED -> IN_PROGRESS -> COMPLETED", () => {
    const t = new TaskLifecycleTracker("task-1");
    t.transition("ACKNOWLEDGED");
    t.transition("DISPATCHED");
    t.transition("IN_PROGRESS");
    t.transition("COMPLETED");
    expect(t.currentState()).toBe("COMPLETED");
    expect(t.isTerminal()).toBe(true);
  });

  it("supports STALLED -> RETRYING -> IN_PROGRESS -> COMPLETED", () => {
    const t = new TaskLifecycleTracker("task-1");
    t.transition("ACKNOWLEDGED");
    t.transition("DISPATCHED");
    t.transition("IN_PROGRESS");
    t.transition("STALLED");
    t.transition("RETRYING");
    t.transition("IN_PROGRESS");
    t.transition("COMPLETED");
    expect(t.currentState()).toBe("COMPLETED");
  });

  it("supports STALLED -> ESCALATED", () => {
    const t = new TaskLifecycleTracker("task-1");
    t.transition("ACKNOWLEDGED");
    t.transition("DISPATCHED");
    t.transition("IN_PROGRESS");
    t.transition("STALLED");
    t.transition("ESCALATED");
    expect(t.currentState()).toBe("ESCALATED");
    expect(t.isTerminal()).toBe(true);
  });

  it("COMPLETED is terminal (any transition out throws)", () => {
    const t = new TaskLifecycleTracker("task-1");
    t.transition("ACKNOWLEDGED");
    t.transition("DISPATCHED");
    t.transition("IN_PROGRESS");
    t.transition("COMPLETED");
    expect(() => t.transition("IN_PROGRESS")).toThrow(IllegalTransitionError);
  });

  it("CANCELLED is terminal", () => {
    const t = new TaskLifecycleTracker("task-1");
    t.transition("CANCELLED");
    expect(t.isTerminal()).toBe(true);
    expect(() => t.transition("IN_PROGRESS")).toThrow(IllegalTransitionError);
  });

  it("FAILED is terminal", () => {
    const t = new TaskLifecycleTracker("task-1");
    t.transition("ACKNOWLEDGED");
    t.transition("DISPATCHED");
    t.transition("IN_PROGRESS");
    t.transition("FAILED");
    expect(t.isTerminal()).toBe(true);
  });

  it("history records all transitions with timestamps", () => {
    const t = new TaskLifecycleTracker("task-1");
    t.transition("ACKNOWLEDGED");
    t.transition("DISPATCHED");
    t.transition("IN_PROGRESS");
    t.transition("COMPLETED");
    const h = t.history();
    expect(h.length).toBe(5); // initial + 4 transitions
    for (const e of h) {
      expect(typeof e.at).toBe("string");
      expect(new Date(e.at).toString()).not.toBe("Invalid Date");
    }
  });

  it("emits JSONL events to a custom sink", () => {
    const events: string[] = [];
    const t = new TaskLifecycleTracker("task-1", (line) => events.push(line));
    t.transition("ACKNOWLEDGED");
    t.transition("DISPATCHED");
    expect(events.length).toBe(3); // initial + 2 transitions
    for (const e of events) {
      expect(() => JSON.parse(e)).not.toThrow();
    }
  });
});

describe("TaskLifecycleStore", () => {
  it("creates, gets, and lists trackers", () => {
    const s = new TaskLifecycleStore();
    const t1 = s.create("task-1");
    const t2 = s.create("task-2");
    expect(s.get("task-1")).toBe(t1);
    expect(s.get("task-2")).toBe(t2);
    expect(s.get("nonexistent")).toBeNull();
    expect(s.list().length).toBe(2);
  });

  it("rejects duplicate task creation", () => {
    const s = new TaskLifecycleStore();
    s.create("task-1");
    expect(() => s.create("task-1")).toThrow();
  });
});
