/**
 * v0.4.3 audit regression test (required #8)
 * Test: coinmarketcal-estimated-display-date
 *
 * Per the v0.4.3 audit (P0-4): "More importantly, the production schema
 * still expects legacy fields. The live test mocks the legacy snake_case
 * body, so it does not prove v2 compatibility." v0.4.3 also fixes the
 * estimated-date handling so the UI can render the v2
 * `displayedDate` without converting an estimated window into a
 * falsely-precise timestamp.
 *
 * Per docs/DATA_PLANE.md: "respect isEstimated and render displayedDate;
 * do not convert an estimated window into a falsely precise timestamp."
 */

import { describe, it, expect } from "vitest";
import { CoinMarketCalAdapter } from "../providers/coinmarketcal.js";

describe("v0.4.3 P0-4: CoinMarketCal estimated-date handling is honest", () => {
  const adapter = new CoinMarketCalAdapter();

  it("isEstimated=true is preserved in the payload (v1 + v2 fields)", () => {
    const obs = adapter.normalize(
      { data: [{ id: 1, title: "TBD", coins: [{ symbol: "BTC" }], date: "2026-12-31T00:00:00Z", isEstimated: true, displayedDate: "Q4 2026" }] },
      { canonicalAssets: new Map(), endpoint: "events", receivedAt: new Date().toISOString(), rawSchemaVersion: "1.0.0" },
    );
    expect(obs).toHaveLength(1);
    const p = obs[0]!.payload as Record<string, any>;
    expect(p.isEstimated).toBe(true);
    expect(p.displayDate).toBe("Q4 2026");
  });

  it("epistemicState is INFERRED when isEstimated is true", () => {
    const obs = adapter.normalize(
      { data: [{ id: 1, title: "TBD", coins: [{ symbol: "BTC" }], date: "2026-12-31T00:00:00Z", isEstimated: true }] },
      { canonicalAssets: new Map(), endpoint: "events", receivedAt: new Date().toISOString(), rawSchemaVersion: "1.0.0" },
    );
    expect(obs[0]!.epistemicState).toBe("INFERRED");
  });

  it("epistemicState is KNOWN when isEstimated is false (verified event)", () => {
    const obs = adapter.normalize(
      { data: [{ id: 2, title: "Confirmed", coins: [{ symbol: "BTC" }], date: "2026-01-15T00:00:00Z", isEstimated: false, displayedDate: "Jan 15 2026" }] },
      { canonicalAssets: new Map(), endpoint: "events", receivedAt: new Date().toISOString(), rawSchemaVersion: "1.0.0" },
    );
    expect(obs[0]!.epistemicState).toBe("KNOWN");
  });

  it("v1 snake_case is_estimated is also respected", () => {
    const obs = adapter.normalize(
      { data: [{ id: 3, title: "v1 event", coins: [{ symbol: "BTC" }], date_event: "2026-12-31T00:00:00Z", is_estimated: true, display_date: "Q4 2026" }] },
      { canonicalAssets: new Map(), endpoint: "events", receivedAt: new Date().toISOString(), rawSchemaVersion: "1.0.0" },
    );
    expect(obs[0]!.epistemicState).toBe("INFERRED");
    const p = obs[0]!.payload as Record<string, any>;
    expect(p.isEstimated).toBe(true);
    expect(p.displayDate).toBe("Q4 2026");
  });

  it("displayedDate is preserved as a string (no false-precision conversion)", () => {
    // The audit caught that the v1 path used a single date_event even
    // for estimated windows. v0.4.3 keeps the rendered displayedDate
    // ("Q4 2026") in the payload so the UI can show "Q4 2026" rather
    // than a precise timestamp that the event doesn't deserve.
    const obs = adapter.normalize(
      { data: [{ id: 4, title: "TBD", coins: [{ symbol: "BTC" }], date: "2026-12-31T00:00:00Z", isEstimated: true, displayedDate: "Q4 2026" }] },
      { canonicalAssets: new Map(), endpoint: "events", receivedAt: new Date().toISOString(), rawSchemaVersion: "1.0.0" },
    );
    const p = obs[0]!.payload as Record<string, any>;
    // occurredAt is the precise date (so we know it was set), but
    // displayedDate is the honest UI string.
    expect(typeof p.displayDate).toBe("string");
    expect(p.displayDate).toBe("Q4 2026");
  });
});
