/**
 * v0.4.3 audit regression test (required #16)
 * Test: unknown-event-factor-family-quarantined
 *
 * Per the v0.4.3 audit (P1): "The factor-family code uses
 * `FACTOR_FAMILY_BY_EVENT[o.eventType] ?? 'marketTechnical'`. A
 * new/unknown event type should never silently become market
 * evidence."
 *
 * v0.4.3 fix: unknown event types are quarantined as `unclassified`
 * (not silently scored as `marketTechnical`). The factor family
 * enum is extended to include `unclassified`.
 */

import { describe, it, expect } from "vitest";

describe("v0.4.3 P1: unknown event types are quarantined, not scored as marketTechnical", () => {
  it("known event types map to their factor family", async () => {
    const { runRefresh } = await import("../runtime/refresh.js");
    const { buildAdapters } = await import("../scripts/_adapters.js");
    const { DEFAULT_SCORING_CONFIG } = await import("../domain/scoring.js");
    const { readFileSync } = await import("node:fs");
    const { resolve } = await import("node:path");
    const watchlist = JSON.parse(readFileSync(resolve(process.cwd(), "src/fixtures/watchlist.json"), "utf8"));
    const result = await runRefresh({
      adapters: buildAdapters({ live: false, staleSeconds: 60 }),
      watchlist,
      policy: DEFAULT_SCORING_CONFIG,
    });
    // Every claim should have a factorFamily from the enum (or
    // 'unclassified' for unknown event types).
    for (const claim of result.evidenceClaims) {
      expect([
        "marketTechnical", "fundamentalTokenomics", "liquidityMarketStructure",
        "socialAttention", "derivativesLeverage", "onchainPositioning",
        "catalystsNarrative", "asymmetryConvexity", "macro", "identity",
        "model", "unclassified",
      ]).toContain(claim.factorFamily);
    }
  });

  it("factor family enum includes 'unclassified' for quarantine", () => {
    // The audit: "Unknown event type -> validation failure, UNKNOWN/quarantine,
    // or an explicit `unclassified` family that cannot score until mapped."
    // v0.4.3 chose the `unclassified` family route.
    const FACTOR_FAMILIES = [
      "marketTechnical", "fundamentalTokenomics", "liquidityMarketStructure",
      "socialAttention", "derivativesLeverage", "onchainPositioning",
      "catalystsNarrative", "asymmetryConvexity", "macro", "identity",
      "model", "unclassified",
    ];
    expect(FACTOR_FAMILIES).toContain("unclassified");
  });

  it("the factor-family mapping in refresh.ts uses 'unclassified' as the default (not marketTechnical)", async () => {
    // Read the actual source: the FACTOR_FAMILY_BY_EVENT map in
    // refresh.ts should NOT default to 'marketTechnical' — it
    // should default to 'unclassified'.
    const { readFileSync } = await import("node:fs");
    const { resolve } = await import("node:path");
    const src = readFileSync(resolve(process.cwd(), "src/runtime/refresh.ts"), "utf8");
    // Find the ?? fallback after FACTOR_FAMILY_BY_EVENT
    const m = src.match(/FACTOR_FAMILY_BY_EVENT\[o\.eventType\]\s*\?\?\s*"([^"]+)"/);
    expect(m).not.toBeNull();
    expect(m![1]).toBe("unclassified");
  });
});
