/**
 * v0.4.4 regression: persistRefresh MUST thread identityProvenance through
 * to the canonical_assets table. Earlier builds had
 * `upsertCanonicalFromWatchlist` in src/providers/identity.ts dropping the
 * field, so every persisted row had identity_provenance = null even though
 * the in-memory canonicalMap had it set. This test guards against that.
 */

import { describe, it, expect, beforeEach, afterEach } from "vitest";
import { mkdtempSync, rmSync } from "node:fs";
import { join } from "node:path";
import { tmpdir } from "node:os";
import { openStorage } from "../storage/client.js";
import { persistRefresh } from "../storage/integration.js";
import { runRefresh } from "../runtime/refresh.js";
import { loadWatchlist } from "../scripts/_watchlist.js";
import { buildAdapters } from "../scripts/_adapters.js";
import { DEFAULT_SCORING_CONFIG } from "../domain/scoring.js";

describe("v0.4.4 P0 #5 follow-up: identityProvenance is persisted", () => {
  let tmp: string;
  let dbPath: string;

  beforeEach(() => {
    tmp = mkdtempSync(join(tmpdir(), "zobiris-ip-"));
    dbPath = join(tmp, "test.db");
  });

  afterEach(() => {
    rmSync(tmp, { recursive: true, force: true });
  });

  it("first refresh: every canonical asset row has identity_provenance set", async () => {
    const adapters = buildAdapters({ staleSeconds: 60, live: false });
    const watchlist = await loadWatchlist();
    const result = await runRefresh({
      mode: "deep",
      watchlist,
      policy: DEFAULT_SCORING_CONFIG,
      adapters,
      dbPath,
    });
    const db = openStorage({ path: dbPath });
    try {
      persistRefresh({
        db: db.db,
        watchlist,
        observations: result.observations,
        evidenceClaims: result.evidenceClaims,
        snapshot: result.snapshot,
        canonicalMap: result.canonicalMap,
        providerHealthUpdates: result.providerHealthUpdates,
      });
      const rows = db.sqlite
        .prepare("SELECT symbol, identity_provenance FROM canonical_assets ORDER BY symbol")
        .all() as Array<{ symbol: string; identity_provenance: string | null }>;
      expect(rows.length).toBe(watchlist.length);
      const nullCount = rows.filter((r) => r.identity_provenance == null).length;
      expect(nullCount, `expected zero null identity_provenance rows, got ${nullCount}`).toBe(0);
      // All should be one of the v0.4.4 enum values.
      const valid = new Set(["uuidv4-initial", "uuidv4-persisted", "persistence-rehydrated", "fallback"]);
      const invalid = rows.filter((r) => r.identity_provenance == null || !valid.has(r.identity_provenance));
      expect(invalid, `unexpected identity_provenance values: ${JSON.stringify(invalid)}`).toEqual([]);
    } finally {
      db.close();
    }
  });

  it("second refresh (same DB): the persisted identity_provenance survives", async () => {
    // First refresh
    const adapters1 = buildAdapters({ staleSeconds: 60, live: false });
    const watchlist = await loadWatchlist();
    const r1 = await runRefresh({
      mode: "deep",
      watchlist,
      policy: DEFAULT_SCORING_CONFIG,
      adapters: adapters1,
      dbPath,
    });
    const db1 = openStorage({ path: dbPath });
    try {
      persistRefresh({
        db: db1.db,
        watchlist,
        observations: r1.observations,
        evidenceClaims: r1.evidenceClaims,
        snapshot: r1.snapshot,
        canonicalMap: r1.canonicalMap,
        providerHealthUpdates: r1.providerHealthUpdates,
      });
    } finally {
      db1.close();
    }
    // Second refresh on the same DB
    const adapters2 = buildAdapters({ staleSeconds: 60, live: false });
    const r2 = await runRefresh({
      mode: "deep",
      watchlist,
      policy: DEFAULT_SCORING_CONFIG,
      adapters: adapters2,
      dbPath,
    });
    const db2 = openStorage({ path: dbPath });
    try {
      persistRefresh({
        db: db2.db,
        watchlist,
        observations: r2.observations,
        evidenceClaims: r2.evidenceClaims,
        snapshot: r2.snapshot,
        canonicalMap: r2.canonicalMap,
        providerHealthUpdates: r2.providerHealthUpdates,
      });
      // Re-read BTC: the canonicalAssetId should match r1's (immutable), and
      // identity_provenance should be "uuidv4-persisted" because the second
      // refresh rehydrated from DB.
      const btc1 = r1.canonicalMap.get("BTC");
      const btc2 = r2.canonicalMap.get("BTC");
      expect(btc1).toBeDefined();
      expect(btc2).toBeDefined();
      expect(btc1?.id).toBeDefined();
      expect(btc2?.id).toBe(btc1?.id);
      expect(btc2?.identityProvenance).toBe("uuidv4-persisted");

      const btcRow = db2.sqlite
        .prepare("SELECT identity_provenance FROM canonical_assets WHERE symbol = ?")
        .get("BTC") as { identity_provenance: string };
      expect(btcRow.identity_provenance).toBe("uuidv4-persisted");
    } finally {
      db2.close();
    }
  });
});
