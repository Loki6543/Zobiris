/**
 * Specialist tests — slice 5+ v0.4.0.
 */

import { describe, it, expect } from "vitest";
import { randomUUID } from "node:crypto";
import { type CanonicalAsset, type NormalizedObservation } from "../domain/index.js";
import {
  marketStructureSpecialist,
  derivativesSpecialist,
  socialSpecialist,
  riskSpecialist,
  reconcilerSpecialist,
  challengerSpecialist,
  portfolioSpecialist,
  orchestrate,
  aggregateAcrossAssets,
  getSpecialistRegistry,
  summarizeAllocations,
  type SpecialistOpinion,
} from "../specialists/index.js";
import { type PortfolioAllocationResult } from "../specialists/portfolio.js";

function makeCanonical(symbol: string, mappingStatus: "verified" | "ambiguous" | "unmapped" | "quarantined" = "verified"): CanonicalAsset {
  return {
    id: randomUUID(),
    symbol,
    name: symbol,
    providerIds: {},
    mappingStatus,
    mappingConfidence: mappingStatus === "verified" ? 1.0 : 0.5,
    updatedAt: new Date().toISOString(),
  };
}

function makeQuoteObs(
  assetId: string,
  provider: string,
  payload: { priceUsd?: number; changePct24h?: number; volumeUsd24h?: number; marketCapUsd?: number },
  occurredAt = new Date().toISOString(),
): NormalizedObservation {
  return {
    id: randomUUID(),
    idempotencyKey: `${assetId}:${provider}:${occurredAt}`,
    provider,
    providerEventId: `${assetId}:${occurredAt}`,
    eventType: "quote",
    schemaVersion: "1.0.0",
    canonicalAssetId: assetId,
    quarantineState: "verified",
    occurredAt,
    receivedAt: occurredAt,
    retrievedAt: occurredAt,
    normalizerVersion: "0.1.0",
    payload,
    epistemicState: "KNOWN",
    evidenceConfidence: 0.95,
    licenseClass: "display-only",
  };
}

function makeFundingObs(
  assetId: string,
  rate: number,
  provider: string,
): NormalizedObservation {
  return {
    id: randomUUID(),
    idempotencyKey: `${assetId}:${provider}:funding:${Date.now()}`,
    provider,
    providerEventId: `${assetId}:funding:${Date.now()}`,
    eventType: "funding",
    schemaVersion: "1.0.0",
    canonicalAssetId: assetId,
    quarantineState: "verified",
    occurredAt: new Date().toISOString(),
    receivedAt: new Date().toISOString(),
    retrievedAt: new Date().toISOString(),
    normalizerVersion: "0.1.0",
    payload: { rate, exchange: "binance" },
    epistemicState: "KNOWN",
    evidenceConfidence: 0.9,
    licenseClass: "display-only",
  };
}

function makeSocialObs(
  assetId: string,
  payload: { mentions24h?: number; sentiment?: number; socialDominance?: number },
  provider = "lunarcrush",
): NormalizedObservation {
  return {
    id: randomUUID(),
    idempotencyKey: `${assetId}:${provider}:social:${Date.now()}`,
    provider,
    providerEventId: `${assetId}:social:${Date.now()}`,
    eventType: "social",
    schemaVersion: "1.0.0",
    canonicalAssetId: assetId,
    quarantineState: "verified",
    occurredAt: new Date().toISOString(),
    receivedAt: new Date().toISOString(),
    retrievedAt: new Date().toISOString(),
    normalizerVersion: "0.1.0",
    payload,
    epistemicState: "KNOWN",
    evidenceConfidence: 0.7,
    licenseClass: "display-only",
  };
}

describe("specialist pool — individual specialists", () => {
  it("market_structure emits bullish thesis on +5% 24h", async () => {
    const a = makeCanonical("BTC");
    const obs = makeQuoteObs(a.id, "kraken", { priceUsd: 60000, changePct24h: 5.0, volumeUsd24h: 1_000_000_000, marketCapUsd: 1_200_000_000_000 });
    const result = await marketStructureSpecialist.run({ canonicalAsset: a, observations: [obs], priorOpinions: [], seed: 1 });
    expect(result.ok).toBe(true);
    if (!result.ok) return;
    expect(result.opinions).toHaveLength(1);
    expect(firstOp(result.opinions).direction).toBe("bullish");
    expect(firstOp(result.opinions).type).toBe("thesis");
  });

  it("market_structure emits strongly_bearish on -10% 24h with low volume", async () => {
    const a = makeCanonical("TOKEN");
    const obs = makeQuoteObs(a.id, "kraken", { priceUsd: 1, changePct24h: -10.0, volumeUsd24h: 50_000, marketCapUsd: 1_000_000 });
    const result = await marketStructureSpecialist.run({ canonicalAsset: a, observations: [obs], priorOpinions: [], seed: 1 });
    expect(result.ok).toBe(true);
    if (!result.ok) return;
    expect(firstOp(result.opinions).direction).toBe("strongly_bearish");
  });

  it("market_structure fails when no quote observations", async () => {
    const a = makeCanonical("BTC");
    const result = await marketStructureSpecialist.run({ canonicalAsset: a, observations: [], priorOpinions: [], seed: 1 });
    expect(result.ok).toBe(false);
    if (result.ok) return;
    expect(result.error.code).toBe("NO_QUOTES");
    expect(result.error.oepOutcome).toBe("INSUFFICIENT_EVIDENCE");
  });

  it("derivatives_positioning reads hot funding as bullish", async () => {
    const a = makeCanonical("BTC");
    const obs = makeFundingObs(a.id, 0.0005, "coinglass");
    const result = await derivativesSpecialist.run({ canonicalAsset: a, observations: [obs], priorOpinions: [], seed: 1 });
    expect(result.ok).toBe(true);
    if (!result.ok) return;
    expect(firstOp(result.opinions).direction).toMatch(/^strongly_bullish$|^bullish$/);
  });

  it("derivatives_positioning returns INSUFFICIENT_EVIDENCE when no data", async () => {
    const a = makeCanonical("BTC");
    const result = await derivativesSpecialist.run({ canonicalAsset: a, observations: [], priorOpinions: [], seed: 1 });
    expect(result.ok).toBe(false);
  });

  it("social_attention reduces conviction when only one provider", async () => {
    const a = makeCanonical("DOGE");
    const obs = makeSocialObs(a.id, { mentions24h: 50_000, sentiment: 0.6, socialDominance: 0.02 });
    const result = await socialSpecialist.run({ canonicalAsset: a, observations: [obs], priorOpinions: [], seed: 1 });
    expect(result.ok).toBe(true);
    if (!result.ok) return;
    expect(firstOp(result.opinions).confidence).toBe("speculative"); // single-provider penalty
  });

  it("social_attention reads multi-provider consensus as tentative", async () => {
    const a = makeCanonical("DOGE");
    const obs1 = makeSocialObs(a.id, { mentions24h: 50_000, sentiment: 0.6 }, "lunarcrush");
    const obs2 = makeSocialObs(a.id, { mentions24h: 48_000, sentiment: 0.55 }, "twitter");
    const result = await socialSpecialist.run({ canonicalAsset: a, observations: [obs1, obs2], priorOpinions: [], seed: 1 });
    expect(result.ok).toBe(true);
    if (!result.ok) return;
    expect(firstOp(result.opinions).confidence).not.toBe("speculative");
  });

  it("risk_compliance emits veto on quarantined asset", async () => {
    const a = makeCanonical("BAD", "quarantined");
    const result = await riskSpecialist.run({ canonicalAsset: a, observations: [], priorOpinions: [], seed: 1 });
    expect(result.ok).toBe(true);
    if (!result.ok) return;
    const flag = firstOp(result.opinions);
    expect(flag.type).toBe("risk_flag");
    expect(flag.direction).toBe("strongly_bearish");
    expect(flag.strength).toBeGreaterThanOrEqual(0.8);
    expect(flag.summary).toContain("IDENTITY_QUARANTINED");
  });

  it("risk_compliance emits no flag for healthy verified asset", async () => {
    const a = makeCanonical("BTC", "verified");
    const result = await riskSpecialist.run({ canonicalAsset: a, observations: [], priorOpinions: [], seed: 1 });
    expect(result.ok).toBe(true);
    if (!result.ok) return;
    expect(firstOp(result.opinions).direction).toBe("neutral");
    expect(firstOp(result.opinions).strength).toBe(0);
  });

  it("risk_compliance flags weak fundamentals", async () => {
    const a = makeCanonical("X", "verified");
    const result = await riskSpecialist.run({
      canonicalAsset: a,
      observations: [],
      priorOpinions: [],
      metadata: { factorScores: { fundamentalTokenomics: 0.1, liquidityMarketStructure: 0.5 } },
      seed: 1,
    });
    expect(result.ok).toBe(true);
    if (!result.ok) return;
    expect(firstOp(result.opinions).summary).toContain("WEAK_FUNDAMENTALS");
  });

  it("challenger flags overconfidence on definitive 1-evidence opinion", async () => {
    const a = makeCanonical("BTC", "verified");
    const overconfident: SpecialistOpinion = {
      id: "op-1",
      specialistId: "market_structure",
      canonicalAssetId: a.id,
      type: "thesis",
      direction: "strongly_bullish",
      confidence: "definitive",
      strength: 0.9,
      summary: "test",
      reasoning: "test",
      evidence: [{ provider: "kraken", capability: "market.quotes", description: "only one", weight: 1, freshness: "live" }],
      respondsTo: [],
      emittedAt: new Date().toISOString(),
      seed: 1,
      caveats: [],
    };
    const result = await challengerSpecialist.run({ canonicalAsset: a, observations: [], priorOpinions: [overconfident], seed: 1 });
    expect(result.ok).toBe(true);
    if (!result.ok) return;
    expect(result.opinions.some(o => o.summary.includes("OVERCONFIDENCE"))).toBe(true);
  });

  it("challenger flags independence violation (1 provider, multiple evidence)", async () => {
    const a = makeCanonical("BTC", "verified");
    const single: SpecialistOpinion = {
      id: "op-1",
      specialistId: "market_structure",
      canonicalAssetId: a.id,
      type: "thesis",
      direction: "bullish",
      confidence: "directional",
      strength: 0.7,
      summary: "test",
      reasoning: "test",
      evidence: [
        { provider: "kraken", capability: "market.quotes", description: "e1", weight: 0.5, freshness: "live" },
        { provider: "kraken", capability: "market.quotes", description: "e2", weight: 0.5, freshness: "live" },
      ],
      respondsTo: [],
      emittedAt: new Date().toISOString(),
      seed: 1,
      caveats: [],
    };
    const result = await challengerSpecialist.run({ canonicalAsset: a, observations: [], priorOpinions: [single], seed: 1 });
    expect(result.ok).toBe(true);
    if (!result.ok) return;
    expect(result.opinions.some(o => o.summary.includes("INDEPENDENCE_VIOLATION"))).toBe(true);
  });

  it("reconciler returns empty when fewer than 2 priors", async () => {
    const a = makeCanonical("BTC", "verified");
    const result = await reconcilerSpecialist.run({ canonicalAsset: a, observations: [], priorOpinions: [], seed: 1 });
    expect(result.ok).toBe(true);
    if (!result.ok) return;
    expect(result.opinions).toHaveLength(0);
  });

  it("reconciler emits bullish when all priors bullish", async () => {
    const a = makeCanonical("BTC", "verified");
    const priors: SpecialistOpinion[] = [
      mkOp("market_structure", "bullish", "directional", a.id),
      mkOp("derivatives_positioning", "bullish", "directional", a.id),
      mkOp("social_attention", "mildly_bullish", "tentative", a.id),
    ];
    const result = await reconcilerSpecialist.run({ canonicalAsset: a, observations: [], priorOpinions: priors, seed: 1 });
    expect(result.ok).toBe(true);
    if (!result.ok) return;
    expect(firstOp(result.opinions).direction).toBe("bullish");
  });

  it("portfolio_allocator returns 0% when no priors", async () => {
    const a = makeCanonical("BTC", "verified");
    const result = await portfolioSpecialist.run({ canonicalAsset: a, observations: [], priorOpinions: [], seed: 1 });
    expect(result.ok).toBe(true);
    if (!result.ok) return;
    expect(firstOp(result.opinions).strength).toBe(0);
  });

  it("portfolio_allocator caps target at 15% even with strong consensus", async () => {
    const a = makeCanonical("BTC", "verified");
    const priors: SpecialistOpinion[] = [];
    for (let i = 0; i < 5; i++) {
      priors.push({
        id: `op-${i}`,
        specialistId: "market_structure",
        canonicalAssetId: a.id,
        type: "thesis",
        direction: "strongly_bullish",
        confidence: "definitive",
        strength: 1.0,
        summary: "test",
        reasoning: "test",
        evidence: [
          { provider: "kraken", capability: "market.quotes", description: "e", weight: 0.8, freshness: "live" },
          { provider: "cmc", capability: "market.quotes", description: "e", weight: 0.8, freshness: "live" },
        ],
        respondsTo: [],
        emittedAt: new Date().toISOString(),
        seed: 1,
        caveats: [],
      });
    }
    const result = await portfolioSpecialist.run({ canonicalAsset: a, observations: [], priorOpinions: priors, seed: 1 });
    expect(result.ok).toBe(true);
    if (!result.ok) return;
    expect(firstOp(result.opinions).strength).toBeLessThanOrEqual(0.15);
  });
});

describe("orchestrator — end-to-end", () => {
  it("orchestrate runs the full pipeline in order", async () => {
    const a = makeCanonical("BTC", "verified");
    const obs = makeQuoteObs(a.id, "kraken", { priceUsd: 60000, changePct24h: 3.0, volumeUsd24h: 1e9, marketCapUsd: 1.2e12 });
    const result = await orchestrate({ canonicalAsset: a, observations: [obs], seed: 1 });
    expect(result.executionOrder).toEqual([
      "market_structure",
      "derivatives_positioning",
      "social_attention",
      "risk_compliance",
      "evidence_reconciler",
      "challenger",
      "portfolio_allocator",
    ]);
    expect(result.opinions.length).toBeGreaterThan(0);
  });

  it("orchestrate produces a reconciled view for an asset with full observations", async () => {
    const a = makeCanonical("BTC", "verified");
    const obs = [
      makeQuoteObs(a.id, "kraken", { priceUsd: 60000, changePct24h: 4.0, volumeUsd24h: 1e9, marketCapUsd: 1.2e12 }),
      makeFundingObs(a.id, 0.0002, "coinglass"),
      makeSocialObs(a.id, { mentions24h: 50_000, sentiment: 0.4, socialDominance: 0.10 }),
    ];
    const result = await orchestrate({ canonicalAsset: a, observations: obs, seed: 1 });
    expect(result.reconciled).not.toBeNull();
    expect(result.allocation).not.toBeNull();
  });

  it("orchestrate marks asset as vetoed on hard risk gate", async () => {
    const a = makeCanonical("BAD", "quarantined");
    const result = await orchestrate({ canonicalAsset: a, observations: [], seed: 1 });
    expect(result.vetoed).toBe(true);
    expect(result.allocation).not.toBeNull();
    expect(result.allocation?.targetWeightPct).toBe(0);
  });

  it("aggregateAcrossAssets sums correctly and tracks reserve", async () => {
    const a1 = makeCanonical("BTC", "verified");
    const a2 = makeCanonical("ETH", "verified");
    const a3 = makeCanonical("BAD", "quarantined");
    const obs1 = makeQuoteObs(a1.id, "kraken", { priceUsd: 60000, changePct24h: 3.0, volumeUsd24h: 1e9, marketCapUsd: 1.2e12 });
    const obs2 = makeQuoteObs(a2.id, "kraken", { priceUsd: 3000, changePct24h: 2.0, volumeUsd24h: 5e8, marketCapUsd: 3.6e11 });
    const r1 = await orchestrate({ canonicalAsset: a1, observations: [obs1], seed: 1 });
    const r2 = await orchestrate({ canonicalAsset: a2, observations: [obs2], seed: 1 });
    const r3 = await orchestrate({ canonicalAsset: a3, observations: [], seed: 1 });
    const agg = aggregateAcrossAssets([r1, r2, r3]);
    expect(agg.vetoedAssets).toContain("BAD");
    expect(agg.totalAllocatedPct + agg.reservePct).toBeCloseTo(1.0, 5);
  });
});

describe("getSpecialistRegistry", () => {
  it("returns all 7 specialists", () => {
    const reg = getSpecialistRegistry();
    expect(Object.keys(reg).length).toBe(7);
    expect(reg["market_structure"]).toBeDefined();
    expect(reg["risk_compliance"]).toBeDefined();
    expect(reg["portfolio_allocator"]).toBeDefined();
  });
});

describe("summarizeAllocations", () => {
  it("respects vetoes from risk_flag opinions", () => {
    const opinions: SpecialistOpinion[] = [
      mkOp("portfolio_allocator", "mildly_bullish", "directional", "BTC", "allocation_hint", 0.10),
      mkOp("risk_compliance", "strongly_bearish", "definitive", "BTC", "risk_flag", 1.0),
      mkOp("portfolio_allocator", "mildly_bullish", "directional", "ETH", "allocation_hint", 0.08),
    ];
    const sum: PortfolioAllocationResult = summarizeAllocations(opinions, 0.275);
    expect(sum.byAsset.get("BTC")?.targetWeightPct).toBe(0);
    expect(sum.byAsset.get("ETH")?.targetWeightPct).toBe(0.08);
    expect(sum.vetoed).toContain("BTC");
  });
});

function mkOp(
  specialistId: any,
  direction: any,
  confidence: any,
  canonicalAssetId: string,
  type: any = "thesis",
  strength = 0.5,
): SpecialistOpinion {
  return {
    id: `op-${Math.random().toString(36).slice(2, 8)}`,
    specialistId,
    canonicalAssetId,
    type,
    direction,
    confidence,
    strength,
    summary: "test",
    reasoning: "test",
    evidence: [{ provider: "test", capability: "test", description: "test", weight: 0.5, freshness: "live" }],
    respondsTo: [],
    emittedAt: new Date().toISOString(),
    seed: 1,
    caveats: [],
  };
}

function firstOp<T>(arr: T[]): T {
  if (arr.length === 0) throw new Error("expected at least one opinion");
  return arr[0] as T;
}
