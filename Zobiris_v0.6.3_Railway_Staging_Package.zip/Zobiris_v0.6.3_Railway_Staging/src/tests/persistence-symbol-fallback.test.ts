/**
 * v0.4.4 audit fix: persistence symbol-fallback is quarantined.
 *
 * The audit caught: when the storage layer rehydrates an
 * observation by symbol (because canonicalAssetId is not in
 * the row), the result had quarantineState="verified" hard-
 * coded. The audit wanted: persistence-symbol-fallback is
 * quarantined.
 */
import { describe, it, expect, beforeEach, afterEach } from "vitest";
import { openStorage, type DB } from "../storage/client.js";
import { ingestObservation } from "../storage/repository.js";
import { observations } from "../storage/schema.js";
import { eq } from "drizzle-orm";

describe("v0.4.4: persistence symbol-fallback is quarantined", () => {
  let db: DB;
  let sqlite: { close: () => void };

  beforeEach(() => {
    const opened = openStorage({ path: ":memory:" });
    db = opened.db;
    sqlite = opened.sqlite;
  });
  afterEach(() => sqlite?.close());

  it("ingestObservation preserves the identityMatchMethod and quarantineState from the caller", () => {
    // The v0.4.4 invariant: when the persistence path inserts
    // an observation via symbol fallback, the row's
    // identityMatchMethod = "persistence-symbol-fallback" and
    // quarantineState = "ambiguous" (NOT verified).
    const result = ingestObservation(db, {
      id: "obs-1",
      idempotencyKey: "ik-1",
      provider: "cmc",
      providerEventId: "1",
      eventType: "quote",
      schemaVersion: "1.0.0",
      canonicalAssetId: null,
      // The audit caught that v0.4.3 hard-coded verified in
      // the server rehydration path. v0.4.4 lets the caller
      // decide the quarantine state and persists it as-given.
      quarantineState: "ambiguous",
      identityMatchMethod: "persistence-symbol-fallback",
      occurredAt: Date.now(),
      payload: { symbol: "BTC" },
      normalizerVersion: "1.0.0",
      epistemicState: "UNKNOWN" as const,
      evidenceConfidence: 0,
    });
    expect(result).toBeDefined();
    // Now read it back via the integration / server path. The
    // rehydrated row must still have the ambiguous state and
    // persistence-symbol-fallback match method.
    const direct = db.select().from(observations).where(eq(observations.id, "obs-1")).get();
    expect(direct?.quarantineState).toBe("ambiguous");
    expect(direct?.identityMatchMethod).toBe("persistence-symbol-fallback");
  });
});
