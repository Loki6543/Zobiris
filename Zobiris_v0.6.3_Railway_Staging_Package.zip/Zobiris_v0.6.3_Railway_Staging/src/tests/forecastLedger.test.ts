/**
 * Forecast ledger tests — slice 5+ v0.4.0.
 */

import { describe, it, expect } from "vitest";
import {
  opinionToForecast,
  resolveForecast,
  buildCalibrationReport,
  ForecastLedger,
  type Forecast,
} from "../learning/forecastLedger.js";

describe("opinionToForecast", () => {
  it("produces pBullish > 0.5 for bullish direction", () => {
    const f = opinionToForecast({
      opinion: {
        specialistId: "market_structure",
        direction: "bullish",
        confidence: "directional",
        strength: 0.7,
        summary: "BTC looks strong",
      },
      symbol: "BTC",
      windowDays: 7,
    });
    expect(f.pBullish).toBeGreaterThan(0.5);
    expect(f.pBearish).toBeLessThan(0.5);
    expect(f.evaluated).toBe(false);
    expect(f.evaluateAt).toBeDefined();
  });

  it("produces pBullish < 0.5 for bearish direction", () => {
    const f = opinionToForecast({
      opinion: {
        specialistId: "derivatives_positioning",
        direction: "strongly_bearish",
        confidence: "strong",
        strength: 0.9,
        summary: "Hot funding + liquidations",
      },
      symbol: "ETH",
      windowDays: 7,
    });
    expect(f.pBullish).toBeLessThan(0.5);
  });

  it("higher confidence produces more extreme probabilities", () => {
    const speculative = opinionToForecast({
      opinion: { specialistId: "x", direction: "bullish", confidence: "speculative", strength: 0.5, summary: "" },
      symbol: "X",
      windowDays: 1,
    });
    const definitive = opinionToForecast({
      opinion: { specialistId: "x", direction: "bullish", confidence: "definitive", strength: 0.5, summary: "" },
      symbol: "X",
      windowDays: 1,
    });
    expect(definitive.pBullish).toBeGreaterThan(speculative.pBullish);
  });
});

describe("resolveForecast", () => {
  function mkForecast(pBullish: number, direction: any = "bullish"): Forecast {
    return {
      id: "f1",
      kind: "directional",
      symbol: "BTC",
      madeAt: new Date().toISOString(),
      direction,
      confidence: "directional",
      pBullish,
      pBearish: 1 - pBullish,
      specialistId: "x",
      rationale: "",
      evaluateAt: new Date().toISOString(),
      evaluated: false,
    };
  }

  it("marks correct when direction matches and move exceeds threshold", () => {
    const f = mkForecast(0.8, "bullish");
    const r = resolveForecast(f, 5.0);
    expect(r.outcome).toBe("correct");
    expect(r.directionAccuracy).toBe(1);
  });

  it("marks incorrect when direction does not match", () => {
    const f = mkForecast(0.8, "bullish");
    const r = resolveForecast(f, -5.0);
    expect(r.outcome).toBe("incorrect");
    expect(r.directionAccuracy).toBe(0);
  });

  it("returns lower Brier score for confident correct forecast", () => {
    const confident = mkForecast(0.9, "bullish");
    const r1 = resolveForecast(confident, 5.0);
    expect(r1.brierScore).toBeLessThan(0.05);
  });

  it("is idempotent on already-evaluated forecasts", () => {
    const f = mkForecast(0.8, "bullish");
    const r1 = resolveForecast(f, 5.0);
    const r2 = resolveForecast(r1, -10.0); // should NOT re-resolve
    expect(r2.realizedMovePct).toBe(5.0);
    expect(r2.outcome).toBe("correct");
  });

  it("respects threshold parameter", () => {
    const f = mkForecast(0.55, "mildly_bullish");
    const r1 = resolveForecast(f, 0.5, 1.0); // threshold 1%, move 0.5% is neutral
    expect(r1.outcome).toBe("incorrect"); // predicted mildly_bullish, market neutral
  });
});

describe("buildCalibrationReport", () => {
  it("aggregates bySpecialist and byConfidence", () => {
    const forecasts: Forecast[] = [
      mkResolved(0.8, "x", "directional", "correct", 0.04),
      mkResolved(0.7, "x", "directional", "correct", 0.09),
      mkResolved(0.6, "y", "tentative", "incorrect", 0.36),
    ];
    const report = buildCalibrationReport(forecasts);
    expect(report.total).toBe(3);
    expect(report.resolved).toBe(3);
    expect(report.correct).toBe(2);
    expect(report.incorrect).toBe(1);
    expect(report.bySpecialist["x"]?.total).toBe(2);
    expect(report.bySpecialist["x"]?.correct).toBe(2);
    expect(report.byConfidence["directional"]?.total).toBe(2);
  });

  it("returns zero for empty input", () => {
    const report = buildCalibrationReport([]);
    expect(report.total).toBe(0);
    expect(report.meanBrierScore).toBe(0);
    expect(report.directionAccuracy).toBe(0);
  });
});

describe("ForecastLedger", () => {
  it("records and resolves", () => {
    const ledger = new ForecastLedger();
    const f = opinionToForecast({
      opinion: { specialistId: "x", direction: "bullish", confidence: "directional", strength: 0.7, summary: "test" },
      symbol: "BTC",
      windowDays: 7,
    });
    ledger.record(f);
    expect(ledger.pending().length).toBe(1);
    const resolved = ledger.resolve(f.id, 5.0);
    expect(resolved?.outcome).toBe("correct");
    expect(ledger.pending().length).toBe(0);
  });

  it("returns null when resolving non-existent", () => {
    const ledger = new ForecastLedger();
    expect(ledger.resolve("nope", 5.0)).toBeNull();
  });

  it("produces a calibration report", () => {
    const ledger = new ForecastLedger();
    for (let i = 0; i < 10; i++) {
      const f = opinionToForecast({
        opinion: {
          specialistId: i % 2 === 0 ? "a" : "b",
          direction: "bullish",
          confidence: "directional",
          strength: 0.6,
          summary: "",
        },
        symbol: "X",
        windowDays: 7,
      });
      ledger.record(f);
      ledger.resolve(f.id, i % 2 === 0 ? 3.0 : -2.0);
    }
    const report = ledger.report();
    expect(report.total).toBe(10);
    expect(report.resolved).toBe(10);
    expect(report.correct).toBe(5);
    expect(report.incorrect).toBe(5);
  });
});

function mkResolved(pBullish: number, specialistId: string, confidence: any, outcome: any, brier: number): Forecast {
  return {
    id: Math.random().toString(36),
    kind: "directional",
    symbol: "X",
    madeAt: new Date().toISOString(),
    direction: "bullish",
    confidence,
    pBullish,
    pBearish: 1 - pBullish,
    specialistId,
    rationale: "",
    evaluateAt: new Date().toISOString(),
    evaluated: true,
    outcome,
    brierScore: brier,
    directionAccuracy: outcome === "correct" ? 1 : 0,
    resolvedAt: new Date().toISOString(),
  };
}
