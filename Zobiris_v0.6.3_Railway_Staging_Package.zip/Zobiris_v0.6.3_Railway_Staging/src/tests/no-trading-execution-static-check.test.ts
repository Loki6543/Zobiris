/**
 * v0.4.4 audit fix (P0 #14): no-trading-execution static check.
 *
 * The application is decision support only. This test runs the
 * `scripts/check_no_trading.sh` script and asserts the exit code is 0.
 *
 * If a future change introduces a wallet signer, order executor, or
 * seed-phrase handler, the static check fails the release.
 */
import { describe, it, expect } from "vitest";
import { execFileSync } from "node:child_process";
import { existsSync } from "node:fs";
import { resolve } from "node:path";

describe("v0.4.4 P0 #14: no-trading-execution static check", () => {
  it("the source tree has no executable trading paths", () => {
    const script = resolve(__dirname, "..", "..", "scripts", "check_no_trading.sh");
    expect(existsSync(script), `check_no_trading.sh missing at ${script}`).toBe(true);
    let out = "";
    let code = 0;
    try {
      out = execFileSync("bash", [script], { encoding: "utf8", stdio: "pipe" });
    } catch (e: any) {
      out = (e.stdout ?? "") + (e.stderr ?? "");
      code = e.status ?? 1;
    }
    // The script prints OK or FAIL lines; we require exit 0 and an
    // OK marker in the output.
    expect(code, `check_no_trading.sh exited ${code}\n${out}`).toBe(0);
    expect(out).toMatch(/OK:/);
  });
});
