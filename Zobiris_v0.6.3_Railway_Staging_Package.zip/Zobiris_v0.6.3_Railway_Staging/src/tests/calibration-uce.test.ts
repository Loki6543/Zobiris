/**
 * Tests for the Iyaza Addendum calibration store + UCE robustness.
 */
import { describe, it, expect } from "vitest";
import { CalibrationStore } from "../calibration/store.js";
import { runRobustness, type Option, type Criterion } from "../uce/robustness.js";

describe("CalibrationStore", () => {
  it("initial posterior is uniform (alpha=1, beta=1, mean=0.5)", () => {
    const s = new CalibrationStore();
    const p = s.getPosterior("specialist.x.y" as any);
    expect(p.alpha).toBe(1);
    expect(p.beta).toBe(1);
    expect(p.n).toBe(0);
    expect(p.mean).toBeCloseTo(0.5, 5);
  });

  it("after 10 successes, mean > 0.8", () => {
    const s = new CalibrationStore();
    const k = "provider.cmc.market_quotes" as any;
    for (let i = 0; i < 10; i++) s.recordOutcome(k, true);
    expect(s.getPosterior(k).mean).toBeGreaterThan(0.8);
  });

  it("after 10 failures, mean < 0.2", () => {
    const s = new CalibrationStore();
    const k = "provider.bad.x" as any;
    for (let i = 0; i < 10; i++) s.recordOutcome(k, false);
    expect(s.getPosterior(k).mean).toBeLessThan(0.2);
  });

  it("getRanking sorts by mean correctly", () => {
    const s = new CalibrationStore();
    const kA = "k.a" as any;
    const kB = "k.b" as any;
    const kC = "k.c" as any;
    for (let i = 0; i < 5; i++) s.recordOutcome(kA, true);
    for (let i = 0; i < 8; i++) s.recordOutcome(kB, true);
    for (let i = 0; i < 3; i++) s.recordOutcome(kC, true);
    const ranking = s.getRanking([kA, kB, kC]);
    expect(ranking[0]).toBe(kB); // highest mean
    expect(ranking[2]).toBe(kC); // lowest mean
  });

  it("size() returns the number of distinct keys", () => {
    const s = new CalibrationStore();
    s.recordOutcome("k.a" as any, true);
    s.recordOutcome("k.a" as any, true);
    s.recordOutcome("k.b" as any, true);
    expect(s.size()).toBe(2);
  });
});

describe("UCE robustness", () => {
  const criteria: Criterion[] = [
    { id: "score", direction: "maximize", weight: 1.0 },
    { id: "fee", direction: "minimize", weight: 0.5 },
  ];

  it("returns DOMINANT_ROBUST when one option beats others by a wide margin", () => {
    const options: Option[] = [
      { id: "A", criteria: { score: 0.95, fee: 0.1 } },
      { id: "B", criteria: { score: 0.5, fee: 0.5 } },
      { id: "C", criteria: { score: 0.4, fee: 0.6 } },
    ];
    const r = runRobustness({ options, criteria, iterations: 500, seed: 42 });
    expect(r.baseWinner).toBe("A");
    expect(r.winnerFlipRate).toBeLessThan(0.05);
    expect(r.verdict).toBe("DOMINANT_ROBUST");
  });

  it("returns NO_CLEAR_DOMINANCE when options are close AND uncertain inputs exist", () => {
    const options: Option[] = [
      { id: "A", criteria: { score: 0.5, fee: 0.5 } },
      { id: "B", criteria: { score: 0.5, fee: 0.5 } },
      { id: "C", criteria: { score: 0.5, fee: 0.5 } },
    ];
    // Uncertain inputs add enough noise to create winner-flip
    const r = runRobustness({
      options,
      criteria,
      uncertainInputs: [{ id: "score", low: -0.2, likely: 0, high: 0.2 }],
      iterations: 500,
      seed: 42,
    });
    expect(r.verdict).toBe("NO_CLEAR_DOMINANCE");
  });

  it("returns CONSTRAINT_BLOCKED when no option satisfies hard constraints", () => {
    const options: Option[] = [
      { id: "A", criteria: { score: 0.9, fee: 0.1 }, hardConstraints: { licensed: false } },
      { id: "B", criteria: { score: 0.8, fee: 0.2 }, hardConstraints: { licensed: false } },
    ];
    const r = runRobustness({ options, criteria, iterations: 100, seed: 1 });
    expect(r.verdict).toBe("CONSTRAINT_BLOCKED");
  });

  it("is deterministic with the same seed", () => {
    const options: Option[] = [
      { id: "A", criteria: { score: 0.7, fee: 0.3 } },
      { id: "B", criteria: { score: 0.6, fee: 0.4 } },
    ];
    const r1 = runRobustness({ options, criteria, iterations: 200, seed: 123 });
    const r2 = runRobustness({ options, criteria, iterations: 200, seed: 123 });
    expect(r1.winnerFlipRate).toBeCloseTo(r2.winnerFlipRate, 5);
    expect(r1.baseWinner).toBe(r2.baseWinner);
  });

  it("runs 1000 iterations by default", () => {
    const options: Option[] = [
      { id: "A", criteria: { score: 0.9, fee: 0.1 } },
      { id: "B", criteria: { score: 0.5, fee: 0.5 } },
    ];
    const r = runRobustness({ options, criteria, seed: 7 });
    expect(r.iterations).toBe(1000);
  });

  it("confidence interval sums to 1.0", () => {
    const options: Option[] = [
      { id: "A", criteria: { score: 0.8, fee: 0.2 } },
      { id: "B", criteria: { score: 0.7, fee: 0.3 } },
      { id: "C", criteria: { score: 0.6, fee: 0.4 } },
    ];
    const r = runRobustness({ options, criteria, iterations: 200, seed: 99 });
    const sum = r.confidenceInterval.reduce((a, b) => a + b.pWin, 0);
    expect(Math.abs(sum - 1.0)).toBeLessThan(0.01);
  });

  it("returns INSUFFICIENT_EVIDENCE for empty options", () => {
    const r = runRobustness({ options: [], criteria, iterations: 100 });
    expect(r.verdict).toBe("INSUFFICIENT_EVIDENCE");
  });
});
