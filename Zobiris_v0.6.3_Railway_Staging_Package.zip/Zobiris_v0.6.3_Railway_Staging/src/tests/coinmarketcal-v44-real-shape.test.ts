/**
 * v0.4.4 audit fix (P0-4): CoinMarketCal v2 contract.
 *
 * The audit caught:
 *   - v0.4.3 used `?max=100&page=1` (v1 paginated). v2 uses
 *     cursor pagination via `meta.cursor` (the first page has no
 *     page param).
 *   - v0.4.3 used `event.date` as both the source timestamp and
 *     occurredAt. For future events, especially `isEstimated`
 *     events, the event date is the scheduled date, NOT when
 *     Zobiris learned the information. The source timestamp must
 *     be `lastVerifiedAt`.
 *   - v0.4.3 typed event.id as `number`. v2 returns event.id as
 *     a string ("48291"). v0.4.4 accepts both.
 *   - v0.4.3 used `coins[].symbol` for identity. Tickers collide;
 *     v2 documents `coins[].slug` as the stable identity.
 */
import { describe, it, expect, beforeEach, afterEach, vi } from "vitest";
import { CoinMarketCalAdapter } from "../providers/coinmarketcal.js";
import { type CanonicalAsset } from "../domain/index.js";

function makeAsset(symbol: string, slug?: string): CanonicalAsset {
  return {
    id: `cn-${symbol.toLowerCase()}-test`,
    symbol,
    name: symbol,
    providerIds: slug ? { coinmarketcalId: slug } : {},
    mappingStatus: slug ? "verified" : "unmapped",
    mappingConfidence: slug ? 0.9 : 0,
    updatedAt: new Date().toISOString(),
  };
}

const mockFetch = vi.fn();
const realFetch = globalThis.fetch;
beforeEach(() => { (globalThis as any).fetch = mockFetch; });
afterEach(() => { (globalThis as any).fetch = realFetch; mockFetch.mockReset(); });

describe("v0.4.4 P0-4: CoinMarketCal v2 contract", () => {
  it("live URL uses limit=100 (no page param on the first page)", async () => {
    mockFetch.mockResolvedValueOnce({
      ok: true, status: 200,
      json: async () => ({ data: [], meta: { cursor: "abc123" } }),
    });
    const adapter = new CoinMarketCalAdapter();
    adapter.configure({
      baseUrl: "https://api.coinmarketcal.com",
      forceFixtures: false,
      liveConfig: { apiKey: "test-key" },
    });
    await adapter.fetch({ canonicalAssets: new Map() });
    const [urlArg] = mockFetch.mock.calls[0] as [string, RequestInit];
    expect(urlArg).toContain("limit=100");
    // v0.4.4: cursor pagination. The first page has no page param.
    expect(urlArg).not.toContain("page=");
    // v0.4.4: the API key is in the x-api-key header, NOT the
    // query string.
    expect(urlArg).not.toContain("key=");
    const [, initArg] = mockFetch.mock.calls[0] as [string, RequestInit];
    const headers = (initArg.headers ?? {}) as Record<string, string>;
    expect(headers["x-api-key"]).toBe("test-key");
  });

  it("normalizes the v2 response with event.id as STRING, not number", () => {
    const adapter = new CoinMarketCalAdapter();
    const obs = adapter.normalize(
      {
        // v2 documented response shape
        data: [
          {
            id: "48291",  // v2: STRING id
            title: "BTC halving",
            coins: [{ id: "1", slug: "bitcoin", symbol: "BTC" }],
            date: "2025-12-15T00:00:00Z",
            displayedDate: "Dec 15, 2025",
            isEstimated: true,
            categories: ["mining"],
            sourceUrl: "https://example.com/btc-halving",
            lastVerifiedAt: "2024-09-12T10:00:00Z",
          },
        ],
        meta: { cursor: null },
      },
      {
        canonicalAssets: new Map([["cn-btc-test", makeAsset("BTC", "bitcoin")]]),
        endpoint: "events",
        receivedAt: new Date().toISOString(),
        rawSchemaVersion: "2.0.0",
      },
    );
    expect(obs).toHaveLength(1);
    expect(obs[0]?.canonicalAssetId).toBe("cn-btc-test");
    // providerEventId is the event id (string)
    expect(obs[0]?.providerEventId).toBe("48291");
    // The payload must include the slug identity (not the symbol).
    const p = obs[0]!.payload as Record<string, any>;
    expect(p.slug).toBe("bitcoin");
    // The event date is the scheduled date, kept in the payload
    // — NOT used as the source timestamp.
    expect(p.eventDate).toBe("2025-12-15T00:00:00Z");
    expect(p.isEstimated).toBe(true);
  });

  it("source timestamp is lastVerifiedAt (NOT event.date for estimated events)", () => {
    const adapter = new CoinMarketCalAdapter();
    const obs = adapter.normalize(
      {
        data: [{
          id: "1",
          title: "Future event",
          coins: [{ id: "1", slug: "bitcoin", symbol: "BTC" }],
          date: "2030-12-15T00:00:00Z",  // future, isEstimated
          isEstimated: true,
          lastVerifiedAt: "2024-09-12T10:00:00Z",  // information-retrieved
        }],
      },
      {
        canonicalAssets: new Map([["cn-btc-test", makeAsset("BTC", "bitcoin")]]),
        endpoint: "events",
        receivedAt: new Date().toISOString(),
        rawSchemaVersion: "2.0.0",
      },
    );
    expect(obs).toHaveLength(1);
    // The source timestamp is the information-retrieved time,
    // NOT the future event date.
    const sourceTs = obs[0]?.sourceTimestamp;
    expect(sourceTs).toBe("2024-09-12T10:00:00Z");
    // occurredAt is also the retrieval time, NOT the event date.
    expect(obs[0]?.occurredAt).toBe("2024-09-12T10:00:00Z");
  });

  it("uses coins[].slug for identity resolution, not symbol-only fallback", () => {
    const adapter = new CoinMarketCalAdapter();
    // Two events with the same symbol "BTC" but different slugs
    // (one verified via slug, one symbol-only). The slug-based
    // event should resolve to a verified canonical asset; the
    // symbol-only one should not.
    const obs = adapter.normalize(
      {
        data: [
          {
            id: "1",
            title: "Verified BTC event",
            coins: [{ id: "1", slug: "bitcoin", symbol: "BTC" }],
            date: "2025-01-01T00:00:00Z",
            isEstimated: false,
            lastVerifiedAt: "2024-09-12T10:00:00Z",
          },
          {
            id: "2",
            title: "Unverified BTC event",
            coins: [{ id: "2", slug: "btc-other", symbol: "BTC" }],
            date: "2025-02-01T00:00:00Z",
            isEstimated: false,
            lastVerifiedAt: "2024-09-12T10:00:00Z",
          },
        ],
      },
      {
        canonicalAssets: new Map([["cn-btc-test", makeAsset("BTC", "bitcoin")]]),
        endpoint: "events",
        receivedAt: new Date().toISOString(),
        rawSchemaVersion: "2.0.0",
      },
    );
    expect(obs).toHaveLength(2);
    // The slug=bitcoin event is verified via provider-id.
    const verified = obs.find(o => o.providerEventId === "1");
    expect(verified?.canonicalAssetId).toBe("cn-btc-test");
    expect(verified?.quarantineState).toBe("verified");
    // The slug=btc-other event does NOT match; it falls through
    // to symbol-only (ambiguous). It still creates an observation
    // (for display in the case file) but is quarantined.
    const other = obs.find(o => o.providerEventId === "2");
    expect(other?.quarantineState).toBe("ambiguous");
  });

  it("fallback data is marked as dataMode=fallback (no silent fixture)", async () => {
    mockFetch.mockResolvedValueOnce({
      ok: false, status: 500, text: async () => "server error",
    });
    const adapter = new CoinMarketCalAdapter();
    adapter.configure({
      baseUrl: "https://api.coinmarketcal.com",
      forceFixtures: false,
      liveConfig: { apiKey: "test-key" },
    });
    const result = await adapter.fetch({ canonicalAssets: new Map() });
    // No fixture → null data with networkError.
    expect(result).toHaveLength(1);
    expect(result[0]?.data).toBeNull();
    expect(adapter.lastNetworkError).toMatch(/500/);
    expect(adapter.health().status).toBe("degraded");
  });
});
