/**
 * Portfolio + verifier tests.
 *
 * Verifies: weight sum + reserve = 100, two-rank split is preserved,
 * ambiguous identity cannot receive weight, every watchlist asset is present.
 */
import { describe, it, expect } from "vitest";
import { buildAssetSnapshot } from "../portfolio/buildPortfolio.js";
import { normalizePortfolio, PORTFOLIO_SUM_TOLERANCE } from "../portfolio/normalize.js";
import { runVerifier } from "../verifier/invariants.js";
import { DEFAULT_SCORING_CONFIG } from "../domain/scoring.js";
import type { CanonicalAsset } from "../domain/canonicalAsset.js";
import type { AssetAnalysisSnapshot } from "../domain/portfolio.js";

const WATCHLIST = ["BTC", "ETH", "SOL", "AVAX", "LINK", "UNI", "AAVE", "DOGE"];

function mkCanonical(symbol: string, over: Partial<CanonicalAsset> = {}): CanonicalAsset {
  return {
    id: `id-${symbol}`,
    symbol,
    name: symbol,
    providerIds: { kraken: symbol === "BTC" ? "XBT" : symbol },
    mappingStatus: "verified",
    mappingConfidence: 0.9,
    updatedAt: new Date().toISOString(),
    ...over,
  };
}

function mkEvidence(_symbol: string, over: Partial<Parameters<typeof buildAssetSnapshot>[0]["evidence"]> = {}) {
  return {
    hasMarketPrice: true,
    hasSocial: true,
    hasDerivatives: false,
    hasOnchain: false,
    hasCatalysts: true,
    identityConfidence: 0.9,
    identityEpistemicState: "KNOWN" as const,
    priceEpistemicState: "KNOWN" as const,
    socialEpistemicState: "KNOWN" as const,
    derivativesEpistemicState: "UNKNOWN" as const,
    onchainEpistemicState: "UNKNOWN" as const,
    catalystsEpistemicState: "KNOWN" as const,
    crossSourceAgreement: 0.6,
    freshness: 0.9,
    conflictCount: 0,
    change24hPct: 5.0,
    price: 100,
    exploitFlagged: false,
    upcomingUnlockPct: undefined,
    holderConcentration: undefined,
    volumeToMcRatio: undefined,
    projectIntegrityOk: true,
    ...over,
  };
}

describe("normalizePortfolio", () => {
  it("weights + reserve + unallocated = 100% within tolerance", () => {
    const assets = WATCHLIST.map(sym => {
      const canonical = mkCanonical(sym);
      return buildAssetSnapshot({
        symbol: sym,
        canonical,
        evidence: mkEvidence(sym),
        evidenceClaimIds: [],
      });
    });
    const norm = normalizePortfolio(assets, DEFAULT_SCORING_CONFIG, null);
    // Invariant: allocated + reserve + unallocated = 100
    const sum = norm.snapshot.totalAllocatedPct + norm.snapshot.reservePct + norm.snapshot.unallocatedPct;
    expect(Math.abs(sum - 100)).toBeLessThanOrEqual(PORTFOLIO_SUM_TOLERANCE);
  });

  it("every watchlist asset appears in the snapshot", () => {
    const assets = WATCHLIST.map(sym => buildAssetSnapshot({
      symbol: sym,
      canonical: mkCanonical(sym),
      evidence: mkEvidence(sym),
      evidenceClaimIds: [],
    }));
    const norm = normalizePortfolio(assets, DEFAULT_SCORING_CONFIG, null);
    for (const sym of WATCHLIST) {
      expect(norm.snapshot.rankedAssets.find(a => a.symbol === sym)).toBeDefined();
    }
  });

  it("ambiguous identity cannot receive positive weight", () => {
    const assets = WATCHLIST.map((sym, i) => buildAssetSnapshot({
      symbol: sym,
      canonical: mkCanonical(sym, { mappingStatus: i === 0 ? "ambiguous" : "verified" }),
      evidence: mkEvidence(sym),
      evidenceClaimIds: [],
    }));
    const norm = normalizePortfolio(assets, DEFAULT_SCORING_CONFIG, null);
    const btc = norm.snapshot.rankedAssets.find(a => a.symbol === "BTC")!;
    expect(btc.targetWeight.pct).toBe(0);
  });

  it("opportunity rank and allocation rank can differ for speculative assets", () => {
    const assets: AssetAnalysisSnapshot[] = WATCHLIST.map(sym => {
      const speculative = sym === "DOGE";
      return buildAssetSnapshot({
        symbol: sym,
        canonical: mkCanonical(sym),
        evidence: mkEvidence(sym, {
          change24hPct: speculative ? 25 : 3,  // 25% → high risk
          // risk is a derived field in buildAssetSnapshot, not a direct input.
        }),
        evidenceClaimIds: [],
      });
    });
    const norm = normalizePortfolio(assets, DEFAULT_SCORING_CONFIG, null);
    const doge = norm.snapshot.rankedAssets.find(a => a.symbol === "DOGE")!;
    // DOGE has 25% change → marketTechnical ~100, but high-risk scalar 0.68 vs others' 1.0.
    expect(doge.opportunityRank).toBeGreaterThanOrEqual(1);
    if (doge.allocationRank != null) {
      // The two ranks can be different. In a typical build, DOGE ranks
      // higher in opportunity (high change) than in allocation (high risk).
      // We do not assert which way; we only assert the rank system supports
      // the split. In particular: the rank of any asset must be <= the
      // number of assets with non-null rank in that dimension.
      expect(doge.opportunityRank).toBeLessThanOrEqual(WATCHLIST.length);
      expect(doge.allocationRank).toBeLessThanOrEqual(WATCHLIST.length);
    }
  });

  it("computeChanges detects new/dropped top-10 when prior exists", () => {
    // First refresh: 8 assets all in top-10.
    const first = WATCHLIST.map(sym => buildAssetSnapshot({
      symbol: sym,
      canonical: mkCanonical(sym),
      evidence: mkEvidence(sym),
      evidenceClaimIds: [],
    }));
    const norm1 = normalizePortfolio(first, DEFAULT_SCORING_CONFIG, null);
    // Second refresh: drop one, add a new one.
    const newAssets = ["NEW1", ...WATCHLIST.slice(0, 7)].map(sym => buildAssetSnapshot({
      symbol: sym,
      canonical: mkCanonical(sym, { mappingStatus: sym === "NEW1" ? "unmapped" : "verified" }),
      evidence: sym === "NEW1" ? mkEvidence(sym, { hasMarketPrice: false, hasSocial: false, hasCatalysts: false }) : mkEvidence(sym),
      evidenceClaimIds: [],
    }));
    const norm2 = normalizePortfolio(newAssets, DEFAULT_SCORING_CONFIG, norm1.snapshot);
    // Dedupe symbol uniqueness matters: we changed the universe.
    expect(norm2.snapshot.changesSinceLastRefresh).toBeDefined();
  });

  it("preserves a strict risk-gate size cap during portfolio normalization", () => {
    const capped = buildAssetSnapshot({ symbol: "CAP", canonical: mkCanonical("CAP"), evidence: mkEvidence("CAP"), evidenceClaimIds: [] });
    const ordinary = buildAssetSnapshot({ symbol: "ORD", canonical: mkCanonical("ORD"), evidence: mkEvidence("ORD"), evidenceClaimIds: [] });
    capped.targetWeight.pct = 1;
    capped.riskGates = [{
      code: "SUSPICIOUS_VOLUME",
      active: true,
      reason: "possible wash trading",
      effect: "size_cap",
      cap: 1,
    }];
    ordinary.targetWeight.pct = 2.26;

    const norm = normalizePortfolio([capped, ordinary], DEFAULT_SCORING_CONFIG, null);
    expect(norm.snapshot.rankedAssets.find(a => a.symbol === "CAP")?.targetWeight.pct).toBe(1);
    expect(norm.snapshot.rankedAssets.find(a => a.symbol === "ORD")?.targetWeight.pct).toBe(89);
    expect(norm.diagnostics.bindingRiskCapCount).toBe(1);
  });

  it("accepts explicit under-allocation when every eligible asset is capped", () => {
    const assets = ["A", "B"].map((symbol, index) => {
      const asset = buildAssetSnapshot({ symbol, canonical: mkCanonical(symbol), evidence: mkEvidence(symbol), evidenceClaimIds: [] });
      const cap = index + 1;
      asset.targetWeight.pct = cap;
      asset.riskGates = [{ code: `CAP_${symbol}`, active: true, reason: "test cap", effect: "size_cap", cap }];
      return asset;
    });
    const norm = normalizePortfolio(assets, DEFAULT_SCORING_CONFIG, null);
    expect(norm.snapshot.totalAllocatedPct).toBe(3);
    expect(norm.snapshot.reservePct).toBe(10);
    expect(norm.snapshot.unallocatedPct).toBe(87);
    expect(norm.diagnostics.bindingRiskCapCount).toBe(2);
  });
});

describe("runVerifier", () => {
  it("emits WEIGHT_AMBIGUOUS_IDENTITY error for ambiguous + positive weight", () => {
    const assets: AssetAnalysisSnapshot[] = WATCHLIST.map((sym, i) => {
      const canonical = mkCanonical(sym, { mappingStatus: i === 0 ? "ambiguous" : "verified" });
      const snap = buildAssetSnapshot({
        symbol: sym,
        canonical,
        evidence: mkEvidence(sym),
        evidenceClaimIds: [],
      });
      // Force a positive weight for the ambiguous one (post-normalize will be zeroed, but pre-norm we can check)
      if (i === 0) snap.targetWeight.pct = 5;
      return snap;
    });
    const norm = normalizePortfolio(assets, DEFAULT_SCORING_CONFIG, null);
    const findings = runVerifier({
      snapshot: norm.snapshot,
      canonicalAssets: new Map(WATCHLIST.map((sym, i) => [sym, mkCanonical(sym, { mappingStatus: i === 0 ? "ambiguous" : "verified" })] as const)),
      watchlist: WATCHLIST,
    });
    const ids = findings.filter(f => f.code === "WEIGHT_AMBIGUOUS_IDENTITY");
    // After normalize, ambiguous weight is zeroed, so the verifier should NOT find this.
    expect(ids.length).toBe(0);
  });

  it("emits WATCHLIST_ASSET_MISSING error when a watchlist symbol is not in the snapshot", () => {
    const assets: AssetAnalysisSnapshot[] = ["BTC", "ETH"].map(sym => buildAssetSnapshot({
      symbol: sym,
      canonical: mkCanonical(sym),
      evidence: mkEvidence(sym),
      evidenceClaimIds: [],
    }));
    const norm = normalizePortfolio(assets, DEFAULT_SCORING_CONFIG, null);
    const findings = runVerifier({
      snapshot: norm.snapshot,
      canonicalAssets: new Map(),
      watchlist: ["BTC", "ETH", "SOL"],   // SOL missing
    });
    const missing = findings.filter(f => f.code === "WATCHLIST_ASSET_MISSING");
    expect(missing.length).toBe(1);
    expect(missing[0]?.message).toContain("SOL");
  });

  it("emits WEIGHT_EXCEEDS_RISK_CAP for any post-normalization cap breach", () => {
    const asset = buildAssetSnapshot({ symbol: "CAP", canonical: mkCanonical("CAP"), evidence: mkEvidence("CAP"), evidenceClaimIds: [] });
    asset.targetWeight.pct = 1.01;
    asset.riskGates = [{ code: "SUSPICIOUS_VOLUME", active: true, reason: "possible wash trading", effect: "size_cap", cap: 1 }];
    const snapshot = normalizePortfolio([asset], DEFAULT_SCORING_CONFIG, null).snapshot;
    snapshot.rankedAssets[0]!.targetWeight.pct = 1.01;
    snapshot.totalAllocatedPct = 1.01;
    const findings = runVerifier({ snapshot, canonicalAssets: new Map(), watchlist: ["CAP"] });
    expect(findings.some(f => f.code === "WEIGHT_EXCEEDS_RISK_CAP")).toBe(true);
  });
});
