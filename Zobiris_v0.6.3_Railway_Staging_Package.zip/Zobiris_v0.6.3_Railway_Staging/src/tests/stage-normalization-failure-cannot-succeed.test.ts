/**
 * v0.4.3 audit regression test (required #13)
 * Test: stage-normalization-failure-cannot-succeed
 *
 * Per the v0.4.3 audit (P0-7A): "A schema/normalization error can
 * therefore occur while health() remains connected, allowing a stage
 * to be marked succeeded even though processing failed."
 *
 * v0.4.3 fix: the stage status depends on the actual acquisition
 * outcome (normalizedObservationCount, hadFailure, providerConfigured),
 * not on the adapter's `health()`. A normalization failure sets
 * hadFailure=true and the stage status is "degraded" or "failed"
 * (never "succeeded").
 */

import { describe, it, expect } from "vitest";
import { runRefresh } from "../runtime/refresh.js";
import { buildAdapters } from "../scripts/_adapters.js";
import { CMCAdapter } from "../providers/cmc.js";

describe("v0.4.3 P0-7A: normalization failure cannot mark stage as succeeded", () => {
  it("when CMC normalization fails, the acquire-market stage is degraded (not succeeded)", async () => {
    // Wire a CMC adapter that returns a payload the validator will reject.
    const cmc = new CMCAdapter();
    cmc.configure({
      baseUrl: "https://pro-api.coinmarketcap.com",
      fixturePath: "",  // no fixture; force fetch path
    });
    // Force fixtures off so we can inject a bad payload via the live
    // path, but we don't actually have a live key, so we just call
    // normalize directly with a bad payload through a fixture.
    // Instead: use a fixture file that contains invalid data, which
    // will cause normalization to fail. The cleanest way: replace
    // the fixture with garbage.
    const { mkdtempSync, writeFileSync, rmSync } = await import("node:fs");
    const { tmpdir } = await import("node:os");
    const tmp = mkdtempSync(`${tmpdir}/zobiris-test-`);
    try {
      const badFixture = `${tmp}/cmc-bad.json`;
      // Schema-valid outer envelope, but the inner data is missing
      // the required `quote.USD.price` fields, so the normalizer
      // can still parse, but the resulting observation has
      // evidenceConfidence=0 and the stage has hadFailure=true.
      // For a true failure, write data that violates the schema.
      writeFileSync(badFixture, "this is not json");
      cmc.configure({ baseUrl: "x", fixturePath: badFixture, forceFixtures: true });
      const adapters = buildAdapters({ live: false, staleSeconds: 60 });
      // Override the CMC adapter with our bad-fixture one.
      (adapters as any).cmc = cmc;
      const { DEFAULT_SCORING_CONFIG } = await import("../domain/scoring.js");
      const { readFileSync } = await import("node:fs");
      const { resolve } = await import("node:path");
      const watchlist = JSON.parse(readFileSync(resolve(process.cwd(), "src/fixtures/watchlist.json"), "utf8"));
      const session = await runRefresh({
        adapters,
        watchlist,
        policy: DEFAULT_SCORING_CONFIG,
      });
      // The stage should NOT be "succeeded" for acquire-market.
      const acquireMarket = session.session.stages.find(s => s.name === "acquire-market");
      expect(acquireMarket).toBeDefined();
      // It can be "degraded" or "failed" — anything but "succeeded".
      expect(acquireMarket!.status).not.toBe("succeeded");
    } finally {
      rmSync(tmp, { recursive: true, force: true });
    }
  });
});
