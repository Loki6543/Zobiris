/**
 * v0.4.4 audit fix (P0-5): LunarCrush v4 list/v1 contract.
 *
 * The audit caught:
 *   - The v0.4.3 schema expected a nested `data: { coins: [{...metrics}] }`
 *     shape. The current API4 list endpoint returns a flat
 *     `data: [...]` array.
 *   - v0.4.3 used `social_volume` and `price_change_24h` (legacy v3
 *     names). v4 uses `social_volume_24h` and `percent_change_24h`.
 *   - v0.4.3 labeled LunarCrush as effectively live, but list/v1 is
 *     cached (up to ~1 hour). The freshness hint must be "delayed".
 *   - The list endpoint returns up to 1000+ coins; the runtime
 *     should request a large limit (1000) to cover the watchlist.
 *
 * v0.4.4 fixes all of these.
 */
import { describe, it, expect } from "vitest";
import { LunarCrushAdapter } from "../providers/lunarcrush.js";
import { type CanonicalAsset } from "../domain/index.js";

function makeAsset(symbol: string, lunarcrushId?: string): CanonicalAsset {
  return {
    id: `cn-${symbol.toLowerCase()}-test`,
    symbol,
    name: symbol,
    providerIds: lunarcrushId ? { lunarcrushId } : {},
    mappingStatus: lunarcrushId ? "verified" : "unmapped",
    mappingConfidence: lunarcrushId ? 0.9 : 0,
    updatedAt: new Date().toISOString(),
  };
}

function assetMap(...assets: CanonicalAsset[]): Map<string, CanonicalAsset> {
  return new Map(assets.map(a => [a.id, a]));
}

describe("v0.4.4 P0-5: LunarCrush v4 list/v1 contract", () => {
  it("parses the v4 flat-array response shape with v4 field names", () => {
    const adapter = new LunarCrushAdapter();
    const obs = adapter.normalize(
      {
        // v0.4.4: v4 returns a flat data[] array, with the v4
        // documented field names (social_volume_24h, etc.).
        config: { generated: 1700000000 },
        data: [
          {
            id: 1,
            name: "Bitcoin",
            symbol: "BTC",
            social_volume_24h: 245000,
            interactions_24h: 100000,
            galaxy_score: 78.2,
            alt_rank: 1,
            sentiment: 72.3,
            social_dominance: 28.4,
            price: 78408.5,
            percent_change_24h: 1.23,
          },
        ],
      },
      {
        canonicalAssets: assetMap(makeAsset("BTC", "1")),
        endpoint: "list",
        receivedAt: new Date().toISOString(),
        rawSchemaVersion: "4.0.0",
      },
    );
    expect(obs).toHaveLength(1);
    const p = obs[0]!.payload as Record<string, any>;
    // v0.4.4: v4 documented field names are present.
    expect(p.socialVolume24h).toBe(245000);
    expect(p.interactions24h).toBe(100000);
    expect(p.galaxyScore).toBe(78.2);
    expect(p.altRank).toBe(1);
    expect(p.priceUsd).toBe(78408.5);
    // Legacy v3 names are still emitted as aliases.
    expect(p.socialVolume).toBe(245000);
  });

  it("uses config.generated as the source timestamp (LunarCrush list is delayed)", () => {
    const adapter = new LunarCrushAdapter();
    const generatedTs = 1700000000;  // Nov 2023
    const obs = adapter.normalize(
      {
        config: { generated: generatedTs },
        data: [{ id: 1, name: "Bitcoin", symbol: "BTC", galaxy_score: 78 }],
      },
      {
        canonicalAssets: assetMap(makeAsset("BTC", "1")),
        endpoint: "list",
        receivedAt: new Date().toISOString(),
        rawSchemaVersion: "4.0.0",
      },
    );
    expect(obs).toHaveLength(1);
    // The source timestamp should be derived from config.generated.
    const sourceTs = obs[0]?.sourceTimestamp;
    expect(sourceTs).toBeDefined();
    const date = new Date(sourceTs!);
    expect(date.getUTCFullYear()).toBe(2023);
    expect(date.getUTCMonth()).toBe(10);  // November (0-indexed)
  });

  it("marks the freshness as delayed (list/v1 is cached, not real-time)", () => {
    const adapter = new LunarCrushAdapter();
    const obs = adapter.normalize(
      {
        config: { generated: 1700000000 },
        data: [{ id: 1, name: "Bitcoin", symbol: "BTC", galaxy_score: 78 }],
      },
      {
        canonicalAssets: assetMap(makeAsset("BTC", "1")),
        endpoint: "list",
        receivedAt: new Date().toISOString(),
        rawSchemaVersion: "4.0.0",
      },
    );
    expect(obs[0]!.payload).toMatchObject({ freshnessHint: "delayed" });
  });

  it("legacy v3 field names are still accepted (backward compat)", () => {
    const adapter = new LunarCrushAdapter();
    const obs = adapter.normalize(
      // v3 legacy: nested data.coins[].metrics with social_volume
      // and price_change_24h.
      {
        data: {
          coins: [
            {
              id: 1,
              name: "Bitcoin",
              symbol: "BTC",
              metrics: {
                galaxy_score: 78.2,
                alt_rank: 1,
                social_volume: 245000,
                sentiment: 72.3,
                price: 78408.5,
                price_change_24h: 1.23,
              },
            },
          ],
        },
      },
      {
        canonicalAssets: assetMap(makeAsset("BTC", "1")),
        endpoint: "list",
        receivedAt: new Date().toISOString(),
        rawSchemaVersion: "1.0.0",
      },
    );
    expect(obs).toHaveLength(1);
    const p = obs[0]!.payload as Record<string, any>;
    expect(p.galaxyScore).toBe(78.2);
    expect(p.priceUsd).toBe(78408.5);
    expect(p.change24hPct).toBe(1.23);
    // Legacy field names promoted to the v4 24h variants.
    expect(p.socialVolume24h).toBe(245000);
  });

  it("handles 50-asset watchlist coverage from a single list/v1 response", () => {
    // v0.4.4 audit check: can a single list/v1 response cover
    // the 50-asset Zobiris watchlist? The list endpoint is the
    // only documented API4 endpoint that returns the full
    // universe in one call.
    const adapter = new LunarCrushAdapter();
    const data = Array.from({ length: 50 }, (_, i) => ({
      id: i + 1,
      name: `Coin${i}`,
      symbol: `C${i}`,
      galaxy_score: 50 + (i % 30),
      social_volume_24h: 1000 * (i + 1),
      percent_change_24h: (i % 7) - 3,
    }));
    const obs = adapter.normalize(
      { config: { generated: 1700000000 }, data },
      {
        canonicalAssets: assetMap(...data.map(c => makeAsset(c.symbol, String(c.id)))),
        endpoint: "list",
        receivedAt: new Date().toISOString(),
        rawSchemaVersion: "4.0.0",
      },
    );
    expect(obs).toHaveLength(50);
  });
});
