import { describe, expect, it } from "vitest";
import { openStorage } from "../storage/client.js";

describe("removed address-investigation structure", () => {
  it("does not leave the retired investigation table in a migrated database", () => {
    const storage = openStorage({ path: ":memory:" });
    try {
      const row = storage.sqlite
        .prepare("SELECT COUNT(*) AS count FROM sqlite_master WHERE type = 'table' AND name = 'asset_investigations'")
        .get() as { count: number };
      expect(row.count).toBe(0);
    } finally {
      storage.close();
    }
  });
});
