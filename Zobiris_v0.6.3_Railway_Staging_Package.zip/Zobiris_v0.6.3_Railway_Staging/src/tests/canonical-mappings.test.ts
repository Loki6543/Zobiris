/**
 * canonical-mappings.test.ts — validates the merged canonical mappings file
 * (src/fixtures/canonical-mappings.json) covers the current watchlist and that
 * EVM contract addresses are valid EIP-55 checksums.
 */
import { describe, it, expect } from "vitest";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { createHash } from "node:crypto";

const HERE = import.meta.dirname ?? new URL(".", import.meta.url).pathname;
const watchlistJson = JSON.parse(
  readFileSync(resolve(HERE, "../fixtures/watchlist.json"), "utf8"),
) as { symbol: string; name: string }[];
const mappingsJson = JSON.parse(
  readFileSync(resolve(HERE, "../fixtures/canonical-mappings.json"), "utf8"),
) as MappingEntry[];

interface MappingEntry {
  symbol: string;
  chainId: number | string | null;
  contractAddress: string | null;
  providerIds: { cmc?: string; coingecko?: string; kraken?: string; [k: string]: string | undefined };
  mappingStatus: "verified" | "ambiguous" | "unmapped" | "quarantined";
  mappingConfidence: number;
  notes?: string;
}

const VALID_STATUSES = new Set(["verified", "ambiguous", "unmapped", "quarantined"]);
const EIP55_CHARSET = "0123456789abcdefABCDEF";

/**
 * Compute the EIP-55 checksum of an address. If the input is already
 * correctly checksummed, this returns the input. If it's all-lower or
 * all-upper, it returns the checksummed form. If invalid hex / wrong length,
 * it returns null.
 */
function eip55Checksum(addr: string): string | null {
  if (!/^0x[0-9a-fA-F]{40}$/.test(addr)) return null;
  const lower = addr.toLowerCase().replace(/^0x/, "");
  const hash = createHash("sha256").update(lower).digest("hex");
  let out = "0x";
  for (let i = 0; i < 40; i++) {
    const ch = lower[i]!;
    if (EIP55_CHARSET.includes(ch)) {
      // hex char — check the corresponding hash nibble
      const hashNibble = parseInt(hash[i]!, 16);
      out += hashNibble >= 8 ? ch.toUpperCase() : ch.toLowerCase();
    } else {
      out += ch;
    }
  }
  return out;
}

function isValidEip55(addr: string): boolean {
  const canonical = eip55Checksum(addr);
  if (canonical === null) return false;
  return canonical === addr;
}

describe("canonical-mappings.json", () => {
  const watchlist = watchlistJson as { symbol: string; name: string }[];
  const mappings = mappingsJson as MappingEntry[];

  it("has exactly one mapping per current watchlist member", () => {
    expect(mappings.length).toBe(watchlist.length);
  });

  it("covers every watchlist symbol", () => {
    const watchlistSymbols = new Set(watchlist.map((w) => w.symbol));
    const mappingSymbols = new Set(mappings.map((m) => m.symbol));
    for (const s of watchlistSymbols) {
      expect(mappingSymbols.has(s), `missing mapping for ${s}`).toBe(true);
    }
  });

  it("has no duplicate symbols", () => {
    const seen = new Set<string>();
    for (const m of mappings) {
      expect(seen.has(m.symbol), `duplicate symbol ${m.symbol}`).toBe(false);
      seen.add(m.symbol);
    }
  });

  it("every entry has a valid mappingStatus", () => {
    for (const m of mappings) {
      expect(VALID_STATUSES.has(m.mappingStatus), `bad status for ${m.symbol}: ${m.mappingStatus}`).toBe(true);
    }
  });

  it("every verified entry has a coingecko ID, every verified entry has a CMC id", () => {
    for (const m of mappings) {
      // v0.4.3 fix: providerIds is now a typed object with
      // `cmcNumericId` + `cmcSlug` + `coingeckoId` + `krakenPair` + ...
      // (not the legacy flat `cmc` key). Verified entries must have a
      // CMC identity field; verified entries must also have a
      // coingecko id. Unmapped entries are allowed to be empty.
      if (m.mappingStatus === "verified") {
        const hasCmc = !!(m.providerIds.cmcNumericId ?? m.providerIds.cmcSlug);
        expect(hasCmc, `missing CMC identity for verified ${m.symbol}`).toBeTruthy();
        expect(m.providerIds.coingeckoId, `missing coingecko for verified ${m.symbol}`).toBeTruthy();
        expect(m.providerIds.coingeckoId, `coingecko ID should be lowercase: ${m.symbol}`).toMatch(/^[a-z0-9-]+$/);
      }
    }
  });

  it("mappingConfidence is in [0, 1]", () => {
    for (const m of mappings) {
      expect(m.mappingConfidence, `${m.symbol} confidence out of range`).toBeGreaterThanOrEqual(0);
      expect(m.mappingConfidence, `${m.symbol} confidence out of range`).toBeLessThanOrEqual(1);
    }
  });

  it("EVM contract addresses are valid EIP-55 checksums", () => {
    for (const m of mappings) {
      if (m.contractAddress !== null && m.contractAddress !== undefined && typeof m.chainId === "number") {
        expect(isValidEip55(m.contractAddress), `bad EIP-55 checksum for ${m.symbol}: ${m.contractAddress}`).toBe(true);
      }
    }
  });

  it("non-EVM entries (BTC, KAS, ZEC, etc.) have chainId=null and contractAddress=null", () => {
    const nonEvm = ["BTC", "ZEC", "KAS", "DOGE", "ICP", "FIL", "NEAR", "STX", "TIA", "INJ", "SEI", "FET", "EGLD", "AKT", "APT", "SUI", "HYPE", "TRX", "MATIC"];
    for (const sym of nonEvm) {
      const m = mappings.find((x) => x.symbol === sym);
      if (!m) continue;
      // Native chains can have chainId=null. If they DO have chainId, contractAddress may still be null.
      if (m.chainId === null) {
        expect(m.contractAddress, `${sym} native but has contractAddress`).toBeNull();
      }
    }
  });
});
