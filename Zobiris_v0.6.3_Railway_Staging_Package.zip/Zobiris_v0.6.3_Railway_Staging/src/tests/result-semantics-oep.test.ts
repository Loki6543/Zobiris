/**
 * Tests for the Iyaza Addendum result semantics + OEP outcome taxonomy.
 */
import { describe, it, expect } from "vitest";
import {
  taskTerminalResultSchema,
  verifyCompletion,
  type TaskTerminalResult,
} from "../tasks/result.js";
import {
  ALL_OEP_OUTCOMES,
  INTEGRITY_OUTCOMES,
  oepOutcomeSchema,
  oepScopeOf,
  isIntegrityBypass,
  classifyError,
  SUCCESS_OUTCOMES,
  QUALITY_OUTCOMES,
  OPERATIONAL_OUTCOMES,
  KNOWLEDGE_OUTCOMES,
  ESCALATION_OUTCOMES,
} from "../oep/taxonomy.js";

describe("result semantics", () => {
  it("All 6 terminal states are parseable", () => {
    const prepared: TaskTerminalResult = {
      state: "prepared",
      taskId: "task-1",
      producedAt: "2026-08-22T03:00:00.000Z",
      draftArtifactRefs: ["a.json"],
    };
    const completed: TaskTerminalResult = {
      state: "completed_unverified",
      taskId: "task-1",
      producedAt: "2026-08-22T03:00:00.000Z",
      artifactRefs: ["a.json"],
      summary: "ran",
    };
    const verified: TaskTerminalResult = {
      state: "verified_complete",
      taskId: "task-1",
      producedAt: "2026-08-22T03:00:00.000Z",
      artifactRefs: ["a.json"],
      verificationRefs: ["v.json"],
      summary: "ran",
    };
    const insufficient: TaskTerminalResult = {
      state: "insufficient_evidence",
      taskId: "task-1",
      producedAt: "2026-08-22T03:00:00.000Z",
      missingCapabilities: ["market.quotes"],
      summary: "no data",
    };
    const failed: TaskTerminalResult = {
      state: "failed",
      taskId: "task-1",
      producedAt: "2026-08-22T03:00:00.000Z",
      failureCode: "TIMEOUT",
      summary: "timed out",
    };
    const cancelled: TaskTerminalResult = {
      state: "cancelled",
      taskId: "task-1",
      producedAt: "2026-08-22T03:00:00.000Z",
    };
    for (const r of [prepared, completed, verified, insufficient, failed, cancelled]) {
      expect(taskTerminalResultSchema.safeParse(r).success).toBe(true);
    }
  });

  it("verifyCompletion promotes completed_unverified -> verified_complete with valid evidence", () => {
    const result: TaskTerminalResult = {
      state: "completed_unverified",
      taskId: "task-1",
      producedAt: "2026-08-22T03:00:00.000Z",
      artifactRefs: ["a.json"],
      summary: "ran",
    };
    const verified = verifyCompletion(result, {
      verifierId: "verifier-1",
      at: "2026-08-22T03:01:00.000Z",
      rationale: "all gates pass",
      artifactRefs: ["verifier-report.json"],
      flags: {},
    });
    expect(verified.state).toBe("verified_complete");
  });

  it("verifyCompletion stays completed_unverified with no evidence", () => {
    const result: TaskTerminalResult = {
      state: "completed_unverified",
      taskId: "task-1",
      producedAt: "2026-08-22T03:00:00.000Z",
      artifactRefs: ["a.json"],
      summary: "ran",
    };
    const r = verifyCompletion(result, null);
    expect(r.state).toBe("completed_unverified");
  });

  it("verifyCompletion stays completed_unverified with flagged evidence", () => {
    const result: TaskTerminalResult = {
      state: "completed_unverified",
      taskId: "task-1",
      producedAt: "2026-08-22T03:00:00.000Z",
      artifactRefs: ["a.json"],
      summary: "ran",
    };
    const r = verifyCompletion(result, {
      verifierId: "verifier-1",
      at: "2026-08-22T03:01:00.000Z",
      rationale: "found a regression",
      artifactRefs: [],
      flags: { acceptanceFailed: true },
    });
    expect(r.state).toBe("completed_unverified");
  });
});

describe("OEP outcome taxonomy", () => {
  it("All 27 outcomes parse through the Zod schema", () => {
    expect(ALL_OEP_OUTCOMES.length).toBeGreaterThanOrEqual(27);
    for (const o of ALL_OEP_OUTCOMES) {
      expect(oepOutcomeSchema.safeParse(o).success).toBe(true);
    }
  });

  it("isIntegrityBypass returns true for the 6 bypass outcomes", () => {
    for (const o of INTEGRITY_OUTCOMES) {
      expect(isIntegrityBypass(o)).toBe(true);
    }
  });

  it("isIntegrityBypass returns false for operational and success outcomes", () => {
    expect(isIntegrityBypass("TIMEOUT")).toBe(false);
    expect(isIntegrityBypass("PROVIDER_UNAVAILABLE")).toBe(false);
    expect(isIntegrityBypass("SUCCESS")).toBe(false);
    expect(isIntegrityBypass("SUCCESS_WITH_DEGRADATION")).toBe(false);
    expect(isIntegrityBypass("INSUFFICIENT_EVIDENCE")).toBe(false);
  });

  it("oepScopeOf maps each outcome to its scope", () => {
    for (const o of SUCCESS_OUTCOMES) expect(oepScopeOf(o)).toBe("success");
    for (const o of QUALITY_OUTCOMES) expect(oepScopeOf(o)).toBe("quality");
    for (const o of INTEGRITY_OUTCOMES) expect(oepScopeOf(o)).toBe("integrity");
    for (const o of OPERATIONAL_OUTCOMES) expect(oepScopeOf(o)).toBe("operational");
    for (const o of KNOWLEDGE_OUTCOMES) expect(oepScopeOf(o)).toBe("knowledge");
    for (const o of ESCALATION_OUTCOMES) expect(oepScopeOf(o)).toBe("escalation");
  });

  it("classifyError maps auth errors to AUTH_FAILURE", () => {
    expect(classifyError(new Error("invalid api key"))).toBe("AUTH_FAILURE");
    expect(classifyError(new Error("401 unauthorized"))).toBe("AUTH_FAILURE");
    expect(classifyError(new Error("403 forbidden"))).toBe("AUTH_FAILURE");
  });

  it("classifyError maps rate-limit/quota to RATE_LIMITED/QUOTA_EXHAUSTED", () => {
    expect(classifyError(new Error("rate limit exceeded"))).toBe("RATE_LIMITED");
    expect(classifyError(new Error("429 too many requests"))).toBe("RATE_LIMITED");
    expect(classifyError(new Error("API quota exhausted"))).toBe("QUOTA_EXHAUSTED");
  });

  it("classifyError maps timeouts to TIMEOUT", () => {
    expect(classifyError(new Error("request timed out"))).toBe("TIMEOUT");
    expect(classifyError(new Error("AbortError"))).toBe("TIMEOUT");
  });

  it("classifyError maps network failures to PROVIDER_UNAVAILABLE", () => {
    expect(classifyError(new Error("econnrefused 127.0.0.1:443"))).toBe("PROVIDER_UNAVAILABLE");
    expect(classifyError(new Error("fetch failed"))).toBe("PROVIDER_UNAVAILABLE");
  });

  it("classifyError returns UNKNOWN for null/undefined", () => {
    expect(classifyError(null)).toBe("UNKNOWN");
    expect(classifyError(undefined)).toBe("UNKNOWN");
  });
});
