/**
 * Risk & compliance specialist.
 *
 * Reads the canonical asset mapping status, hard risk gate flags, and
 * pre-existing factor scores, and emits a *risk_flag* opinion. This specialist
 * is the gatekeeper for allocation: even if market structure is bullish,
 * a risk_flag of severity "veto" should block any positive weight.
 */

import { randomUUID } from "node:crypto";
import {
  type Specialist,
  type SpecialistContext,
  type SpecialistRunResult,
  type ConfidenceLevel,
  type EvidenceRef,
} from "./contract.js";

export const riskSpecialist: Specialist = {
  id: "risk_compliance",
  displayName: "Risk & Compliance",
  description:
    "Inspects canonical mapping status, hard risk gate flags, and the watchlist metadata. " +
    "Emits a risk_flag opinion that the orchestrator must respect before any allocation.",

  async run(ctx: SpecialistContext): Promise<SpecialistRunResult> {
    const a = ctx.canonicalAsset;
    const flags: string[] = [];
    const caveats: string[] = [];

    // Identity flags
    if (a.mappingStatus === "ambiguous") {
      flags.push("IDENTITY_AMBIGUOUS");
      caveats.push("Multiple plausible chain addresses — canonical mapping is ambiguous.");
    } else if (a.mappingStatus === "quarantined") {
      flags.push("IDENTITY_QUARANTINED");
      caveats.push("Canonical mapping is quarantined; do not allocate.");
    } else if (a.mappingStatus === "unmapped") {
      flags.push("IDENTITY_UNMAPPED");
      caveats.push("No canonical mapping yet — allocation requires manual verification.");
    }

    // Hard gate
    if (ctx.metadata?.hardGateTripped) {
      flags.push("HARD_GATE_TRIPPED");
      caveats.push("Hard risk gate has tripped — allocation must be zero or capped.");
    }

    // Factor score checks: very low fundamentals
    if (ctx.metadata?.factorScores) {
      const fundScore = ctx.metadata.factorScores["fundamentalTokenomics"];
      if (typeof fundScore === "number" && fundScore < 0.20) {
        flags.push("WEAK_FUNDAMENTALS");
      }
      const liqScore = ctx.metadata.factorScores["liquidityMarketStructure"];
      if (typeof liqScore === "number" && liqScore < 0.15) {
        flags.push("ILLIQUID");
        caveats.push("Liquidity is critically low — slippage risk on entry/exit.");
      }
    }

    // Watchlist rank: the source-defined bottom ten often has weaker coverage.
    const watchlistRank = ctx.metadata?.watchlistRank;
    const watchlistSize = ctx.metadata?.watchlistSize;
    if (
      watchlistRank != null &&
      watchlistSize != null &&
      watchlistSize > 10 &&
      watchlistRank > watchlistSize - 10
    ) {
      caveats.push("Bottom-10 of watchlist — research coverage is thin.");
    }

    const hasVeto = flags.includes("IDENTITY_QUARANTINED") || flags.includes("HARD_GATE_TRIPPED");

    if (flags.length === 0) {
      return {
        ok: true,
        opinions: [
          {
            id: randomUUID(),
            specialistId: "risk_compliance",
            canonicalAssetId: a.id,
            type: "risk_flag",
            direction: "neutral",
            confidence: "definitive" as ConfidenceLevel,
            strength: 0.0,
            summary: `No active risk flags for ${a.symbol} (${a.mappingStatus}).`,
            reasoning: "All identity, gate, liquidity, and fundamental checks passed.",
            evidence: [],
            respondsTo: [],
            emittedAt: new Date().toISOString(),
            seed: ctx.seed,
            caveats,
          },
        ],
      };
    }

    return {
      ok: true,
      opinions: [
        {
          id: randomUUID(),
          specialistId: "risk_compliance",
          canonicalAssetId: a.id,
          type: "risk_flag",
          direction: hasVeto ? "strongly_bearish" : "bearish",
          confidence: "definitive" as ConfidenceLevel,
          strength: hasVeto ? 1.0 : 0.6,
          summary: `${flags.length} risk flag${flags.length === 1 ? "" : "s"} for ${a.symbol}: ${flags.join(", ")}.`,
          reasoning: `Detected flags: ${flags.join(", ")}. ${hasVeto ? "These constitute a VETO — allocation must be zero." : "These are warnings; allocation may be capped or require additional evidence."}`,
          evidence: [
            {
              provider: "internal",
              capability: "risk.identity",
              description: `Canonical mapping status: ${a.mappingStatus}`,
              weight: 1.0,
              freshness: "live",
            },
            ...(ctx.metadata?.hardGateTripped
              ? ([
                  {
                    provider: "internal",
                    capability: "risk.gate",
                    description: "Hard risk gate tripped during this refresh",
                    weight: 1.0,
                    freshness: "live" as const,
                  },
                ] as EvidenceRef[])
              : []),
          ] as EvidenceRef[],
          respondsTo: [],
          emittedAt: new Date().toISOString(),
          seed: ctx.seed,
          caveats,
        },
      ],
    };
  },
};
