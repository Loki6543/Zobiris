/**
 * Market structure specialist.
 *
 * Reads quote observations (price, 24h change, 24h volume) for a single asset
 * and emits a directional thesis. This specialist is intentionally simple —
 * it does not call providers, it reads observations already in memory.
 *
 * The point is to demonstrate the specialist pattern end-to-end and to give
 * the runtime a real, useful opinion (not a placeholder) for every asset.
 */

import { randomUUID } from "node:crypto";
import {
  type Specialist,
  type SpecialistContext,
  type SpecialistOpinion,
  type SpecialistRunResult,
  type Direction,
  type ConfidenceLevel,
} from "./contract.js";

const QUOTE_TYPES = new Set(["quote", "ticker", "price", "spot", "market"]);

interface QuoteObservationPayload {
  priceUsd?: number | null;
  changePct24h?: number | null;
  volumeUsd24h?: number | null;
  marketCapUsd?: number | null;
}

function classifyDirection(changePct24h: number | null): { direction: Direction; strength: number; confidence: ConfidenceLevel } {
  if (changePct24h == null) {
    return { direction: "neutral", strength: 0.0, confidence: "speculative" };
  }
  const abs = Math.abs(changePct24h);
  if (changePct24h > 8) {
    return { direction: "strongly_bullish", strength: Math.min(0.95, 0.6 + abs / 100), confidence: "directional" };
  }
  if (changePct24h > 3) {
    return { direction: "bullish", strength: Math.min(0.8, 0.4 + abs / 100), confidence: "directional" };
  }
  if (changePct24h > 0.5) {
    return { direction: "mildly_bullish", strength: 0.3 + abs / 100, confidence: "tentative" };
  }
  if (changePct24h > -0.5) {
    return { direction: "neutral", strength: 0.1, confidence: "tentative" };
  }
  if (changePct24h > -3) {
    return { direction: "mildly_bearish", strength: 0.3 + abs / 100, confidence: "tentative" };
  }
  if (changePct24h > -8) {
    return { direction: "bearish", strength: Math.min(0.8, 0.4 + abs / 100), confidence: "directional" };
  }
  return { direction: "strongly_bearish", strength: Math.min(0.95, 0.6 + abs / 100), confidence: "directional" };
}

function classifyVolume(volumeUsd24h: number | null, marketCapUsd: number | null): { label: string; convictionBoost: number } {
  if (volumeUsd24h == null) return { label: "UNKNOWN", convictionBoost: -0.1 };
  if (marketCapUsd != null && marketCapUsd > 0) {
    const turnover = volumeUsd24h / marketCapUsd;
    if (turnover > 0.30) return { label: "very_high", convictionBoost: +0.10 };
    if (turnover > 0.10) return { label: "high", convictionBoost: +0.05 };
    if (turnover > 0.03) return { label: "moderate", convictionBoost: 0 };
    if (turnover > 0.01) return { label: "low", convictionBoost: -0.05 };
    return { label: "very_low", convictionBoost: -0.15 };
  }
  // No market cap to compare; use absolute volume
  if (volumeUsd24h > 1_000_000_000) return { label: "very_high", convictionBoost: +0.10 };
  if (volumeUsd24h > 100_000_000) return { label: "high", convictionBoost: +0.05 };
  if (volumeUsd24h > 10_000_000) return { label: "moderate", convictionBoost: 0 };
  if (volumeUsd24h > 1_000_000) return { label: "low", convictionBoost: -0.05 };
  return { label: "very_low", convictionBoost: -0.15 };
}

export const marketStructureSpecialist: Specialist = {
  id: "market_structure",
  displayName: "Market Structure",
  description:
    "Reads quote observations (price, 24h change, 24h volume) and emits a directional thesis. " +
    "Treats low-volume and high-vol moves as lower conviction.",

  async run(ctx: SpecialistContext): Promise<SpecialistRunResult> {
    const quotes = ctx.observations.filter(o => QUOTE_TYPES.has(o.eventType));
    if (quotes.length === 0) {
      return {
        ok: false,
        error: {
          code: "NO_QUOTES",
          message: `No quote observations for ${ctx.canonicalAsset.symbol}`,
          oepOutcome: "INSUFFICIENT_EVIDENCE",
        },
      };
    }

    // Pick the freshest quote
    const sortedQuotes = [...quotes].sort((a, b) => (b.occurredAt ?? "").localeCompare(a.occurredAt ?? ""));
    const freshest = sortedQuotes[0];
    if (!freshest) {
      return {
        ok: false,
        error: {
          code: "NO_QUOTES",
          message: `No quote observations for ${ctx.canonicalAsset.symbol} after sort`,
          oepOutcome: "INSUFFICIENT_EVIDENCE",
        },
      };
    }
    const payload = (freshest.payload ?? {}) as QuoteObservationPayload;
    const provider = freshest.provider;

    const changePct24h = payload.changePct24h ?? null;
    const volumeUsd24h = payload.volumeUsd24h ?? null;
    const marketCapUsd = payload.marketCapUsd ?? null;
    const priceUsd = payload.priceUsd ?? null;

    const dir = classifyDirection(changePct24h);
    const vol = classifyVolume(volumeUsd24h, marketCapUsd);
    const adjustedStrength = Math.max(0, Math.min(1, dir.strength + vol.convictionBoost));

    const directionWord =
      dir.direction === "neutral" ? "range-bound" :
      dir.direction.startsWith("strongly_") ? `${dir.direction.replace("strongly_", "")} (strong)` :
      dir.direction;

    const summary =
      `Market structure reads ${ctx.canonicalAsset.symbol} as ${directionWord} ` +
      `on ${changePct24h != null ? `${changePct24h.toFixed(2)}% 24h` : "no 24h change"} ` +
      `with ${vol.label} volume conviction.`;

    const reasoning = [
      `Source: ${provider} (capability: market.quotes).`,
      priceUsd != null ? `Spot reference: $${priceUsd.toLocaleString("en-US", { maximumFractionDigits: 6 })}.` : "Spot price not provided.",
      changePct24h != null ? `24h change: ${changePct24h.toFixed(2)}%.` : "24h change UNKNOWN.",
      volumeUsd24h != null ? `24h volume: $${(volumeUsd24h / 1_000_000).toFixed(1)}M.` : "24h volume UNKNOWN.",
      marketCapUsd != null ? `Market cap: $${(marketCapUsd / 1_000_000_000).toFixed(2)}B. Turnover: ${((volumeUsd24h ?? 0) / marketCapUsd * 100).toFixed(1)}%.` : "Market cap UNKNOWN.",
      `Classified direction: ${dir.direction} (strength ${dir.strength.toFixed(2)}).`,
      `Volume adjustment: ${vol.label} (${vol.convictionBoost >= 0 ? "+" : ""}${vol.convictionBoost.toFixed(2)}).`,
      `Final strength: ${adjustedStrength.toFixed(2)}.`,
    ].join(" ");

    const opinion: SpecialistOpinion = {
      id: randomUUID(),
      specialistId: "market_structure",
      canonicalAssetId: ctx.canonicalAsset.id,
      type: "thesis",
      direction: dir.direction,
      confidence: dir.confidence,
      strength: adjustedStrength,
      summary,
      reasoning,
      evidence: [
        {
          observationId: freshest.id,
          provider,
          capability: "market.quotes",
          description: freshest.occurredAt
            ? `Quote at ${freshest.occurredAt} from ${provider}`
            : `Quote from ${provider} (no source timestamp)`,
          weight: vol.label === "very_high" || vol.label === "high" ? 0.9 : vol.label === "very_low" ? 0.4 : 0.7,
          freshness: freshest.occurredAt && (Date.now() - new Date(freshest.occurredAt).getTime() < 5 * 60_000) ? "live" : "recent",
        },
      ],
      respondsTo: [],
      emittedAt: new Date().toISOString(),
      seed: ctx.seed,
      caveats: [
        priceUsd == null ? "Spot price UNKNOWN." : "",
        changePct24h == null ? "24h change UNKNOWN." : "",
        volumeUsd24h == null ? "24h volume UNKNOWN." : "",
        vol.label === "very_low" ? "Very low volume — conviction is low." : "",
        vol.label === "very_high" ? "Very high turnover — move may already be priced in or driven by thin liquidity." : "",
      ].filter(Boolean),
    };

    return { ok: true, opinions: [opinion] };
  },
};
