/**
 * Portfolio allocator specialist.
 *
 * Reads prior opinions and emits an allocation_hint per asset. The allocator
 * is the second of the two-rank split (Opportunity Rank ≠ Allocation Rank):
 * it intentionally dampens the impact of high-opportunity but low-confidence
 * theses, and caps total allocation per risk flags.
 *
 * Allocation rule (slice 5+ v0.4.0):
 *  - Score 0..1 from prior opinion consensus (weighted by independence).
 *  - Reserve 27.5% as USDC-equivalent baseline (configurable).
 *  - Cap per-asset at 15% to avoid concentration.
 *  - If any veto risk_flag, force 0% for that asset.
 *  - Confidence gate: only assets with at least one "directional"-or-better
 *    thesis can receive > 2% weight.
 */

import { randomUUID } from "node:crypto";
import {
  type Specialist,
  type SpecialistContext,
  type SpecialistOpinion,
  type SpecialistRunResult,
} from "./contract.js";

const CONFIDENCE_RANK: Record<SpecialistOpinion["confidence"], number> = {
  speculative: 0,
  tentative: 1,
  directional: 2,
  strong: 3,
  definitive: 4,
};

const DIRECTION_SCORE: Record<SpecialistOpinion["direction"], number> = {
  strongly_bearish: -1.0,
  bearish: -0.7,
  mildly_bearish: -0.3,
  neutral: 0.0,
  mildly_bullish: 0.3,
  bullish: 0.7,
  strongly_bullish: 1.0,
};

export interface PortfolioAllocationResult {
  totalAllocatedPct: number;
  reservePct: number;
  byAsset: Map<string, { targetWeightPct: number; rationale: string }>;
  vetoed: string[];
}

export const portfolioSpecialist: Specialist = {
  id: "portfolio_allocator",
  displayName: "Portfolio Allocator",
  description:
    "Reads prior opinions and emits an allocation_hint. Applies per-asset caps, " +
    "vetoes on risk flags, and the 27.5% reserve rule.",

  async run(ctx: SpecialistContext): Promise<SpecialistRunResult> {
    const vetoed: string[] = [];

    // 1. Detect vetoes (risk_flag with strength >= 0.8 and bearish direction)
    const BEARISH_DIRECTIONS = new Set(["bearish", "strongly_bearish", "mildly_bearish"]);
    for (const op of ctx.priorOpinions) {
      if (op.type === "risk_flag" && op.strength >= 0.8 && BEARISH_DIRECTIONS.has(op.direction)) {
        vetoed.push(op.canonicalAssetId);
      }
    }

    // 2. Score by consensus: weighted average of (direction_score * confidence_rank / 4 * strength)
    const scores = new Map<string, { score: number; totalWeight: number; conviction: number; opinionCount: number }>();
    const seenProvidersByAsset = new Map<string, Set<string>>();

    for (const op of ctx.priorOpinions) {
      if (op.type === "challenge") continue; // challenges do not contribute to score
      if (op.canonicalAssetId !== ctx.canonicalAsset.id) continue;
      if (vetoed.includes(op.canonicalAssetId)) continue;

      const dirScore = DIRECTION_SCORE[op.direction];
      const confMult = CONFIDENCE_RANK[op.confidence] / 4;
      const evidenceProviders = new Set(op.evidence.map(e => e.provider));
      // Independence: more distinct providers = higher weight
      const independenceMult = Math.min(1.0, 0.5 + evidenceProviders.size * 0.25);
      const w = op.strength * confMult * independenceMult;

      const cur = scores.get(op.canonicalAssetId) ?? { score: 0, totalWeight: 0, conviction: 0, opinionCount: 0 };
      cur.score += dirScore * w;
      cur.totalWeight += w;
      cur.conviction = Math.max(cur.conviction, CONFIDENCE_RANK[op.confidence]);
      cur.opinionCount += 1;
      scores.set(op.canonicalAssetId, cur);

      const seen = seenProvidersByAsset.get(op.canonicalAssetId) ?? new Set<string>();
      for (const p of evidenceProviders) seen.add(p);
      seenProvidersByAsset.set(op.canonicalAssetId, seen);
    }

    const scoreEntry = scores.get(ctx.canonicalAsset.id);
    if (!scoreEntry || scoreEntry.totalWeight === 0) {
      return {
        ok: true,
        opinions: [
          {
            id: randomUUID(),
            specialistId: "portfolio_allocator",
            canonicalAssetId: ctx.canonicalAsset.id,
            type: "allocation_hint",
            direction: "neutral",
            confidence: "speculative",
            strength: 0,
            summary: `${ctx.canonicalAsset.symbol}: no directional opinion consensus, allocation = 0%.`,
            reasoning: "Either no priors or all priors were vetoes / challenges. Per policy, allocation = 0% in this case.",
            evidence: [],
            respondsTo: [],
            emittedAt: new Date().toISOString(),
            seed: ctx.seed,
            caveats: vetoed.includes(ctx.canonicalAsset.id) ? ["Asset is vetoed by risk flag."] : [],
          },
        ],
      };
    }

    // Average score: -1 to 1
    const avgScore = scoreEntry.score / scoreEntry.totalWeight;
    // Map [-1, 1] -> [0, 1] "raw appetite"
    const rawAppetite = (avgScore + 1) / 2;
    // Apply conviction discount: low conviction (speculative/tentative) -> cap
    const convictionMult = scoreEntry.conviction >= 2 ? 1.0 : 0.4;
    const appetite = rawAppetite * convictionMult;

    // Per-asset cap: 15%
    const targetPct = Math.min(0.15, appetite * 0.20); // map 0..1 appetite to 0..20%, then cap 15%
    const targetPctClamped = Math.max(0, Math.min(0.15, targetPct));

    const providersCount = seenProvidersByAsset.get(ctx.canonicalAsset.id)?.size ?? 0;
    const summary =
      `${ctx.canonicalAsset.symbol}: raw appetite ${(rawAppetite * 100).toFixed(0)}%, ` +
      `conviction x${convictionMult.toFixed(1)} → ` +
      `target weight ${(targetPctClamped * 100).toFixed(2)}% ` +
      `(${scoreEntry.opinionCount} opinion${scoreEntry.opinionCount === 1 ? "" : "s"}, ` +
      `${providersCount} provider${providersCount === 1 ? "" : "s"}).`;

    const reasoning = [
      `Aggregated ${scoreEntry.opinionCount} non-challenge opinion${scoreEntry.opinionCount === 1 ? "" : "s"}.`,
      `Mean direction score: ${avgScore.toFixed(2)} (-1 bearish, +1 bullish).`,
      `Mean conviction: ${(scoreEntry.conviction).toFixed(1)} (0=spec, 4=definitive).`,
      `Raw appetite: ${(rawAppetite * 100).toFixed(1)}%.`,
      `Conviction multiplier: ${convictionMult.toFixed(2)} (full at directional-or-better).`,
      `Per-asset cap: 15%.`,
      `Final target: ${(targetPctClamped * 100).toFixed(2)}%.`,
    ].join(" ");

    return {
      ok: true,
      opinions: [
        {
          id: randomUUID(),
          specialistId: "portfolio_allocator",
          canonicalAssetId: ctx.canonicalAsset.id,
          type: "allocation_hint",
          direction: avgScore > 0.1 ? "mildly_bullish" : avgScore < -0.1 ? "mildly_bearish" : "neutral",
          confidence: scoreEntry.conviction >= 3 ? "directional" : "tentative",
          strength: targetPctClamped,
          summary,
          reasoning,
          evidence: [],
          respondsTo: [],
          emittedAt: new Date().toISOString(),
          seed: ctx.seed,
          caveats: [
            providersCount < 2 ? "Single provider only — allocation capped at minimum weight." : "",
            scoreEntry.conviction < 2 ? "Low conviction — allocation heavily discounted." : "",
            targetPctClamped >= 0.15 ? "Per-asset cap of 15% applied." : "",
          ].filter(Boolean),
        },
      ],
    };
  },
};

/** Helper for orchestrators: collect allocation hints and compute totals. */
export function summarizeAllocations(
  opinions: SpecialistOpinion[],
  reservePct = 0.275,
  perAssetCap = 0.15,
): PortfolioAllocationResult {
  const hints = opinions.filter(o => o.type === "allocation_hint");
  const BEARISH_DIRECTIONS = new Set(["bearish", "strongly_bearish", "mildly_bearish"]);
  const vetoedSet = new Set(
    opinions
      .filter(o => o.type === "risk_flag" && o.strength >= 0.8 && BEARISH_DIRECTIONS.has(o.direction))
      .map(o => o.canonicalAssetId),
  );
  const byAsset = new Map<string, { targetWeightPct: number; rationale: string }>();
  for (const h of hints) {
    if (vetoedSet.has(h.canonicalAssetId)) {
      byAsset.set(h.canonicalAssetId, { targetWeightPct: 0, rationale: "VETOED by risk flag" });
      continue;
    }
    const w = Math.min(perAssetCap, Math.max(0, h.strength));
    byAsset.set(h.canonicalAssetId, { targetWeightPct: w, rationale: h.summary });
  }
  const total = [...byAsset.values()].reduce((acc, v) => acc + v.targetWeightPct, 0);
  return {
    totalAllocatedPct: total,
    reservePct,
    byAsset,
    vetoed: [...vetoedSet],
  };
}
