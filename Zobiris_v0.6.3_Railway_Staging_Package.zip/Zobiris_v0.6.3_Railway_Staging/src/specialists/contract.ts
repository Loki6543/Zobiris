/**
 * Specialist contract — the minimum surface every cognitive specialist exposes.
 *
 * A specialist takes a typed context (assets, observations, prior opinions) and
 * emits one or more typed opinions. Specialists are pure functions of their
 * inputs (no I/O, no provider calls, no DB writes) so that the orchestrator can
 * route, parallelize, replay, and verify them deterministically.
 *
 * Per the Iyaza addendum:
 *  - Upper layers depend on `SpecialistId`, not a specific implementation.
 *  - Each opinion carries evidence references (observationIds) so the verifier
 *    can re-check the conclusion.
 *  - The opinion is *not* the final answer; it is one input into the
 *    orchestrator's synthesis. The Challenger can dissent, the Reconciler can
 *    merge, and the Verifier can reject.
 */

import { z } from "zod";
import { type CanonicalAsset, type NormalizedObservation } from "../domain/index.js";

/**
 * Each specialist has a stable, vendor-neutral ID. The capability registry
 * uses these to gate which specialists can run for a given task type.
 */
export const SPECIALIST_IDS = [
  "market_structure",
  "derivatives_positioning",
  "social_attention",
  "tokenomics_liquidity",
  "risk_compliance",
  "portfolio_allocator",
  "evidence_reconciler",
  "challenger",
] as const;

export type SpecialistId = typeof SPECIALIST_IDS[number];

export const specialistIdSchema = z.enum(SPECIALIST_IDS);

/** Stronger, less mergeable evidence. */
export const confidenceLevelSchema = z.enum(["speculative", "tentative", "directional", "strong", "definitive"]);
export type ConfidenceLevel = z.infer<typeof confidenceLevelSchema>;

/** Where the opinion is leaning. Symmetric — none/mild/moderate/strong. */
export const directionSchema = z.enum([
  "strongly_bearish",
  "bearish",
  "mildly_bearish",
  "neutral",
  "mildly_bullish",
  "bullish",
  "strongly_bullish",
]);
export type Direction = z.infer<typeof directionSchema>;

/** Type of conclusion a specialist emits. */
export const opinionTypeSchema = z.enum([
  "thesis",          // a directional narrative view
  "risk_flag",       // a concern or veto candidate
  "allocation_hint", // a portfolio weighting suggestion
  "challenge",       // a dissent against another opinion
  "reconciliation",  // a synthesis of two prior opinions
]);
export type OpinionType = z.infer<typeof opinionTypeSchema>;

export const evidenceRefSchema = z.object({
  observationId: z.string().min(1).optional(),
  provider: z.string().min(1),
  capability: z.string().min(1),
  description: z.string().min(1),
  weight: z.number().min(0).max(1),
  freshness: z.enum(["live", "recent", "delayed", "stale", "unavailable"]),
});
export type EvidenceRef = z.infer<typeof evidenceRefSchema>;

/** A single emitted opinion from a specialist. */
export interface SpecialistOpinion {
  id: string;
  specialistId: SpecialistId;
  canonicalAssetId: string;
  type: OpinionType;
  direction: Direction;
  confidence: ConfidenceLevel;
  /** Numeric 0-1 strength (separate from confidence *level*). */
  strength: number;
  /** Human-readable rationale. */
  summary: string;
  /** Detailed rationale with trace. */
  reasoning: string;
  evidence: EvidenceRef[];
  /** IDs of prior opinions this one is responding to (for challenger / reconciler). */
  respondsTo: string[];
  /** Time the opinion was produced. */
  emittedAt: string;
  /** Determinism: if non-null, the specialist used a seeded random source. */
  seed: number | null;
  /** Honest disclosures: what the specialist could NOT conclude from the inputs. */
  caveats: string[];
}

export const specialistOpinionSchema = z.object({
  id: z.string().min(1),
  specialistId: specialistIdSchema,
  canonicalAssetId: z.string().min(1),
  type: opinionTypeSchema,
  direction: directionSchema,
  confidence: confidenceLevelSchema,
  strength: z.number().min(0).max(1),
  summary: z.string().min(1).max(500),
  reasoning: z.string().min(1).max(4000),
  evidence: z.array(evidenceRefSchema),
  respondsTo: z.array(z.string()),
  emittedAt: z.string(),
  seed: z.number().int().nullable(),
  caveats: z.array(z.string()),
});

/** Minimum inputs a specialist receives. */
export interface SpecialistContext {
  canonicalAsset: CanonicalAsset;
  /** All known observations for this asset (any provider, any event type). */
  observations: NormalizedObservation[];
  /** Prior opinions emitted by other specialists for this asset. */
  priorOpinions: SpecialistOpinion[];
  /** Optional per-asset metadata. */
  metadata?: {
    /** Watchlist rank (1 = first in user list). */
    watchlistRank?: number;
    /** Current source-defined watchlist size. */
    watchlistSize?: number;
    /** Pre-computed factor scores if available (8-factor 0-1 each). */
    factorScores?: Record<string, number>;
    /** Two-rank split from scoring. */
    opportunityRank?: number;
    allocationRank?: number;
    /** Whether any hard risk gate has tripped. */
    hardGateTripped?: boolean;
    /** Any additional extensibility fields. */
    [key: string]: unknown;
  };
  /** Determinism: specialist should use this seed if it samples randomness. */
  seed: number;
}

export type SpecialistRunResult =
  | { ok: true; opinions: SpecialistOpinion[] }
  | { ok: false; error: { code: string; message: string; oepOutcome?: string } };

export interface Specialist {
  readonly id: SpecialistId;
  readonly displayName: string;
  readonly description: string;
  /** A specialist is allowed to emit zero or more opinions. */
  run(ctx: SpecialistContext): Promise<SpecialistRunResult>;
}
