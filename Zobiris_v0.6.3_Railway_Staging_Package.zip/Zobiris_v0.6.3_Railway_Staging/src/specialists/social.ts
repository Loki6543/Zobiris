/**
 * Social attention specialist.
 *
 * Reads social attention observations (mentions, sentiment, dominance,
 * galaxy score from LunarCrush) and emits a directional opinion. This
 * specialist is *peripheral* — social signals are notoriously noisy —
 * so it explicitly returns a low-confidence thesis unless multiple
 * independent providers agree.
 */

import { randomUUID } from "node:crypto";
import {
  type Specialist,
  type SpecialistContext,
  type SpecialistRunResult,
  type Direction,
  type ConfidenceLevel,
  type EvidenceRef,
} from "./contract.js";

const SOCIAL_TYPES = new Set(["social", "social_attention", "mentions", "sentiment", "galaxy_score"]);

interface SocialObservationPayload {
  mentions24h?: number | null;
  sentiment?: number | null;       // -1 to 1
  galaxyScore?: number | null;     // 0-100 (LunarCrush)
  socialDominance?: number | null; // 0-1
}

function classifySocial(mentions24h: number | null, sentiment: number | null, socialDominance: number | null): { direction: Direction; confidence: ConfidenceLevel; strength: number } {
  let score = 0;
  let evidence = 0;
  if (sentiment != null) {
    score += sentiment;
    evidence++;
  }
  if (mentions24h != null && mentions24h > 1000) {
    // High attention — direction uncertain but market is paying attention
    evidence++;
    score += 0.1; // mild attention premium
  }
  if (socialDominance != null && socialDominance > 0.05) {
    // High social dominance — not directly directional, but a structural concern
    evidence++;
    score -= 0.1; // reflexivity risk
  }

  if (evidence === 0) {
    return { direction: "neutral", confidence: "speculative", strength: 0 };
  }
  const normalized = score / Math.max(1, evidence);

  if (normalized > 0.3) return { direction: "bullish", confidence: "tentative", strength: Math.min(0.7, 0.3 + normalized) };
  if (normalized > 0.1) return { direction: "mildly_bullish", confidence: "tentative", strength: 0.3 + normalized };
  if (normalized > -0.1) return { direction: "neutral", confidence: "speculative", strength: 0.1 };
  if (normalized > -0.3) return { direction: "mildly_bearish", confidence: "tentative", strength: 0.3 + Math.abs(normalized) };
  return { direction: "bearish", confidence: "tentative", strength: Math.min(0.7, 0.3 + Math.abs(normalized)) };
}

export const socialSpecialist: Specialist = {
  id: "social_attention",
  displayName: "Social Attention",
  description:
    "Reads social observations (mentions, sentiment, dominance) and emits a tentative " +
    "directional opinion. Always low conviction — social signals are noisy.",

  async run(ctx: SpecialistContext): Promise<SpecialistRunResult> {
    const socials = ctx.observations.filter(o => SOCIAL_TYPES.has(o.eventType));
    if (socials.length === 0) {
      return {
        ok: false,
        error: {
          code: "NO_SOCIAL_DATA",
          message: `No social observations for ${ctx.canonicalAsset.symbol}`,
          oepOutcome: "INSUFFICIENT_EVIDENCE",
        },
      };
    }

    let mentions24h: number | null = null;
    let sentiment: number | null = null;
    let socialDominance: number | null = null;
    const providers = new Set<string>();
    let freshestTime = "";
    let freshestId: string | undefined;

    for (const obs of socials) {
      const payload = (obs.payload ?? {}) as SocialObservationPayload;
      if (payload.mentions24h != null) mentions24h = payload.mentions24h;
      if (payload.sentiment != null) sentiment = payload.sentiment;
      if (payload.socialDominance != null) socialDominance = payload.socialDominance;
      providers.add(obs.provider);
      const time = obs.occurredAt ?? obs.receivedAt;
      if (time > freshestTime) {
        freshestTime = time;
        freshestId = obs.id;
      }
    }

    const dir = classifySocial(mentions24h, sentiment, socialDominance);
    const independentProviders = providers.size;

    // Per addendum rule: social is always low conviction. Penalty if only one provider.
    const finalConfidence: ConfidenceLevel = independentProviders > 1 ? dir.confidence : "speculative";
    const finalStrength = independentProviders > 1 ? dir.strength : dir.strength * 0.5;

    const summary =
      `Social signal on ${ctx.canonicalAsset.symbol}: ${dir.direction} ` +
      `(mentions ${mentions24h != null ? mentions24h.toLocaleString("en-US") : "UNKNOWN"}, ` +
      `sentiment ${sentiment != null ? sentiment.toFixed(2) : "UNKNOWN"}, ` +
      `${independentProviders} provider${independentProviders === 1 ? "" : "s"}).`;

    const reasoning = [
      `Sources: ${[...providers].join(", ") || "none"}.`,
      mentions24h != null ? `Mentions (24h): ${mentions24h.toLocaleString("en-US")}.` : "Mentions UNKNOWN.",
      sentiment != null ? `Sentiment: ${sentiment.toFixed(2)} (range -1 to 1).` : "Sentiment UNKNOWN.",
      socialDominance != null ? `Social dominance: ${(socialDominance * 100).toFixed(2)}%.` : "Social dominance UNKNOWN.",
      `Independent providers: ${independentProviders}.`,
      `Classified direction: ${dir.direction} (strength ${dir.strength.toFixed(2)}, confidence ${dir.confidence}).`,
      `Single-provider penalty applied: confidence ${finalConfidence}, strength ${finalStrength.toFixed(2)}.`,
    ].join(" ");

    const evidence = freshestId
      ? ([
          {
            observationId: freshestId,
            provider: [...providers][0] ?? "unknown",
            capability: "social.attention",
            description: `Social observation (freshest) at ${freshestTime}`,
            weight: 0.4,
            freshness: (Date.now() - new Date(freshestTime).getTime() < 5 * 60_000 ? "live" : "recent") as "live" | "recent",
          },
        ] as EvidenceRef[])
      : [];

    return {
      ok: true,
      opinions: [
        {
          id: randomUUID(),
          specialistId: "social_attention",
          canonicalAssetId: ctx.canonicalAsset.id,
          type: "thesis",
          direction: dir.direction,
          confidence: finalConfidence,
          strength: finalStrength,
          summary,
          reasoning,
          evidence,
          respondsTo: [],
          emittedAt: new Date().toISOString(),
          seed: ctx.seed,
          caveats: [
            mentions24h == null ? "Mentions UNKNOWN." : "",
            sentiment == null ? "Sentiment UNKNOWN." : "",
            socialDominance == null ? "Social dominance UNKNOWN." : "",
            independentProviders < 2 ? "Only one social source — single-provider risk." : "",
            "Social signals are notoriously noisy; treat as peripheral.",
          ].filter(Boolean),
        },
      ],
    };
  },
};
