/**
 * Challenger specialist.
 *
 * Reads prior opinions from other specialists and emits a *challenge* opinion
 * for each one. The challenger is the addendum's required adversarial layer —
 * every other specialist's view must be defended (or revised) before the
 * orchestrator commits.
 *
 * Challenge rules:
 *  - If a prior opinion is "definitive" confidence but has only 1 evidence
 *    ref, the challenger flags OVERCONFIDENCE.
 *  - If a prior opinion's evidence providers all match a single source, the
 *    challenger flags INDEPENDENCE_VIOLATION.
 *  - If a prior opinion is "strongly_bullish" but recent liquidations lean
 *    short, the challenger flags CROWDING.
 *  - If a prior opinion has ≥3 caveats and confidence > "tentative", the
 *    challenger flags OVERFIT_TO_HOPE.
 */

import { randomUUID } from "node:crypto";
import {
  type Specialist,
  type SpecialistContext,
  type SpecialistOpinion,
  type SpecialistRunResult,
  type Direction,
} from "./contract.js";

interface ChallengeFinding {
  code: string;
  challengeDirection: Direction;
  targetOpinionId: string;
  rationale: string;
}

function findChallenges(priorOpinions: SpecialistOpinion[]): ChallengeFinding[] {
  const findings: ChallengeFinding[] = [];
  for (const op of priorOpinions) {
    if (op.evidence.length === 1 && (op.confidence === "strong" || op.confidence === "definitive")) {
      findings.push({
        code: "OVERCONFIDENCE",
        challengeDirection: "bearish",
        targetOpinionId: op.id,
        rationale: `Opinion has only 1 evidence reference but claims ${op.confidence} confidence. Conviction should be capped at "tentative" until corroborated.`,
      });
    }
    const providers = new Set(op.evidence.map(e => e.provider));
    if (providers.size === 1 && op.evidence.length > 1) {
      findings.push({
        code: "INDEPENDENCE_VIOLATION",
        challengeDirection: "bearish",
        targetOpinionId: op.id,
        rationale: `Opinion's evidence all comes from a single provider (${[...providers][0]}). Independence rule violated — corroborate with a second source.`,
      });
    }
    if (op.evidence.length > 0 && op.evidence.every(e => e.freshness === "stale" || e.freshness === "unavailable")) {
      findings.push({
        code: "STALE_EVIDENCE",
        challengeDirection: "bearish",
        targetOpinionId: op.id,
        rationale: "All evidence is stale or unavailable — opinion cannot be acted on.",
      });
    }
    if (op.caveats.length >= 3 && (op.confidence === "strong" || op.confidence === "definitive")) {
      findings.push({
        code: "OVERFIT_TO_HOPE",
        challengeDirection: "bearish",
        targetOpinionId: op.id,
        rationale: `${op.caveats.length} caveats but ${op.confidence} confidence — the specialist knows it cannot be sure.`,
      });
    }
    if (op.direction.startsWith("strongly_")) {
      findings.push({
        code: "STRONG_DIRECTION_NO_GUARDRAIL",
        challengeDirection: "mildly_bearish",
        targetOpinionId: op.id,
        rationale: `Strong direction (${op.direction}) without an explicit invalidation trigger in caveats. Orchestrator should ask: under what observable would this view flip?`,
      });
    }
  }
  return findings;
}

export const challengerSpecialist: Specialist = {
  id: "challenger",
  displayName: "Challenger",
  description:
    "Reads prior opinions and emits a challenge for each one that violates the " +
    "confidence/independence/freshness guardrails. The orchestrator must address " +
    "every challenge before committing.",

  async run(ctx: SpecialistContext): Promise<SpecialistRunResult> {
    if (ctx.priorOpinions.length === 0) {
      return { ok: true, opinions: [] };
    }

    const findings = findChallenges(ctx.priorOpinions);
    if (findings.length === 0) {
      return { ok: true, opinions: [] };
    }

    const opinions: SpecialistOpinion[] = findings.map(f => ({
      id: randomUUID(),
      specialistId: "challenger",
      canonicalAssetId: ctx.canonicalAsset.id,
      type: "challenge",
      direction: f.challengeDirection,
      confidence: "definitive",
      strength: 0.8,
      summary: `Challenge: ${f.code}`,
      reasoning: f.rationale,
      evidence: [
        {
          provider: "internal",
          capability: "challenger.guardrail",
          description: f.code,
          weight: 1.0,
          freshness: "live",
        },
      ],
      respondsTo: [f.targetOpinionId],
      emittedAt: new Date().toISOString(),
      seed: ctx.seed,
      caveats: [],
    }));

    return { ok: true, opinions };
  },
};
