/**
 * Evidence reconciler specialist.
 *
 * Looks for agreement vs conflict across prior opinions. If multiple
 * independent specialists agree on direction, the reconciler emits a
 * synthesis (the "Opportunity Rank" signal). If they conflict, the
 * reconciler emits a note that goes to the challenger / orchestrator.
 */

import { randomUUID } from "node:crypto";
import {
  type Specialist,
  type SpecialistContext,
  type SpecialistRunResult,
  type Direction,
} from "./contract.js";

const DIRECTION_BUCKETS: Record<string, "bullish" | "bearish" | "neutral"> = {
  strongly_bullish: "bullish",
  bullish: "bullish",
  mildly_bullish: "bullish",
  neutral: "neutral",
  mildly_bearish: "bearish",
  bearish: "bearish",
  strongly_bearish: "bearish",
};

export const reconcilerSpecialist: Specialist = {
  id: "evidence_reconciler",
  displayName: "Evidence Reconciler",
  description:
    "Aggregates prior opinions into a single reconciled direction. " +
    "Reports agreement level (low/medium/high) and confidence. " +
    "Outputs an Opportunity Rank signal (separate from Allocation Rank).",

  async run(ctx: SpecialistContext): Promise<SpecialistRunResult> {
    if (ctx.priorOpinions.length < 2) {
      return { ok: true, opinions: [] };
    }

    const directions = ctx.priorOpinions.map(o => DIRECTION_BUCKETS[o.direction] ?? "neutral");
    const bullish = directions.filter(d => d === "bullish").length;
    const bearish = directions.filter(d => d === "bearish").length;
    const neutral = directions.filter(d => d === "neutral").length;
    const total = directions.length;

    let reconciled: Direction;
    let agreement: "low" | "medium" | "high";
    if (bullish / total > 0.6) {
      reconciled = bullish === total ? "bullish" : "bullish";
      agreement = bullish === total ? "high" : "medium";
    } else if (bearish / total > 0.6) {
      reconciled = "bearish";
      agreement = bearish === total ? "high" : "medium";
    } else if (neutral / total > 0.5) {
      reconciled = "neutral";
      agreement = "medium";
    } else {
      reconciled = "neutral";
      agreement = "low";
    }

    // Confidence scales with agreement
    const confidence = agreement === "high" ? "directional" : agreement === "medium" ? "tentative" : "speculative";

    // Strength: how lopsided the consensus is, times how many priors
    const lopsidedness = Math.max(bullish, bearish, neutral) / total;
    const strength = Math.min(0.9, lopsidedness * 0.7 + Math.min(1, total / 5) * 0.3);

    const summary =
      `Reconciled view: ${reconciled} (agreement ${agreement}, ` +
      `${bullish} bull / ${bearish} bear / ${neutral} neutral of ${total}).`;

    const reasoning = [
      `Reconciled ${total} prior opinion${total === 1 ? "" : "s"}.`,
      `Direction tally: bullish=${bullish}, bearish=${bearish}, neutral=${neutral}.`,
      `Lopsidedness: ${(lopsidedness * 100).toFixed(0)}%.`,
      `Agreement: ${agreement}.`,
      `Reconciled direction: ${reconciled}.`,
      `Confidence: ${confidence}.`,
      `Strength: ${strength.toFixed(2)}.`,
    ].join(" ");

    return {
      ok: true,
      opinions: [
        {
          id: randomUUID(),
          specialistId: "evidence_reconciler",
          canonicalAssetId: ctx.canonicalAsset.id,
          type: "reconciliation",
          direction: reconciled,
          confidence,
          strength,
          summary,
          reasoning,
          evidence: [],
          respondsTo: ctx.priorOpinions.map(o => o.id),
          emittedAt: new Date().toISOString(),
          seed: ctx.seed,
          caveats: [
            agreement === "low" ? "Low agreement across specialists — opportunity rank uncertain." : "",
            total < 3 ? "Few opinions to reconcile." : "",
          ].filter(Boolean),
        },
      ],
    };
  },
};
