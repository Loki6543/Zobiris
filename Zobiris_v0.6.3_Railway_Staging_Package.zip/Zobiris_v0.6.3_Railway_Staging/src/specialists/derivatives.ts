/**
 * Derivatives positioning specialist.
 *
 * Reads funding rate and liquidation observations and emits a directional
 * opinion weighted by the asymmetry between long and short positioning.
 *
 * Per docs/DATA_PLANE.md: funding rate semantics differ between exchanges —
 * we treat the absolute value as the "tilt" of the market and the sign as the
 * crowd lean. This is intentionally simple; the addendum's
 * derivatives.specialist.deep variant can add basis / OI / options later.
 */

import { randomUUID } from "node:crypto";
import {
  type Specialist,
  type SpecialistContext,
  type SpecialistRunResult,
  type Direction,
  type ConfidenceLevel,
  type EvidenceRef,
} from "./contract.js";

const FUNDING_TYPES = new Set(["funding"]);
const LIQUIDATION_TYPES = new Set(["liquidation"]);

interface FundingObservationPayload {
  rate?: number | null;          // e.g. 0.0001 = 0.01% per 8h
  exchange?: string | null;
}

interface LiquidationObservationPayload {
  side?: "long" | "short" | "buy" | "sell" | null;
  volumeUsd?: number | null;
  price?: number | null;
}

function directionFromFunding(rate: number | null): { direction: Direction; strength: number; confidence: ConfidenceLevel } {
  if (rate == null) return { direction: "neutral", strength: 0, confidence: "speculative" };
  // Per 8h: 0.01% = 0.0001, 0.03% = 0.0003 (typically "hot" for perps)
  const abs = Math.abs(rate);
  if (rate > 0.0003) {
    return { direction: "strongly_bullish", strength: Math.min(0.9, 0.6 + abs * 1000), confidence: "directional" };
  }
  if (rate > 0.0001) {
    return { direction: "bullish", strength: Math.min(0.7, 0.4 + abs * 1000), confidence: "directional" };
  }
  if (rate > 0) {
    return { direction: "mildly_bullish", strength: 0.2 + abs * 1000, confidence: "tentative" };
  }
  if (rate > -0.0001) {
    return { direction: "neutral", strength: 0.1, confidence: "tentative" };
  }
  if (rate > -0.0003) {
    return { direction: "mildly_bearish", strength: 0.2 + abs * 1000, confidence: "tentative" };
  }
  return { direction: "bearish", strength: Math.min(0.7, 0.4 + abs * 1000), confidence: "directional" };
}

export const derivativesSpecialist: Specialist = {
  id: "derivatives_positioning",
  displayName: "Derivatives Positioning",
  description:
    "Reads funding rates and liquidation volumes, emits a directional opinion " +
    "weighted by long/short asymmetry. Crowded longs/funding hot = late-cycle caution.",

  async run(ctx: SpecialistContext): Promise<SpecialistRunResult> {
    const fundings = ctx.observations.filter(o => FUNDING_TYPES.has(o.eventType));
    const liquidations = ctx.observations.filter(o => LIQUIDATION_TYPES.has(o.eventType));

    if (fundings.length === 0 && liquidations.length === 0) {
      return {
        ok: false,
        error: {
          code: "NO_DERIVATIVES_DATA",
          message: `No funding or liquidation observations for ${ctx.canonicalAsset.symbol}`,
          oepOutcome: "INSUFFICIENT_EVIDENCE",
        },
      };
    }

    // Aggregate funding: average across exchanges, weighted by recency
    let fundingSum = 0;
    let fundingWeight = 0;
    let fundingCount = 0;
    let fundingProvider = "unknown";
    let freshestFundingId: string | undefined;
    let freshestFundingTime = "";

    for (const obs of fundings) {
      const payload = (obs.payload ?? {}) as FundingObservationPayload;
      const rate = payload.rate;
      if (rate == null) continue;
      const time = obs.occurredAt ?? obs.receivedAt;
      const w = time > freshestFundingTime ? 1.0 : 0.5;
      fundingSum += rate * w;
      fundingWeight += w;
      fundingCount++;
      if (time > freshestFundingTime) {
        freshestFundingTime = time;
        freshestFundingId = obs.id;
        fundingProvider = obs.provider;
      }
    }

    // Aggregate liquidations: long/short imbalance
    let longLiqUsd = 0;
    let shortLiqUsd = 0;
    for (const obs of liquidations) {
      const payload = (obs.payload ?? {}) as LiquidationObservationPayload;
      if (payload.volumeUsd == null) continue;
      if (payload.side === "long" || payload.side === "buy") longLiqUsd += payload.volumeUsd;
      else if (payload.side === "short" || payload.side === "sell") shortLiqUsd += payload.volumeUsd;
    }
    const totalLiq = longLiqUsd + shortLiqUsd;
    const longLiqShare = totalLiq > 0 ? longLiqUsd / totalLiq : null;

    const avgFunding = fundingWeight > 0 ? fundingSum / fundingWeight : null;
    const dir = directionFromFunding(avgFunding);

    // Liquidation bias: longs being liquidated is mildly bullish (shorts closing)
    // shorts being liquidated is mildly bearish (longs closing). But high lopsided
    // liquidation pressure weakens the funding direction.
    let lopsidedness: "balanced" | "lopsided_longs" | "lopsided_shorts" = "balanced";
    if (longLiqShare != null) {
      if (longLiqShare > 0.7) lopsidedness = "lopsided_longs";
      else if (longLiqShare < 0.3) lopsidedness = "lopsided_shorts";
    }
    let convictionAdjust = 0;
    if (lopsidedness === "lopsided_longs" && dir.direction.includes("bullish")) {
      convictionAdjust = -0.1; // longs getting rekt — late-cycle caution
    } else if (lopsidedness === "lopsided_shorts" && dir.direction.includes("bearish")) {
      convictionAdjust = -0.1;
    } else if (lopsidedness !== "balanced") {
      convictionAdjust = +0.05; // confirmed lopsided move
    }
    const finalStrength = Math.max(0, Math.min(1, dir.strength + convictionAdjust));

    const fundingPct = avgFunding != null ? (avgFunding * 100).toFixed(4) + "%" : "UNKNOWN";
    const directionWord =
      dir.direction === "neutral" ? "balanced funding" :
      dir.direction.startsWith("strongly_") ? `${dir.direction.replace("strongly_", "")} funding (strong)` :
      `${dir.direction} funding`;

    const summary =
      `Derivatives position on ${ctx.canonicalAsset.symbol}: ${directionWord} ` +
      `(funding ${fundingPct}${totalLiq > 0 ? `, liquidations ${lopsidedness}` : ""}).`;

    const reasoning = [
      `Aggregated funding from ${fundingCount} source${fundingCount === 1 ? "" : "s"}.`,
      avgFunding != null ? `Mean funding rate: ${(avgFunding * 100).toFixed(4)}% per 8h.` : "Funding UNKNOWN.",
      totalLiq > 0
        ? `Liquidations: $${(longLiqUsd / 1_000_000).toFixed(1)}M longs, $${(shortLiqUsd / 1_000_000).toFixed(1)}M shorts. Long-share: ${(longLiqShare! * 100).toFixed(1)}%.`
        : "No recent liquidations in window.",
      `Lopsidedness: ${lopsidedness}.`,
      `Classified direction: ${dir.direction} (strength ${dir.strength.toFixed(2)}).`,
      `Conviction adjustment: ${convictionAdjust >= 0 ? "+" : ""}${convictionAdjust.toFixed(2)}.`,
      `Final strength: ${finalStrength.toFixed(2)}.`,
    ].join(" ");

    const evidence: EvidenceRef[] = [];
    if (freshestFundingId) {
      evidence.push({
        observationId: freshestFundingId,
        provider: fundingProvider,
        capability: "derivs.funding",
        description: `Funding observation (freshest) at ${freshestFundingTime}`,
        weight: 0.8,
        freshness: (Date.now() - new Date(freshestFundingTime).getTime() < 60_000 ? "live" : "recent") as "live" | "recent",
      });
    }
    for (const obs of liquidations.slice(0, 2)) {
      evidence.push({
        observationId: obs.id,
        provider: obs.provider,
        capability: "derivs.liquidations",
        description: `Liquidation at ${obs.occurredAt ?? "?"}`,
        weight: 0.5,
        freshness: ((obs.occurredAt && Date.now() - new Date(obs.occurredAt).getTime() < 60_000) ? "live" : "recent") as "live" | "recent",
      });
    }

    return {
      ok: true,
      opinions: [
        {
          id: randomUUID(),
          specialistId: "derivatives_positioning",
          canonicalAssetId: ctx.canonicalAsset.id,
          type: "thesis",
          direction: dir.direction,
          confidence: dir.confidence,
          strength: finalStrength,
          summary,
          reasoning,
          evidence,
          respondsTo: [],
          emittedAt: new Date().toISOString(),
          seed: ctx.seed,
          caveats: [
            avgFunding == null ? "Funding UNKNOWN." : "",
            totalLiq === 0 ? "No recent liquidation data." : "",
            lopsidedness !== "balanced" ? `Lopsided liquidation pressure (${lopsidedness}) — may be late-cycle.` : "",
          ].filter(Boolean),
        },
      ],
    };
  },
};
