/**
 * Specialist orchestrator.
 *
 * Coordinates specialist runs for a single asset, in dependency order:
 *   1. Independent specialists (market_structure, derivatives, social) — read observations
 *   2. Risk specialist — depends on metadata + prior opinions
 *   3. Reconciler — depends on ≥2 priors
 *   4. Challenger — depends on all priors (must run last)
 *   5. Portfolio allocator — depends on priors, must respect risk vetoes
 *
 * The orchestrator emits an aggregate *result* that includes the final
 * opportunity rank, allocation hint, and the open challenges the human
 * must address.
 *
 * Per the Iyaza addendum: the orchestrator never re-orders specialists in
 * ways that hide evidence; it always records what was run, in what order,
 * and what each specialist said.
 */

import { randomUUID } from "node:crypto";
import { z } from "zod";
import { type CanonicalAsset, type NormalizedObservation } from "../domain/index.js";
import { type Specialist, type SpecialistOpinion, type SpecialistRunResult } from "./contract.js";
import { marketStructureSpecialist } from "./marketStructure.js";
import { derivativesSpecialist } from "./derivatives.js";
import { socialSpecialist } from "./social.js";
import { riskSpecialist } from "./risk.js";
import { reconcilerSpecialist } from "./reconciler.js";
import { challengerSpecialist } from "./challenger.js";
import { portfolioSpecialist } from "./portfolio.js";
import { partitionObservationsByEligibility } from "../providers/eligibility.js";

export interface OrchestratorInput {
  canonicalAsset: CanonicalAsset;
  observations: NormalizedObservation[];
  metadata?: {
    watchlistRank?: number;
    watchlistSize?: number;
    factorScores?: Record<string, number>;
    opportunityRank?: number;
    allocationRank?: number;
    hardGateTripped?: boolean;
    [key: string]: unknown;
  };
  /** Seed for reproducibility. */
  seed?: number;
}

export interface OrchestratorResult {
  assetId: string;
  symbol: string;
  runId: string;
  startedAt: string;
  finishedAt: string;
  /** All opinions in the order they were produced. */
  opinions: SpecialistOpinion[];
  /** Open challenges that block the conclusion. */
  openChallenges: SpecialistOpinion[];
  /** Final reconciled direction + strength. */
  reconciled: { direction: string; strength: number; confidence: string } | null;
  /** Final allocation hint. */
  allocation: { targetWeightPct: number; rationale: string } | null;
  /** Whether risk vetoes are active. */
  vetoed: boolean;
  /** All specialist errors. */
  errors: Array<{ specialistId: string; code: string; message: string; oepOutcome?: string }>;
  /** Specialist execution order. */
  executionOrder: string[];
  /** v0.4.4 audit fix (P0-1): counts of observations excluded by the
   *  eligibility policy. The case file / audit trail can show this
   *  for transparency; scoring used only the eligible subset. */
  excludedObservations: { ambiguous: number; quarantined: number };
}

/** Specialist registry. Could be loaded from capability registry; kept simple here. */
const SPECIALIST_REGISTRY: Record<string, Specialist> = {
  market_structure: marketStructureSpecialist,
  derivatives_positioning: derivativesSpecialist,
  social_attention: socialSpecialist,
  risk_compliance: riskSpecialist,
  evidence_reconciler: reconcilerSpecialist,
  challenger: challengerSpecialist,
  portfolio_allocator: portfolioSpecialist,
};

/** Per-asset orchestrator pipeline. Specialists run in this order. */
const PIPELINE = [
  "market_structure",
  "derivatives_positioning",
  "social_attention",
  "risk_compliance",
  "evidence_reconciler",
  "challenger",
  "portfolio_allocator",
] as const;

export async function orchestrate(input: OrchestratorInput): Promise<OrchestratorResult> {
  const startedAt = new Date().toISOString();
  const runId = randomUUID();
  const seed = input.seed ?? Math.floor(Math.random() * 1_000_000);

  // v0.4.4 audit fix (P0-1): ambiguous / quarantined observations are
  // partitioned out BEFORE specialists run. The excluded observations
  // are still recorded in the result for the case file (so the
  // operator can see "excluded evidence requiring identity resolution")
  // but they cannot affect any specialist's opinion, factor score,
  // target weight, or rank.
  const partition = partitionObservationsByEligibility(input.observations);
  const eligible = partition.eligible;
  const excludedAmbiguous = partition.displayOnlyAmbiguous.length;
  const excludedQuarantined = partition.quarantined.length;

  const allOpinions: SpecialistOpinion[] = [];
  const errors: OrchestratorResult["errors"] = [];
  const executionOrder: string[] = [];

  for (const specialistId of PIPELINE) {
    const specialist = SPECIALIST_REGISTRY[specialistId];
    if (!specialist) {
      errors.push({ specialistId, code: "UNKNOWN_SPECIALIST", message: `Specialist ${specialistId} not registered` });
      continue;
    }
    executionOrder.push(specialistId);

    // Build context incrementally: each specialist sees all prior opinions.
    // v0.4.4: specialists see ONLY analytically eligible observations.
    const priorOpinions = allOpinions.filter(o => o.canonicalAssetId === input.canonicalAsset.id);
    let result: SpecialistRunResult;
    try {
      result = await specialist.run({
        canonicalAsset: input.canonicalAsset,
        observations: eligible,
        priorOpinions,
        metadata: input.metadata,
        seed,
      });
    } catch (e) {
      errors.push({
        specialistId,
        code: "EXCEPTION",
        message: e instanceof Error ? e.message : String(e),
      });
      continue;
    }

    if (!result.ok) {
      errors.push({
        specialistId,
        code: result.error.code,
        message: result.error.message,
        oepOutcome: result.error.oepOutcome,
      });
      continue;
    }

    for (const op of result.opinions) {
      allOpinions.push(op);
    }
  }

  const finishedAt = new Date().toISOString();

  // Find vetoes
  const BEARISH_DIRECTIONS = new Set(["bearish", "strongly_bearish", "mildly_bearish"]);
  const vetoes = allOpinions.filter(o => o.type === "risk_flag" && o.strength >= 0.8 && BEARISH_DIRECTIONS.has(o.direction));
  const vetoed = vetoes.length > 0;

  // Find open challenges (challenger opinions)
  const openChallenges = allOpinions.filter(o => o.type === "challenge");

  // Reconciled view
  const reconciled = allOpinions.find(o => o.type === "reconciliation") ?? null;

  // Final allocation
  const allocation = allOpinions.find(o => o.type === "allocation_hint") ?? null;

  return {
    assetId: input.canonicalAsset.id,
    symbol: input.canonicalAsset.symbol,
    runId,
    startedAt,
    finishedAt,
    opinions: allOpinions,
    openChallenges,
    reconciled: reconciled
      ? { direction: reconciled.direction, strength: reconciled.strength, confidence: reconciled.confidence }
      : null,
    allocation: allocation
      ? { targetWeightPct: allocation.strength, rationale: allocation.summary }
      : null,
    vetoed,
    errors,
    executionOrder,
    // v0.4.4 audit fix (P0-1): record how many observations were
    // excluded from the specialist pipeline because of weak identity.
    // The case file / audit trail can show this; scoring already used
    // only the eligible subset.
    excludedObservations: {
      ambiguous: excludedAmbiguous,
      quarantined: excludedQuarantined,
    },
  };
}

/** Summary aggregate over many assets — used by the runtime to build a portfolio snapshot. */
export function aggregateAcrossAssets(results: OrchestratorResult[]): {
  totalAllocatedPct: number;
  reservePct: number;
  byAsset: Array<{ symbol: string; assetId: string; targetWeightPct: number; reconciledDirection: string; reconciledStrength: number; vetoed: boolean; openChallenges: number }>;
  vetoedAssets: string[];
  challengeCount: number;
} {
  const byAsset = results.map(r => ({
    symbol: r.symbol,
    assetId: r.assetId,
    targetWeightPct: r.vetoed ? 0 : (r.allocation?.targetWeightPct ?? 0),
    reconciledDirection: r.reconciled?.direction ?? "neutral",
    reconciledStrength: r.reconciled?.strength ?? 0,
    vetoed: r.vetoed,
    openChallenges: r.openChallenges.length,
  }));
  const totalAllocatedPct = byAsset.reduce((acc, a) => acc + a.targetWeightPct, 0);
  const reservePct = Math.max(0, 1 - totalAllocatedPct);
  return {
    totalAllocatedPct,
    reservePct,
    byAsset,
    vetoedAssets: byAsset.filter(a => a.vetoed).map(a => a.symbol),
    challengeCount: byAsset.reduce((acc, a) => acc + a.openChallenges, 0),
  };
}

/** Expose the registry so other modules can introspect or test. */
export function getSpecialistRegistry(): Record<string, Specialist> {
  return SPECIALIST_REGISTRY;
}

export const orchestratorContractSchema = z.object({
  runId: z.string(),
  symbol: z.string(),
  startedAt: z.string(),
  finishedAt: z.string(),
  opinionCount: z.number().int().min(0),
  openChallenges: z.number().int().min(0),
  vetoed: z.boolean(),
  reconciledDirection: z.string().nullable(),
  reconciledStrength: z.number().min(0).max(1).nullable(),
  allocationPct: z.number().min(0).max(1).nullable(),
});
