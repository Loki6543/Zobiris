/**
 * Normalize weights to target (allocated + reserve) = 100%.
 *
 * Positive weights are proportionally scaled to (100 - reserve), subject to
 * every active hard risk-gate cap. Binding caps are frozen first and only the
 * remaining uncapped assets receive the remaining budget. If every eligible
 * asset is capped, the portfolio stays under-allocated rather than weakening
 * a safety constraint.
 *
 * This module is deterministic and side-effect free.
 */

import { type AssetAnalysisSnapshot, type PortfolioAnalysisSnapshot } from "../domain/portfolio.js";
import { assignAllocationRanks, assignOpportunityRanks } from "./ranks.js";
import type { ScoringConfig } from "../domain/scoring.js";

const TOLERANCE = 0.1;     // 0.1% tolerance for the 100% sum invariant

export interface NormalizeResult {
  snapshot: PortfolioAnalysisSnapshot;
  diagnostics: {
    allocatedPct: number;
    reservePct: number;
    unallocatedPct: number;
    bindingRiskCapCount: number;
    zeroCount: number;
  };
}

export function normalizePortfolio(
  assets: AssetAnalysisSnapshot[],
  config: ScoringConfig,
  previous: PortfolioAnalysisSnapshot | null,
): NormalizeResult {
  // Step 1: assign ranks
  assignOpportunityRanks(assets);
  assignAllocationRanks(assets);

  // Step 2: bounded proportional allocation (water filling). Risk-gate caps
  // are non-averagable and must survive portfolio-level normalization.
  const reserve = config.reservePct;
  const target = 100 - reserve;
  let zeroed = 0;
  const allocations = allocateWithinRiskCaps(assets, target);
  const scaled = assets.map((asset, index) => {
    const pct = allocations[index] ?? 0;
    if (pct <= 0) zeroed++;
    return { ...asset, targetWeight: { ...asset.targetWeight, pct } };
  });
  const bindingRiskCapCount = scaled.filter((asset) => {
    const cap = strictRiskCap(asset);
    return Number.isFinite(cap) && asset.targetWeight.pct > 0 &&
      Math.abs(asset.targetWeight.pct - cap) <= 0.0001;
  }).length;

  // Re-rank after scaling
  assignAllocationRanks(scaled);

  const finalAlloc = scaled.reduce((s, a) => s + a.targetWeight.pct, 0);
  const unallocated = Math.max(0, 100 - finalAlloc - reserve);

  // Build the snapshot
  const changes = computeChanges(previous, scaled);

  const snapshot: PortfolioAnalysisSnapshot = {
    asOf: new Date().toISOString(),
    policyVersion: config.version,
    regime: previous?.regime ?? "UNKNOWN",
    regimeConfidence: previous?.regimeConfidence ?? 0,
    totalAllocatedPct: round(finalAlloc, 2),
    reservePct: reserve,
    unallocatedPct: round(unallocated, 2),
    conclusion: previous?.conclusion ?? "",
    rankedAssets: scaled,
    sectorConcentration: {},     // populated in slice 4
    narrativeConcentration: {},  // populated in slice 4
    topRiskGates: scaled
      .flatMap(a => a.riskGates.map(g => ({ ...g, reason: `${a.symbol}: ${g.reason}` })))
      .filter(g => g.active)
      .slice(0, 10),
    changesSinceLastRefresh: changes,
    stages: [],
  };

  return {
    snapshot,
    diagnostics: {
      allocatedPct: round(finalAlloc, 2),
      reservePct: reserve,
      unallocatedPct: round(unallocated, 2),
      bindingRiskCapCount,
      zeroCount: zeroed,
    },
  };
}

function strictRiskCap(asset: AssetAnalysisSnapshot): number {
  if (asset.riskGates.some((gate) => gate.active && gate.effect === "veto")) return 0;
  const caps = asset.riskGates
    .filter((gate) => gate.active && gate.effect === "size_cap" && typeof gate.cap === "number")
    .map((gate) => gate.cap!);
  return caps.length > 0 ? Math.min(...caps) : Number.POSITIVE_INFINITY;
}

function allocateWithinRiskCaps(
  assets: AssetAnalysisSnapshot[],
  target: number,
): number[] {
  const allocations = assets.map(() => 0);
  let remainingBudget = Math.max(0, target);
  let active = assets
    .map((asset, index) => ({
      index,
      base: Math.max(0, asset.targetWeight.pct),
      cap: strictRiskCap(asset),
    }))
    .filter((item) => item.base > 0 && item.cap > 0);

  while (active.length > 0 && remainingBudget > 0) {
    const baseSum = active.reduce((sum, item) => sum + item.base, 0);
    if (baseSum <= 0) break;
    const scale = remainingBudget / baseSum;
    const newlyBinding = active.filter(
      (item) => Number.isFinite(item.cap) && item.base * scale > item.cap,
    );
    if (newlyBinding.length === 0) {
      for (const item of active) {
        allocations[item.index] = Math.min(item.cap, round(item.base * scale, 4));
      }
      remainingBudget = 0;
      break;
    }
    const bindingIndexes = new Set(newlyBinding.map((item) => item.index));
    for (const item of newlyBinding) {
      allocations[item.index] = Math.min(item.cap, round(item.cap, 4));
      remainingBudget = Math.max(0, remainingBudget - item.cap);
    }
    active = active.filter((item) => !bindingIndexes.has(item.index));
  }

  return allocations;
}

function round(n: number, places: number): number {
  const f = Math.pow(10, places);
  return Math.round(n * f) / f;
}

function computeChanges(previous: PortfolioAnalysisSnapshot | null, current: AssetAnalysisSnapshot[]) {
  if (!previous) {
    return {
      rankUps: [],
      rankDowns: [],
      newTopTen: [],
      droppedTopTen: [],
      largestTargetWeightChanges: [],
    };
  }
  const prevBySymbol = new Map(previous.rankedAssets.map(a => [a.symbol, a] as const));
  const rankUps: string[] = [];
  const rankDowns: string[] = [];
  for (const a of current) {
    const prev = prevBySymbol.get(a.symbol);
    if (!prev || a.opportunityRank == null || prev.opportunityRank == null) continue;
    if (a.opportunityRank < prev.opportunityRank) rankUps.push(a.symbol);
    if (a.opportunityRank > prev.opportunityRank) rankDowns.push(a.symbol);
  }
  const prevTop10 = previous.rankedAssets
    .filter(a => a.opportunityRank != null && a.opportunityRank <= 10)
    .map(a => a.symbol);
  const currTop10 = current
    .filter(a => a.opportunityRank != null && a.opportunityRank <= 10)
    .map(a => a.symbol);
  const newTopTen = currTop10.filter(s => !prevTop10.includes(s));
  const droppedTopTen = prevTop10.filter(s => !currTop10.includes(s));
  const largestTargetWeightChanges = current
    .map(a => {
      const prev = prevBySymbol.get(a.symbol);
      if (!prev) return null;
      const delta = a.targetWeight.pct - prev.targetWeight.pct;
      return { symbol: a.symbol, from: prev.targetWeight.pct, to: a.targetWeight.pct, delta: round(delta, 2) };
    })
    .filter((x): x is { symbol: string; from: number; to: number; delta: number } => x != null && Math.abs(x.delta) > 0.5)
    .sort((a, b) => Math.abs(b.delta) - Math.abs(a.delta))
    .slice(0, 10);
  return { rankUps, rankDowns, newTopTen, droppedTopTen, largestTargetWeightChanges };
}

export { TOLERANCE as PORTFOLIO_SUM_TOLERANCE };
