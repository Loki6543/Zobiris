/**
 * Two-rank split: Opportunity Rank vs Allocation Rank.
 *
 * Per docs/SCORING_AND_PORTFOLIO.md:
 *   "A speculative asset can rank #3 in opportunity and #17 in allocation.
 *    This is desired behavior."
 *
 *   Opportunity Rank: raw/adjusted attractiveness.
 *   Allocation Rank: actual priority for capital after confidence, risk, gates.
 */

import { type AssetAnalysisSnapshot } from "../domain/portfolio.js";

export function assignOpportunityRanks(assets: AssetAnalysisSnapshot[]): AssetAnalysisSnapshot[] {
  // Eligible = currentAnalysisReady (has score, confidence, market data within budget)
  const eligible = assets
    .filter(a => a.evidenceState !== "STALE" && a.evidenceState !== "UNKNOWN" && a.opportunity.adjusted > 0)
    .slice()
    .sort((a, b) => b.opportunity.adjusted - a.opportunity.adjusted);
  eligible.forEach((a, i) => { a.opportunityRank = i + 1; });
  for (const a of assets) {
    if (a.opportunityRank == null || (a.opportunityRank ?? 0) === 0) {
      a.opportunityRank = null;
    }
  }
  return assets;
}

export function assignAllocationRanks(assets: AssetAnalysisSnapshot[]): AssetAnalysisSnapshot[] {
  const eligible = assets
    .filter(a => a.targetWeight.pct > 0)
    .slice()
    .sort((a, b) => b.targetWeight.pct - a.targetWeight.pct);
  eligible.forEach((a, i) => { a.allocationRank = i + 1; });
  for (const a of assets) {
    if (!(a.targetWeight.pct > 0)) a.allocationRank = null;
  }
  return assets;
}
