/**
 * Top-level portfolio builder.
 *
 * Given a watchlist + observations, produce a per-asset analysis snapshot.
 * This module orchestrates: raw score, confidence, gates, weights. It does
 * NOT normalize to 100% (that's normalizePortfolio).
 */

import {
  type CanonicalAsset,
  type AssetAnalysisSnapshot,
  type PortfolioRole,
  type ActionLabel,
  type RiskLevel,
  type FactorScore,
} from "../domain/index.js";
import { computeRawScore, type RawFactorInput } from "../scoring/score.js";
import { computeConfidence } from "../scoring/confidence.js";
import { evaluateRiskGates, classifyRisk, type RiskGateContext } from "../scoring/riskGates.js";
import { computeTargetWeight } from "../scoring/weights.js";
import { DEFAULT_SCORING_CONFIG, type ScoringConfig } from "../domain/scoring.js";
import { type EpistemicState } from "../domain/evidence.js";

export interface AssetEvidenceSummary {
  hasMarketPrice: boolean;
  hasSocial: boolean;
  hasDerivatives: boolean;
  hasOnchain: boolean;
  hasCatalysts: boolean;
  identityConfidence: number;        // 1 if verified, 0.5 if unmapped, 0 if ambiguous
  identityEpistemicState: EpistemicState;
  priceEpistemicState: EpistemicState;
  socialEpistemicState: EpistemicState;
  derivativesEpistemicState: EpistemicState;
  onchainEpistemicState: EpistemicState;
  catalystsEpistemicState: EpistemicState;
  crossSourceAgreement: number;     // 0-1: how many distinct providers contributed
  freshness: number;                 // 0-1
  conflictCount: number;
  change24hPct: number | null;
  price: number | null;
  exploitFlagged: boolean;
  upcomingUnlockPct: number | undefined;
  holderConcentration: number | undefined;
  volumeToMcRatio: number | undefined;
  projectIntegrityOk: boolean | undefined;
}

export interface BuildAssetInput {
  symbol: string;
  canonical: CanonicalAsset | null;
  evidence: AssetEvidenceSummary;
  evidenceClaimIds: string[];
  evidenceClaimIdsByFamily?: Partial<Record<FactorScore["family"], string[]>>;
  config?: ScoringConfig;
}

// SECTOR_BY_SYMBOL removed in slice 1; sector classification is a slice 3 deliverable
// (cross-asset sector exposure + risk budgeting). The active watchlist is currently
// treated as a flat universe for opportunity/portfolio ranking.
export function buildAssetSnapshot(input: BuildAssetInput): AssetAnalysisSnapshot {
  const cfg = input.config ?? DEFAULT_SCORING_CONFIG;
  const symbol = input.symbol;
  const canonical = input.canonical;
  const e = input.evidence;

  // Factor scores: each is 0-100 from "specialist", with epistemic discount.
  const factors: RawFactorInput[] = [
    { family: "marketTechnical", raw: marketTechnicalScore(e), epistemicState: e.priceEpistemicState, evidenceClaimIds: input.evidenceClaimIdsByFamily?.marketTechnical },
    { family: "fundamentalTokenomics", raw: fundamentalScore(e), epistemicState: e.catalystsEpistemicState, evidenceClaimIds: input.evidenceClaimIdsByFamily?.fundamentalTokenomics },
    { family: "liquidityMarketStructure", raw: liquidityScore(e), epistemicState: e.priceEpistemicState, evidenceClaimIds: input.evidenceClaimIdsByFamily?.liquidityMarketStructure },
    { family: "socialAttention", raw: socialScore(e), epistemicState: e.socialEpistemicState, evidenceClaimIds: input.evidenceClaimIdsByFamily?.socialAttention },
    { family: "derivativesLeverage", raw: derivativesScore(e), epistemicState: e.derivativesEpistemicState, evidenceClaimIds: input.evidenceClaimIdsByFamily?.derivativesLeverage },
    { family: "onchainPositioning", raw: onchainScore(e), epistemicState: e.onchainEpistemicState, evidenceClaimIds: input.evidenceClaimIdsByFamily?.onchainPositioning },
    { family: "catalystsNarrative", raw: catalystsScore(e), epistemicState: e.catalystsEpistemicState, evidenceClaimIds: input.evidenceClaimIdsByFamily?.catalystsNarrative },
    { family: "asymmetryConvexity", raw: asymmetryScore(e), epistemicState: e.priceEpistemicState, evidenceClaimIds: input.evidenceClaimIdsByFamily?.asymmetryConvexity },
  ];

  const coverage = (
    (e.hasMarketPrice ? 1 : 0) +
    (e.hasSocial ? 1 : 0) +
    (e.hasDerivatives ? 1 : 0) +
    (e.hasOnchain ? 1 : 0) +
    (e.hasCatalysts ? 1 : 0) +
    (canonical ? 1 : 0)
  ) / 6;

  const rawScore = computeRawScore({ factors, evidenceCoverage: coverage, config: cfg });

  const confidence = computeConfidence({
    sourceReputation: sourceReputationFor(e),
    coverage,
    freshness: e.freshness,
    crossSourceAgreement: e.crossSourceAgreement,
    identityConfidence: e.identityConfidence,
    unresolvedConflicts: e.conflictCount,
  });

  const gateCtx: RiskGateContext = {
    symbol,
    mappingStatus: canonical?.mappingStatus ?? "unmapped",
    hasMarketData: e.hasMarketPrice,
    exploitFlagged: e.exploitFlagged,
    upcomingUnlockPct: e.upcomingUnlockPct,
    holderConcentration: e.holderConcentration,
    volumeToMcRatio: e.volumeToMcRatio,
    criticalEvidenceStale: e.priceEpistemicState === "STALE",
    criticalEvidenceConflicted: e.priceEpistemicState === "CONFLICTED",
    projectIntegrityOk: e.projectIntegrityOk,
  };
  const gates = evaluateRiskGates(gateCtx);
  const risk = classifyRisk({ gates, hasMarketData: e.hasMarketPrice, change24hPct: e.change24hPct });

  const weight = computeTargetWeight({
    symbol,
    adjustedScore: rawScore.adjusted,
    confidencePct: confidence.pct,
    risk,
    gates,
    scalars: {
      volatility: 0.7,
      liquidity: e.hasMarketPrice ? 0.8 : 0.3,
      regime: 0.7,
      diversification: 0.7,
      correlation: 0.7,
    },
    config: cfg,
  });

  const role = roleFor(symbol, rawScore.adjusted, gates, coverage, risk);
  const action = actionFor(rawScore.adjusted, confidence.pct, risk, gates, e, cfg);
  const evidenceState: EpistemicState = e.priceEpistemicState === "STALE" ? "STALE" :
    e.priceEpistemicState === "CONFLICTED" ? "CONFLICTED" :
    !e.hasMarketPrice ? "UNKNOWN" :
    coverage > 0.6 ? "KNOWN" : "INFERRED";

  return {
    symbol,
    canonicalAssetId: canonical?.id ?? null,
    mappingStatus: canonical?.mappingStatus ?? "unmapped",
    asOf: new Date().toISOString(),
    opportunity: rawScore,
    confidence,
    riskGates: gates,
    targetWeight: weight,
    role,
    action,
    risk,
    evidenceClaimIds: input.evidenceClaimIds,
    counterEvidenceClaimIds: [],
    evidenceState,
    conclusion: buildConclusion({ symbol, role, action, weight, gates, evidence: e, rawScore, confidence }),
    scenarios: {},
    invalidationConditions: [],
    opportunityRank: null,
    allocationRank: null,
    evidenceCoverage: round(coverage, 3),
    criticalUnknowns: 6 - Math.round(coverage * 6),
  };
}

export function isEligibleForRank(snapshot: AssetAnalysisSnapshot): boolean {
  return snapshot.evidenceState !== "STALE" && snapshot.evidenceState !== "UNKNOWN"
    && snapshot.opportunity.adjusted > 0;
}

function marketTechnicalScore(e: AssetEvidenceSummary): number {
  if (!e.hasMarketPrice || e.change24hPct == null) return 0;
  // Simple model: |change| maps to 50-80, with sign mattering.
  // Real implementation would use trend, momentum, relative strength.
  const abs = Math.abs(e.change24hPct);
  const base = 50 + Math.min(40, abs * 4);
  return Math.max(0, Math.min(100, e.change24hPct >= 0 ? base : base - 10));
}

function fundamentalScore(e: AssetEvidenceSummary): number {
  let s = 55;
  if (e.hasCatalysts) s += 20;
  if (e.upcomingUnlockPct != null && e.upcomingUnlockPct < 2) s += 5;
  if (e.holderConcentration != null && e.holderConcentration < 0.5) s += 5;
  return Math.max(0, Math.min(100, s));
}

function liquidityScore(e: AssetEvidenceSummary): number {
  if (!e.hasMarketPrice) return 0;
  // Real implementation would use volume/MC and orderbook depth.
  if (e.volumeToMcRatio == null) return 60;
  const s = 40 + Math.min(60, e.volumeToMcRatio * 12);
  return Math.max(0, Math.min(100, s));
}

function socialScore(e: AssetEvidenceSummary): number {
  if (!e.hasSocial) return 0;
  return e.socialEpistemicState === "KNOWN" ? 70 :
         e.socialEpistemicState === "INFERRED" ? 55 : 35;
}

function derivativesScore(e: AssetEvidenceSummary): number {
  if (!e.hasDerivatives) return 0;
  return e.derivativesEpistemicState === "KNOWN" ? 60 : 35;
}

function onchainScore(e: AssetEvidenceSummary): number {
  if (!e.hasOnchain) return 0;
  return e.onchainEpistemicState === "KNOWN" ? 60 : 35;
}

function catalystsScore(e: AssetEvidenceSummary): number {
  if (!e.hasCatalysts) return 0;
  return e.catalystsEpistemicState === "KNOWN" ? 80 :
         e.catalystsEpistemicState === "INFERRED" ? 60 : 40;
}

function asymmetryScore(_e: AssetEvidenceSummary): number {
  // Heuristic: 55 baseline for any asset with some evidence.
  return 55;
}

function sourceReputationFor(e: AssetEvidenceSummary): number {
  // Tiered reputation. Real impl would per-provider.
  let r = 0;
  if (e.hasMarketPrice) r += 0.3;
  if (e.hasSocial) r += 0.2;
  if (e.hasDerivatives) r += 0.2;
  if (e.hasOnchain) r += 0.15;
  if (e.hasCatalysts) r += 0.15;
  return Math.min(1, r);
}

function roleFor(_symbol: string, score: number, gates: ReturnType<typeof evaluateRiskGates>, coverage: number, risk: RiskLevel): PortfolioRole {
  if (gates.some(g => g.effect === "veto")) return "EXIT_CANDIDATE";
  if (coverage < 0.3) return "WATCHLIST";
  if (score >= 80 && risk !== "High") return "CORE";
  if (score >= 70 && risk !== "High") return "GROWTH";
  if (score >= 60 && gates.length === 0) return "ASYMMETRIC";
  if (score >= 50) return "TACTICAL";
  return "WATCHLIST";
}

function actionFor(
  score: number, confidence: number, risk: RiskLevel, gates: ReturnType<typeof evaluateRiskGates>,
  e: AssetEvidenceSummary, cfg: ScoringConfig,
): ActionLabel {
  if (gates.some(g => g.effect === "veto")) return "AVOID";
  if (!e.hasMarketPrice) return "RESEARCH";
  if (e.priceEpistemicState === "STALE") return "REVALIDATE";
  if (score >= cfg.buyThreshold && confidence >= cfg.minConfidenceForBuy && risk === "Low") return "STRONG_BUY";
  if (score >= cfg.buyThreshold && confidence >= cfg.minConfidenceForBuy) return "BUY";
  if (score >= cfg.accumulateThreshold && confidence >= 60) return "ACCUMULATE";
  if (score >= cfg.holdThreshold) return "HOLD";
  if (score >= 50) return "RESEARCH";
  return "REDUCE";
}

function buildConclusion(input: {
  symbol: string; role: PortfolioRole; action: ActionLabel;
  weight: ReturnType<typeof computeTargetWeight>;
  gates: ReturnType<typeof evaluateRiskGates>;
  evidence: AssetEvidenceSummary;
  rawScore: ReturnType<typeof computeRawScore>;
  confidence: ReturnType<typeof computeConfidence>;
}): string {
  const e = input.evidence;
  const lines: string[] = [];
  lines.push(`${input.symbol}: role=${input.role}, action=${input.action}, weight=${input.weight.pct.toFixed(2)}%.`);
  lines.push(`Score ${input.rawScore.adjusted.toFixed(1)} (raw ${input.rawScore.raw.toFixed(1)}, penalty ${input.rawScore.evidenceGapPenalty.toFixed(1)}).`);
  lines.push(`Confidence ${input.confidence.pct.toFixed(0)}%.`);
  if (e.hasMarketPrice) {
    lines.push(`Price available; 24h change ${e.change24hPct?.toFixed(2) ?? "—"}%.`);
  } else {
    lines.push(`No current market price.`);
  }
  if (input.gates.length) {
    lines.push(`Active risk gates: ${input.gates.map(g => g.code).join(", ")}.`);
  } else {
    lines.push(`No active risk gates.`);
  }
  if (!e.hasSocial) lines.push(`Social evidence missing (LunarCrush adapter fixture not loaded in slice 1).`);
  if (!e.hasDerivatives) lines.push(`Derivatives evidence missing (CoinGlass adapter fixture not loaded in slice 1).`);
  return lines.join(" ");
}

function round(n: number, places: number): number {
  const f = Math.pow(10, places);
  return Math.round(n * f) / f;
}
