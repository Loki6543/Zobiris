/**
 * Per-asset case file builder.
 *
 * Per docs/PRODUCT_REQUIREMENTS.md and the master prompt, every asset must
 * have a rich, evidence-backed case file. Slice 5+ v0.4.0 expands the case
 * file with:
 *  - score anatomy (per-factor contributions)
 *  - evidence summary (which providers contributed what)
 *  - scenarios (bull/base/bear)
 *  - invalidation conditions
 *  - specialist reconciliation
 *  - open challenges
 *  - the risk gate history
 */

import {
  type AssetAnalysisSnapshot,
  type NormalizedObservation,
} from "../domain/index.js";
import { type CanonicalAsset } from "../domain/canonicalAsset.js";
import { type OrchestratorResult } from "../specialists/orchestrator.js";
import { isObservationEligibleForAnalysis } from "../providers/eligibility.js";

export interface CaseFileEvidence {
  provider: string;
  capability: string;
  eventType: string;
  observedAt: string | null;
  receivedAt: string;
  epistemicState: string;
  confidence: number;
  summary: string;
  dataMode: "live" | "snapshot" | "fallback";
  providerEndpoint: string | null;
  payloadHash: string | null;
  requestedMarket: string | null;
  eligibility:
    "eligible" | "display_only_ambiguous" | "quarantined" | "rejected";
}

export interface CaseFileClaimInput {
  id: string;
  claim: string;
  source: string;
  factorFamily: string;
  epistemicState: string;
  freshness: string;
  dataMode: string;
}

export interface CaseFile {
  symbol: string;
  asOf: string;
  canonical: CanonicalAsset | null;
  identity: {
    status: string;
    confidence: number;
    chainId: string | null;
    contractAddress: string | null;
    providerIds: Record<string, string>;
  };
  score: {
    opportunity: number;
    confidence: number;
    targetWeightPct: number;
    opportunityRank: number | null;
    allocationRank: number | null;
  };
  conclusion: string;
  role: string;
  action: string;
  risk: string;
  scenarios: {
    bull: string | null;
    base: string | null;
    bear: string | null;
  };
  invalidationConditions: string[];
  evidenceCoverage: number;
  criticalUnknowns: number;
  evidence: CaseFileEvidence[];
  contradictions: Array<{
    code: string;
    summary: string;
    source: string;
    factorFamily: string;
    claimId: string | null;
  }>;
  unknowns: Array<{
    code: string;
    summary: string;
    severity: "critical" | "warning" | "informational";
  }>;
  /** v0.4.0: cognitive specialist reconciliation */
  specialist: {
    reconciledDirection: string;
    reconciledStrength: number;
    reconciledConfidence: string;
    targetWeightPct: number;
    vetoed: boolean;
    vetoReason: string | null;
    openChallenges: Array<{
      code: string;
      summary: string;
      rationale: string;
    }>;
    specialistOpinions: Array<{
      specialistId: string;
      type: string;
      direction: string;
      confidence: string;
      strength: number;
      summary: string;
    }>;
  } | null;
  /** v0.6.0 Strategy Engine 2.1 decision layer (serialized from the snapshot). */
  strategy21: unknown | null;
  /** Audit trail of recent conclusions for this asset. */
  recentHistory: Array<{
    asOf: string;
    opportunity: number;
    confidence: number;
    action: string;
  }>;
  changeSincePrevious: {
    previousAsOf: string;
    opportunityDelta: number;
    confidenceDelta: number;
    actionChanged: boolean;
    previousAction: string;
  } | null;
  /** Honest disclosures. */
  caveats: string[];
}

export interface BuildCaseFileInput {
  symbol: string;
  assetAnalysis: AssetAnalysisSnapshot | null;
  canonical: CanonicalAsset | null;
  observations: NormalizedObservation[];
  evidenceClaims?: CaseFileClaimInput[];
  specialistResult: OrchestratorResult | null;
  /** Optional: previous snapshots to build a recent history. */
  recentHistory?: Array<{
    asOf: string;
    rankedAssets: Array<{
      symbol: string;
      opportunity: { adjusted: number };
      confidence: { pct: number };
      action: string;
    }>;
  }>;
}

export function buildCaseFile(input: BuildCaseFileInput): CaseFile {
  const {
    symbol,
    assetAnalysis,
    canonical,
    observations,
    evidenceClaims = [],
    specialistResult,
    recentHistory = [],
  } = input;
  const asOf = assetAnalysis?.asOf ?? new Date().toISOString();

  // Identity summary
  const identity = {
    status:
      canonical?.mappingStatus ?? assetAnalysis?.mappingStatus ?? "unmapped",
    confidence: canonical?.mappingConfidence ?? 0,
    chainId: canonical?.chainId ?? null,
    contractAddress: canonical?.contractAddress ?? null,
    providerIds: canonical?.providerIds ?? {},
  };

  // Evidence summary
  const evidence: CaseFileEvidence[] = observations.slice(0, 30).map((o) => {
    const payload = (o.payload ?? {}) as Record<string, unknown>;
    let summary = `${o.eventType} from ${o.provider}`;
    if (typeof payload.priceUsd === "number")
      summary += ` price=$${payload.priceUsd}`;
    if (typeof payload.changePct24h === "number")
      summary += ` change=${payload.changePct24h}%`;
    if (typeof payload.change24hPct === "number")
      summary += ` change=${payload.change24hPct}%`;
    if (typeof payload.rate === "number") summary += ` rate=${payload.rate}`;
    if (typeof payload.mentions24h === "number")
      summary += ` mentions=${payload.mentions24h}`;
    if (typeof payload.title === "string")
      summary += ` title=${payload.title.slice(0, 50)}`;
    return {
      provider: o.provider,
      capability: o.eventType,
      eventType: o.eventType,
      observedAt: o.sourceTimestamp ?? o.occurredAt,
      receivedAt: o.receivedAt,
      epistemicState: o.epistemicState,
      confidence: o.evidenceConfidence,
      summary,
      dataMode: o.dataMode ?? "live",
      providerEndpoint: o.providerEndpoint ?? null,
      payloadHash: o.payloadHash ?? null,
      requestedMarket:
        [o.requestedExchange, o.requestedSymbol].filter(Boolean).join(":") ||
        null,
      eligibility: isObservationEligibleForAnalysis(o),
    };
  });

  const contradictions: CaseFile["contradictions"] = [];
  const contradictionIds = new Set(
    assetAnalysis?.counterEvidenceClaimIds ?? [],
  );
  for (const claim of evidenceClaims) {
    if (
      claim.epistemicState !== "CONFLICTED" &&
      !contradictionIds.has(claim.id)
    )
      continue;
    contradictions.push({
      code:
        claim.epistemicState === "CONFLICTED"
          ? "CONFLICTED_CLAIM"
          : "COUNTER_EVIDENCE",
      summary: claim.claim,
      source: claim.source,
      factorFamily: claim.factorFamily,
      claimId: claim.id,
    });
  }
  for (const observation of observations) {
    if (observation.epistemicState !== "CONFLICTED") continue;
    contradictions.push({
      code: "CONFLICTED_OBSERVATION",
      summary: `${observation.eventType} evidence is marked conflicted`,
      source: observation.provider,
      factorFamily: observation.eventType,
      claimId: null,
    });
  }

  const unknowns: CaseFile["unknowns"] = [];
  if (!assetAnalysis)
    unknowns.push({
      code: "NO_SNAPSHOT",
      summary: "No deterministic snapshot exists for this asset.",
      severity: "critical",
    });
  if (!canonical || canonical.mappingStatus !== "verified") {
    unknowns.push({
      code: "IDENTITY_UNVERIFIED",
      summary: `Canonical identity is ${canonical?.mappingStatus ?? "unmapped"}.`,
      severity: "critical",
    });
  }
  if (observations.length === 0)
    unknowns.push({
      code: "NO_OBSERVATIONS",
      summary: "No provider observations are available.",
      severity: "critical",
    });
  const displayOnlyCount = evidence.filter(
    (item) => item.eligibility !== "eligible",
  ).length;
  if (displayOnlyCount > 0)
    unknowns.push({
      code: "DISPLAY_ONLY_EVIDENCE",
      summary: `${displayOnlyCount} observation${displayOnlyCount === 1 ? " is" : "s are"} visible for audit but excluded from analysis.`,
      severity: "warning",
    });
  if ((assetAnalysis?.criticalUnknowns ?? 0) > 0)
    unknowns.push({
      code: "CRITICAL_UNKNOWNS",
      summary: `${assetAnalysis!.criticalUnknowns} critical unknown${assetAnalysis!.criticalUnknowns === 1 ? " remains" : "s remain"} in the deterministic snapshot.`,
      severity: "critical",
    });
  for (const claim of evidenceClaims.filter(
    (item) =>
      item.epistemicState === "UNKNOWN" || item.epistemicState === "STALE",
  )) {
    unknowns.push({
      code: claim.epistemicState === "STALE" ? "STALE_CLAIM" : "UNKNOWN_CLAIM",
      summary: claim.claim,
      severity: claim.epistemicState === "STALE" ? "warning" : "critical",
    });
  }

  // Caveats
  const caveats: string[] = [];
  if (canonical?.mappingStatus !== "verified")
    caveats.push(`Identity status: ${canonical?.mappingStatus ?? "unmapped"}`);
  if (!assetAnalysis) caveats.push("No snapshot for this asset yet.");
  if ((observations.length ?? 0) === 0)
    caveats.push("No observations available.");
  if (evidence.length === 0)
    caveats.push("No usable evidence after normalization.");
  if (
    specialistResult?.openChallenges &&
    specialistResult.openChallenges.length > 0
  ) {
    caveats.push(
      `${specialistResult.openChallenges.length} open challenges from the Challenger.`,
    );
  }

  // Specialist section
  let specialist: CaseFile["specialist"] = null;
  if (specialistResult) {
    specialist = {
      reconciledDirection: specialistResult.reconciled?.direction ?? "neutral",
      reconciledStrength: specialistResult.reconciled?.strength ?? 0,
      reconciledConfidence:
        specialistResult.reconciled?.confidence ?? "speculative",
      targetWeightPct: specialistResult.vetoed
        ? 0
        : (specialistResult.allocation?.targetWeightPct ?? 0),
      vetoed: specialistResult.vetoed,
      vetoReason: specialistResult.vetoed
        ? (specialistResult.opinions.find(
            (o) => o.type === "risk_flag" && o.strength >= 0.8,
          )?.summary ?? null)
        : null,
      openChallenges: specialistResult.openChallenges.map((c) => ({
        code: c.summary.replace(/^Challenge: /, ""),
        summary: c.summary,
        rationale: c.reasoning,
      })),
      specialistOpinions: specialistResult.opinions.map((o) => ({
        specialistId: o.specialistId,
        type: o.type,
        direction: o.direction,
        confidence: o.confidence,
        strength: o.strength,
        summary: o.summary,
      })),
    };
  }

  // Recent history (from previous snapshots)
  const hist: CaseFile["recentHistory"] = [];
  for (const prev of recentHistory.slice(0, 5)) {
    const a = prev.rankedAssets.find((ra) => ra.symbol === symbol);
    if (a) {
      hist.push({
        asOf: prev.asOf,
        opportunity: a.opportunity.adjusted,
        confidence: a.confidence.pct,
        action: a.action,
      });
    }
  }
  const previous = hist[0] ?? null;
  const changeSincePrevious =
    assetAnalysis && previous
      ? {
          previousAsOf: previous.asOf,
          opportunityDelta: Number(
            (assetAnalysis.opportunity.adjusted - previous.opportunity).toFixed(
              4,
            ),
          ),
          confidenceDelta: Number(
            (assetAnalysis.confidence.pct - previous.confidence).toFixed(4),
          ),
          actionChanged: assetAnalysis.action !== previous.action,
          previousAction: previous.action,
        }
      : null;

  return {
    symbol,
    asOf,
    canonical: canonical ?? null,
    identity,
    score: {
      opportunity: assetAnalysis?.opportunity.adjusted ?? 0,
      confidence: assetAnalysis?.confidence.pct ?? 0,
      targetWeightPct: assetAnalysis?.targetWeight.pct ?? 0,
      opportunityRank: assetAnalysis?.opportunityRank ?? null,
      allocationRank: assetAnalysis?.allocationRank ?? null,
    },
    conclusion:
      assetAnalysis?.conclusion ?? "No deterministic conclusion is available.",
    role: assetAnalysis?.role ?? "WATCHLIST",
    action: assetAnalysis?.action ?? "INSUFFICIENT_DATA",
    risk: assetAnalysis?.risk ?? "Unknown",
    scenarios: {
      bull: assetAnalysis?.scenarios?.bull ?? null,
      base: assetAnalysis?.scenarios?.base ?? null,
      bear: assetAnalysis?.scenarios?.bear ?? null,
    },
    invalidationConditions: assetAnalysis?.invalidationConditions ?? [],
    evidenceCoverage: assetAnalysis?.evidenceCoverage ?? 0,
    criticalUnknowns: assetAnalysis?.criticalUnknowns ?? 0,
    evidence,
    contradictions,
    unknowns,
    specialist,
    strategy21: (assetAnalysis as unknown as { strategy21?: unknown } | null)?.strategy21 ?? null,
    recentHistory: hist,
    changeSincePrevious,
    caveats,
  };
}
