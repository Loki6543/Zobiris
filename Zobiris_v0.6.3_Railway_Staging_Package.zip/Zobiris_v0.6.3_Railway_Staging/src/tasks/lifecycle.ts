/**
 * Iyaza Addendum — Item B: Task lifecycle state machine.
 *
 * Lifecycle:
 *   NEW -> ACKNOWLEDGED -> DISPATCHED -> IN_PROGRESS
 *                                       |
 *                                       v
 *                                   COMPLETED | FAILED | STALLED | CLARIFICATION_NEEDED
 *                                                  |
 *                                                  v
 *                                              RETRYING | ESCALATED | CANCELLED
 *
 * The state machine is enforced: every transition is validated against the legal
 * set. Illegal transitions throw.
 */
export const TASK_LIFECYCLE_STATES = [
  "NEW",
  "ACKNOWLEDGED",
  "DISPATCHED",
  "IN_PROGRESS",
  "COMPLETED",
  "FAILED",
  "CLARIFICATION_NEEDED",
  "STALLED",
  "RETRYING",
  "ESCALATED",
  "CANCELLED",
] as const;
export type TaskLifecycleState = (typeof TASK_LIFECYCLE_STATES)[number];

export const TERMINAL_STATES: ReadonlySet<TaskLifecycleState> = new Set([
  "COMPLETED",
  "FAILED",
  "ESCALATED",
  "CANCELLED",
]);

const LEGAL_TRANSITIONS: Record<TaskLifecycleState, ReadonlySet<TaskLifecycleState>> = {
  NEW: new Set(["ACKNOWLEDGED", "CANCELLED"]),
  ACKNOWLEDGED: new Set(["DISPATCHED", "CANCELLED"]),
  DISPATCHED: new Set(["IN_PROGRESS", "FAILED", "CANCELLED"]),
  IN_PROGRESS: new Set(["COMPLETED", "FAILED", "STALLED", "CLARIFICATION_NEEDED", "CANCELLED"]),
  STALLED: new Set(["RETRYING", "ESCALATED", "FAILED", "CANCELLED"]),
  RETRYING: new Set(["IN_PROGRESS", "FAILED", "CANCELLED"]),
  CLARIFICATION_NEEDED: new Set(["IN_PROGRESS", "FAILED", "CANCELLED"]),
  COMPLETED: new Set(),
  FAILED: new Set(),
  ESCALATED: new Set(),
  CANCELLED: new Set(),
};

export interface LifecycleEvent {
  taskId: string;
  from: TaskLifecycleState;
  to: TaskLifecycleState;
  at: string;
  meta?: Record<string, unknown>;
}

export class IllegalTransitionError extends Error {
  constructor(public readonly from: TaskLifecycleState, public readonly to: TaskLifecycleState, public readonly taskId: string) {
    super(`illegal task lifecycle transition for ${taskId}: ${from} -> ${to}`);
    this.name = "IllegalTransitionError";
  }
}

/**
 * Tracker for a single task. Records transitions to an in-memory history buffer.
 * Optionally emits JSONL events to a stream (e.g., process.stdout or a file stream).
 */
export class TaskLifecycleTracker {
  readonly taskId: string;
  private current: TaskLifecycleState = "NEW";
  private readonly events: LifecycleEvent[] = [];
  private readonly sink?: (line: string) => void;

  constructor(taskId: string, sink?: (line: string) => void) {
    this.taskId = taskId;
    this.sink = sink;
    this.record("NEW", undefined);
  }

  currentState(): TaskLifecycleState {
    return this.current;
  }

  history(): LifecycleEvent[] {
    return [...this.events];
  }

  isTerminal(): boolean {
    return TERMINAL_STATES.has(this.current);
  }

  /**
   * Record a transition. Throws IllegalTransitionError if the transition is not legal.
   */
  transition(to: TaskLifecycleState, meta?: Record<string, unknown>): void {
    const from = this.current;
    if (TERMINAL_STATES.has(from)) {
      throw new IllegalTransitionError(from, to, this.taskId);
    }
    if (!LEGAL_TRANSITIONS[from].has(to)) {
      throw new IllegalTransitionError(from, to, this.taskId);
    }
    this.current = to;
    this.record(from, to, meta);
  }

  private record(from: TaskLifecycleState, to: TaskLifecycleState | undefined, meta?: Record<string, unknown>): void {
    const event: LifecycleEvent = {
      taskId: this.taskId,
      from,
      to: to ?? from,
      at: new Date().toISOString(),
      meta,
    };
    this.events.push(event);
    if (this.sink) {
      this.sink(JSON.stringify(event));
    }
  }
}

/**
 * In-memory store of trackers keyed by taskId.
 */
export class TaskLifecycleStore {
  private readonly trackers = new Map<string, TaskLifecycleTracker>();

  create(taskId: string, sink?: (line: string) => void): TaskLifecycleTracker {
    if (this.trackers.has(taskId)) {
      throw new Error(`task already exists: ${taskId}`);
    }
    const tracker = new TaskLifecycleTracker(taskId, sink);
    this.trackers.set(taskId, tracker);
    return tracker;
  }

  get(taskId: string): TaskLifecycleTracker | null {
    return this.trackers.get(taskId) ?? null;
  }

  list(): TaskLifecycleTracker[] {
    return Array.from(this.trackers.values());
  }
}
