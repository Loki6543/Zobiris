/**
 * Iyaza Addendum — Item B: Typed TaskSpec.
 *
 * Every non-trivial operation is compiled into a TaskSpec before execution.
 * Per the addendum: a Refresh is an auditable job with explicit completion
 * conditions, not "call providers then score".
 */
import { z } from "zod";
import { randomUUID } from "node:crypto";

export const TASK_TYPES = [
  "refresh.daily",
  "refresh.deep",
  "refresh.challenge",
  "research",
  "experiment",
  "provider.recovery",
] as const;
export type TaskType = (typeof TASK_TYPES)[number];

export const RISK_CLASSES = ["read", "write_candidate", "write_durable"] as const;
export type RiskClass = (typeof RISK_CLASSES)[number];

export const EFFORT_MODES = ["daily", "deep", "challenge"] as const;
export type EffortMode = (typeof EFFORT_MODES)[number];

export const taskSpecSchema = z.object({
  taskId: z.string().min(1),
  parentSessionId: z.string().optional(),
  taskType: z.enum(TASK_TYPES),
  goal: z.string().min(1),
  riskClass: z.enum(RISK_CLASSES),
  pointInTimeCutoff: z.string().datetime(),
  explicitConstraints: z.array(z.string()),
  acceptanceCriteria: z.array(z.string()),
  requiredCapabilities: z.array(z.string()),
  requestedArtifacts: z.array(z.string()),
  effortMode: z.enum(EFFORT_MODES),
  verificationRequirements: z.array(z.string()),
  stopConditions: z.array(z.string()),
  currentUserInstruction: z.string().optional(),
});
export type TaskSpec = z.infer<typeof taskSpecSchema>;

export interface CompileRefreshOpts {
  taskType?: TaskType;
  effortMode: EffortMode;
  pointInTimeCutoff: string;
  parentSessionId?: string;
  requiredCapabilities?: string[];
  currentUserInstruction?: string;
  /** Optional explicit overrides; defaults are sensible. */
  goal?: string;
  explicitConstraints?: string[];
  acceptanceCriteria?: string[];
  stopConditions?: string[];
}

/**
 * Build a TaskSpec for a normal Refresh All. Defaults are conservative
 * (no trade execution, no auto-promotion, no contract changes).
 */
export function compileRefreshTaskSpec(opts: CompileRefreshOpts): TaskSpec {
  const taskId = `task-${randomUUID()}`;
  const goal = opts.goal ?? `Refresh all canonical assets and produce a portfolio conclusion as of ${opts.pointInTimeCutoff}.`;
  const requiredCapabilities = opts.requiredCapabilities ?? [
    "market.quotes",
    "social.attention",
    "derivs.funding",
    "events.calendar",
    "identity.metadata",
  ];
  const explicitConstraints = opts.explicitConstraints ?? [
    "No trade execution, no wallet interaction.",
    "Ticker is never a primary key for evidence join.",
    "Degraded provider state must be exposed, not silently substituted.",
    "Score, confidence, and target weight are computed and stored separately.",
  ];
  const acceptanceCriteria = opts.acceptanceCriteria ?? [
    "Refresh produces a snapshot with per-asset case files.",
    "Verifier passes with no fatal findings.",
    "Risk gates fire on any hard-gate violation (unmapped, liquidity-cap, suspicious-volume, etc.).",
    "Provider health is reported in the snapshot.",
  ];
  const stopConditions = opts.stopConditions ?? [
    "Stops on FAILED terminal state; no automatic retry past retry budget.",
    "Stops on STALLED longer than 60 seconds without a heartbeat.",
  ];
  const verificationRequirements = [
    "Independent Verifier pass on the conclusion.",
    "Challenger review on at least 1 high-stakes asset (e.g. unmapped or hard-gated).",
  ];
  const requestedArtifacts = [
    "snapshot.json",
    "per-asset case file for every eligible watchlist symbol",
    "provider health report",
    "audit event log",
  ];

  return {
    taskId,
    parentSessionId: opts.parentSessionId,
    taskType: opts.taskType ?? (opts.effortMode === "daily" ? "refresh.daily" : opts.effortMode === "deep" ? "refresh.deep" : "refresh.challenge"),
    goal,
    riskClass: "write_candidate",
    pointInTimeCutoff: opts.pointInTimeCutoff,
    explicitConstraints,
    acceptanceCriteria,
    requiredCapabilities,
    requestedArtifacts,
    effortMode: opts.effortMode,
    verificationRequirements,
    stopConditions,
    currentUserInstruction: opts.currentUserInstruction,
  };
}
