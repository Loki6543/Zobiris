/**
 * Iyaza Addendum — Item C: Strong terminal result semantics.
 *
 * Distinguishes transport success from analytical verification. Only
 * independent acceptance evidence can promote a result to `verified_complete`.
 */
import { z } from "zod";

export const TASK_TERMINAL_STATES = [
  "prepared",
  "completed_unverified",
  "verified_complete",
  "insufficient_evidence",
  "failed",
  "cancelled",
] as const;
export type TaskTerminalState = (typeof TASK_TERMINAL_STATES)[number];

const baseFields = {
  taskId: z.string().min(1),
  producedAt: z.string().datetime(),
  durationMs: z.number().int().min(0).optional(),
  notes: z.string().optional(),
};

export const preparedResultSchema = z.object({
  state: z.literal("prepared"),
  ...baseFields,
  draftArtifactRefs: z.array(z.string()),
});
export const completedUnverifiedResultSchema = z.object({
  state: z.literal("completed_unverified"),
  ...baseFields,
  artifactRefs: z.array(z.string()),
  summary: z.string().min(1),
});
export const verifiedCompleteResultSchema = z.object({
  state: z.literal("verified_complete"),
  ...baseFields,
  artifactRefs: z.array(z.string()),
  verificationRefs: z.array(z.string()),
  summary: z.string().min(1),
});
export const insufficientEvidenceResultSchema = z.object({
  state: z.literal("insufficient_evidence"),
  ...baseFields,
  missingCapabilities: z.array(z.string()),
  summary: z.string().min(1),
});
export const failedResultSchema = z.object({
  state: z.literal("failed"),
  ...baseFields,
  failureCode: z.string().min(1),
  summary: z.string().min(1),
});
export const cancelledResultSchema = z.object({
  state: z.literal("cancelled"),
  ...baseFields,
  reason: z.string().optional(),
});

export const taskTerminalResultSchema = z.discriminatedUnion("state", [
  preparedResultSchema,
  completedUnverifiedResultSchema,
  verifiedCompleteResultSchema,
  insufficientEvidenceResultSchema,
  failedResultSchema,
  cancelledResultSchema,
]);
export type TaskTerminalResult = z.infer<typeof taskTerminalResultSchema>;
export type CompletedUnverified = z.infer<typeof completedUnverifiedResultSchema>;
export type VerifiedComplete = z.infer<typeof verifiedCompleteResultSchema>;

/** Verification evidence required to promote unverified -> verified. */
export interface VerificationEvidence {
  verifierId: string;
  /** Verifier sign-off timestamp. */
  at: string;
  /** Free-text rationale. */
  rationale: string;
  /** Any artifact refs the verifier consulted. */
  artifactRefs: string[];
  /** Verifier-level failure flags; if any are true, the evidence is invalid. */
  flags: {
    /** A required acceptance criterion was not met. */
    acceptanceFailed?: boolean;
    /** The verifier found a risk-gate violation that the producer missed. */
    riskGateViolation?: boolean;
    /** The verifier found a hard policy violation. */
    policyViolation?: boolean;
  };
}

/**
 * Promote a `completed_unverified` result to `verified_complete` only when the
 * verification evidence is present and valid. Any flag invalidates the promotion
 * and returns the input unchanged (the caller can then add a `failed` result).
 */
export function verifyCompletion(
  result: TaskTerminalResult,
  evidence: VerificationEvidence | null,
): TaskTerminalResult {
  if (result.state !== "completed_unverified") {
    return result;
  }
  if (!evidence) {
    return result;
  }
  // Any flag set means evidence is invalid.
  if (evidence.flags.acceptanceFailed || evidence.flags.riskGateViolation || evidence.flags.policyViolation) {
    return result;
  }
  return {
    state: "verified_complete",
    taskId: result.taskId,
    producedAt: result.producedAt,
    durationMs: result.durationMs,
    notes: result.notes,
    artifactRefs: result.artifactRefs,
    verificationRefs: [evidence.verifierId, ...evidence.artifactRefs],
    summary: result.summary,
  };
}
