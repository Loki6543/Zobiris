/**
 * Shared adapter builder for the CLI and HTTP server.
 */

import { resolve } from "node:path";
import { KrakenAdapter } from "../providers/kraken.js";
import { CMCAdapter } from "../providers/cmc.js";
import { LunarCrushAdapter } from "../providers/lunarcrush.js";
import { CoinGlassAdapter } from "../providers/coinglass.js";
import { CoinMarketCalAdapter } from "../providers/coinmarketcal.js";
import type { RefreshAdapters } from "../runtime/refresh.js";

const PROJECT_ROOT = resolve(import.meta.dirname ?? new URL(".", import.meta.url).pathname, "..", "..");
const FIXTURE_DIR = resolve(PROJECT_ROOT, "src", "providers", "fixtures");

export interface BuildAdaptersOpts {
  staleSeconds: number;
  live: boolean;
}

export function buildAdapters(opts: BuildAdaptersOpts): RefreshAdapters {
  const kraken = new KrakenAdapter();
  kraken.configure({
    baseUrl: "https://api.kraken.com",
    pairMap: { BTC: "XBTUSD", SOL: "SOLUSD" },
    resultKeyToSymbol: { XBTUSD: "BTC", XXBTZUSD: "BTC", SOLUSD: "SOL" },
    forceFixtures: !opts.live,
    staleSeconds: opts.staleSeconds,
    timeoutMs: 10_000,
    fixturePaths: {
      BTC: `${FIXTURE_DIR}/kraken-btc-ticker.valid.json`,
      SOL: `${FIXTURE_DIR}/kraken-sol-ticker.valid.json`,
    },
  });
  // v0.4.3 audit fix (P1): CMC no-key state is now explicit. If the
  // operator runs with --live and no CMC_API_KEY is set, the adapter
  // surfaces as `credentials-needed` rather than silently claiming
  // "fixture mode" (the fixture path is empty in live mode, so
  // `health()` would have reported "credentials-needed" anyway, but
  // the log message used to be misleading).
  const cmc = new CMCAdapter();
  const cmcKey = process.env.CMC_API_KEY ?? "";
  const cmcLive = opts.live && Boolean(cmcKey && cmcKey.length > 0);
  if (cmcLive) {
    cmc.configure({
      baseUrl: "https://pro-api.coinmarketcap.com",
      fixturePath: "",
      liveConfig: { apiKey: cmcKey, timeoutMs: 10_000 },
    });
    cmc.setLiveMode(cmcKey);
  } else if (opts.live) {
    // Live mode requested, no key configured: explicit credentials-needed.
    // Do NOT silently use the fixture. The runtime will record this
    // honestly in the audit trail.
    cmc.configure({
      baseUrl: "https://pro-api.coinmarketcap.com",
      fixturePath: "",  // no fixture in live mode
    });
    // eslint-disable-next-line no-console
    console.warn("CMC_API_KEY not set; CMC adapter will report credentials-needed (no fixture fallback in live mode).");
  } else {
    // Default (non-live): fixture mode is the safe baseline.
    cmc.configure({
      baseUrl: "https://pro-api.coinmarketcap.com",
      fixturePath: `${FIXTURE_DIR}/cmc-quote.valid.json`,
    });
  }
  // LunarCrush live path: only enabled when --live AND LUNARCRUSH_API_KEY is set.
  // v0.4.2 audit fix (P0 BLOCKER 3): the v4 base URL is lunarcrush.com/api4
  // (not api.lunarcrush.com/v4). The auth is Authorization: Bearer <key>
  // (not ?key=<key> in the query string).
  const lunarcrushKey = process.env["LUNARCRUSH_API_KEY"];
  const lunarcrushLive = opts.live && Boolean(lunarcrushKey && lunarcrushKey.length > 0);
  const lunarcrush = new LunarCrushAdapter();
  if (lunarcrushLive) {
    lunarcrush.configure({
      baseUrl: "https://lunarcrush.com/api4",
      fixturePath: `${FIXTURE_DIR}/lunarcrush-coin.valid.json`,
      liveConfig: { apiKey: lunarcrushKey as string, timeoutMs: 10_000 },
    });
  } else {
    lunarcrush.configure({
      baseUrl: "https://lunarcrush.com/api4",
      fixturePath: opts.live ? "" : `${FIXTURE_DIR}/lunarcrush-coin.valid.json`,
    });
  }
  // CoinGlass live path: only enabled when --live AND COINGLASS_API_KEY is set.
  // Per audit P0 #4, this was previously never wired through buildAdapters.
  const coinglassKey = process.env["COINGLASS_API_KEY"];
  const coinglassLive = opts.live && Boolean(coinglassKey && coinglassKey.length > 0);
  const coinglass = new CoinGlassAdapter();
  if (coinglassLive) {
    coinglass.configure({
      baseUrl: "https://open-api-v4.coinglass.com",
      fundingFixturePath: `${FIXTURE_DIR}/coinglass-funding.valid.json`,
      liquidationsFixturePath: `${FIXTURE_DIR}/coinglass-liquidations.valid.json`,
      liveConfig: { apiKey: coinglassKey as string, timeoutMs: 10_000 },
      forceFixtures: false,
    });
  } else {
    coinglass.configure({
      baseUrl: "https://open-api-v4.coinglass.com",
      fundingFixturePath: opts.live ? "" : `${FIXTURE_DIR}/coinglass-funding.valid.json`,
      liquidationsFixturePath: opts.live ? "" : `${FIXTURE_DIR}/coinglass-liquidations.valid.json`,
    });
  }
  // CoinMarketCal live path: only enabled when --live AND COINMARKETCAL_API_KEY is set.
  // Per audit P0 #4, this was previously never wired through buildAdapters.
  const coinmarketcalKey = process.env["COINMARKETCAL_API_KEY"];
  const coinmarketcalLive = opts.live && Boolean(coinmarketcalKey && coinmarketcalKey.length > 0);
  const coinmarketcal = new CoinMarketCalAdapter();
  if (coinmarketcalLive) {
    coinmarketcal.configure({
      baseUrl: "https://api.coinmarketcal.com",
      fixturePath: `${FIXTURE_DIR}/coinmarketcal.valid.json`,
      liveConfig: { apiKey: coinmarketcalKey as string, timeoutMs: 10_000 },
      forceFixtures: false,
    });
  } else {
    coinmarketcal.configure({
      baseUrl: "https://api.coinmarketcal.com",
      fixturePath: opts.live ? "" : `${FIXTURE_DIR}/coinmarketcal.valid.json`,
    });
  }
  return { kraken, cmc, lunarcrush, coinglass, coinmarketcal };
}
