#!/usr/bin/env node
/**
 * Zobiris Core CLI.
 *
 * Subcommands:
 *   refresh            Run a refresh on the active watchlist, persist to DB, print summary.
 *   replay <id>        Replay a stored session.
 *   snapshots          List recent snapshots.
 *   audit              List recent audit events.
 *   providers          Show provider health + circuit-breaker state.
 *   db-info            Show database file path, table counts.
 */
import { runRefresh } from "../runtime/refresh.js";
import { DEFAULT_SCORING_CONFIG } from "../domain/scoring.js";
import { redact } from "../runtime/secrets.js";
import { openStorage } from "../storage/client.js";
import { persistRefresh, drainOutbox } from "../storage/integration.js";
import {
  replaySession,
  getRecentSnapshots,
  listAuditEvents,
  listProviderHealth,
  listAllCanonical,
} from "../storage/repository.js";
import { buildAdapters } from "./_adapters.js";
import { loadWatchlist } from "./_watchlist.js";
import { saveStrategyMarketState } from "../strategy21/storage.js";

const DEFAULT_DB = process.env.ZOBIRIS_DB_PATH ?? "./zobiris.db";

async function cmdRefresh(opts: any) {
  const adapters = buildAdapters({ staleSeconds: opts.stale, live: !opts.forceFixtures });
  const watchlist = await loadWatchlist();
  const result = await runRefresh({ mode: "deep", watchlist, policy: DEFAULT_SCORING_CONFIG, adapters, dbPath: opts.db ?? DEFAULT_DB });

  let storageInfo = null;
  if (!opts.noPersist) {
    const storage = openStorage({ path: opts.db ?? DEFAULT_DB });
    try {
      const persisted = persistRefresh({
        db: storage.db,
        watchlist,
        observations: result.observations,
        evidenceClaims: result.evidenceClaims,
        snapshot: result.snapshot,
        canonicalMap: result.canonicalMap,
        stages: result.session.stages,
        providerHealthUpdates: result.providerHealthUpdates.length > 0
          ? result.providerHealthUpdates
          : [
              { provider: "kraken", status: "snapshot", freshness: "delayed", success: true },
              { provider: "cmc", status: "snapshot", freshness: "unavailable", success: true },
              { provider: "lunarcrush", status: "snapshot", freshness: "unavailable", success: true },
              { provider: "coinglass", status: "snapshot", freshness: "unavailable", success: true },
              { provider: "coinmarketcal", status: "snapshot", freshness: "unavailable", success: true },
            ],
      });
      const drained = drainOutbox(storage.db);
      const firstStrategy = (result.snapshot.rankedAssets as unknown as Array<{ strategy21?: { marketState?: string; marketEnteredAt?: string; minimumDwellUntil?: string } }>).find((a) => a.strategy21)?.strategy21;
      if (firstStrategy?.marketState && firstStrategy.marketEnteredAt && firstStrategy.minimumDwellUntil) {
        try {
          saveStrategyMarketState(opts.db ?? DEFAULT_DB, { state: firstStrategy.marketState as any, enteredAt: firstStrategy.marketEnteredAt, minimumDwellUntil: firstStrategy.minimumDwellUntil });
        } catch {
          // Persistence of the refresh itself remains authoritative.
        }
      }
      storageInfo = { ...persisted, dbPath: opts.db ?? DEFAULT_DB };
      if (opts.format === "text") {
        console.error(`[storage] persisted to ${storageInfo.dbPath}`);
        console.error(`[storage] sessionId=${persisted.sessionId} snapshotId=${persisted.snapshotId}`);
        console.error(`[storage] observations=${persisted.observationCount} evidence=${persisted.evidenceClaimCount} outbox=${drained.published}`);
      }
    } finally { storage.close(); }
  }

  if (opts.format === "json") {
    console.log(JSON.stringify({
      session: result.session,
      snapshot: result.snapshot,
      findings: result.findings,
      observationCount: result.observations.length,
      evidenceClaimCount: result.evidenceClaims.length,
      storage: storageInfo,
    }, null, 2));
    return 0;
  }

  const s = result.snapshot;
  const eligible = s.rankedAssets.filter(a => a.opportunityRank != null);
  const allocated = s.rankedAssets.filter(a => a.allocationRank != null);
  console.log("");
  console.log("=== ZOBIRIS INTELLIGENCE ENGINE — REFRESH ===");
  console.log(`Session: ${result.session.id}`);
  console.log(`Mode: ${result.session.mode}   Policy: v${result.session.policyVersion}`);
  console.log(`Started: ${result.session.startedAt}`);
  console.log(`AsOf: ${s.asOf}`);
  console.log(`Observations: ${result.observations.length} (after dedup)`);
  console.log(`Evidence claims: ${result.evidenceClaims.length}`);
  if (storageInfo) {
    console.log(`Persisted: session=${storageInfo.sessionId.slice(0, 16)}…  snapshot=${storageInfo.snapshotId.slice(0, 16)}…`);
  }
  console.log("");
  console.log(`Regime: ${s.regime} (confidence ${s.regimeConfidence}%)`);
  const strategyRows = s.rankedAssets as unknown as Array<{ strategy21?: { doctrine?: string; marketState?: string; nextDollarRank?: number | null; researchRank?: number; positionAuthority?: { maxNextOrderUsd?: number } } }>;
  const strategy = strategyRows.find((a) => a.strategy21)?.strategy21;
  if (strategy) {
    console.log(`Strategy 2.1: ${strategy.doctrine ?? strategy.marketState} | next-dollar ready=${strategyRows.filter((a) => a.strategy21?.nextDollarRank != null).length}`);
    console.log(`Capital: maneuver=$1,200 | future strategic reserve=$1,800 | eventual target=$3,000`);
  }
  console.log(`Allocated: ${s.totalAllocatedPct}% + Reserve: ${s.reservePct}% = ${(s.totalAllocatedPct + s.reservePct).toFixed(2)}%`);
  console.log(`Unallocated: ${s.unallocatedPct}%`);
  console.log(`Eligible for rank: ${eligible.length} of ${s.rankedAssets.length}`);
  console.log(`Allocated: ${allocated.length} of ${s.rankedAssets.length}`);
  console.log("");
  console.log("Top 10 by Opportunity:");
  for (const a of eligible.slice(0, 10)) {
    const s21 = (a as unknown as { strategy21?: { researchRank?: number; nextDollarRank?: number | null; positionAuthority?: { maxNextOrderUsd?: number } } }).strategy21;
    const ranks = s21 ? `  R#${String(s21.researchRank ?? "-").padEnd(2)} N$#${String(s21.nextDollarRank ?? "-").padEnd(2)} max+$${Number(s21.positionAuthority?.maxNextOrderUsd ?? 0).toFixed(0).padStart(3)}` : "";
    console.log(`  #${a.opportunityRank}  ${a.symbol.padEnd(6)} score=${a.opportunity.adjusted.toString().padStart(5)}  conf=${a.confidence.pct.toString().padStart(5)}%  role=${a.role.padEnd(13)}  action=${a.action.padEnd(20)}  weight=${a.targetWeight.pct.toFixed(2).padStart(6)}%  risk=${a.risk.padEnd(8)}  state=${a.evidenceState}${ranks}`);
  }
  console.log("");
  console.log("Verifier findings:");
  const errors = result.findings.filter(f => f.severity === "error");
  const warnings = result.findings.filter(f => f.severity === "warn");
  console.log(`  ${errors.length} errors, ${warnings.length} warnings`);
  for (const f of errors) console.log(`  ERROR [${f.code}] ${f.message}`);
  for (const f of warnings.slice(0, 5)) console.log(`  WARN  [${f.code}] ${f.message}`);
  if (warnings.length > 5) console.log(`  ... ${warnings.length - 5} more warnings`);
  console.log("");
  console.log(`Conclusion: ${s.conclusion}`);
  console.log("");
  console.log("Stages:");
  for (const st of result.session.stages) {
    console.log(`  ${st.index}. ${st.name} → ${st.status}`);
  }
  console.log("");
  console.log("=== END ===");
  return errors.length > 0 ? 1 : 0;
}

function cmdReplay(opts: any) {
  const storage = openStorage({ path: opts.db ?? DEFAULT_DB });
  try {
    const r = replaySession(storage.db, opts.sessionId);
    if (opts.format === "json") {
      console.log(JSON.stringify(r, null, 2));
      return 0;
    }
    console.log(`\n=== REPLAY: ${opts.sessionId} ===`);
    console.log(`Session: ${r.session?.mode} | status=${r.session?.status} | policy v${r.session?.policyVersion}`);
    console.log(`Started: ${r.session?.startedAt}  Completed: ${r.session?.completedAt ?? "(open)"}`);
    console.log(`Stages: ${(JSON.parse(r.session?.stages ?? "[]")).length}`);
    console.log(`Observations: ${r.observations.length}`);
    console.log(`Evidence claims: ${r.evidenceClaims.length}`);
    console.log(`Audit events: ${r.auditEvents.length}`);
    if (r.snapshot) {
      console.log(`Snapshot @ ${r.snapshot.asOf} | regime=${r.snapshot.regime}`);
      console.log(`  Allocated ${r.snapshot.totalAllocatedPct}% + reserve ${r.snapshot.reservePct}% + unallocated ${r.snapshot.unallocatedPct}%`);
      console.log(`  Conclusion: ${r.snapshot.conclusion.slice(0, 200)}`);
    }
    if (r.outbox.length > 0) {
      console.log(`Outbox events: ${r.outbox.length} (status: ${r.outbox.map(o => `${o.eventType}=${o.status}`).join(", ")})`);
    }
    return 0;
  } finally { storage.close(); }
}

function cmdSnapshots(opts: any) {
  const storage = openStorage({ path: opts.db ?? DEFAULT_DB });
  try {
    const snaps = getRecentSnapshots(storage.db, opts.limit);
    if (opts.format === "json") {
      console.log(JSON.stringify(snaps, null, 2));
      return 0;
    }
    console.log(`\n=== RECENT SNAPSHOTS (${snaps.length}) ===`);
    for (const s of snaps) {
      console.log(`${s.asOf}  regime=${s.regime.padEnd(10)}  alloc=${s.totalAllocatedPct.toString().padStart(6)}%  reserve=${s.reservePct}%  unalloc=${s.unallocatedPct}%  policy=v${s.policyVersion}  id=${s.id.slice(0, 16)}…`);
    }
    return 0;
  } finally { storage.close(); }
}

function cmdAudit(opts: any) {
  const storage = openStorage({ path: opts.db ?? DEFAULT_DB });
  try {
    const events = listAuditEvents(storage.db, { limit: opts.limit, eventType: opts.eventType });
    if (opts.format === "json") {
      console.log(JSON.stringify(events, null, 2));
      return 0;
    }
    console.log(`\n=== AUDIT (${events.length}) ===`);
    for (const e of events) {
      console.log(`${e.occurredAt}  [${e.eventType.padEnd(24)}]  session=${(e.sessionId ?? "-").slice(0, 12)}…  symbol=${e.symbol ?? "-"}`);
    }
    return 0;
  } finally { storage.close(); }
}

function cmdProviders(opts: any) {
  const storage = openStorage({ path: opts.db ?? DEFAULT_DB });
  try {
    const health = listProviderHealth(storage.db);
    if (opts.format === "json") {
      console.log(JSON.stringify(health, null, 2));
      return 0;
    }
    console.log(`\n=== PROVIDER HEALTH (${health.length}) ===`);
    for (const h of health) {
      console.log(`${h.provider.padEnd(14)}  status=${h.status.padEnd(15)}  freshness=${h.freshness.padEnd(12)}  circuit=${h.circuitState.padEnd(10)}  fails=${h.consecutiveFailures}`);
    }
    return 0;
  } finally { storage.close(); }
}

function cmdDbInfo(opts: any) {
  const path = opts.db ?? DEFAULT_DB;
  const storage = openStorage({ path });
  try {
    const tables = [
      "canonical_assets", "watchlist", "observations", "evidence_claims",
      "refresh_sessions", "snapshots", "provider_health", "outbox_events",
      "memory_records", "forecasts", "calibration_runs", "audit_events",
    ];
    console.log(`\n=== DB INFO ===`);
    console.log(`Path: ${path}`);
    console.log(`Mode: ${path === ":memory:" ? "in-memory" : "file"}`);
    for (const t of tables) {
      const row: any = storage.sqlite.prepare(`SELECT COUNT(*) AS n FROM ${t}`).get();
      console.log(`  ${t.padEnd(22)} ${row.n} rows`);
    }
    const canonical = listAllCanonical(storage.db);
    console.log(`\nCanonical asset mapping status:`);
    const byStatus: Record<string, number> = {};
    for (const c of canonical) {
      byStatus[c.mappingStatus] = (byStatus[c.mappingStatus] ?? 0) + 1;
    }
    for (const [k, v] of Object.entries(byStatus)) {
      console.log(`  ${k.padEnd(12)} ${v}`);
    }
    return 0;
  } finally { storage.close(); }
}

function printHelp() {
  console.log(`Usage: zobiris <command> [options]

Commands:
  refresh                  Run a refresh; persists to DB by default.
  replay <sessionId>       Replay a stored session.
  snapshots                List recent snapshots.
  audit                    List recent audit events.
  providers                Show provider health + circuit-breaker state.
  db-info                  Show database file path, table counts, mapping status.

Options:
  --db=PATH                SQLite file (default ./zobiris.db or $ZOBIRIS_DB_PATH).
  --stale=SECONDS          Simulate stale Kraken fixture timestamps.
  --format=text|json       Output format.
  --no-fixtures            Disable fixture mode (will fail without credentials).
  --no-persist             Skip DB persistence (in-memory only).
  --limit=N                Limit rows for list commands.
  --type=TYPE              Filter audit by event type.
`);
}

function parseArgs(argv: string[]) {
  const flags: Record<string, any> = {};
  if (argv.length === 0 || argv[0] === "--help" || argv[0] === "-h") {
    return { command: "help", subArg: null, flags };
  }
  // Flags can come before or after the subcommand. Extract them first.
  const SUBCOMMANDS = new Set(["refresh", "replay", "snapshots", "audit", "providers", "db-info", "help"]);
  const positional: string[] = [];
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i]!;
    if (a.startsWith("--")) {
      const eq = a.indexOf("=");
      if (eq > 0) {
        flags[a.slice(2, eq)] = a.slice(eq + 1);
      } else {
        const key = a.slice(2);
        // peek next non-flag arg
        if (i + 1 < argv.length && !argv[i + 1]!.startsWith("--")) {
          // if next arg looks like a subcommand or no following subcommand, treat as bool
          if (SUBCOMMANDS.has(argv[i + 1]!)) {
            flags[key] = true;
          } else {
            flags[key] = argv[i + 1]!;
            i++;
          }
        } else {
          flags[key] = true;
        }
      }
    } else {
      positional.push(a);
    }
  }
  const command = positional[0] ?? "help";
  const subArg = positional[1] ?? null;
  return { command, subArg, flags };
}

async function main() {
  const { command, subArg, flags } = parseArgs(process.argv.slice(2));
  const db = typeof flags["db"] === "string" ? flags["db"] : null;
  const format = flags["format"] === "json" ? "json" : "text";
  const stale = Number(flags["stale"] ?? 0) || 0;
  const limit = Number(flags["limit"] ?? 20) || 20;
  const noPersist = flags["no-persist"] === true;

  let code = 0;
  try {
    switch (command) {
      case "refresh":
        code = await cmdRefresh({ db, stale, format, noPersist, live: flags["no-fixtures"] === true });
        break;
      case "replay":
        if (!subArg) { console.error("replay requires a session id"); code = 2; break; }
        code = cmdReplay({ db, sessionId: subArg, format });
        break;
      case "snapshots":
        code = cmdSnapshots({ db, limit, format });
        break;
      case "audit":
        code = cmdAudit({ db, limit, eventType: typeof flags["type"] === "string" ? flags["type"] : undefined, format });
        break;
      case "providers":
        code = cmdProviders({ db, format });
        break;
      case "db-info":
        code = cmdDbInfo({ db });
        break;
      case "help":
        printHelp();
        code = 0;
        break;
      default:
        console.error(`Unknown command: ${command}`);
        printHelp();
        code = 2;
    }
  } catch (e) {
    console.error("FATAL:", redact(String((e as any)?.stack ?? e)));
    code = 3;
  }
  process.exit(code);
}

main();
