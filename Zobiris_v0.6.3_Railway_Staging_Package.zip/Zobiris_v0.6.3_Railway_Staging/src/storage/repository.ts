/**
 * Repository — domain operations on top of Drizzle.
 *
 * Idempotent by design: every operation has a deterministic key. The outbox
 * table is the transactional handshake between the engine and downstream
 * consumers (UI, audit, replay).
 */
import { randomUUID } from "node:crypto";
import { eq, and, desc, sql } from "drizzle-orm";
import type { DB } from "./client.js";
import type { ExtractTablesWithRelations } from "drizzle-orm";
import type { SQLiteTransaction } from "drizzle-orm/sqlite-core";
import * as schema from "./schema.js";
import {
  canonicalAssets,
  watchlist,
  observations,
  evidenceClaims,
  refreshSessions,
  snapshots,
  providerHealth,
  outboxEvents,
  memoryRecords,
  forecasts,
  calibrationRuns,
  auditEvents,
  canonicalAssetAliases,
  identityMergeHistory,
  type AuditEventType,
} from "./schema.js";

/**
 * DBTx = DB | transaction. All repository functions accept either the top-
 * level DB or a transaction handle so the persistRefresh transaction can call
 * them in one atomic block.
 */
export type DBTx =
  | DB
  | SQLiteTransaction<
      "sync",
      RunResult,
      typeof schema,
      ExtractTablesWithRelations<typeof schema>
    >;
import type { RunResult } from "better-sqlite3";

// ---------- JSON helpers ----------

export function jget<T = unknown>(s: string | null | undefined, fallback: T): T {
  if (!s) return fallback;
  try { return JSON.parse(s) as T; } catch { return fallback; }
}
export function jset(v: unknown): string {
  return JSON.stringify(v ?? null);
}

// ---------- Canonical assets ----------

export interface CanonicalAssetInput {
  id?: string;
  symbol: string;
  name: string;
  chainId?: string;
  contractAddress?: string;
  sector?: string;
  mappingStatus: "verified" | "ambiguous" | "unmapped" | "quarantined";
  mappingConfidence: number;
  providerIds: Record<string, string>;
  /**
   * v0.4.4 audit fix (P0-7): the strongest identity key known at
   * creation. Used as the basis for canonicalAssetId when no id
   * is provided. After v0.4.4 the canonicalAssetId is IMMUTABLE:
   * if stronger identity is later discovered, it is appended to
   * canonical_asset_aliases and the id is never changed.
   *
   * Typical values: "chain+contract", "provider-id", "provider-slug",
   * "chain+symbol", "symbol-only".
   */
  identityProvenance?: string;
}

export function upsertCanonicalAsset(db: DBTx, input: CanonicalAssetInput): string {
  const now = Date.now();
  const id = input.id ?? randomUUID();
  const existing = db.select({ id: canonicalAssets.id })
    .from(canonicalAssets)
    .where(eq(canonicalAssets.symbol, input.symbol))
    .all();
  if (existing.length > 0) {
    db.update(canonicalAssets)
      .set({
        name: input.name,
        chainId: input.chainId ?? null,
        contractAddress: input.contractAddress ?? null,
        sector: input.sector ?? null,
        mappingStatus: input.mappingStatus,
        mappingConfidence: input.mappingConfidence,
        providerIds: jset(input.providerIds),
        // v0.4.4: the id is immutable, but the identityProvenance
        // can be updated to reflect the strongest identity we now
        // know about. The id itself never changes.
        identityProvenance: input.identityProvenance ?? undefined,
        updatedAt: now,
      })
      .where(eq(canonicalAssets.id, existing[0]!.id))
      .run();
    return existing[0]!.id;
  }
  db.insert(canonicalAssets).values({
    id,
    symbol: input.symbol,
    name: input.name,
    chainId: input.chainId ?? null,
    contractAddress: input.contractAddress ?? null,
    sector: input.sector ?? null,
    mappingStatus: input.mappingStatus,
    mappingConfidence: input.mappingConfidence,
    providerIds: jset(input.providerIds),
    // v0.4.4 audit fix (P0-7): record the identity provenance so
    // the canonicalAssetId derivation can be re-verified.
    identityProvenance: input.identityProvenance ?? null,
    createdAt: now,
    updatedAt: now,
  }).run();
  // v0.4.4 audit fix (P0-7): append aliases for the new asset so
  // the immutable id can be located by any of the provider-native
  // identities. This is what makes the id truly immutable: the
  // table grows by APPEND, never by update of the canonical id.
  for (const [kind, value] of Object.entries(input.providerIds ?? {})) {
    if (!value) continue;
    try {
      db.insert(canonicalAssetAliases).values({
        id: randomUUID(),
        canonicalAssetId: id,
        aliasKind: kind,
        aliasValue: String(value),
        confidence: input.mappingConfidence,
        source: input.identityProvenance ?? "upsertCanonicalAsset",
        createdAt: now,
        superseded: 0,
        supersededAt: null,
      }).run();
    } catch (e) {
      // v0.4.4: alias uniqueness (kind, value) is global. If
      // another canonical asset already has this alias, record
      // the collision in identity_merge_history. The current
      // asset's id is NOT changed — the runtime operator must
      // resolve the collision manually.
      if (e instanceof Error && /UNIQUE/i.test(e.message)) {
        try {
          db.insert(identityMergeHistory).values({
            id: randomUUID(),
            survivorCanonicalAssetId: id,
            inputAliasKind: kind,
            inputAliasValue: String(value),
            action: "id_collided",
            notes: `alias (${kind}=${value}) already claimed by another asset; current id ${id} not changed`,
            occurredAt: now,
          }).run();
        } catch {
          // ignore: merge history is best-effort observability
        }
      }
    }
  }
  return id;
}

/**
 * v0.4.4 audit fix (P0-7): append a new alias to a canonical asset
 * without changing the canonical id. The id is immutable; new
 * identity information is recorded as a new row in
 * canonical_asset_aliases.
 */
export function appendCanonicalAlias(
  db: DBTx,
  canonicalAssetId: string,
  kind: string,
  value: string,
  confidence: number,
  source: string,
): void {
  const now = Date.now();
  try {
    db.insert(canonicalAssetAliases).values({
      id: randomUUID(),
      canonicalAssetId,
      aliasKind: kind,
      aliasValue: value,
      confidence,
      source,
      createdAt: now,
      superseded: 0,
      supersededAt: null,
    }).run();
    db.update(canonicalAssets)
      .set({ updatedAt: now })
      .where(eq(canonicalAssets.id, canonicalAssetId))
      .run();
  } catch (e) {
    if (e instanceof Error && /UNIQUE/i.test(e.message)) {
      // Alias already exists for another asset; record the merge
      // event so the operator can see the collision.
      try {
        db.insert(identityMergeHistory).values({
          id: randomUUID(),
          survivorCanonicalAssetId: canonicalAssetId,
          inputAliasKind: kind,
          inputAliasValue: value,
          action: "id_collided",
          notes: `alias (${kind}=${value}) already claimed`,
          occurredAt: now,
        }).run();
      } catch {
        // best-effort
      }
    }
  }
}

/**
 * v0.4.4 audit fix (P0-7): lookup a canonical asset by any of its
 * aliases. Returns the asset id if the alias resolves, undefined
 * otherwise.
 */
export function getCanonicalByAlias(
  db: DBTx,
  kind: string,
  value: string,
): { canonicalAssetId: string } | undefined {
  return db.select({ canonicalAssetId: canonicalAssetAliases.canonicalAssetId })
    .from(canonicalAssetAliases)
    .where(and(
      eq(canonicalAssetAliases.aliasKind, kind),
      eq(canonicalAssetAliases.aliasValue, value),
      eq(canonicalAssetAliases.superseded, 0),
    ))
    .get();
}

export function getCanonicalBySymbol(db: DBTx, symbol: string) {
  return db.select().from(canonicalAssets).where(eq(canonicalAssets.symbol, symbol)).get();
}

export function getCanonicalById(db: DBTx, id: string) {
  return db.select().from(canonicalAssets).where(eq(canonicalAssets.id, id)).get();
}

export function listCanonicalByMapping(db: DBTx, status: string) {
  return db.select().from(canonicalAssets).where(eq(canonicalAssets.mappingStatus, status)).all();
}

export function listAllCanonical(db: DB) {
  return db.select().from(canonicalAssets).all();
}

// ---------- Watchlist ----------

export function syncWatchlist(db: DBTx, entries: { symbol: string; name: string; rank: number; source?: string }[]): { synced: number; added: string[]; removed: string[]; reactivated: string[] } {
  const now = Date.now();
  const incomingSymbols = new Set(entries.map(e => e.symbol.toUpperCase()));
  let synced = 0;
  const added: string[] = [];
  const reactivated: string[] = [];

  // First pass: insert / update incoming entries.
  for (const e of entries) {
    const upper = e.symbol.toUpperCase();
    const existing = db.select({ id: watchlist.id, removedAt: watchlist.removedAt })
      .from(watchlist)
      .where(eq(watchlist.symbol, upper))
      .get();
    if (existing) {
      const wasRemoved = existing.removedAt != null;
      db.update(watchlist)
        .set({ name: e.name, rank: e.rank, source: e.source ?? "cmc", removedAt: null })
        .where(eq(watchlist.id, existing.id))
        .run();
      if (wasRemoved) reactivated.push(upper);
    } else {
      db.insert(watchlist).values({
        id: randomUUID(),
        symbol: upper,
        name: e.name,
        rank: e.rank,
        source: e.source ?? "cmc",
        addedAt: now,
      }).run();
      added.push(upper);
    }
    synced++;
  }

  // Second pass: mark entries that are absent from the incoming list as
  // removed (but keep the row so historical data stays queryable). Per the
  // audit: membership removals must be handled; sync must not silently
  // preserve stale entries as "active" merely because their count matches.
  const existingActive = db.select({ id: watchlist.id, symbol: watchlist.symbol })
    .from(watchlist)
    .where(sql`${watchlist.removedAt} IS NULL`)
    .all();
  const removed: string[] = [];
  for (const row of existingActive) {
    if (!incomingSymbols.has(row.symbol.toUpperCase())) {
      db.update(watchlist)
        .set({ removedAt: now })
        .where(eq(watchlist.id, row.id))
        .run();
      removed.push(row.symbol);
    }
  }

  return { synced, added, removed, reactivated };
}

export function listActiveWatchlist(db: DB) {
  return db.select().from(watchlist).where(sql`${watchlist.removedAt} IS NULL`)
    .orderBy(watchlist.rank).all();
}

// ---------- Observations (idempotent) ----------

export interface ObservationInput {
  id?: string;
  idempotencyKey: string;
  provider: string;
  providerEventId?: string;
  eventType: string;
  schemaVersion: string;
  canonicalAssetId?: string | null;
  quarantineState?: "verified" | "ambiguous" | "unmapped" | "quarantined";
  // v0.4.4 audit fix: persist identity match method for roundtrip
  // provenance. The audit caught that the server's reconstruction
  // path was hard-coding quarantineState: "verified" and losing the
  // match method.
  identityMatchMethod?: string | null;
  dataMode?: "live" | "snapshot" | "fallback";
  providerEndpoint?: string | null;
  requestedSymbol?: string | null;
  requestedExchange?: string | null;
  providerGeneratedAt?: number | null;
  fallbackReason?: string | null;
  upstreamFailure?: unknown;
  payloadHash?: string | null;
  sourceTimestamp?: number | null;
  occurredAt: number;
  receivedAt?: number;
  payload: unknown;
  epistemicState: "KNOWN" | "INFERRED" | "UNCERTAIN" | "CONFLICTED" | "UNKNOWN" | "STALE";
  evidenceConfidence: number;
  licenseClass?: string;
  raw?: unknown;
  normalizerVersion: string;
  sessionId?: string | null;
}

export interface IngestResult { inserted: boolean; id: string; }

export function ingestObservation(db: DBTx, input: ObservationInput): IngestResult {
  // Idempotent: try insert with onConflict do nothing; return whether a row was created.
  const id = input.id ?? randomUUID();
  const now = input.receivedAt ?? Date.now();
  db.insert(observations).values({
    id,
    idempotencyKey: input.idempotencyKey,
    provider: input.provider,
    providerEventId: input.providerEventId ?? null,
    eventType: input.eventType,
    schemaVersion: input.schemaVersion,
    canonicalAssetId: input.canonicalAssetId ?? null,
    quarantineState: input.quarantineState ?? "verified",
    identityMatchMethod: input.identityMatchMethod ?? null,
    dataMode: input.dataMode ?? "live",
    providerEndpoint: input.providerEndpoint ?? null,
    requestedSymbol: input.requestedSymbol ?? null,
    requestedExchange: input.requestedExchange ?? null,
    providerGeneratedAt: input.providerGeneratedAt ?? null,
    fallbackReason: input.fallbackReason ?? null,
    upstreamFailure: input.upstreamFailure ? jset(input.upstreamFailure) : null,
    payloadHash: input.payloadHash ?? null,
    sourceTimestamp: input.sourceTimestamp ?? null,
    occurredAt: input.occurredAt,
    receivedAt: now,
    payload: jset(input.payload),
    epistemicState: input.epistemicState,
    evidenceConfidence: input.evidenceConfidence,
    licenseClass: input.licenseClass ?? "display-only",
    raw: input.raw ? jset(input.raw) : null,
    normalizerVersion: input.normalizerVersion,
    sessionId: input.sessionId ?? null,
  }).onConflictDoNothing({ target: observations.idempotencyKey }).run();
  // better-sqlite3 doesn't return rows-affected through drizzle nicely, so query.
  const row = db.select({ id: observations.id, receivedAt: observations.receivedAt })
    .from(observations)
    .where(eq(observations.idempotencyKey, input.idempotencyKey))
    .get();
  if (!row) throw new Error("ingestObservation: insert failed silently");
  return { inserted: row.receivedAt === now, id: row.id };
}

export function listObservationsBySession(db: DBTx, sessionId: string) {
  return db.select().from(observations).where(eq(observations.sessionId, sessionId)).all();
}

export function getObservationsForSymbol(db: DBTx, symbol: string, limit = 50) {
  const ca = db.select({ id: canonicalAssets.id }).from(canonicalAssets).where(eq(canonicalAssets.symbol, symbol)).get();
  if (!ca) return [];
  return db.select().from(observations)
    .where(eq(observations.canonicalAssetId, ca.id))
    .orderBy(desc(observations.receivedAt))
    .limit(limit)
    .all();
}

export function getEvidenceForSymbol(db: DBTx, symbol: string, limit = 50) {
  return db.select().from(evidenceClaims)
    .where(eq(evidenceClaims.symbol, symbol))
    .orderBy(desc(evidenceClaims.receivedAt))
    .limit(limit)
    .all();
}

// ---------- Evidence claims ----------

export interface EvidenceClaimInput {
  id?: string;
  observationId: string;
  symbol: string;
  factorFamily: string;
  claim: string;
  source: string;
  observedAt: number;
  receivedAt?: number;
  freshnessAgeSeconds: number;
  epistemicState: string;
  evidenceConfidence: number;
  licenseClass?: string;
  providerIds: string[];
  memoryIds?: string[];
  claimOrigin?: "provider" | "model" | "synthetic" | "rehydrated";
  freshness?: "live" | "delayed" | "stale" | "unavailable";
  dataMode?: "live" | "snapshot" | "fallback";
  payloadHash?: string;
  transformationVersion?: string;
  providerEndpoint?: string;
  modelProvider?: string;
  modelVersion?: string;
  parentClaimIds?: string[];
}

export function insertEvidenceClaim(db: DBTx, input: EvidenceClaimInput): string {
  const id = input.id ?? randomUUID();
  db.insert(evidenceClaims).values({
    id,
    observationId: input.observationId,
    symbol: input.symbol,
    factorFamily: input.factorFamily,
    claim: input.claim,
    source: input.source,
    observedAt: input.observedAt,
    receivedAt: input.receivedAt ?? Date.now(),
    freshnessAgeSeconds: input.freshnessAgeSeconds,
    epistemicState: input.epistemicState,
    evidenceConfidence: input.evidenceConfidence,
    licenseClass: input.licenseClass ?? "display-only",
    providerIds: jset(input.providerIds),
    memoryIds: jset(input.memoryIds ?? []),
    claimOrigin: input.claimOrigin ?? "provider",
    freshness: input.freshness ?? "live",
    dataMode: input.dataMode ?? "live",
    payloadHash: input.payloadHash ?? null,
    transformationVersion: input.transformationVersion ?? "0.0.0",
    providerEndpoint: input.providerEndpoint ?? null,
    modelProvider: input.modelProvider ?? null,
    modelVersion: input.modelVersion ?? null,
    parentClaimIds: jset(input.parentClaimIds ?? []),
  }).run();
  return id;
}

// ---------- Sessions + snapshots ----------

export function openSession(db: DBTx, input: { id: string; mode: string; policyVersion: string; pointInTimeCutoff?: number; specialistRoster: string[] }): void {
  db.insert(refreshSessions).values({
    id: input.id,
    mode: input.mode,
    status: "open",
    startedAt: Date.now(),
    pointInTimeCutoff: input.pointInTimeCutoff ?? Date.now(),
    policyVersion: input.policyVersion,
    specialistRoster: jset(input.specialistRoster),
    stages: jset([]),
  }).run();
}

export function appendSessionStage(db: DBTx, sessionId: string, stage: { index: number; name: string; status: string; notes?: string }): void {
  const row = db.select({ stages: refreshSessions.stages }).from(refreshSessions)
    .where(eq(refreshSessions.id, sessionId)).get();
  if (!row) throw new Error(`appendSessionStage: session ${sessionId} not found`);
  const stages = jget<Array<typeof stage & { startedAt: string; completedAt: string }>>(row.stages, []);
  const now = new Date().toISOString();
  stages.push({ ...stage, startedAt: now, completedAt: now });
  db.update(refreshSessions).set({ stages: jset(stages) }).where(eq(refreshSessions.id, sessionId)).run();
}

export function closeSession(db: DBTx, sessionId: string, input: {
  status: "complete" | "fail";
  verifierOutput?: unknown;
  challengerOutput?: unknown;
  synthesizerOutput?: unknown;
  conclusion?: string;
  observationCount: number;
  evidenceClaimCount: number;
}): void {
  db.update(refreshSessions).set({
    status: input.status,
    completedAt: Date.now(),
    verifierOutput: input.verifierOutput ? jset(input.verifierOutput) : null,
    challengerOutput: input.challengerOutput ? jset(input.challengerOutput) : null,
    synthesizerOutput: input.synthesizerOutput ? jset(input.synthesizerOutput) : null,
    conclusion: input.conclusion ?? null,
    observationCount: input.observationCount,
    evidenceClaimCount: input.evidenceClaimCount,
  }).where(eq(refreshSessions.id, sessionId)).run();
}

export interface SnapshotInput {
  id?: string;
  sessionId: string;
  asOf: number;
  policyVersion: string;
  regime: string;
  regimeConfidence: number;
  totalAllocatedPct: number;
  reservePct: number;
  unallocatedPct: number;
  rankedAssets: unknown;
  sectorConcentration: Record<string, number>;
  narrativeConcentration: Record<string, number>;
  topRiskGates: unknown;
  changesSinceLastRefresh: unknown;
  conclusion: string;
  brierScore?: number | null;
  calibrationBucket?: string | null;
}

export function insertSnapshot(db: DBTx, input: SnapshotInput): string {
  const id = input.id ?? randomUUID();
  db.insert(snapshots).values({
    id,
    sessionId: input.sessionId,
    asOf: input.asOf,
    policyVersion: input.policyVersion,
    regime: input.regime,
    regimeConfidence: input.regimeConfidence,
    totalAllocatedPct: input.totalAllocatedPct,
    reservePct: input.reservePct,
    unallocatedPct: input.unallocatedPct,
    rankedAssets: jset(input.rankedAssets),
    sectorConcentration: jset(input.sectorConcentration),
    narrativeConcentration: jset(input.narrativeConcentration),
    topRiskGates: jset(input.topRiskGates),
    changesSinceLastRefresh: jset(input.changesSinceLastRefresh),
    conclusion: input.conclusion,
    brierScore: input.brierScore ?? null,
    calibrationBucket: input.calibrationBucket ?? null,
  }).run();
  return id;
}

export function getLatestSnapshot(db: DB) {
  return db.select().from(snapshots).orderBy(desc(snapshots.asOf)).get();
}

export function getSnapshotById(db: DBTx, id: string) {
  return db.select().from(snapshots).where(eq(snapshots.id, id)).get();
}

export function getRecentSnapshots(db: DBTx, limit = 10) {
  return db.select().from(snapshots).orderBy(desc(snapshots.asOf)).limit(limit).all();
}

export function getSessionById(db: DBTx, id: string) {
  return db.select().from(refreshSessions).where(eq(refreshSessions.id, id)).get();
}

// ---------- Provider health + circuit breaker ----------

export interface ProviderHealthUpdate {
  provider: string;
  status: "connected" | "degraded" | "disconnected" | "credentials-needed" | "adapter-needed" | "snapshot";
  lastConnectedAt?: number;
  lastMessageAt?: number;
  lastEventAt?: number;
  lastErrorAt?: number;
  lastErrorClass?: string;
  freshness: "live" | "delayed" | "stale" | "backfilling" | "unavailable";
  onSuccess?: boolean;
  circuitFailureThreshold?: number;        // default 3
  circuitResetSeconds?: number;             // default 300
}

export function upsertProviderHealth(db: DBTx, u: ProviderHealthUpdate): {
  circuitState: "closed" | "open" | "half-open";
  consecutiveFailures: number;
  circuitOpened: boolean;
} {
  const threshold = u.circuitFailureThreshold ?? 3;
  const resetMs = (u.circuitResetSeconds ?? 300) * 1000;
  const now = Date.now();
  const existing = db.select().from(providerHealth).where(eq(providerHealth.provider, u.provider)).get();
  const isFailure = u.onSuccess === false;
  const isSuccess = u.onSuccess === true;

  let state: "closed" | "open" | "half-open" = (existing?.circuitState as "closed" | "open" | "half-open" | undefined) ?? "closed";
  let consecutiveFailures = existing?.consecutiveFailures ?? 0;
  let circuitOpenedAt = existing?.circuitOpenedAt ?? null;
  let circuitNextRetryAt = existing?.circuitNextRetryAt ?? null;
  let circuitOpened = false;

  if (existing && state === "open" && circuitNextRetryAt && now >= circuitNextRetryAt) {
    state = "half-open";
  }

  if (isFailure) {
    consecutiveFailures++;
    if (consecutiveFailures >= threshold && state !== "open") {
      state = "open";
      circuitOpenedAt = now;
      circuitNextRetryAt = now + resetMs;
      circuitOpened = true;
    }
  } else if (isSuccess) {
    consecutiveFailures = 0;
    if (state === "half-open" || state === "open") {
      state = "closed";
      circuitOpenedAt = null;
      circuitNextRetryAt = null;
    }
  }

  if (existing) {
    db.update(providerHealth).set({
      status: u.status,
      lastConnectedAt: u.lastConnectedAt ?? existing.lastConnectedAt,
      lastMessageAt: u.lastMessageAt ?? existing.lastMessageAt,
      lastEventAt: u.lastEventAt ?? existing.lastEventAt,
      lastErrorAt: u.lastErrorAt ?? existing.lastErrorAt,
      lastErrorClass: u.lastErrorClass ?? existing.lastErrorClass,
      freshness: u.freshness,
      circuitState: state,
      circuitOpenedAt,
      circuitNextRetryAt,
      consecutiveFailures,
      reconnectAttempt: isFailure ? (existing.reconnectAttempt + 1) : 0,
      updatedAt: now,
    }).where(eq(providerHealth.provider, u.provider)).run();
  } else {
    db.insert(providerHealth).values({
      id: randomUUID(),
      provider: u.provider,
      status: u.status,
      reconnectAttempt: isFailure ? 1 : 0,
      lastConnectedAt: u.lastConnectedAt ?? null,
      lastMessageAt: u.lastMessageAt ?? null,
      lastEventAt: u.lastEventAt ?? null,
      lastErrorAt: u.lastErrorAt ?? null,
      lastErrorClass: u.lastErrorClass ?? null,
      freshness: u.freshness,
      circuitState: state,
      circuitOpenedAt,
      circuitNextRetryAt,
      consecutiveFailures,
      updatedAt: now,
    }).run();
  }
  return { circuitState: state, consecutiveFailures, circuitOpened };
}

export function listProviderHealth(db: DB) {
  return db.select().from(providerHealth).all();
}

export function shouldAttemptProvider(db: DBTx, provider: string): boolean {
  const row = db.select().from(providerHealth).where(eq(providerHealth.provider, provider)).get();
  if (!row) return true;
  if (row.circuitState === "closed") return true;
  if (row.circuitState === "half-open") return true;
  if (row.circuitState === "open" && row.circuitNextRetryAt && Date.now() >= row.circuitNextRetryAt) return true;
  return false;
}

// ---------- DB info (counts + mapping status) ----------

export function getDbInfo(db: DBTx, dbPath: string) {
  const tables = [
    "canonical_assets", "watchlist", "observations", "evidence_claims",
    "refresh_sessions", "snapshots", "provider_health", "outbox_events",
    "memory_records", "forecasts", "calibration_runs", "audit_events",
  ];
  const counts: Record<string, number> = {};
  for (const t of tables) {
    const row = db.all<{ n: number }>(sql.raw(`SELECT COUNT(*) AS n FROM ${t}`));
    counts[t] = Number(row[0]?.n ?? 0);
  }
  const byMapping = db.all<{ mapping_status: string; n: number }>(
    sql`SELECT mapping_status, COUNT(*) AS n FROM canonical_assets GROUP BY mapping_status`
  );
  return {
    dbPath,
    counts,
    canonicalMappingStatus: byMapping.reduce<Record<string, number>>((acc, r) => {
      acc[r.mapping_status] = Number(r.n);
      return acc;
    }, {}),
  };
}

// ---------- Outbox (transactional handshake) ----------

export function enqueueOutbox(db: DBTx, input: {
  aggregateType: "snapshot" | "observation" | "evidence_claim" | "session";
  aggregateId: string;
  eventType: string;
  payload: unknown;
  scheduledFor?: number;
}): string {
  const id = randomUUID();
  db.insert(outboxEvents).values({
    id,
    aggregateType: input.aggregateType,
    aggregateId: input.aggregateId,
    eventType: input.eventType,
    payload: jset(input.payload),
    scheduledFor: input.scheduledFor ?? null,
  }).run();
  return id;
}

export function listPendingOutbox(db: DBTx, limit = 100) {
  return db.select().from(outboxEvents)
    .where(eq(outboxEvents.status, "pending"))
    .limit(limit)
    .all();
}

export function markOutboxPublished(db: DBTx, id: string): void {
  db.update(outboxEvents).set({ status: "published", publishedAt: Date.now() })
    .where(eq(outboxEvents.id, id)).run();
}

export function markOutboxFailed(db: DBTx, id: string, err: string): void {
  const row = db.select().from(outboxEvents).where(eq(outboxEvents.id, id)).get();
  if (!row) return;
  const newAttempt = row.attempt + 1;
  db.update(outboxEvents).set({
    status: newAttempt >= 5 ? "failed" : "pending",
    attempt: newAttempt,
    lastError: err,
  }).where(eq(outboxEvents.id, id)).run();
}

// ---------- Audit (allowlisted) ----------

export function emitAudit(db: DBTx, input: {
  eventType: AuditEventType;
  sessionId?: string;
  symbol?: string;
  payload?: Record<string, unknown>;
  actor?: string;
}): string {
  const id = randomUUID();
  db.insert(auditEvents).values({
    id,
    eventType: input.eventType,
    sessionId: input.sessionId ?? null,
    symbol: input.symbol ?? null,
    payload: jset(input.payload ?? {}),
    actor: input.actor ?? "zobiris",
  }).run();
  return id;
}

export function listAuditEvents(db: DBTx, opts: { limit?: number; eventType?: string; sessionId?: string } = {}) {
  let q = db.select().from(auditEvents).$dynamic();
  if (opts.eventType) q = q.where(eq(auditEvents.eventType, opts.eventType as AuditEventType));
  if (opts.sessionId) q = q.where(eq(auditEvents.sessionId, opts.sessionId));
  return q.orderBy(desc(auditEvents.occurredAt)).limit(opts.limit ?? 100).all();
}

// ---------- Memory (slice 7) ----------

export interface MemoryRecordInput {
  id?: string;
  kind: "episodic" | "semantic" | "regime" | "procedural" | "graph" | "hypothesis";
  symbol?: string | null;
  subject: string;
  body: string;
  provenance: unknown;
  confidence: number;
  freshness?: number;
  status?: "active" | "promoted" | "retired" | "contested";
  tags?: string[];
  falsifiability?: string | null;
  invalidationConditions?: string[] | null;
  trigger?: string | null;
  action?: string | null;
}

export function insertMemory(db: DBTx, input: MemoryRecordInput): string {
  const id = input.id ?? randomUUID();
  db.insert(memoryRecords).values({
    id,
    kind: input.kind,
    symbol: input.symbol ?? null,
    subject: input.subject,
    body: input.body,
    provenance: jset(input.provenance),
    confidence: input.confidence,
    freshness: input.freshness ?? Date.now(),
    status: input.status ?? "active",
    tags: jset(input.tags ?? []),
    falsifiability: input.falsifiability ?? null,
    invalidationConditions: input.invalidationConditions ? jset(input.invalidationConditions) : null,
    trigger: input.trigger ?? null,
    action: input.action ?? null,
  }).run();
  return id;
}

export function listMemoryByKind(db: DBTx, kind: string, opts: { symbol?: string; status?: string; limit?: number } = {}) {
  let q = db.select().from(memoryRecords).$dynamic();
  if (kind) q = q.where(eq(memoryRecords.kind, kind));
  if (opts.symbol) q = q.where(eq(memoryRecords.symbol, opts.symbol));
  if (opts.status) q = q.where(eq(memoryRecords.status, opts.status));
  return q.orderBy(desc(memoryRecords.freshness)).limit(opts.limit ?? 50).all();
}

// ---------- Forecasts (slice 11) ----------

export function insertForecast(db: DBTx, input: {
  id?: string;
  sessionId: string;
  snapshotId: string;
  symbol: string;
  horizonDays: number;
  forecast: unknown;
  hidden?: boolean;
}): string {
  const id = input.id ?? randomUUID();
  db.insert(forecasts).values({
    id,
    sessionId: input.sessionId,
    snapshotId: input.snapshotId,
    symbol: input.symbol,
    horizonDays: input.horizonDays,
    forecast: jset(input.forecast),
    hidden: input.hidden ? 1 : 0,
  }).run();
  return id;
}

export function listForecasts(db: DBTx, opts: { symbol?: string; hidden?: boolean; limit?: number } = {}) {
  let q = db.select().from(forecasts).$dynamic();
  if (opts.symbol) q = q.where(eq(forecasts.symbol, opts.symbol));
  if (opts.hidden != null) q = q.where(eq(forecasts.hidden, opts.hidden ? 1 : 0));
  return q.orderBy(desc(forecasts.createdAt)).limit(opts.limit ?? 100).all();
}

export function recordForecastActual(db: DBTx, id: string, actual: unknown, brier: number): void {
  db.update(forecasts).set({ actual: jset(actual), brier, resolvedAt: Date.now() })
    .where(eq(forecasts.id, id)).run();
}

// ---------- Calibration runs (slice 11) ----------

export function insertCalibrationRun(db: DBTx, input: {
  id?: string;
  policyVersion: string;
  scope: string;
  sampleSize: number;
  metrics: unknown;
  hiddenHoldout?: boolean;
  promotion?: string;
  notes?: string;
}): string {
  const id = input.id ?? randomUUID();
  db.insert(calibrationRuns).values({
    id,
    policyVersion: input.policyVersion,
    scope: input.scope,
    sampleSize: input.sampleSize,
    metrics: jset(input.metrics),
    hiddenHoldout: input.hiddenHoldout ? 1 : 0,
    promotion: input.promotion ?? "neutral",
    notes: input.notes ?? null,
  }).run();
  return id;
}

export function listCalibrationRuns(db: DBTx, limit = 20) {
  return db.select().from(calibrationRuns).orderBy(desc(calibrationRuns.runAt)).limit(limit).all();
}

// ---------- Replay ----------

export interface ReplayResult {
  sessionId: string;
  session: ReturnType<typeof getSessionById>;
  snapshot: ReturnType<typeof getSnapshotById>;
  observations: ReturnType<typeof listObservationsBySession>;
  evidenceClaims: Array<ReturnType<typeof getEvidenceClaimsBySession>[number]>;
  auditEvents: ReturnType<typeof listAuditEvents>;
  outbox: ReturnType<typeof listOutboxByAggregate>;
}

export function getEvidenceClaimsBySession(db: DBTx, sessionId: string) {
  return db.select().from(evidenceClaims)
    .innerJoin(observations, eq(evidenceClaims.observationId, observations.id))
    .where(eq(observations.sessionId, sessionId))
    .all()
    .map(row => row.evidence_claims);
}

export function listOutboxByAggregate(db: DBTx, aggregateType: string, aggregateId: string) {
  return db.select().from(outboxEvents)
    .where(and(eq(outboxEvents.aggregateType, aggregateType), eq(outboxEvents.aggregateId, aggregateId)))
    .all();
}

export function replaySession(db: DBTx, sessionId: string): ReplayResult {
  const session = getSessionById(db, sessionId);
  if (!session) throw new Error(`replaySession: session ${sessionId} not found`);
  const snapRow = db.select().from(snapshots).where(eq(snapshots.sessionId, sessionId)).get();
  return {
    sessionId,
    session,
    snapshot: snapRow,
    observations: listObservationsBySession(db, sessionId),
    evidenceClaims: getEvidenceClaimsBySession(db, sessionId),
    auditEvents: listAuditEvents(db, { sessionId, limit: 1000 }),
    outbox: snapRow ? listOutboxByAggregate(db, "snapshot", snapRow.id) : [],
  };
}
