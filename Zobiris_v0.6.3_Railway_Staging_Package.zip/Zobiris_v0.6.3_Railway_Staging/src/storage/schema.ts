/**
 * Drizzle ORM schema — SQLite native (better-sqlite3) for local/test, PostgreSQL
 * for production deployment. The SQL is portable: every column maps 1:1
 * (text → text, integer → integer/bigint, real → double precision, integer
 * unix-epoch-ms → timestamptz). The migration from SQLite to Postgres is
 * mechanical — see docs/POSTGRES_MIGRATION.md (slice 2 deliverable).
 *
 * Tables (release-blocker "transactional_outbox" lives in `outbox_events`):
 *   - canonical_assets        ticker never primary key; 4-state machine
 *   - watchlist               source-defined CMC watchlist membership
 *   - observations            normalized, idempotency-keyed provider output
 *   - evidence_claims         user-facing evidence ledger
 *   - refresh_sessions        19-stage contract with stage telemetry
 *   - snapshots               point-in-time portfolio analyses + What-Changed
 *   - provider_health         per-provider circuit-breaker state
 *   - outbox_events           transactional outbox; release-blocker for atomicity
 *   - memory_records          episodic/semantic/regime memory (slice 7)
 *   - forecasts               Brier-scored forecast ledger (slice 11)
 *   - calibration_runs        backtest + replay evaluation (slice 11)
 *   - audit_events            append-only allowlist
 */
import { sql } from "drizzle-orm";
import {
  sqliteTable,
  text,
  integer,
  real,
  index,
  uniqueIndex,
} from "drizzle-orm/sqlite-core";

const nowMs = sql`(unixepoch() * 1000)`;

export const canonicalAssets = sqliteTable("canonical_assets", {
  id: text("id").primaryKey(),
  symbol: text("symbol").notNull(),
  name: text("name").notNull(),
  chainId: text("chain_id"),
  contractAddress: text("contract_address"),
  sector: text("sector"),
  mappingStatus: text("mapping_status").notNull(),
  mappingConfidence: real("mapping_confidence").notNull().default(0),
  providerIds: text("provider_ids").notNull().default("{}"),
  // v0.4.4 audit fix (P0-7): capture the identity provenance —
  // the strongest identity key known at the time of creation.
  // canonicalAssetId is the IMMUTABLE primary key; if a stronger
  // identity is later discovered, the asset stays under its
  // original id and a new row in `canonical_asset_aliases` records
  // the additional identity information. The audit also flagged
  // that v0.4.2 ids are derived (e.g. SHA-256 of provider-id +
  // symbol), which is not stable if either component changes.
  // v0.4.4 stores the strongest identity that produced the id, so
  // the derivation can be re-verified.
  identityProvenance: text("identity_provenance"),
  createdAt: integer("created_at").notNull().default(nowMs),
  updatedAt: integer("updated_at").notNull().default(nowMs),
}, (t) => ({
  symbolIdx: index("canonical_assets_symbol_idx").on(t.symbol),
  mappingIdx: index("canonical_assets_mapping_idx").on(t.mappingStatus),
}));

/**
 * v0.4.4 audit fix (P0-7): aliases for a canonical asset. The
 * canonicalAssetId is IMMUTABLE — when stronger identity information
 * is later discovered (e.g. a chain+contract address), a new row
 * is appended here instead of changing the id. This preserves
 * referential integrity for historical observations, snapshots,
 * forecasts, etc.
 *
 * aliasKind is one of: "cmc_numeric_id" | "cmc_slug" |
 * "coingecko_id" | "kraken_pair" | "lunarcrush_id" |
 * "coinmarketcal_slug" | "coinglass_id" | "contract" | "chain_symbol"
 * | "legacy_canonical_id" | "symbol_only".
 *
 * source records the origin: "live_cmc_v3", "live_lunarcrush_v4",
 * "research", "imported_from_v0.4.x", etc. — for auditability.
 */
export const canonicalAssetAliases = sqliteTable("canonical_asset_aliases", {
  id: text("id").primaryKey(),
  canonicalAssetId: text("canonical_asset_id").notNull(),
  aliasKind: text("alias_kind").notNull(),
  aliasValue: text("alias_value").notNull(),
  confidence: real("confidence").notNull().default(0.5),
  source: text("source").notNull().default("unknown"),
  createdAt: integer("created_at").notNull().default(nowMs),
  superseded: integer("superseded").notNull().default(0),  // 0 = active, 1 = historical
  supersededAt: integer("superseded_at"),
}, (t) => ({
  assetIdx: index("canonical_aliases_asset_idx").on(t.canonicalAssetId),
  aliasIdx: uniqueIndex("canonical_aliases_alias_idx").on(t.aliasKind, t.aliasValue),
}));

/**
 * v0.4.4 audit fix (P0-7): the identity_merge_history records every
 * identity-resolution event. The canonicalAssetId is the resolved
 * (immutable) id; the input identity is what the runtime saw. If
 * the runtime later discovers a stronger identity and a DIFFERENT
 * canonical id exists, the new id is added to aliases and the merge
 * is recorded here. The id of the merged-into asset is never
 * changed.
 */
export const identityMergeHistory = sqliteTable("identity_merge_history", {
  id: text("id").primaryKey(),
  // The asset that the identity was merged INTO (the survivor).
  survivorCanonicalAssetId: text("survivor_canonical_asset_id").notNull(),
  // The input identity that triggered the merge.
  inputAliasKind: text("input_alias_kind").notNull(),
  inputAliasValue: text("input_alias_value").notNull(),
  // What the merge did.
  action: text("action").notNull(),  // "alias_appended" | "id_collided" | "no_op"
  notes: text("notes"),
  occurredAt: integer("occurred_at").notNull().default(nowMs),
}, (t) => ({
  survivorIdx: index("identity_merge_history_survivor_idx").on(t.survivorCanonicalAssetId),
  occurredAtIdx: index("identity_merge_history_occurred_at_idx").on(t.occurredAt),
}));

export const watchlist = sqliteTable("watchlist", {
  id: text("id").primaryKey(),
  symbol: text("symbol").notNull(),
  name: text("name").notNull(),
  cmcWatchlistId: text("cmc_watchlist_id").default("69c01b46aed37c7160053535"),
  rank: integer("rank").notNull(),
  addedAt: integer("added_at").notNull().default(nowMs),
  removedAt: integer("removed_at"),
  source: text("source").notNull().default("cmc"),
}, (t) => ({
  symbolIdx: uniqueIndex("watchlist_symbol_idx").on(t.symbol),
  activeIdx: index("watchlist_active_idx").on(t.removedAt),
}));

export const observations = sqliteTable("observations", {
  id: text("id").primaryKey(),
  idempotencyKey: text("idempotency_key").notNull(),
  provider: text("provider").notNull(),
  providerEventId: text("provider_event_id"),
  eventType: text("event_type").notNull(),
  schemaVersion: text("schema_version").notNull(),
  canonicalAssetId: text("canonical_asset_id"),
  quarantineState: text("quarantine_state").notNull().default("verified"),
  // v0.4.4 audit fix: persist the identity match method so the
  // rehydration path can preserve the original identity provenance.
  identityMatchMethod: text("identity_match_method"),
  dataMode: text("data_mode").notNull().default("live"),
  providerEndpoint: text("provider_endpoint"),
  requestedSymbol: text("requested_symbol"),
  requestedExchange: text("requested_exchange"),
  providerGeneratedAt: integer("provider_generated_at"),
  fallbackReason: text("fallback_reason"),
  upstreamFailure: text("upstream_failure"),
  payloadHash: text("payload_hash"),
  sourceTimestamp: integer("source_timestamp"),
  occurredAt: integer("occurred_at").notNull(),
  receivedAt: integer("received_at").notNull().default(nowMs),
  payload: text("payload").notNull(),
  epistemicState: text("epistemic_state").notNull().default("UNKNOWN"),
  evidenceConfidence: real("evidence_confidence").notNull().default(0),
  licenseClass: text("license_class").notNull().default("display-only"),
  raw: text("raw"),
  normalizerVersion: text("normalizer_version").notNull(),
  sessionId: text("session_id"),
}, (t) => ({
  idempIdx: uniqueIndex("observations_idemp_idx").on(t.idempotencyKey),
  providerIdx: index("observations_provider_idx").on(t.provider, t.eventType),
  canonicalIdx: index("observations_canonical_idx").on(t.canonicalAssetId),
  receivedAtIdx: index("observations_received_at_idx").on(t.receivedAt),
}));

export const evidenceClaims = sqliteTable("evidence_claims", {
  id: text("id").primaryKey(),
  observationId: text("observation_id").notNull(),
  symbol: text("symbol").notNull(),
  factorFamily: text("factor_family").notNull(),
  claim: text("claim").notNull(),
  source: text("source").notNull(),
  observedAt: integer("observed_at").notNull(),
  receivedAt: integer("received_at").notNull().default(nowMs),
  freshnessAgeSeconds: integer("freshness_age_seconds").notNull().default(0),
  epistemicState: text("epistemic_state").notNull(),
  evidenceConfidence: real("evidence_confidence").notNull(),
  licenseClass: text("license_class").notNull().default("display-only"),
  providerIds: text("provider_ids").notNull().default("[]"),
  memoryIds: text("memory_ids").notNull().default("[]"),
  // v0.4.4 audit fix: typed provenance, freshness, dataMode,
  // transformation version, provider endpoint, payload hash,
  // model info, and parent claim IDs (for model-derived claims).
  claimOrigin: text("claim_origin").notNull().default("provider"),
  freshness: text("freshness").notNull().default("live"),
  dataMode: text("data_mode").notNull().default("live"),
  payloadHash: text("payload_hash"),
  transformationVersion: text("transformation_version").notNull().default("0.0.0"),
  providerEndpoint: text("provider_endpoint"),
  modelProvider: text("model_provider"),
  modelVersion: text("model_version"),
  parentClaimIds: text("parent_claim_ids").notNull().default("[]"),
}, (t) => ({
  symbolIdx: index("evidence_claims_symbol_idx").on(t.symbol),
  familyIdx: index("evidence_claims_family_idx").on(t.factorFamily),
  receivedAtIdx: index("evidence_claims_received_at_idx").on(t.receivedAt),
}));

export const refreshSessions = sqliteTable("refresh_sessions", {
  id: text("id").primaryKey(),
  mode: text("mode").notNull().default("deep"),
  status: text("status").notNull().default("open"),
  startedAt: integer("started_at").notNull().default(nowMs),
  completedAt: integer("completed_at"),
  pointInTimeCutoff: integer("point_in_time_cutoff"),
  policyVersion: text("policy_version").notNull(),
  specialistRoster: text("specialist_roster").notNull().default("[]"),
  stages: text("stages").notNull().default("[]"),
  verifierOutput: text("verifier_output"),
  challengerOutput: text("challenger_output"),
  synthesizerOutput: text("synthesizer_output"),
  conclusion: text("conclusion"),
  observationCount: integer("observation_count").notNull().default(0),
  evidenceClaimCount: integer("evidence_claim_count").notNull().default(0),
}, (t) => ({
  startedAtIdx: index("refresh_sessions_started_at_idx").on(t.startedAt),
  statusIdx: index("refresh_sessions_status_idx").on(t.status),
}));

export const snapshots = sqliteTable("snapshots", {
  id: text("id").primaryKey(),
  sessionId: text("session_id").notNull(),
  asOf: integer("as_of").notNull(),
  policyVersion: text("policy_version").notNull(),
  regime: text("regime").notNull().default("UNKNOWN"),
  regimeConfidence: real("regime_confidence").notNull().default(0),
  totalAllocatedPct: real("total_allocated_pct").notNull().default(0),
  reservePct: real("reserve_pct").notNull().default(10),
  unallocatedPct: real("unallocated_pct").notNull().default(0),
  rankedAssets: text("ranked_assets").notNull(),
  sectorConcentration: text("sector_concentration").notNull().default("{}"),
  narrativeConcentration: text("narrative_concentration").notNull().default("{}"),
  topRiskGates: text("top_risk_gates").notNull().default("[]"),
  changesSinceLastRefresh: text("changes_since_last_refresh").notNull(),
  conclusion: text("conclusion").notNull().default(""),
  brierScore: real("brier_score"),
  calibrationBucket: text("calibration_bucket"),
}, (t) => ({
  asOfIdx: index("snapshots_as_of_idx").on(t.asOf),
  sessionIdx: index("snapshots_session_idx").on(t.sessionId),
  regimeIdx: index("snapshots_regime_idx").on(t.regime),
}));

export const providerHealth = sqliteTable("provider_health", {
  id: text("id").primaryKey(),
  provider: text("provider").notNull(),
  status: text("status").notNull(),
  reconnectAttempt: integer("reconnect_attempt").notNull().default(0),
  lastConnectedAt: integer("last_connected_at"),
  lastMessageAt: integer("last_message_at"),
  lastEventAt: integer("last_event_at"),
  lastErrorAt: integer("last_error_at"),
  lastErrorClass: text("last_error_class"),
  freshness: text("freshness").notNull().default("unavailable"),
  circuitState: text("circuit_state").notNull().default("closed"),
  circuitOpenedAt: integer("circuit_opened_at"),
  circuitNextRetryAt: integer("circuit_next_retry_at"),
  consecutiveFailures: integer("consecutive_failures").notNull().default(0),
  updatedAt: integer("updated_at").notNull().default(nowMs),
}, (t) => ({
  providerIdx: uniqueIndex("provider_health_provider_idx").on(t.provider),
  circuitIdx: index("provider_health_circuit_idx").on(t.circuitState),
}));

export const outboxEvents = sqliteTable("outbox_events", {
  id: text("id").primaryKey(),
  aggregateType: text("aggregate_type").notNull(),
  aggregateId: text("aggregate_id").notNull(),
  eventType: text("event_type").notNull(),
  payload: text("payload").notNull(),
  status: text("status").notNull().default("pending"),
  attempt: integer("attempt").notNull().default(0),
  lastError: text("last_error"),
  createdAt: integer("created_at").notNull().default(nowMs),
  publishedAt: integer("published_at"),
  scheduledFor: integer("scheduled_for"),
}, (t) => ({
  statusIdx: index("outbox_events_status_idx").on(t.status),
  aggregateIdx: index("outbox_events_aggregate_idx").on(t.aggregateType, t.aggregateId),
  scheduledForIdx: index("outbox_events_scheduled_for_idx").on(t.scheduledFor),
}));

export const memoryRecords = sqliteTable("memory_records", {
  id: text("id").primaryKey(),
  kind: text("kind").notNull(),
  symbol: text("symbol"),
  subject: text("subject").notNull(),
  body: text("body").notNull(),
  provenance: text("provenance").notNull(),
  confidence: real("confidence").notNull(),
  freshness: integer("freshness").notNull().default(nowMs),
  status: text("status").notNull().default("active"),
  tags: text("tags").notNull().default("[]"),
  falsifiability: text("falsifiability"),
  invalidationConditions: text("invalidation_conditions"),
  trigger: text("trigger"),
  action: text("action"),
  createdAt: integer("created_at").notNull().default(nowMs),
  updatedAt: integer("updated_at").notNull().default(nowMs),
}, (t) => ({
  kindIdx: index("memory_records_kind_idx").on(t.kind),
  symbolIdx: index("memory_records_symbol_idx").on(t.symbol),
  statusIdx: index("memory_records_status_idx").on(t.status),
  freshnessIdx: index("memory_records_freshness_idx").on(t.freshness),
}));

export const forecasts = sqliteTable("forecasts", {
  id: text("id").primaryKey(),
  sessionId: text("session_id").notNull(),
  snapshotId: text("snapshot_id").notNull(),
  symbol: text("symbol").notNull(),
  horizonDays: integer("horizon_days").notNull(),
  forecast: text("forecast").notNull(),
  actual: text("actual"),
  brier: real("brier"),
  hidden: integer("hidden").notNull().default(0),
  createdAt: integer("created_at").notNull().default(nowMs),
  resolvedAt: integer("resolved_at"),
}, (t) => ({
  sessionIdx: index("forecasts_session_idx").on(t.sessionId),
  symbolIdx: index("forecasts_symbol_idx").on(t.symbol),
  hiddenIdx: index("forecasts_hidden_idx").on(t.hidden),
  horizonIdx: index("forecasts_horizon_idx").on(t.horizonDays),
}));

export const calibrationRuns = sqliteTable("calibration_runs", {
  id: text("id").primaryKey(),
  runAt: integer("run_at").notNull().default(nowMs),
  policyVersion: text("policy_version").notNull(),
  scope: text("scope").notNull(),
  sampleSize: integer("sample_size").notNull(),
  metrics: text("metrics").notNull(),
  hiddenHoldout: integer("hidden_holdout").notNull().default(0),
  promotion: text("promotion").default("neutral"),
  notes: text("notes"),
}, (t) => ({
  runAtIdx: index("calibration_runs_run_at_idx").on(t.runAt),
  scopeIdx: index("calibration_runs_scope_idx").on(t.scope),
}));

export const AUDIT_EVENT_TYPES = [
  "refresh.start", "refresh.complete", "refresh.fail",
  "provider.connect", "provider.disconnect", "provider.circuit.open", "provider.circuit.close",
  "outbox.publish", "outbox.fail",
  "snapshot.publish",
  "evidence.create", "evidence.promote", "evidence.retire",
  "calibration.run", "calibration.promote", "calibration.demote",
  "user.note", "user.review",
] as const;
export type AuditEventType = typeof AUDIT_EVENT_TYPES[number];

export const auditEvents = sqliteTable("audit_events", {
  id: text("id").primaryKey(),
  eventType: text("event_type").notNull().$type<AuditEventType>(),
  occurredAt: integer("occurred_at").notNull().default(nowMs),
  actor: text("actor").notNull().default("zobiris"),
  sessionId: text("session_id"),
  symbol: text("symbol"),
  payload: text("payload").notNull().default("{}"),
}, (t) => ({
  typeIdx: index("audit_events_type_idx").on(t.eventType),
  occurredAtIdx: index("audit_events_occurred_at_idx").on(t.occurredAt),
  sessionIdx: index("audit_events_session_idx").on(t.sessionId),
}));

export type CanonicalAssetRow = typeof canonicalAssets.$inferSelect;
export type ObservationRow = typeof observations.$inferSelect;
export type EvidenceClaimRow = typeof evidenceClaims.$inferSelect;
export type RefreshSessionRow = typeof refreshSessions.$inferSelect;
export type SnapshotRow = typeof snapshots.$inferSelect;
export type ProviderHealthRow = typeof providerHealth.$inferSelect;
export type OutboxEventRow = typeof outboxEvents.$inferSelect;
export type MemoryRecordRow = typeof memoryRecords.$inferSelect;
export type ForecastRow = typeof forecasts.$inferSelect;
export type CalibrationRunRow = typeof calibrationRuns.$inferSelect;
export type AuditEventRow = typeof auditEvents.$inferSelect;
