/**
 * Storage integration — bridges the in-memory `runRefresh` to the persistent
 * storage layer. The runtime still does the orchestration; this module
 * persists everything atomically through the outbox.
 *
 * The contract:
 *   - one storage transaction per refresh stage that mutates data
 *   - every snapshot publishes an outbox event for downstream consumers
 *   - every provider attempt updates provider_health (with circuit breaker)
 *   - all state changes append to the audit log (allowlisted)
 */
import { randomUUID } from "node:crypto";
import { eq } from "drizzle-orm";
import type { DB } from "./client.js";
import {
  ingestObservation,
  insertEvidenceClaim,
  openSession,
  appendSessionStage,
  closeSession,
  insertSnapshot,
  upsertProviderHealth,
  enqueueOutbox,
  emitAudit,
  syncWatchlist,
  getCanonicalBySymbol,
  markOutboxPublished,
  markOutboxFailed,
  jget,
  type ObservationInput,
  type EvidenceClaimInput,
} from "./repository.js";
import { outboxEvents, canonicalAssets } from "./schema.js";
import { upsertCanonicalFromWatchlist } from "../providers/identity.js";
import type {
  NormalizedObservation,
  EvidenceClaim,
  PortfolioAnalysisSnapshot,
  CanonicalAsset,
  ProviderHealth,
} from "../domain/index.js";

/** Returns from persistRefresh. */
export interface PersistRefreshResult {
  sessionId: string;
  observationCount: number;
  evidenceClaimCount: number;
  snapshotId: string;
  outboxIds: string[];
  added: string[];
  removed: string[];
  reactivated: string[];
}

/** Options for fault injection (used by the audit regression tests). */
export interface PersistRefreshOptions {
  /** When set, the matching after-step will throw to simulate a crash. */
  failAfter?: "syncWatchlist" | "canonical" | "providerHealth" | "openSession" | "observations" | "evidence" | "snapshot" | "outbox" | "stages" | "closeSession" | "audit";
}

export interface PersistedRefreshInput {
  db: DB;
  /** Runtime session id; keeps HTTP/runtime/storage evidence under one id. */
  sessionId?: string;
  watchlist: { symbol: string; name: string }[];
  observations: NormalizedObservation[];
  evidenceClaims: EvidenceClaim[];
  snapshot: PortfolioAnalysisSnapshot;
  canonicalMap: Map<string, CanonicalAsset>;
  providerHealthUpdates?: Array<{ provider: string; status: ProviderHealth["status"]; freshness: ProviderHealth["freshness"]; success: boolean; lastErrorClass?: string; lastErrorAt?: number }>;
  sessionMode?: "deep" | "delta" | "backfill";
  stages?: Array<{ index: number; name: string; status: string; notes?: string }>;
  options?: PersistRefreshOptions;
}



/**
 * Persist an entire refresh run in one storage transaction.
 *
 * Per the v0.4.1 audit (P0 #3), the entire durable mutation phase is now
 * wrapped in a single `db.transaction(...)` call. If any step throws, the
 * transaction rolls back and *no* rows from this refresh are committed.
 *
 * The external outbox publisher (`drainOutbox`) is intentionally OUTSIDE the
 * transaction — it only sees rows that have been committed.
 *
 * Order of operations (atomic):
 *   1. Sync watchlist (idempotent + marks removals)
 *   2. Upsert canonical assets
 *   3. Update provider health (with circuit breaker)
 *   4. Open session row
 *   5. Ingest observations (idempotent by key)
 *   6. Insert evidence claims
 *   7. Insert snapshot
 *   8. Enqueue outbox events for snapshot publication
 *   9. Append session stage telemetry
 *  10. Close session
 *  11. Emit audit events
 */
export function persistRefresh(input: PersistedRefreshInput): PersistRefreshResult {
  const { db, watchlist, observations: obs, evidenceClaims, snapshot, canonicalMap } = input;
  const mode = input.sessionMode ?? "deep";
  const opts = input.options ?? {};

  // Pre-compute everything we need OUTSIDE the transaction so the
  // transaction body is a single closure passed to db.transaction.
  const sessionId = input.sessionId ?? (snapshot.rankedAssets.length > 0
    ? `sess-${Date.now()}-${randomUUID().slice(0, 8)}`
    : `sess-${randomUUID()}`);
  const policyVersion = snapshot.policyVersion;
  const watchlistEntries = watchlist.map((w, i) => ({ symbol: w.symbol, name: w.name, rank: i + 1, source: "cmc" }));

  // Wrap the entire mutation phase in one real DB transaction. better-sqlite3
  // (and the Drizzle wrapper) commit on return and roll back on throw.
  let result: PersistRefreshResult;
  try {
    result = db.transaction((tx) => {
      // 1. Watchlist sync (handles adds + removals)
      const syncResult = syncWatchlist(tx, watchlistEntries);
      if (opts.failAfter === "syncWatchlist") {
        throw new Error("FAULT_INJECTION: after syncWatchlist");
      }

      // 2. Canonical assets
      for (const ca of canonicalMap.values()) {
        upsertCanonicalFromWatchlist(tx, ca);
      }
      if (opts.failAfter === "canonical") {
        throw new Error("FAULT_INJECTION: after canonical upserts");
      }

      // 3. Provider health
      for (const u of input.providerHealthUpdates ?? []) {
        upsertProviderHealth(tx, {
          provider: u.provider,
          status: u.status,
          freshness: u.freshness,
          onSuccess: u.success,
          lastErrorAt: u.lastErrorAt,
          lastErrorClass: u.lastErrorClass,
        });
      }
      if (opts.failAfter === "providerHealth") {
        throw new Error("FAULT_INJECTION: after providerHealth");
      }

      // 4. Open session
      openSession(tx, {
        id: sessionId,
        mode,
        policyVersion,
        pointInTimeCutoff: new Date(snapshot.asOf).getTime(),
        specialistRoster: ["verifier", "challenger", "synthesizer"],
      });
      emitAudit(tx, { eventType: "refresh.start", sessionId });
      if (opts.failAfter === "openSession") {
        throw new Error("FAULT_INJECTION: after openSession");
      }

      // 5. Observations
      // v0.4.2 audit fix (P0 BLOCKER 2): the normalized observation's
      // canonicalAssetId is now the stable canonical id (cn-... or
      // uuid). The sym: pseudo-id model is gone. We persist that id
      // directly. If it doesn't resolve to a registered canonical row,
      // we still persist the id (so the evidence chain survives) and
      // mark the observation quarantined.
      let obsIngested = 0;
      for (const o of obs) {
        const candidateId = o.canonicalAssetId && o.canonicalAssetId !== "n/a" ? o.canonicalAssetId : null;
        let canonicalId: string | null = null;
        let quarantineState: "verified" | "ambiguous" | "unmapped" | "quarantined" =
          (o.quarantineState ?? "verified") as "verified" | "ambiguous" | "unmapped" | "quarantined";
        // v0.4.4 audit fix: track the original identity match method so
        // rehydration preserves provenance. The audit caught that the
        // server reconstructs observations with quarantineState hard-
        // coded to "verified"; that path now reads both fields.
        let identityMatchMethod: string | null = o.identityMatchMethod ?? null;
        if (candidateId) {
          // Try to look up the canonical row by id first (most specific).
          const ca = tx
            .select()
            .from(canonicalAssets)
            .where(eq(canonicalAssets.id, candidateId))
            .get();
          if (ca) {
            canonicalId = ca.id;
          } else {
            // Fallback: lookup by symbol if the normalizer emitted a
            // non-canonical id (legacy/edge case). v0.4.4 audit fix:
            // a persistence-time symbol fallback is never authoritative.
            // Mark the observation ambiguous and the match method
            // "persistence-symbol-fallback" so downstream consumers
            // can see the provenance.
            const payload = o.payload as Record<string, unknown> | undefined;
            const sym = typeof payload?.["symbol"] === "string" ? (payload["symbol"] as string) : undefined;
            if (sym) {
              const bySym = getCanonicalBySymbol(tx, sym);
              canonicalId = bySym?.id ?? candidateId;
              quarantineState = "ambiguous";
              identityMatchMethod = "persistence-symbol-fallback";
            } else {
              canonicalId = candidateId;
              quarantineState = "quarantined";
            }
          }
        }
        const obsInput: ObservationInput = {
          id: o.id,
          idempotencyKey: o.idempotencyKey,
          provider: o.provider,
          providerEventId: o.providerEventId,
          eventType: o.eventType,
          schemaVersion: o.schemaVersion,
          canonicalAssetId: canonicalId,
          quarantineState,
          identityMatchMethod,
          dataMode: o.dataMode,
          providerEndpoint: o.providerEndpoint,
          requestedSymbol: o.requestedSymbol,
          requestedExchange: o.requestedExchange,
          providerGeneratedAt: o.providerGeneratedAt ? new Date(o.providerGeneratedAt).getTime() : null,
          fallbackReason: o.fallbackReason,
          upstreamFailure: o.upstreamFailure,
          payloadHash: o.payloadHash,
          sourceTimestamp: o.sourceTimestamp ? new Date(o.sourceTimestamp).getTime() : null,
          occurredAt: new Date(o.occurredAt).getTime(),
          receivedAt: new Date(o.receivedAt).getTime(),
          payload: o.payload,
          epistemicState: o.epistemicState,
          evidenceConfidence: o.evidenceConfidence,
          licenseClass: o.licenseClass,
          raw: undefined,
          normalizerVersion: o.normalizerVersion,
          sessionId,
        };
        const r = ingestObservation(tx, obsInput);
        if (r.inserted) obsIngested++;
      }
      if (opts.failAfter === "observations") {
        throw new Error("FAULT_INJECTION: after observations");
      }

      // 6. Evidence claims
      // v0.4.2 audit fix (P0/P1): evidence claims now reference the
      // original observation directly (no synthetic surrogate). The
      // only legitimate use of a synthetic observation is for
      // genuinely model-derived claims (e.g. an analyst note) that
      // did not originate from a provider event. Those carry
      // observationId === undefined AND factorFamily === "model" or
      // are explicitly marked.
      let claimCount = 0;
      for (const c of evidenceClaims) {
        if (c.claimOrigin === "model" && c.parentClaimIds.length === 0) {
          throw new Error(`Model-derived evidence claim ${c.id} must cite at least one parentClaimId.`);
        }
        let observationId = c.observationId;
        if (!observationId) {
          // v0.4.4 audit fix: typed provenance, NOT string-prefix
          // detection. A claim is "synthetic" iff claimOrigin ===
          // "synthetic" or "model". The old `claim.startsWith("synthetic:")`
          // check is removed.
          if (c.factorFamily !== "model" && c.claimOrigin !== "synthetic" && c.claimOrigin !== "model") {
            throw new Error(
              `Provider-derived evidence claim ${c.id} (source=${c.source}, ` +
                `family=${c.factorFamily}, origin=${c.claimOrigin}) has no ` +
                `observationId. Every provider-derived claim must reference the ` +
                `original observation.`,
            );
          }
          const syntheticKey = `synthetic:${c.id}`;
          const synthResult = ingestObservation(tx, {
            idempotencyKey: syntheticKey,
            provider: c.source.split(" ")[0] ?? "synthetic",
            eventType: "synthetic",
            schemaVersion: "1.0.0",
            canonicalAssetId: null,
            quarantineState: "unmapped",
            sourceTimestamp: new Date(c.observedAt).getTime(),
            occurredAt: new Date(c.observedAt).getTime(),
            payload: { claim: c.claim.slice(0, 200) },
            epistemicState: (c.epistemicState as "KNOWN" | "INFERRED" | "UNCERTAIN" | "CONFLICTED" | "UNKNOWN" | "STALE"),
            evidenceConfidence: c.evidenceConfidence,
            licenseClass: c.licenseClass,
            normalizerVersion: "0.1.0",
            sessionId,
          });
          observationId = synthResult.id;
        }
        const claimInput: EvidenceClaimInput = {
          id: c.id,
          observationId,
          symbol: c.symbol,
          factorFamily: c.factorFamily,
          claim: c.claim,
          source: c.source,
          observedAt: new Date(c.observedAt).getTime(),
          receivedAt: new Date(c.receivedAt).getTime(),
          freshnessAgeSeconds: c.freshnessAgeSeconds,
          epistemicState: c.epistemicState,
          evidenceConfidence: c.evidenceConfidence,
          licenseClass: c.licenseClass,
          providerIds: c.providerIds,
          claimOrigin: c.claimOrigin,
          freshness: c.freshness,
          dataMode: c.dataMode,
          payloadHash: c.payloadHash,
          transformationVersion: c.transformationVersion,
          providerEndpoint: c.providerEndpoint,
          modelProvider: c.modelProvider,
          modelVersion: c.modelVersion,
          parentClaimIds: c.parentClaimIds,
        };
        insertEvidenceClaim(tx, claimInput);
        claimCount++;
      }
      if (opts.failAfter === "evidence") {
        throw new Error("FAULT_INJECTION: after evidence");
      }

      // 7. Snapshot
      const snapshotId = insertSnapshot(tx, {
        sessionId,
        asOf: new Date(snapshot.asOf).getTime(),
        policyVersion: snapshot.policyVersion,
        regime: snapshot.regime,
        regimeConfidence: snapshot.regimeConfidence,
        totalAllocatedPct: snapshot.totalAllocatedPct,
        reservePct: snapshot.reservePct,
        unallocatedPct: snapshot.unallocatedPct,
        rankedAssets: snapshot.rankedAssets,
        sectorConcentration: snapshot.sectorConcentration,
        narrativeConcentration: snapshot.narrativeConcentration,
        topRiskGates: snapshot.topRiskGates,
        changesSinceLastRefresh: snapshot.changesSinceLastRefresh,
        conclusion: snapshot.conclusion,
      });
      if (opts.failAfter === "snapshot") {
        throw new Error("FAULT_INJECTION: after snapshot");
      }

      // 8. Outbox (committed atomically with the snapshot)
      const outboxIds: string[] = [];
      outboxIds.push(enqueueOutbox(tx, {
        aggregateType: "snapshot",
        aggregateId: snapshotId,
        eventType: "snapshot.published",
        payload: {
          asOf: snapshot.asOf,
          regime: snapshot.regime,
          totalAllocatedPct: snapshot.totalAllocatedPct,
          rankedCount: snapshot.rankedAssets.length,
        },
      }));
      if (opts.failAfter === "outbox") {
        throw new Error("FAULT_INJECTION: after outbox");
      }

      // 9. Session stages
      const stageList = input.stages && input.stages.length > 0 ? input.stages : (snapshot.stages ?? []);
      for (const st of stageList) {
        appendSessionStage(tx, sessionId, { index: st.index, name: st.name, status: st.status, notes: st.notes });
      }
      if (opts.failAfter === "stages") {
        throw new Error("FAULT_INJECTION: after stages");
      }

      // 10. Close session
      closeSession(tx, sessionId, {
        status: "complete",
        verifierOutput: undefined,
        challengerOutput: undefined,
        synthesizerOutput: undefined,
        conclusion: snapshot.conclusion,
        observationCount: obsIngested,
        evidenceClaimCount: claimCount,
      });
      if (opts.failAfter === "closeSession") {
        throw new Error("FAULT_INJECTION: after closeSession");
      }

      // 11. Audit
      emitAudit(tx, { eventType: "refresh.complete", sessionId, payload: { snapshotId } });
      emitAudit(tx, { eventType: "snapshot.publish", sessionId, payload: { regime: snapshot.regime } });
      if (opts.failAfter === "audit") {
        throw new Error("FAULT_INJECTION: after audit");
      }

      return {
        sessionId,
        observationCount: obsIngested,
        evidenceClaimCount: claimCount,
        snapshotId,
        outboxIds,
        added: syncResult.added,
        removed: syncResult.removed,
        reactivated: syncResult.reactivated,
      };
    });
  } catch (e) {
    throw new Error(
      `persistRefresh failed (sessionId=${sessionId}, failAfter=${opts.failAfter ?? "none"}): ${(e as Error).message}`,
    );
  }

  return result;
}


export function drainOutbox(db: DB, opts: { publish?: (event: { aggregateType: string; aggregateId: string; eventType: string; payload: unknown }) => Promise<void> | void; limit?: number } = {}): { published: number; failed: number } {
  const list = db.select().from(outboxEvents)
    .where(eq(outboxEvents.status, "pending"))
    .limit(opts.limit ?? 100)
    .all();
  let published = 0;
  let failed = 0;
  for (const ev of list) {
    try {
      if (opts.publish) {
        opts.publish({
          aggregateType: ev.aggregateType,
          aggregateId: ev.aggregateId,
          eventType: ev.eventType,
          payload: jget(ev.payload, null),
        });
      }
      markOutboxPublished(db, ev.id);
      published++;
    } catch (e) {
      markOutboxFailed(db, ev.id, String((e as Error).message ?? e));
      failed++;
    }
  }
  return { published, failed };
}
