/**
 * Storage client — better-sqlite3 (local) + Drizzle ORM.
 *
 * Single source of truth for the database connection. Tests use an in-memory
 * ":memory:" database; the CLI uses a file at ZOBIRIS_DB_PATH (default ./zobiris.db).
 *
 * The schema is the same Drizzle types we use in production; switching to
 * PostgreSQL is a `pg-core` schema swap and a connection-string change.
 */
import Database from "better-sqlite3";
import { drizzle } from "drizzle-orm/better-sqlite3";
import * as schema from "./schema.js";
import { mkdirSync } from "node:fs";
import { dirname, resolve } from "node:path";

export type DB = ReturnType<typeof drizzle<typeof schema>>;

export interface StorageOptions {
  /** File path; default "./zobiris.db". Use ":memory:" for in-memory (tests). */
  path?: string;
  /** If true, run migrations on connect (default true). */
  migrate?: boolean;
}

export function openStorage(opts: StorageOptions = {}): { db: DB; sqlite: Database.Database; close: () => void } {
  const path = opts.path ?? process.env.ZOBIRIS_DB_PATH ?? "./zobiris.db";
  if (path !== ":memory:") {
    mkdirSync(dirname(resolve(path)), { recursive: true });
  }
  const sqlite = new Database(path);
  sqlite.pragma("journal_mode = WAL");
  sqlite.pragma("foreign_keys = ON");
  sqlite.pragma("synchronous = NORMAL");
  const db = drizzle(sqlite, { schema });
  if (opts.migrate !== false) {
    runMigrations(sqlite);
  }
  return {
    db,
    sqlite,
    close: () => sqlite.close(),
  };
}

/**
 * Embedded migration runner — same SQL as `drizzle-kit generate` would emit.
 * Idempotent: `CREATE TABLE IF NOT EXISTS`, `CREATE INDEX IF NOT EXISTS`.
 */
export function runMigrations(sqlite: Database.Database): void {
  sqlite.exec(SCHEMA_SQL);
  // v0.4.13: the Solana/BNB address-investigation product surface was
  // intentionally removed. Drop its obsolete persistence structure so an
  // upgraded database exposes only the watchlist-driven analysis model.
  sqlite.exec("DROP TABLE IF EXISTS asset_investigations");
  // v0.4.4 audit fix: ALTER for existing DBs that don't have the
  // new column yet. SQLite's ALTER TABLE is limited; we use
  // a defensive `try { ... } catch` to skip when the column exists.
  try {
    sqlite.exec("ALTER TABLE observations ADD COLUMN identity_match_method TEXT");
  } catch {
    // Column already exists; ignore.
  }
  for (const col of [
    "data_mode TEXT NOT NULL DEFAULT 'live'",
    "provider_endpoint TEXT",
    "requested_symbol TEXT",
    "requested_exchange TEXT",
    "provider_generated_at INTEGER",
    "fallback_reason TEXT",
    "upstream_failure TEXT",
    "payload_hash TEXT",
  ]) {
    try {
      sqlite.exec(`ALTER TABLE observations ADD COLUMN ${col}`);
    } catch {
      // Column already exists; ignore.
    }
  }
  try {
    sqlite.exec("ALTER TABLE canonical_assets ADD COLUMN identity_provenance TEXT");
  } catch {
    // Column already exists; ignore.
  }
  // v0.4.4 audit fix: idempotent ALTERs for evidence_claims columns.
  for (const col of [
    "claim_origin TEXT NOT NULL DEFAULT 'provider'",
    "freshness TEXT NOT NULL DEFAULT 'live'",
    "data_mode TEXT NOT NULL DEFAULT 'live'",
    "payload_hash TEXT",
    "transformation_version TEXT NOT NULL DEFAULT '0.0.0'",
    "provider_endpoint TEXT",
    "model_provider TEXT",
    "model_version TEXT",
    "parent_claim_ids TEXT NOT NULL DEFAULT '[]'",
  ]) {
    try {
      sqlite.exec(`ALTER TABLE evidence_claims ADD COLUMN ${col}`);
    } catch {
      // Column already exists; ignore.
    }
  }
}

const SCHEMA_SQL = `
CREATE TABLE IF NOT EXISTS canonical_assets (
  id TEXT PRIMARY KEY,
  symbol TEXT NOT NULL,
  name TEXT NOT NULL,
  chain_id TEXT,
  contract_address TEXT,
  sector TEXT,
  mapping_status TEXT NOT NULL,
  mapping_confidence REAL NOT NULL DEFAULT 0,
  provider_ids TEXT NOT NULL DEFAULT '{}',
  /* v0.4.4 audit fix (P0-7): identity_provenance records the
     strongest identity key known at the time of creation. The
     canonicalAssetId is the IMMUTABLE primary key. If stronger
     identity is later discovered, it is appended to
     canonical_asset_aliases — the id never changes. */
  identity_provenance TEXT,
  created_at INTEGER NOT NULL DEFAULT (unixepoch() * 1000),
  updated_at INTEGER NOT NULL DEFAULT (unixepoch() * 1000)
);
CREATE INDEX IF NOT EXISTS canonical_assets_symbol_idx ON canonical_assets(symbol);
CREATE INDEX IF NOT EXISTS canonical_assets_mapping_idx ON canonical_assets(mapping_status);

CREATE TABLE IF NOT EXISTS canonical_asset_aliases (
  id TEXT PRIMARY KEY,
  canonical_asset_id TEXT NOT NULL,
  alias_kind TEXT NOT NULL,
  alias_value TEXT NOT NULL,
  confidence REAL NOT NULL DEFAULT 0.5,
  source TEXT NOT NULL DEFAULT 'unknown',
  created_at INTEGER NOT NULL DEFAULT (unixepoch() * 1000),
  superseded INTEGER NOT NULL DEFAULT 0,
  superseded_at INTEGER
);
CREATE INDEX IF NOT EXISTS canonical_aliases_asset_idx ON canonical_asset_aliases(canonical_asset_id);
CREATE UNIQUE INDEX IF NOT EXISTS canonical_aliases_alias_idx ON canonical_asset_aliases(alias_kind, alias_value);

CREATE TABLE IF NOT EXISTS identity_merge_history (
  id TEXT PRIMARY KEY,
  survivor_canonical_asset_id TEXT NOT NULL,
  input_alias_kind TEXT NOT NULL,
  input_alias_value TEXT NOT NULL,
  action TEXT NOT NULL,
  notes TEXT,
  occurred_at INTEGER NOT NULL DEFAULT (unixepoch() * 1000)
);
CREATE INDEX IF NOT EXISTS identity_merge_history_survivor_idx ON identity_merge_history(survivor_canonical_asset_id);
CREATE INDEX IF NOT EXISTS identity_merge_history_occurred_at_idx ON identity_merge_history(occurred_at);

CREATE TABLE IF NOT EXISTS watchlist (
  id TEXT PRIMARY KEY,
  symbol TEXT NOT NULL,
  name TEXT NOT NULL,
  cmc_watchlist_id TEXT DEFAULT '69c01b46aed37c7160053535',
  rank INTEGER NOT NULL,
  added_at INTEGER NOT NULL DEFAULT (unixepoch() * 1000),
  removed_at INTEGER,
  source TEXT NOT NULL DEFAULT 'cmc'
);
CREATE UNIQUE INDEX IF NOT EXISTS watchlist_symbol_idx ON watchlist(symbol);
CREATE INDEX IF NOT EXISTS watchlist_active_idx ON watchlist(removed_at);

CREATE TABLE IF NOT EXISTS observations (
  id TEXT PRIMARY KEY,
  idempotency_key TEXT NOT NULL,
  provider TEXT NOT NULL,
  provider_event_id TEXT,
  event_type TEXT NOT NULL,
  schema_version TEXT NOT NULL,
  canonical_asset_id TEXT,
  quarantine_state TEXT NOT NULL DEFAULT 'verified',
  /* v0.4.4 audit fix: persist the identity match method so rehydration
     does not lose provenance. The audit caught a hard-coded
     quarantine_state='verified' in the server's reconstruction
     path; that path now reads both fields from the row. */
  identity_match_method TEXT,
  data_mode TEXT NOT NULL DEFAULT 'live',
  provider_endpoint TEXT,
  requested_symbol TEXT,
  requested_exchange TEXT,
  provider_generated_at INTEGER,
  fallback_reason TEXT,
  upstream_failure TEXT,
  payload_hash TEXT,
  source_timestamp INTEGER,
  occurred_at INTEGER NOT NULL,
  received_at INTEGER NOT NULL DEFAULT (unixepoch() * 1000),
  payload TEXT NOT NULL,
  epistemic_state TEXT NOT NULL DEFAULT 'UNKNOWN',
  evidence_confidence REAL NOT NULL DEFAULT 0,
  license_class TEXT NOT NULL DEFAULT 'display-only',
  raw TEXT,
  normalizer_version TEXT NOT NULL,
  session_id TEXT
);
CREATE UNIQUE INDEX IF NOT EXISTS observations_idemp_idx ON observations(idempotency_key);
CREATE INDEX IF NOT EXISTS observations_provider_idx ON observations(provider, event_type);
CREATE INDEX IF NOT EXISTS observations_canonical_idx ON observations(canonical_asset_id);
CREATE INDEX IF NOT EXISTS observations_received_at_idx ON observations(received_at);

CREATE TABLE IF NOT EXISTS evidence_claims (
  id TEXT PRIMARY KEY,
  observation_id TEXT NOT NULL,
  symbol TEXT NOT NULL,
  factor_family TEXT NOT NULL,
  claim TEXT NOT NULL,
  source TEXT NOT NULL,
  observed_at INTEGER NOT NULL,
  received_at INTEGER NOT NULL DEFAULT (unixepoch() * 1000),
  freshness_age_seconds INTEGER NOT NULL DEFAULT 0,
  epistemic_state TEXT NOT NULL,
  evidence_confidence REAL NOT NULL,
  license_class TEXT NOT NULL DEFAULT 'display-only',
  provider_ids TEXT NOT NULL DEFAULT '[]',
  memory_ids TEXT NOT NULL DEFAULT '[]',
  /* v0.4.4 audit fix: typed provenance, freshness, dataMode, etc. */
  claim_origin TEXT NOT NULL DEFAULT 'provider',
  freshness TEXT NOT NULL DEFAULT 'live',
  data_mode TEXT NOT NULL DEFAULT 'live',
  payload_hash TEXT,
  transformation_version TEXT NOT NULL DEFAULT '0.0.0',
  provider_endpoint TEXT,
  model_provider TEXT,
  model_version TEXT,
  parent_claim_ids TEXT NOT NULL DEFAULT '[]'
);
CREATE INDEX IF NOT EXISTS evidence_claims_symbol_idx ON evidence_claims(symbol);
CREATE INDEX IF NOT EXISTS evidence_claims_family_idx ON evidence_claims(factor_family);
CREATE INDEX IF NOT EXISTS evidence_claims_received_at_idx ON evidence_claims(received_at);
CREATE INDEX IF NOT EXISTS evidence_claims_claim_origin_idx ON evidence_claims(claim_origin);

CREATE TABLE IF NOT EXISTS refresh_sessions (
  id TEXT PRIMARY KEY,
  mode TEXT NOT NULL DEFAULT 'deep',
  status TEXT NOT NULL DEFAULT 'open',
  started_at INTEGER NOT NULL DEFAULT (unixepoch() * 1000),
  completed_at INTEGER,
  point_in_time_cutoff INTEGER,
  policy_version TEXT NOT NULL,
  specialist_roster TEXT NOT NULL DEFAULT '[]',
  stages TEXT NOT NULL DEFAULT '[]',
  verifier_output TEXT,
  challenger_output TEXT,
  synthesizer_output TEXT,
  conclusion TEXT,
  observation_count INTEGER NOT NULL DEFAULT 0,
  evidence_claim_count INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS refresh_sessions_started_at_idx ON refresh_sessions(started_at);
CREATE INDEX IF NOT EXISTS refresh_sessions_status_idx ON refresh_sessions(status);

CREATE TABLE IF NOT EXISTS snapshots (
  id TEXT PRIMARY KEY,
  session_id TEXT NOT NULL,
  as_of INTEGER NOT NULL,
  policy_version TEXT NOT NULL,
  regime TEXT NOT NULL DEFAULT 'UNKNOWN',
  regime_confidence REAL NOT NULL DEFAULT 0,
  total_allocated_pct REAL NOT NULL DEFAULT 0,
  reserve_pct REAL NOT NULL DEFAULT 10,
  unallocated_pct REAL NOT NULL DEFAULT 0,
  ranked_assets TEXT NOT NULL,
  sector_concentration TEXT NOT NULL DEFAULT '{}',
  narrative_concentration TEXT NOT NULL DEFAULT '{}',
  top_risk_gates TEXT NOT NULL DEFAULT '[]',
  changes_since_last_refresh TEXT NOT NULL,
  conclusion TEXT NOT NULL DEFAULT '',
  brier_score REAL,
  calibration_bucket TEXT
);
CREATE INDEX IF NOT EXISTS snapshots_as_of_idx ON snapshots(as_of);
CREATE INDEX IF NOT EXISTS snapshots_session_idx ON snapshots(session_id);
CREATE INDEX IF NOT EXISTS snapshots_regime_idx ON snapshots(regime);

CREATE TABLE IF NOT EXISTS provider_health (
  id TEXT PRIMARY KEY,
  provider TEXT NOT NULL,
  status TEXT NOT NULL,
  reconnect_attempt INTEGER NOT NULL DEFAULT 0,
  last_connected_at INTEGER,
  last_message_at INTEGER,
  last_event_at INTEGER,
  last_error_at INTEGER,
  last_error_class TEXT,
  freshness TEXT NOT NULL DEFAULT 'unavailable',
  circuit_state TEXT NOT NULL DEFAULT 'closed',
  circuit_opened_at INTEGER,
  circuit_next_retry_at INTEGER,
  consecutive_failures INTEGER NOT NULL DEFAULT 0,
  updated_at INTEGER NOT NULL DEFAULT (unixepoch() * 1000)
);
CREATE UNIQUE INDEX IF NOT EXISTS provider_health_provider_idx ON provider_health(provider);
CREATE INDEX IF NOT EXISTS provider_health_circuit_idx ON provider_health(circuit_state);

CREATE TABLE IF NOT EXISTS outbox_events (
  id TEXT PRIMARY KEY,
  aggregate_type TEXT NOT NULL,
  aggregate_id TEXT NOT NULL,
  event_type TEXT NOT NULL,
  payload TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending',
  attempt INTEGER NOT NULL DEFAULT 0,
  last_error TEXT,
  created_at INTEGER NOT NULL DEFAULT (unixepoch() * 1000),
  published_at INTEGER,
  scheduled_for INTEGER
);
CREATE INDEX IF NOT EXISTS outbox_events_status_idx ON outbox_events(status);
CREATE INDEX IF NOT EXISTS outbox_events_aggregate_idx ON outbox_events(aggregate_type, aggregate_id);
CREATE INDEX IF NOT EXISTS outbox_events_scheduled_for_idx ON outbox_events(scheduled_for);

CREATE TABLE IF NOT EXISTS memory_records (
  id TEXT PRIMARY KEY,
  kind TEXT NOT NULL,
  symbol TEXT,
  subject TEXT NOT NULL,
  body TEXT NOT NULL,
  provenance TEXT NOT NULL,
  confidence REAL NOT NULL,
  freshness INTEGER NOT NULL DEFAULT (unixepoch() * 1000),
  status TEXT NOT NULL DEFAULT 'active',
  tags TEXT NOT NULL DEFAULT '[]',
  falsifiability TEXT,
  invalidation_conditions TEXT,
  trigger TEXT,
  action TEXT,
  created_at INTEGER NOT NULL DEFAULT (unixepoch() * 1000),
  updated_at INTEGER NOT NULL DEFAULT (unixepoch() * 1000)
);
CREATE INDEX IF NOT EXISTS memory_records_kind_idx ON memory_records(kind);
CREATE INDEX IF NOT EXISTS memory_records_symbol_idx ON memory_records(symbol);
CREATE INDEX IF NOT EXISTS memory_records_status_idx ON memory_records(status);
CREATE INDEX IF NOT EXISTS memory_records_freshness_idx ON memory_records(freshness);

CREATE TABLE IF NOT EXISTS forecasts (
  id TEXT PRIMARY KEY,
  session_id TEXT NOT NULL,
  snapshot_id TEXT NOT NULL,
  symbol TEXT NOT NULL,
  horizon_days INTEGER NOT NULL,
  forecast TEXT NOT NULL,
  actual TEXT,
  brier REAL,
  hidden INTEGER NOT NULL DEFAULT 0,
  created_at INTEGER NOT NULL DEFAULT (unixepoch() * 1000),
  resolved_at INTEGER
);
CREATE INDEX IF NOT EXISTS forecasts_session_idx ON forecasts(session_id);
CREATE INDEX IF NOT EXISTS forecasts_symbol_idx ON forecasts(symbol);
CREATE INDEX IF NOT EXISTS forecasts_hidden_idx ON forecasts(hidden);
CREATE INDEX IF NOT EXISTS forecasts_horizon_idx ON forecasts(horizon_days);

CREATE TABLE IF NOT EXISTS calibration_runs (
  id TEXT PRIMARY KEY,
  run_at INTEGER NOT NULL DEFAULT (unixepoch() * 1000),
  policy_version TEXT NOT NULL,
  scope TEXT NOT NULL,
  sample_size INTEGER NOT NULL,
  metrics TEXT NOT NULL,
  hidden_holdout INTEGER NOT NULL DEFAULT 0,
  promotion TEXT DEFAULT 'neutral',
  notes TEXT
);
CREATE INDEX IF NOT EXISTS calibration_runs_run_at_idx ON calibration_runs(run_at);
CREATE INDEX IF NOT EXISTS calibration_runs_scope_idx ON calibration_runs(scope);

CREATE TABLE IF NOT EXISTS audit_events (
  id TEXT PRIMARY KEY,
  event_type TEXT NOT NULL,
  occurred_at INTEGER NOT NULL DEFAULT (unixepoch() * 1000),
  actor TEXT NOT NULL DEFAULT 'zobiris',
  session_id TEXT,
  symbol TEXT,
  payload TEXT NOT NULL DEFAULT '{}'
);
CREATE INDEX IF NOT EXISTS audit_events_type_idx ON audit_events(event_type);
CREATE INDEX IF NOT EXISTS audit_events_occurred_at_idx ON audit_events(occurred_at);
CREATE INDEX IF NOT EXISTS audit_events_session_idx ON audit_events(session_id);
`;
