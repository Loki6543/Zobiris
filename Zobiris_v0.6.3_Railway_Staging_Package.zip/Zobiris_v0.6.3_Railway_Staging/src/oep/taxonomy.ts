/**
 * Iyaza Addendum — Item D: Observability & Evolution Plane (OEP) outcome taxonomy.
 *
 * Distinct failure classes are kept separate so that, e.g., a POLICY_BYPASSED
 * event is never aggregated with normal misfire statistics. Bypass events are
 * integrity violations and warrant their own dashboards and review queues.
 */
import { z } from "zod";

// --- Success ---
export const SUCCESS_OUTCOMES = ["SUCCESS", "SUCCESS_WITH_DEGRADATION"] as const;

// --- Quality ---
export const QUALITY_OUTCOMES = [
  "OUTPUT_MISMATCH",
  "FALLBACK_FIRED",
  "HUMAN_OVERRIDE",
  "CALIBRATION_ERROR",
  "RANKING_ERROR",
] as const;

// --- Integrity (bypass events — must never be merged with quality) ---
export const INTEGRITY_OUTCOMES = [
  "ORCHESTRATOR_BYPASSED",
  "POLICY_BYPASSED",
  "EVIDENCE_RECONCILER_BYPASSED",
  "RISK_GATE_BYPASSED",
  "VERIFICATION_BYPASSED",
  "IDENTITY_MAPPING_BYPASSED",
] as const;

// --- Operational ---
export const OPERATIONAL_OUTCOMES = [
  "TIMEOUT",
  "STALL",
  "PROVIDER_UNAVAILABLE",
  "AUTH_FAILURE",
  "RATE_LIMITED",
  "QUOTA_EXHAUSTED",
  "DEPENDENCY_FAILURE",
  "PERSISTENCE_FAILURE",
  "OUTBOX_FAILURE",
] as const;

// --- Knowledge ---
export const KNOWLEDGE_OUTCOMES = [
  "INSUFFICIENT_EVIDENCE",
  "STALE_EVIDENCE",
  "CONFLICTING_EVIDENCE",
  "UNKNOWN_IDENTITY",
  "TEMPORAL_LEAKAGE_BLOCKED",
] as const;

// --- Escalation ---
export const ESCALATION_OUTCOMES = ["ESCALATED", "UNKNOWN"] as const;

export const ALL_OEP_OUTCOMES = [
  ...SUCCESS_OUTCOMES,
  ...QUALITY_OUTCOMES,
  ...INTEGRITY_OUTCOMES,
  ...OPERATIONAL_OUTCOMES,
  ...KNOWLEDGE_OUTCOMES,
  ...ESCALATION_OUTCOMES,
] as const;
export type OepOutcome = (typeof ALL_OEP_OUTCOMES)[number];

export const OEP_SCOPES = [
  "success",
  "quality",
  "integrity",
  "operational",
  "knowledge",
  "escalation",
] as const;
export type OepScope = (typeof OEP_SCOPES)[number];

export const oepOutcomeSchema = z.enum(ALL_OEP_OUTCOMES);

export const oepScopeOf = (outcome: OepOutcome): OepScope => {
  if (SUCCESS_OUTCOMES.includes(outcome as any)) return "success";
  if (QUALITY_OUTCOMES.includes(outcome as any)) return "quality";
  if (INTEGRITY_OUTCOMES.includes(outcome as any)) return "integrity";
  if (OPERATIONAL_OUTCOMES.includes(outcome as any)) return "operational";
  if (KNOWLEDGE_OUTCOMES.includes(outcome as any)) return "knowledge";
  if (ESCALATION_OUTCOMES.includes(outcome as any)) return "escalation";
  return "escalation";
};

export const isIntegrityBypass = (outcome: OepOutcome): boolean => {
  return INTEGRITY_OUTCOMES.includes(outcome as any);
};

/**
 * Best-effort error classifier. Returns a likely OEP outcome from an error
 * message or error class name. This is heuristic; the producer of the
 * outcome should always be the authoritative source.
 */
export function classifyError(error: Error | string | null | undefined): OepOutcome {
  if (!error) return "UNKNOWN";
  const msg = (typeof error === "string" ? error : error.message ?? "").toLowerCase();
  const className = typeof error === "string" ? "" : error.constructor?.name ?? "";

  // Auth failures
  if (msg.includes("401") || msg.includes("403") || msg.includes("invalid api key") || msg.includes("unauthorized") || className === "AdapterAuthError") {
    return "AUTH_FAILURE";
  }
  // Rate limit / quota
  if (msg.includes("429") || msg.includes("rate limit") || msg.includes("quota")) {
    if (msg.includes("quota")) return "QUOTA_EXHAUSTED";
    return "RATE_LIMITED";
  }
  // Timeout / stall
  if (msg.includes("timeout") || msg.includes("timed out") || msg.includes("abort") || className === "TimeoutError" || className === "AbortError") {
    return "TIMEOUT";
  }
  // Provider unavailable
  if (msg.includes("econnrefused") || msg.includes("enotfound") || msg.includes("network down") || msg.includes("fetch failed")) {
    return "PROVIDER_UNAVAILABLE";
  }
  // Identity
  if (msg.includes("identity") || msg.includes("canonical") || msg.includes("unmapped")) {
    return "UNKNOWN_IDENTITY";
  }
  // Conflict
  if (msg.includes("conflict") || msg.includes("disagreement")) {
    return "CONFLICTING_EVIDENCE";
  }
  // Default
  return "UNKNOWN";
}
