# Railway staging preparation — September 7, 2026

Status: local release checks PASS; hosted release gate BLOCKED on Railway account/project access.

## Changes
- Added railway.json selecting the existing Dockerfile, one region with one replica, /api/health, and bounded restart attempts.
- Set the container SQLite default to /data/zobiris.sqlite.
- Excluded SQLite files and logs from Docker build context.
- Added RAILWAY_STAGING.md with the required volume, variables, runtime volume ownership setting, secrets handling, and hosted HTTP/security/persistence/browser gate.
- Updated STAGING.md to point to the approved Railway procedure.
- No src/ implementation changes, scoring changes, trading functionality, or Historical L2 work.

## Verification run
- Node v24.19.0
- TypeScript: PASS
- Vitest: 66 files, 460 tests PASS (includes UI component and real HTTP authorization tests)
- Strategy 2.1: 73 tests PASS
- Security primitives: 3 tests PASS
- Strategy integration: PASS
- No-trading static gate: PASS
- Production UI build: PASS
- Separate local staging HTTP probe: health plus six anonymous/wrong-token rejection checks PASS

Full outputs are in verification/railway-preflight/. Existing dependencies from the merged checkpoint were reused; npm ci and the Docker image build were not rerun. A fresh native dependency install must succeed in Railway before certification.

## Hosted evidence still missing
No Railway connector, CLI login, or Railway token is available in this workspace. No Railway deployment or billing action occurred. Docker is unavailable locally. Deployment URL, immutable hosted revision, build/startup logs, hosted HTTP tests, actual volume restart persistence, and rendered-browser desktop/mobile QA are all pending. Local component tests do not replace rendered-browser QA.

Historical L2 development remains paused. No claim of historical execution certification is made.

## Provenance
This is an isolated derivative of Zobiris_v0.6.3_Reconciled_Source with merged local baseline fixes already present. Older embedded reports/manifests describe their original checkpoints. RAILWAY_SOURCE_SHA256.txt is authoritative for the files in this package before that manifest was generated; it excludes itself. The ZIP checksum is supplied separately at creation.
