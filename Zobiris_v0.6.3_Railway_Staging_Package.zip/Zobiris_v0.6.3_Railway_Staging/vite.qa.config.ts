import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import { fileURLToPath, URL } from "node:url";

/** Single-bundle QA build used when cloud-browser loopback is unavailable. */
export default defineConfig({
  plugins: [react()],
  resolve: {
    alias: { "@": fileURLToPath(new URL("./src/ui", import.meta.url)) },
  },
  publicDir: false,
  build: {
    outDir: "/tmp/zobiris-v048-ui-qa",
    emptyOutDir: true,
    cssCodeSplit: false,
    rollupOptions: { output: { inlineDynamicImports: true } },
  },
});
